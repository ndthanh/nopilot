# Sources and notices

New backend, fixture, loader, controller, tests and support scripts are supplied under GPL-2.0-or-later; see `LICENSE`.

The QtWin Qt3 source archive is included under `sdk/vendor/qt3-source.7z`. It contains original source and component notices, including bundled PNG/zlib code. Qt GPL and QPL texts are also under `licenses/`. The Qt DLL used only by the fixture corresponds to this source plus the documented build-file patch in `sdk/patches/`.

The MinGW runtime `mingwm10.dll` is distributed with its original DISCLAIMER/README under `licenses/`. The compiler tools are not bundled; the SDK build recipe downloads pinned upstream distributions with their original notices. Windows system DLLs are not redistributed.

Frida is an external installed dependency. The tested Python package is 17.25.1. Its JavaScript API is documented at https://frida.re/docs/javascript-api/ . This package uses its normal module-loading/instrumentation APIs and contains no security-control bypass mechanism.

Cisco QtWebDriver revision `161780d3e816fc9dd52ad1af3933f0ecd77e05bd` is a design reference for guarded handles and stale references: https://github.com/cisco-open-source/qtwebdriver . No source from its server is compiled into this implementation.

The `sdk/` build recipe and small loader probe are carried forward from milestone 1 of this same project.
