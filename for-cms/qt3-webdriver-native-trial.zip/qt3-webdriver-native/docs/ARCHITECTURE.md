# Proposed Architecture

Native milestone update: the delivered implementation now uses Frida only for inventory/loading/C ABI transport, a native GUI dispatcher and guarded registry, Python locators, and an optional HTTP subset. See README.md, PORTING.md and docs/EXPERIMENTS.md. The milestone-1 description below is retained historical context.

Milestone 1 implementation (2026-11-03): the current lab uses a compiled-in Qt3 adapter and GUI-thread Qt sockets, with a Python WebDriver HTTP subset and lazy locator client. No Frida agent or production bridge is included. The broader architecture below remains design intent; see `../README.md` and `EXPERIMENTS.md` for what is implemented and tested.

```
Python / akabot orchestration
        |
Lazy locator + readiness / postcondition engine
        |
Object registry and lifecycle tracking
        |
Qt3-aware action adapter (prototype: authorized Frida test agent)
        |
ITC.exe / qt-mt.dll (or self-controlled Qt3 test simulator)
```

An optional WebDriver-compatible HTTP protocol is a later-stage integration. Playwright cannot directly connect to Selenium WebDriver; its connect interface expects a Playwright server or Chromium CDP. Reuse Playwright's *locator concepts*, not its browser protocol.

## Modules
- `locator`: selector definitions, window/parent scope, class, object name, text and menu path.
- `resolver`: resolve a locator just-in-time before action, avoid stale raw pointers.
- `registry`: opaque element IDs, destruction observation, stale generation handling, scoped handles.
- `actions`: Qt3 widget-aware commands (QLineEdit/QPushButton/QPopupMenu/QDialog), fallback event posting only where appropriate.
- `waits`: bounded conditions based on actual state, not fixed sleeps; distinguish action acknowledged vs postcondition satisfied.
- `trace`: JSONL correlation IDs, timestamps, object identities, ready conditions, result, failure signature; redact sensitive details.
- `recovery`: idempotent operations and checks before retrying actions with possible side effects.

## Critical lifecycle principles
- A readable pointer is not proof that QObject is still the same object.
- Object destruction and reuse must be distinguished; use Qt3 QGuardedPtr or QObject destroyed signal *in an ABI-compatible in-process component* if available, or conservative rediscovery where not.
- Validation and invocation must respect Qt GUI-thread affinity; a stale-check followed by an unsafe cross-thread call is still unsafe.
- Avoid automatic action retries when the outcome is uncertain, especially for banking transactions.

## Initial lab tests
1. Find Qt3 widgets by stable properties.
2. Destroy and recreate children during navigation.
3. Reuse memory addresses and ensure identities are not conflated.
4. Create/destroy QPopupMenu dynamically and select by menu text/ID.
5. Delay data population; wait for verified readiness.
6. Create Qt3 modal dialogs and verify file output.
7. Repeat tests with locked Windows session, comparing traces and outcomes.
