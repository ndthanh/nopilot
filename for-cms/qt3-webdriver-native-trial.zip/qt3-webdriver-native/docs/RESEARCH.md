# Research References and Decisions

Native milestone update: a DLL backend loaded with Frida has now been tested against the independent fixture. Exact-profile admission, controls and log evidence are documented in the current README and docs/EXPERIMENTS.md. Target ABI and comparative stability remain unverified.

Milestone 1 update (2026-11-03): the historical candidate assessment below is retained for context. The QtWin p8 Windows source has now built and run in the isolated lab profile; see `EXPERIMENTS.md`, `../README.md`, and `../PORTING.md` for current evidence and limits. Production ABI compatibility remains unverified.

## Existing tools
- Squish for Qt: proprietary Qt-aware GUI automation. Learn architecture, do not assume current release supports Qt3.
- Cisco QtWebDriver: https://github.com/cisco-open-source/qtwebdriver ; Qt4/Qt5 implementation, not plug-and-play for Qt3. Source inspection found:
  - `inc/extension_qt/widget_element_handle.h`: `QElementHandle` owns `QPointer<QObject>` and tests `!element_.isNull()`.
  - `src/webdriver/extension_qt/widget_view_executor.cc`: `getElement()` distinguishes no-such-element from `kStaleElementReference`; event posting through QApplication::postEvent; QAction invocation via Qt meta-object mechanisms.
  - `src/webdriver/extension_qt/widget_view_util.cc`: maps element IDs to QPointer and maintains session element IDs.
  - These are architecture patterns; they cannot be copied directly to Qt3 without adapting APIs and ABI.
- Playwright: useful for lazy locators, auto-wait and actionability ideas, but Playwright cannot drive QtWebDriver via WebDriver protocol directly.
- GammaRay: https://github.com/KDAB/GammaRay — Qt introspection reference, modern Qt focus.
- Spix: https://github.com/faaxm/spix — Qt UI automation/RPC reference, modern Qt focus.
- Open HMI Tester: https://github.com/pedromateo/openhmitester — possible record/replay design reference.

## Candidate Qt3 lab sources (NOT YET VALIDATED)
- QWin_Reloaded Windows Qt3 packages: https://sourceforge.net/projects/qwinreloaded/files/
- QtWin source: https://sourceforge.net/projects/qtwin/files/
- Qt3 source fork: https://github.com/gnu-andrew/qt3
- Official Qt3 archives: https://download.qt.io/archive/qt/3/
- QCad Windows binaries candidate: https://sourceforge.net/projects/qcadbinary/

Validate binaries, signatures, provenance and `qt-mt.dll` dependency before using them. Different Qt3 builds and compilers can be binary-incompatible despite similar DLL names.

## Priority experiments
1. Qt3 lab toolchain and ABI fingerprint.
2. Simulated QObject lifecycle churn; assess pointer caching and stale references.
3. QPopupMenu item enumeration by ID/index/text and verified activation.
4. JSONL flight recorder, action/postcondition timestamps and failure classification.
5. Decide later whether to add Selenium WebDriver compatibility.
