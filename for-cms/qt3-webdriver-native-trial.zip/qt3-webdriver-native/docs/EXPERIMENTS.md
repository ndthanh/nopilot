# Native backend experiment log

Date: 2026-11-03, Asia/Saigon.

User confirmed that the existing Frida PoC is approved, and requested a native Qt3 backend loaded through Frida, with window/button/input/menu/submenu/checkbox/file-dialog support and detailed logs. Production ABI remains unknown; no real application was attached to during this work.

Built `qt3webdriver.dll` and an independent Qt3 fixture against the previously source-built QtWin p8 / MinGW GCC 3.4.5 SDK. The fixture has no compiled-in automation adapter. Frida 17.25.1 was installed only into the workspace dependency directory for tests.

Verified real Frida attachment, module loading, GUI-thread bootstrap and C ABI transport. Native INFO confirms the dispatcher and current command thread are the same GUI thread. Both attach and Frida spawn paths were exercised against the dedicated fixture.

Implemented native guarded registry, distinct stale/missing/ambiguous errors, lifetime event collection, top-level/tree/scoped selectors, exact text/caption filters, window activation, button activation, Unicode input filling, idempotent checkbox changes, dynamic menu paths, Qt3 file dialog selection/accept/cancel, and pending action reconciliation.

The first caption-selector test exposed a fixture issue: this community port reset the caption when `setMainWidget` ran. Setting the synthetic fixture caption after that call fixed the fixture; the backend matched the actual caption correctly. The failed test log is retained separately from release evidence.

Integration tests exercise 100 destroy/recreate cycles, menu repopulation before activation, password suppression, modal file dialogs opened via a submenu, background-action modal rejection, a timeout while the dialog remains open, and reconciliation without replay. HTTP tests include token rejection, field/check/window/menu operations, concurrent modal completion, stale exported handles, and fresh IDs across sessions.

Probe-only and deliberately mismatched profile tests verify that the native backend is absent from the target module list both before and after the rejected connection attempt. Fingerprinting collects metadata without Qt API calls. Only the known exact Qt/runtime hashes authorize native loading.

See `RESULTS.json` for final test counts and artifact hashes. Logs contain intentional stale/missing errors used by tests; those are assertions of correct rejection, not estimates of workflow failure. No comparison with the user's original Frida-agent implementation has been measured yet.

Final observed result: all 18 integration tests passed, including HTTP modal completion and probe/profile non-loading checks. The standalone example completed four explicitly recorded scenarios across two runs. Each integration run contains approximately 950 native requests/replies (the exact count depends on readiness polling), 100 replacement cycles, zero lifecycle ring-buffer drops and no malformed JSONL lines. The dedicated fixture's captured stderr was empty. Example traces include a transient missing file-dialog poll before it appeared; all scenario outcomes still passed.

The delivery build additionally checks Qt's recorded application thread ID through the pinned build's exported scalar getter before constructing the dispatcher. The fixture's owning Windows thread, the Qt application thread and command execution thread matched. The full 18-test suite passed on this build; see `evidence/delivery`. Latest example tracing also records controller/agent/backend hashes and keeps opaque element IDs visible while redacting content arguments.

Remaining limits: unknown target SDK/compiler ABI; no native Win32 common-dialog adapter; no locked-session/clean-VM/long-duration production results; no full Cisco QtWebDriver upstream compilation. Native DLL remains loaded until the target exits normally.
