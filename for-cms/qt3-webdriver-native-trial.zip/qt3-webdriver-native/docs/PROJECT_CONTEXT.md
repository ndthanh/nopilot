# Project Context — Handoff from ChatGPT discussion

Milestone 1 update (2026-11-03): a self-consistent Qt3 Windows lab profile has been built and tested. The historical target observations below have not been independently reproduced. See `EXPERIMENTS.md` and `../PORTING.md`; full QtWebDriver porting and target integration remain unverified.

## Goal
Build a robust Squish-like semantic automation layer for legacy Qt3 Windows GUI applications, especially a 32-bit proprietary ITC.exe that loads `qt-mt.dll`. Longer-term: expose stable Python controls for akabot workflows without screen-coordinate/image-based automation.

## Confirmed by user
- ITC.exe is a 32-bit Qt3 application and loads `qt-mt.dll`.
- Windows UI Automation does not expose its GUI adequately.
- User has already experimented with Python + Frida and can inspect QObject/QWidget hierarchy, read some properties, invoke Qt methods/slots and automate menus with partial success.
- Two full business workflows have run end-to-end with the Windows screen locked; jobs start through Windows Task Scheduler.
- Estimated 20–30% intermittent failures. User suspects Qt object lifecycle, not yet proven.
- Frida spawn worked in testing; attach to an already-running process triggered Cortex XDR quarantine of a Frida-related binary.
- Only Python and Node.js are available as developer tools on the restricted workstation; a separate machine could build native C++ artifacts.
- One tricky UI is `File > Save As...` in a subordinate `List of authorization transactions` window, with Qt3 QPopupMenu and possibly a Qt3 file-selection dialog; mappings differ between test and production.

## Unknowns / must measure
- Actual qt-mt.dll file version, exports, compiler ABI and linkage.
- Whether raw QObject pointers are cached across steps or rediscovered before calls.
- Whether failures correlate with object destruction, pointer reuse, UI-thread violations, backend readiness or security restrictions.
- Whether a Qt3 build compatible with ITC.exe can be reproduced in a separate lab.
- Whether an approved in-process bridge is possible on target deployment. Packaging a DLL inside a Python wheel does NOT load it into ITC.exe.

## Why this matters
A vendor's alternative automates via screen coordinates/image recognition and reportedly needs a continuously unlocked display and stable monitor configuration. Our user wants semantic automation independent of the rendered pixels. A locked session has already been demonstrated for two workflows, but reliability is insufficient.
