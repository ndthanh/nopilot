"""Optional authenticated loopback WebDriver subset over the native Qt3 backend."""
import argparse
import json
from pathlib import Path
import re
import secrets
import threading
import uuid
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from qt3wd import Driver,Trace,BackendError

ELEMENT='element-6066-11e4-a52e-4f735466cecf'


class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,driver,port=0):
        self.driver=driver;self.token=secrets.token_urlsafe(32)
        self.session=None;self.handles={};self.reverse={};self.lock=threading.RLock()
        super().__init__(('127.0.0.1',port),Handler)
    def export(self,id):
        with self.lock:
            if id not in self.reverse:
                wire=uuid.uuid4().hex;self.reverse[id]=wire;self.handles[wire]=id
            return self.reverse[id]
    def element(self,wire):
        with self.lock:
            if wire not in self.handles:raise BackendError('no such element','Element was not exported in this session')
            return self.driver.handle(self.handles[wire])


class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.0'
    def log_message(self,*_):pass
    def respond(self,status,value):
        raw=json.dumps({'value':value},ensure_ascii=False).encode()
        try:
            self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
        except (ConnectionError,TimeoutError):
            self.close_connection=True
            self.server.driver.trace.event('http_peer_closed',status=status)
    def dispatch(self):
        self.connection.settimeout(10)
        if not secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+self.server.token):
            self.respond(401,{'error':'unauthorized','message':'Bearer token required','stacktrace':''});return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<0 or size>8192 or self.headers.get('Transfer-Encoding'):raise BackendError('invalid argument','Unsupported request body')
            body=json.loads(self.rfile.read(size)) if size else {}
            if not isinstance(body,dict):raise BackendError('invalid argument','Expected JSON object')
            self.server.driver.trace.event('http_request',method=self.command,route=self.path,arguments=body)
            path=self.path.strip('/').split('/')
            if path==['status'] and self.command=='GET':self.respond(200,{'ready':self.server.session is None,'message':'Qt3 native experimental subset'});return
            if path==['session'] and self.command=='POST':
                with self.server.lock:
                    if self.server.session:raise BackendError('session not created','One session is supported')
                    self.server.session=uuid.uuid4().hex;self.server.handles.clear();self.server.reverse.clear()
                self.respond(200,{'sessionId':self.server.session,'capabilities':{'browserName':'qt3-native','qt:experimentalSubset':True}});return
            if len(path)<2 or path[0]!='session' or path[1]!=self.server.session:raise BackendError('invalid session id','Unknown session')
            if len(path)==2 and self.command=='DELETE':
                with self.server.lock:self.server.session=None;self.server.handles.clear();self.server.reverse.clear()
                self.respond(200,None);return
            if path[2:]==['element'] and self.command=='POST':
                using,value=body.get('using'),body.get('value')
                if using=='qt' and isinstance(value,dict):
                    name=value.get('name','');cls=value.get('className','');scope=self.server.element(value['scope']) if value.get('scope') else None
                    text=value.get('text','');caption=value.get('caption','')
                elif using=='css selector' and isinstance(value,str):
                    match=re.fullmatch(r'(Q[A-Za-z0-9_]+)?\[name="([^"\\]+)"\]',value)
                    if not match:raise BackendError('invalid selector','Use qt strategy or QClass[name="name"]')
                    cls,name=match[1] or '',match[2];scope=None;text=caption=''
                else:raise BackendError('invalid argument','Supported locator strategies: qt, restricted css selector')
                if not all(isinstance(v,str) for v in [name,cls,text,caption]):raise BackendError('invalid argument','Selector fields must be strings')
                handle=self.server.driver.locator(name=name,class_name=cls,scope=scope,text=text,caption=caption).resolve()
                self.respond(200,{ELEMENT:self.server.export(handle.id)});return
            if len(path)>=4 and path[2]=='element':
                handle=self.server.element(path[3]);operation=path[4:]
                if operation==['click'] and self.command=='POST':handle.click();self.respond(200,None);return
                if operation==['value'] and self.command=='POST':
                    text=body.get('text');values=body.get('value')
                    if text is None and isinstance(values,list) and all(isinstance(v,str) for v in values):text=''.join(values)
                    if not isinstance(text,str):raise BackendError('invalid argument','Text must be a string')
                    handle.fill(text);self.respond(200,None);return
                if operation==['clear'] and self.command=='POST':handle.fill('');self.respond(200,None);return
                if self.command=='GET' and len(operation)==1:
                    info=handle.describe();key={'text':'text','selected':'checked','displayed':'visible','enabled':'enabled'}.get(operation[0])
                    if key and key in info:self.respond(200,info[key]);return
            if path[2:]==['qt','tree'] and self.command=='GET':
                tree=self.server.driver.snapshot()
                for item in tree['objects']:
                    item['id']=self.server.export(item['id'])
                    if item['parent']:item['parent']=self.server.export(item['parent'])
                self.respond(200,tree);return
            if len(path)>=4 and path[2]=='qt' and self.command=='POST':
                handle=self.server.element(body.get('element'))
                operation='/'.join(path[3:])
                if operation=='menu':
                    segments=body.get('path')
                    if not isinstance(segments,list) or not 1<=len(segments)<=16 or not all(isinstance(s,str) for s in segments):raise BackendError('invalid argument','Menu path must contain 1-16 text segments')
                    result=handle.menu(*segments)
                elif operation=='check':
                    if not isinstance(body.get('checked'),bool):raise BackendError('invalid argument','checked must be boolean')
                    result=handle.check(body['checked'])
                elif operation=='window':result=handle.activate()
                elif operation=='file/path':
                    if not isinstance(body.get('path'),str):raise BackendError('invalid argument','File path must be a string')
                    result=handle.file_path(body['path'])
                elif operation=='file/accept':result=handle.accept_file()
                elif operation=='dialog/cancel':result=handle.cancel_dialog()
                else:raise BackendError('unsupported operation','Unknown Qt operation')
                self.respond(200,result);return
            raise BackendError('unknown command','Unsupported route')
        except BackendError as error:
            self.server.driver.trace.event('http_error',code=error.code,ticket=error.ticket,errorMessage=str(error))
            status=404 if error.code in {'no such element','stale element reference','invalid session id','unknown command'} else 400
            if error.code in {'outcome unknown','session not created','transport error'}:status=500
            self.respond(status,{'error':error.code,'message':str(error),'stacktrace':'','qt:ticket':error.ticket})
        except (ValueError,TypeError,TimeoutError) as error:
            self.respond(400,{'error':'invalid argument','message':str(error),'stacktrace':''})
    do_GET=do_POST=do_DELETE=dispatch


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--pid',type=int);g.add_argument('--spawn',type=Path)
    p.add_argument('--enable-actions',action='store_true');p.add_argument('--include-content',action='store_true')
    p.add_argument('--logs',type=Path,required=True);p.add_argument('--port',type=int,default=0)
    a=p.parse_args();driver=Driver(Trace(a.logs,a.include_content),pid=a.pid,spawn=a.spawn,actions=a.enable_actions)
    server=Server(driver,a.port)
    try:
        print(json.dumps({'url':f'http://127.0.0.1:{server.server_port}','bearerToken':server.token}),flush=True)
        server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:server.server_close();driver.close()
