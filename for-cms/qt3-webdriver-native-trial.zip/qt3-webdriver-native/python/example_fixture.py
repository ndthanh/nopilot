"""Action example for the supplied synthetic fixture. Adapt selectors for your own app."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from qt3wd import Driver,Trace


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pid',type=int,required=True)
    p.add_argument('--file',type=Path);p.add_argument('--logs',type=Path,default=Path('logs')/'example')
    a=p.parse_args();trace=Trace(a.logs);driver=Driver(trace,pid=a.pid,actions=True)
    try:
        with trace.scenario('synthetic-controls'):
            window=driver.locator(class_name='QMainWindow',caption='Qt3 native backend fixture')
            window.activate()
            driver.locator(name='input',scope=window).fill('Synthetic test value')
            driver.locator(name='button',scope=window).click()
            driver.locator(name='status',scope=window).wait(lambda state:state['text'].startswith('clicks:'))
            driver.locator(name='checkbox',scope=window).check(True)
            window.menu('File','Tools','Mark')
            driver.drain_events()
        if a.file:
            with trace.scenario('synthetic-file-dialog'),ThreadPoolExecutor(max_workers=1) as pool:
                opening=pool.submit(window.menu,'File','Tools','Open...',timeout=30)
                dialog=driver.locator(class_name='QFileDialog',name='fileDialog')
                dialog.resolve();dialog.file_path(a.file.resolve());dialog.accept_file()
                opening.result(timeout=5)
    finally:driver.close()
