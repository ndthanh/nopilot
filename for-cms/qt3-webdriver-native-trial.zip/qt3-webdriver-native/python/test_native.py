"""Tests load the DLL through real Frida into an uninstrumented Qt3 fixture."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import unittest
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from http_server import Server,ELEMENT
from qt3wd import Driver,Trace,BackendError,ROOT,validate_profile

EVIDENCE=ROOT/'evidence'/'integration'


def fixture():
    exe=ROOT/'runtime'/'fixture'/'qt3-fixture.exe'
    env=os.environ.copy();env['PATH']=r'C:\Windows\System32;C:\Windows';env.pop('QTDIR',None)
    p=subprocess.Popen([str(exe)],cwd=exe.parent,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    if p.stdout.readline()!=b'fixture-ready\r\n':
        p.terminate();p.wait();raise RuntimeError('Fixture did not start')
    return p


class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        EVIDENCE.mkdir(parents=True,exist_ok=True)
        cls.process=fixture();cls.trace=Trace(EVIDENCE)
        try:cls.driver=Driver(cls.trace,pid=cls.process.pid,actions=True)
        except Exception:
            cls.process.terminate();cls.process.wait();raise
        cls.input=cls.driver.locator(name='input')
        cls.window=cls.driver.locator(name='fixtureWindow')
        cls.status=cls.driver.locator(name='status')
    @classmethod
    def tearDownClass(cls):
        cls.driver.close();cls.process.terminate();cls.process.wait(timeout=5)
        stderr=cls.process.stderr.read().decode(errors='replace')
        (EVIDENCE/'fixture-stderr.log').write_text(stderr,encoding='utf-8')
        cls.process.stdout.close();cls.process.stderr.close()
        if stderr:raise AssertionError(stderr)
    def code(self,expected,fn):
        with self.assertRaises(BackendError) as raised:fn()
        self.assertEqual(raised.exception.code,expected)
        return raised.exception
    def test_01_native_module_and_gui_thread(self):
        inventory=self.driver.script.exports_sync.inventory()
        self.assertIn('qt3webdriver.dll',[m['name'].lower() for m in inventory['modules']])
        info=self.driver.call('INFO');self.assertEqual(info['qt'],'3.3.8')
        self.assertEqual(info['guiThread'],info['currentThread'])
        self.assertEqual(info['guiThread'],info['qtApplicationThread'])
        self.assertTrue(info['actionsEnabled'])
    def test_02_tree_and_scoped_lookup(self):
        tree=self.driver.snapshot();self.trace.save('tree.json',tree)
        names={o['name'] for o in tree['objects']}
        self.assertTrue({'fixtureWindow','button','input','checkbox','menuBar'}<=names)
        self.assertFalse(tree['truncated'])
        scoped=self.driver.locator(name='input',class_name='QLineEdit',scope=self.window)
        self.assertEqual(scoped.resolve().id,self.input.resolve().id)
        titled=self.driver.locator(class_name='QMainWindow',caption='Qt3 native backend fixture')
        self.assertEqual(titled.resolve().id,self.window.resolve().id)
        labelled=self.driver.locator(class_name='QPushButton',text='Activate',scope=titled)
        self.assertEqual(labelled.resolve().id,self.driver.locator(name='button').resolve().id)
    def test_03_fill_unicode(self):
        value='Qt3 thử nghiệm — 123'
        self.assertTrue(self.input.fill(value)['verified'])
        self.assertEqual(self.input.describe()['text'],value)
    def test_04_button(self):
        self.driver.locator(name='button').click()
        self.status.wait(lambda s:s['text'].startswith('clicks:'))
    def test_05_checkbox_idempotent(self):
        checkbox=self.driver.locator(name='checkbox')
        checkbox.check(False)
        self.assertTrue(checkbox.check(True)['changed'])
        self.assertTrue(checkbox.describe()['checked'])
        self.assertFalse(checkbox.check(True)['changed'])
        self.assertTrue(checkbox.check(False)['changed'])
        self.assertFalse(checkbox.describe()['checked'])
    def test_06_window(self):
        self.assertTrue(self.window.activate()['dispatched'])
        self.assertTrue(self.window.describe()['visible'])
    def test_07_menu_submenu_repopulation(self):
        previous=None
        for _ in range(10):
            self.window.menu('File','Tools','Mark')
            result=self.status.wait(lambda s:s['text'].startswith('marked:'))['text']
            self.assertNotEqual(result,previous);previous=result
        items=self.driver.locator(name='toolsMenu').resolve().menu_items()
        self.assertTrue(any(i['id']==77 and i['text']=='Mark' and i['index']!=0 for i in items))
    def test_08_explicit_handle_stale_and_lazy_refresh(self):
        old=self.input.resolve()
        self.driver.locator(name='replace').click()
        self.code('stale element reference',old.describe)
        new=self.input.resolve();self.assertNotEqual(new.id,old.id)
        self.assertTrue(new.describe()['text'].startswith('generation:'))
    def test_09_churn_100_cycles(self):
        seen=set();durations=[]
        start=time.monotonic()
        for index in range(100):
            t=time.monotonic();old=self.input.resolve()
            self.assertNotIn(old.id,seen);seen.add(old.id)
            self.driver.locator(name='replace').click()
            self.code('stale element reference',old.describe)
            self.input.fill(f'cycle-{index}')
            self.assertEqual(self.input.describe()['text'],f'cycle-{index}')
            durations.append((time.monotonic()-t)*1000)
            if index%10==0:
                lifecycle=self.driver.drain_events()
                self.assertEqual(lifecycle['dropped'],0)
        self.trace.save('churn.json',{'cycles':100,'seconds':time.monotonic()-start,'cycleMs':durations,'passed':True})
    def test_10_password_never_returned(self):
        value=self.driver.locator(name='password').describe()
        self.assertTrue(value['password']);self.assertNotIn('text',value)
        self.assertNotIn('DO-NOT-LOG-PASSWORD',json.dumps(self.driver.snapshot()))
    def test_11_modal_file_dialog_via_menu(self):
        path=(EVIDENCE/'synthetic-input.txt').resolve();path.write_text('synthetic fixture data',encoding='utf-8')
        result=[];errors=[]
        def open_dialog():
            try:result.append(self.window.menu('File','Tools','Open...',timeout=10))
            except Exception as e:errors.append(e)
        thread=threading.Thread(target=open_dialog);thread.start()
        dialog=self.driver.locator(name='fileDialog',class_name='QFileDialog')
        try:
            handle=dialog.resolve(timeout=3)
            self.code('element not interactable',lambda:self.driver.locator(name='button').click())
            dialog.file_path(path)
            dialog.accept_file()
            thread.join(5)
            self.assertFalse(thread.is_alive());self.assertFalse(errors,str(errors));self.assertTrue(result)
            actual=self.status.wait(lambda s:s['text'].startswith('file:'))['text'][5:]
            self.assertEqual(Path(actual).resolve(),path)
            self.code('stale element reference',handle.describe)
        finally:
            if thread.is_alive():
                try:dialog.cancel_dialog()
                except Exception:pass
                thread.join(3)
    def test_12_outcome_unknown_then_reconcile_without_replay(self):
        error=self.code('outcome unknown',lambda:self.driver.locator(name='file').click(timeout=.15))
        self.assertIsNotNone(error.ticket)
        dialog=self.driver.locator(name='fileDialog');dialog.resolve()
        dialog.cancel_dialog()
        deadline=time.monotonic()+3;result=None
        while result is None and time.monotonic()<deadline:
            result=self.driver.reconcile(error.ticket)
            if result is None:time.sleep(.02)
        self.assertTrue(result['dispatched'])
        self.status.wait(lambda s:s['text']=='file:cancelled')
    def test_13_unknown_and_ambiguous(self):
        self.code('no such element',lambda:self.driver.call('FIND','','QLineEdit','absent'))
        self.code('invalid selector',lambda:self.driver.call('FIND','','QLineEdit',''))
    def test_14_default_trace_redaction(self):
        rows=(EVIDENCE/'trace.jsonl').read_text(encoding='utf-8')
        self.assertNotIn('DO-NOT-LOG-PASSWORD',rows)
        self.assertNotIn('Qt3 thử nghiệm',rows)
        self.assertNotIn('synthetic-input.txt',rows)
        self.assertIn('"redacted": true',rows)
    def test_15_read_only_and_profile_gate(self):
        process=fixture();driver=None
        try:
            driver=Driver(Trace(EVIDENCE/'readonly'),pid=process.pid,actions=False)
            handle=driver.locator(name='input').resolve()
            self.code('actions disabled',lambda:handle.fill('must-not-change'))
            self.assertEqual(handle.describe()['text'],'initial')
            profile=json.loads((ROOT/'profiles'/'lab.json').read_text())
            profile['qt_sha256']='0'*64
            self.code('abi unsupported',lambda:validate_profile(driver.inventory,profile,ROOT/'runtime'/'qt3webdriver.dll'))
        finally:
            if driver:driver.close()
            process.terminate();process.wait();process.stdout.close();process.stderr.close()
    def test_16_frida_spawn_path(self):
        driver=None
        try:
            driver=Driver(Trace(EVIDENCE/'spawn'),spawn=ROOT/'runtime'/'fixture'/'qt3-fixture.exe',actions=False)
            self.assertEqual(driver.call('INFO')['qt'],'3.3.8')
            self.assertTrue(driver.snapshot()['objects'])
        finally:
            if driver:
                driver.close()
                driver.device.kill(driver.pid) # Only the dedicated fixture spawned by this test.
    def test_17_http_widgets_and_session_ids(self):
        server=Server(self.driver);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        def request(method,path,body=None,token=True):
            headers={'Content-Type':'application/json'}
            if token:headers['Authorization']='Bearer '+server.token
            req=Request(base+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers=headers)
            with urlopen(req,timeout=8) as reply:return json.load(reply)['value']
        try:
            with self.assertRaises(HTTPError) as rejected:request('GET','/status',token=False)
            self.assertEqual(rejected.exception.code,401)
            session=request('POST','/session',{})['sessionId'];prefix='/session/'+session
            def find(name):return request('POST',prefix+'/element',{'using':'qt','value':{'name':name}})[ELEMENT]
            input_id=find('input')
            request('POST',prefix+'/element/'+input_id+'/value',{'text':'http-value'})
            self.assertEqual(request('GET',prefix+'/element/'+input_id+'/text'),'http-value')
            box=find('checkbox');request('POST',prefix+'/qt/check',{'element':box,'checked':True})
            self.assertTrue(request('GET',prefix+'/element/'+box+'/selected'))
            request('POST',prefix+'/qt/window',{'element':find('fixtureWindow')})
            request('POST',prefix+'/qt/menu',{'element':find('fixtureWindow'),'path':['File','Tools','Mark']})
            file_button=find('file');modal_errors=[]
            def open_http_dialog():
                try:request('POST',prefix+'/element/'+file_button+'/click',{})
                except Exception as error:modal_errors.append(error)
            modal_thread=threading.Thread(target=open_http_dialog);modal_thread.start()
            self.driver.locator(name='fileDialog').resolve()
            dialog=find('fileDialog')
            request('POST',prefix+'/qt/file/path',{'element':dialog,'path':str((EVIDENCE/'synthetic-input.txt').resolve())})
            request('POST',prefix+'/qt/file/accept',{'element':dialog})
            modal_thread.join(5);self.assertFalse(modal_thread.is_alive());self.assertFalse(modal_errors,str(modal_errors))
            self.driver.locator(name='replace').click()
            with self.assertRaises(HTTPError) as stale:request('GET',prefix+'/element/'+input_id+'/text')
            self.assertEqual(json.load(stale.exception)['value']['error'],'stale element reference')
            old_window=find('fixtureWindow');request('DELETE',prefix)
            newer=request('POST','/session',{})['sessionId']
            value=request('POST','/session/'+newer+'/element',{'using':'qt','value':{'name':'fixtureWindow'}})[ELEMENT]
            self.assertNotEqual(value,old_window)
            with self.assertRaises(HTTPError):request('GET','/session/'+newer+'/element/'+old_window+'/text')
            request('DELETE','/session/'+newer)
        finally:server.shutdown();server.server_close();thread.join(3)
    def test_18_probe_and_bad_profile_do_not_load_backend(self):
        process=fixture();probe=None
        try:
            probe=Driver(Trace(EVIDENCE/'probe'),pid=process.pid,probe_only=True)
            self.assertNotIn('qt3webdriver.dll',[m['name'].lower() for m in probe.inventory['modules']])
            probe.close();probe=None
            profile=json.loads((ROOT/'profiles'/'lab.json').read_text());profile['qt_sha256']='0'*64
            bad=EVIDENCE/'bad-profile.json';bad.write_text(json.dumps(profile))
            self.code('abi unsupported',lambda:Driver(Trace(EVIDENCE/'blocked'),pid=process.pid,profile=bad))
            probe=Driver(Trace(EVIDENCE/'blocked-confirmation'),pid=process.pid,probe_only=True)
            self.assertNotIn('qt3webdriver.dll',[m['name'].lower() for m in probe.inventory['modules']])
        finally:
            if probe:probe.close()
            process.terminate();process.wait();process.stdout.close();process.stderr.close()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,default=EVIDENCE);a=p.parse_args();EVIDENCE=a.evidence.resolve()
    EVIDENCE.mkdir(parents=True,exist_ok=True)
    with (EVIDENCE/'tests.log').open('w',encoding='utf-8') as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(NativeTests))
    print((EVIDENCE/'tests.log').read_text(encoding='utf-8'))
    (EVIDENCE/'summary.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful()},indent=2))
    raise SystemExit(not result.wasSuccessful())
