"""Experimental Qt3 native backend client and evidence collector."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading
import time
from urllib.parse import quote
import uuid

ROOT=Path(__file__).resolve().parents[1]
SENSITIVE={'text','name','caption','path','selectedFile','input','selector','arguments','message','errorMessage','description'}


class BackendError(Exception):
    def __init__(self,code,message,ticket=None):
        self.code,self.ticket=code,ticket
        super().__init__(f'{code}: {message}')


class Trace:
    def __init__(self,directory,include_content=False):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.run_id=uuid.uuid4().hex;self.salt=secrets.token_bytes(32)
        self.include_content=include_content;self.lock=threading.Lock();self.sequence=0
    def redact(self,value,key=''):
        if key in SENSITIVE and not self.include_content and value is not None:
            raw=json.dumps(value,ensure_ascii=False,sort_keys=True).encode()
            return {'redacted':True,'bytes':len(raw),'runHash':hashlib.sha256(self.salt+raw).hexdigest()}
        if isinstance(value,dict):return {k:self.redact(v,k) for k,v in value.items()}
        if isinstance(value,(list,tuple)):return [self.redact(v) for v in value]
        return value
    def event(self,event,**fields):
        with self.lock:
            self.sequence+=1
            row={'schema':1,'runId':self.run_id,'sequence':self.sequence,'monotonicNs':time.monotonic_ns(),
                 'wallUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'event':event,**self.redact(fields)}
            with (self.directory/'trace.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    def save(self,name,value):
        (self.directory/name).write_text(json.dumps(self.redact(value),indent=2,ensure_ascii=False),encoding='utf-8')
    @contextmanager
    def scenario(self,label):
        scenario=uuid.uuid4().hex;started=time.monotonic()
        self.event('scenario_start',scenarioId=scenario,scenario=label)
        try:
            yield
        except Exception as error:
            self.event('scenario_end',scenarioId=scenario,scenario=label,passed=False,
                       durationMs=(time.monotonic()-started)*1000,errorMessage=str(error))
            raise
        else:self.event('scenario_end',scenarioId=scenario,scenario=label,passed=True,durationMs=(time.monotonic()-started)*1000)


def window_for_pid(pid,timeout=10):
    user=ctypes.WinDLL('user32',use_last_error=True)
    user.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowThreadProcessId.restype=wintypes.DWORD
    user.IsWindowVisible.argtypes=[wintypes.HWND];user.IsWindowVisible.restype=wintypes.BOOL
    user.GetWindow.argtypes=[wintypes.HWND,wintypes.UINT];user.GetWindow.restype=wintypes.HWND
    callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    found=[]
    @callback_type
    def callback(hwnd,_):
        owner=wintypes.DWORD()
        user.GetWindowThreadProcessId(hwnd,ctypes.byref(owner))
        if owner.value==pid and user.IsWindowVisible(hwnd) and not user.GetWindow(hwnd,4):found.append(int(hwnd))
        return True
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        found.clear();user.EnumWindows(callback,0)
        if found:return found[0]
        time.sleep(.05)
    raise BackendError('gui unavailable','No visible top-level target window; specify --hwnd if needed')


def file_hash(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as file:
        for chunk in iter(lambda:file.read(1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()


def native_window_classes(pid):
    user=ctypes.WinDLL('user32',use_last_error=True)
    user.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    user.GetWindowThreadProcessId.restype=wintypes.DWORD
    user.GetClassNameW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
    user.IsWindowVisible.argtypes=[wintypes.HWND]
    rows=[]
    @ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def visit(hwnd,_):
        owner=wintypes.DWORD();thread=user.GetWindowThreadProcessId(hwnd,ctypes.byref(owner))
        if owner.value==pid:
            buffer=ctypes.create_unicode_buffer(256);user.GetClassNameW(hwnd,buffer,256)
            rows.append({'windowClass':buffer.value,'guiThread':thread,'visible':bool(user.IsWindowVisible(hwnd))})
        return True
    user.EnumWindows(visit,0)
    return rows


def validate_profile(inventory,profile,backend):
    if inventory['arch']!='ia32' or inventory['pointerSize']!=4:
        raise BackendError('abi unsupported','This build requires Windows x86')
    if len(inventory['qt'])!=1 or inventory['qt'][0]['name'].lower()!='qt-mt.dll':
        raise BackendError('abi unsupported','Expected exactly one loaded qt-mt.dll')
    if file_hash(inventory['qt'][0]['path'])!=profile['qt_sha256']:
        raise BackendError('abi unsupported','Qt DLL hash does not match the tested native profile; collect fingerprint and build a matching backend')
    if file_hash(backend)!=profile['artifacts']['qt3webdriver.dll']:
        raise BackendError('artifact mismatch','Backend hash does not match the build profile')
    runtimes=[m for m in inventory['modules'] if m['name'].lower()=='mingwm10.dll']
    if len(runtimes)!=1 or file_hash(runtimes[0]['path'])!=profile['artifacts']['mingwm10.dll']:
        raise BackendError('abi unsupported','Loaded MinGW thread runtime does not match the tested profile')
    return True


class Driver:
    def __init__(self,trace,*,pid=None,spawn=None,spawn_args=None,cwd=None,actions=False,profile=None,hwnd=None,probe_only=False):
        import frida
        self.trace=trace;self.device=frida.get_local_device();self.session=None;self.script=None
        self.identity=uuid.uuid4().hex;self.pending=set();self.actions=actions;self.backend_ready=False
        self.pid=pid;self.spawned=False
        trace.event('controller_start',fridaVersion=frida.__version__,actions=actions,probeOnly=probe_only,
                    packageVersion='0.2',controllerSha256=file_hash(Path(__file__)),agentSha256=file_hash(ROOT/'agent'/'loader.js'))
        try:
            if spawn:
                executable=Path(spawn).resolve()
                self.pid=self.device.spawn([str(executable),*(spawn_args or [])],cwd=str(Path(cwd).resolve() if cwd else executable.parent),stdio='pipe');self.spawned=True
                trace.event('process_spawned',pid=self.pid,path=str(executable),arguments=spawn_args or [])
            if not self.pid:raise BackendError('invalid argument','Supply a PID or executable')
            self.session=self.device.attach(self.pid)
            self.session.on('detached',lambda reason,crash:trace.event('session_detached',reason=str(reason),crashPresent=crash is not None))
            self.script=self.session.create_script((ROOT/'agent'/'loader.js').read_text(encoding='utf-8'))
            self.script.on('message',self._message);self.script.load()
            if self.spawned:self.device.resume(self.pid);self.spawned=False
            self.inventory=self.script.exports_sync.inventory()
            self._fingerprint()
            if probe_only:return
            metadata=json.loads(Path(profile or ROOT/'profiles'/'lab.json').read_text(encoding='utf-8'))
            backend=ROOT/'runtime'/'qt3webdriver.dll'
            validate_profile(self.inventory,metadata,backend)
            trace.event('profile_matched',profile=metadata['profile'],qtHash=metadata['qt_sha256'],
                        backendHash=metadata['artifacts']['qt3webdriver.dll'])
            target_hwnd=int(hwnd,0) if isinstance(hwnd,str) else hwnd or window_for_pid(self.pid)
            armed=self.script.exports_sync.begin(str(backend.resolve()),hex(target_hwnd),actions)
            trace.event('bootstrap_armed',details=armed)
            deadline=time.monotonic()+10
            while True:
                state=self.script.exports_sync.status()
                if state['state']=='ready':break
                if state['state']=='failed':raise BackendError('bootstrap failed',str(state))
                if time.monotonic()>deadline:raise BackendError('bootstrap timeout','GUI thread did not initialize backend')
                time.sleep(.02)
            self.backend_ready=True
            info=self.call('INFO')
            if bool(info['actionsEnabled'])!=bool(actions):
                raise BackendError('mode mismatch','An existing backend has another mode; restart the app before changing mode')
            trace.save('backend-info.json',info)
        except Exception as error:
            trace.event('connection_failed',errorType=type(error).__name__,errorMessage=str(error))
            self.close();raise

    def _message(self,message,data):
        if message.get('type')=='send':self.trace.event('agent',payload=message.get('payload'))
        else:self.trace.event('agent_error',description=message.get('description'),line=message.get('lineNumber'))

    def _fingerprint(self):
        record={'pid':self.inventory['pid'],'arch':self.inventory['arch'],'pointerSize':self.inventory['pointerSize'],
                'nativeWindows':native_window_classes(self.pid),'qt':[]}
        for module in self.inventory['qt']:
            item={**module,'sha256':file_hash(module['path'])}
            record['qt'].append(item)
        self.trace.save('fingerprint.json',record)
        self.trace.event('fingerprint',arch=record['arch'],qtModules=len(record['qt']),
                         qtHashes=[m['sha256'] for m in record['qt']])

    def call(self,command,*arguments,timeout=5):
        request='\t'.join(quote(str(x),safe='') for x in (command,*arguments))
        if len(request.encode())>=8192:raise BackendError('invalid argument','Request exceeds native limit')
        correlation=uuid.uuid4().hex
        element_commands={'DESCRIBE','CLICK','FILL','CHECK','WINDOW','MENU','MENU_ITEMS','FILE_PATH','FILE_ACCEPT','DIALOG_CANCEL'}
        self.trace.event('request',correlation=correlation,command=command,arguments=arguments,deadlineMs=round(timeout*1000),
                         elementId=arguments[0] if command in element_commands and arguments else None,
                         scopeId=arguments[0] if command=='FIND' and arguments else None,
                         input=arguments[1] if command=='FILL' and len(arguments)>1 else None)
        try:ticket=self.script.exports_sync.submit(request)
        except Exception as error:
            self.trace.event('transport_exception',correlation=correlation,phase='submit',errorMessage=str(error))
            raise BackendError('outcome unknown','Transport failed during submit; do not replay the action') from error
        if not ticket:raise BackendError('queue unavailable','Backend not ready or queue full')
        self.trace.event('queued',correlation=correlation,ticket=ticket)
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            try:reply=self.script.exports_sync.poll(ticket)
            except Exception as error:
                self.pending.add(ticket)
                self.trace.event('transport_exception',correlation=correlation,ticket=ticket,phase='poll',errorMessage=str(error))
                raise BackendError('outcome unknown','Transport failed after queuing; reconcile if the target is still available',ticket) from error
            if reply['state']==1:
                return self._result(reply['reply'],correlation)
            if reply['state']<0:raise BackendError('transport error','Native ticket is unavailable',ticket)
            time.sleep(min(.01,max(0,deadline-time.monotonic())))
        cancelled=self.script.exports_sync.cancel(ticket)
        if cancelled==1:
            self.trace.event('cancelled_before_dispatch',correlation=correlation,ticket=ticket)
            raise BackendError('timeout before dispatch','Queued request was cancelled without execution',ticket)
        self.pending.add(ticket)
        self.trace.event('outcome_unknown',correlation=correlation,ticket=ticket,command=command)
        raise BackendError('outcome unknown','Request may have executed; use reconcile(ticket) and check postconditions',ticket)

    def _result(self,envelope,correlation=None):
        self.trace.event('reply',correlation=correlation,envelope=envelope)
        result=envelope['result']
        if 'error' in result:raise BackendError(result['error'],result['message'])
        return result['value']

    def reconcile(self,ticket):
        reply=self.script.exports_sync.poll(ticket)
        self.trace.event('reconcile',ticket=ticket,state=reply['state'])
        if reply['state']!=1:return None
        self.pending.discard(ticket)
        return self._result(reply['reply'])

    def locator(self,*,name='',class_name='',scope=None,text='',caption=''):return Locator(self,name,class_name,scope,text,caption)
    def handle(self,id):return Handle(self,id)
    def snapshot(self):return self.call('TREE')
    def drain_events(self):
        result=self.call('EVENTS')
        self.trace.event('native_lifecycle',details=result)
        return result
    def close(self):
        if self.backend_ready and self.session:
            try:self.drain_events()
            except Exception as error:self.trace.event('lifecycle_drain_failed',errorMessage=str(error))
            self.backend_ready=False
        if self.spawned and self.pid:
            try:self.device.resume(self.pid)
            except Exception:pass
            self.spawned=False
        if self.script:
            try:self.script.exports_sync.disarm()
            except Exception:pass
        if self.session:
            try:self.session.detach()
            except Exception:pass
            self.session=None
        self.trace.event('controller_closed',pid=self.pid,pendingTickets=list(self.pending),targetLeftRunning=True)


class Handle:
    def __init__(self,driver,id):self.driver,self.id,self.session=driver,id,driver.identity
    def _call(self,command,*args,timeout=5):
        if self.session!=self.driver.identity:raise BackendError('invalid session','Handle belongs to another session')
        return self.driver.call(command,self.id,*args,timeout=timeout)
    def describe(self):return self._call('DESCRIBE')
    def click(self,timeout=5):return self._call('CLICK',timeout=timeout)
    def fill(self,text):return self._call('FILL',text)
    def check(self,checked=True):return self._call('CHECK','true' if checked else 'false')
    def activate(self):return self._call('WINDOW')
    def menu(self,*segments,timeout=10):return self._call('MENU',*segments,timeout=timeout)
    def menu_items(self):return self._call('MENU_ITEMS')
    def file_path(self,path):return self._call('FILE_PATH',str(path))
    def accept_file(self):return self._call('FILE_ACCEPT')
    def cancel_dialog(self):return self._call('DIALOG_CANCEL')


class Locator:
    def __init__(self,driver,name,cls,scope,text='',caption=''):
        self.driver,self.name,self.cls,self.scope=driver,name,cls,scope
        self.text,self.caption=text,caption
    def resolve(self,timeout=3):
        deadline=time.monotonic()+timeout
        while True:
            if time.monotonic()>=deadline:raise BackendError('locator timeout','No matching widget before deadline')
            scope=self.scope.resolve(max(.001,deadline-time.monotonic())).id if isinstance(self.scope,Locator) else (self.scope.id if self.scope else '')
            if time.monotonic()>=deadline:raise BackendError('locator timeout','Scope resolution exhausted the deadline')
            try:return Handle(self.driver,self.driver.call('FIND',scope,self.cls,self.name,self.text,self.caption,timeout=max(.001,deadline-time.monotonic())))
            except BackendError as error:
                if error.code=='timeout before dispatch':raise BackendError('locator timeout','No matching widget before deadline') from error
                if error.code!='no such element':raise
                if time.monotonic()>=deadline:raise BackendError('locator timeout','No matching widget before deadline') from error
                time.sleep(min(.02,max(0,deadline-time.monotonic())))
    def describe(self):return self.resolve().describe()
    def click(self,timeout=5):return self.resolve().click(timeout)
    def fill(self,text):return self.resolve().fill(text)
    def check(self,value=True):return self.resolve().check(value)
    def activate(self):return self.resolve().activate()
    def menu(self,*segments,timeout=10):return self.resolve().menu(*segments,timeout=timeout)
    def file_path(self,path):return self.resolve().file_path(path)
    def accept_file(self):return self.resolve().accept_file()
    def cancel_dialog(self):return self.resolve().cancel_dialog()
    def wait(self,predicate,timeout=3):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            try:
                value=self.resolve(max(.001,deadline-time.monotonic())).describe()
                if predicate(value):return value
            except BackendError as error:
                if error.code not in {'no such element','stale element reference','locator timeout'}:raise
            time.sleep(min(.02,max(0,deadline-time.monotonic())))
        raise BackendError('postcondition timeout','Condition did not become true')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pid',type=int);group.add_argument('--spawn',type=Path)
    parser.add_argument('--probe-only',action='store_true')
    parser.add_argument('--enable-actions',action='store_true')
    parser.add_argument('--include-content',action='store_true')
    parser.add_argument('--show-names',action='store_true',help='Print object names locally; saved logs remain redacted unless include-content is set')
    parser.add_argument('--app-arg',action='append',default=[])
    parser.add_argument('--cwd',type=Path)
    parser.add_argument('--hwnd')
    parser.add_argument('--logs',type=Path,default=Path('logs')/time.strftime('qt3wd-%Y%m%d-%H%M%S'))
    parser.add_argument('--profile',type=Path)
    args=parser.parse_args();trace=Trace(args.logs,args.include_content);driver=None
    try:
        driver=Driver(trace,pid=args.pid,spawn=args.spawn,spawn_args=args.app_arg,cwd=args.cwd,actions=args.enable_actions,hwnd=args.hwnd,
                      profile=args.profile,probe_only=args.probe_only)
        if args.probe_only:print('Fingerprint collected; backend was not loaded.')
        else:
            tree=driver.snapshot();trace.save('tree.json',tree)
            print(f'Connected. Snapshot: {len(tree["objects"])} objects. Actions enabled: {args.enable_actions}.')
            if args.show_names:print(json.dumps(tree,ensure_ascii=True,indent=2))
            print('Use the Python Driver API for explicit actions; CLI inspection performs none.')
        print(f'Logs: {args.logs.resolve()}')
    except Exception as error:
        trace.event('run_failed',errorType=type(error).__name__,errorMessage=str(error))
        print(f'Run stopped: {error}. Logs: {args.logs.resolve()}')
        raise SystemExit(1)
    finally:
        if driver:driver.close()


if __name__=='__main__':main()
