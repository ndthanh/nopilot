"""Summarize traces without treating expected stale-handle probes as workflow failures."""
import argparse
from collections import Counter
import json
from pathlib import Path


def percentile(values,fraction):
    if not values:return None
    values=sorted(values);return values[min(len(values)-1,round((len(values)-1)*fraction))]


def summarize(directory):
    commands=Counter();errors=Counter();events=Counter();queue=[];execution=[];scenarios=[];malformed=0;dropped=0
    for file in sorted(Path(directory).rglob('trace*.jsonl')):
        with file.open(encoding='utf-8') as source:
            for line in source:
                try:row=json.loads(line)
                except ValueError:malformed+=1;continue
                event=row.get('event');events[event]+=1
                if event=='request':commands[row.get('command','unknown')]+=1
                if event=='reply':
                    native=row.get('envelope',{});queue.append(native.get('queueMs',0));execution.append(native.get('executeMs',0))
                    result=native.get('result',{})
                    if 'error' in result:errors[result['error']]+=1
                if event=='scenario_end':scenarios.append(row)
                if event=='native_lifecycle':dropped+=row.get('details',{}).get('dropped',0)
    return {'commands':dict(commands),'nativeErrorCounts':dict(errors),'events':dict(events),
            'queueMs':{'p50':percentile(queue,.5),'p95':percentile(queue,.95),'max':max(queue) if queue else None},
            'executeMs':{'p50':percentile(execution,.5),'p95':percentile(execution,.95),'max':max(execution) if execution else None},
            'scenarios':{'completed':len(scenarios),'passed':sum(r.get('passed') is True for r in scenarios),
                         'failed':sum(r.get('passed') is False for r in scenarios)},
            'lifecycleEventsDropped':dropped,'malformedLines':malformed,
            'interpretation':'Native errors include transient missing elements during waits and intentional stale/missing tests. Only explicit scenario_end records measure workflow outcomes.'}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('logs',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args();result=summarize(a.logs);encoded=json.dumps(result,indent=2,ensure_ascii=False)
    if a.out:a.out.write_text(encoded,encoding='utf-8')
    print(encoded)
