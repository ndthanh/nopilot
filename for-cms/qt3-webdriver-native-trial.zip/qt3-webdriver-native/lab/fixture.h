#ifndef QT3WD_FIXTURE_H
#define QT3WD_FIXTURE_H
#include <qmainwindow.h>
class QLineEdit;
class QLabel;
class QPopupMenu;
class Fixture : public QMainWindow {
    Q_OBJECT
public:
    Fixture();
public slots:
    void activated();
    void replaceInput();
    void openFile();
    void marked();
    void populate();
    void tick();
private:
    QLineEdit *input_;
    QLabel *status_;
    QPopupMenu *tools_;
    int clicks_,generation_,revision_;
};
#endif
