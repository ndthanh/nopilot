#include "fixture.h"
#include <qapplication.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qcheckbox.h>
#include <qlabel.h>
#include <qpopupmenu.h>
#include <qmenubar.h>
#include <qfiledialog.h>
#include <qtimer.h>
#include <stdio.h>
Fixture::Fixture():QMainWindow(0,"fixtureWindow"),clicks_(0),generation_(0),revision_(0) {
    setCaption("Qt3 native backend fixture");resize(640,300);
    input_=new QLineEdit(this,"input");input_->setGeometry(20,55,300,28);input_->setText("initial");
    QLineEdit *password=new QLineEdit(this,"password");password->setEchoMode(QLineEdit::Password);
    password->setText("DO-NOT-LOG-PASSWORD");password->setGeometry(340,55,260,28);
    QPushButton *button=new QPushButton("Activate",this,"button");button->setGeometry(20,100,130,30);
    connect(button,SIGNAL(clicked()),this,SLOT(activated()));
    QPushButton *replace=new QPushButton("Replace input",this,"replace");replace->setGeometry(160,100,150,30);
    connect(replace,SIGNAL(clicked()),this,SLOT(replaceInput()));
    QPushButton *file=new QPushButton("Open file",this,"file");file->setGeometry(320,100,130,30);
    connect(file,SIGNAL(clicked()),this,SLOT(openFile()));
    QCheckBox *check=new QCheckBox("Enabled option",this,"checkbox");check->setGeometry(20,145,250,30);
    status_=new QLabel("ready",this,"status");status_->setGeometry(20,200,600,50);
    QPopupMenu *fileMenu=new QPopupMenu(this,"fileMenu");
    tools_=new QPopupMenu(this,"toolsMenu");
    tools_->insertItem("Mark",this,SLOT(marked()),0,77);
    tools_->insertItem("Open...",this,SLOT(openFile()),0,91);
    connect(tools_,SIGNAL(aboutToShow()),this,SLOT(populate()));
    fileMenu->insertItem("Tools",tools_);
    fileMenu->insertItem("Open...",this,SLOT(openFile()));
    menuBar()->setName("menuBar");menuBar()->insertItem("&File",fileMenu);
    QTimer *timer=new QTimer(this);connect(timer,SIGNAL(timeout()),this,SLOT(tick()));timer->start(50);
}
void Fixture::activated(){status_->setText(QString("clicks:%1").arg(++clicks_));}
void Fixture::replaceInput(){delete input_;input_=new QLineEdit(this,"input");input_->setGeometry(20,55,300,28);input_->setText(QString("generation:%1").arg(++generation_));input_->show();}
void Fixture::marked(){status_->setText(QString("marked:%1").arg(revision_));}
void Fixture::populate(){tools_->removeItem(123);tools_->insertItem(QString("Revision %1").arg(++revision_),123,0);tools_->setItemEnabled(123,false);}
void Fixture::tick(){}
void Fixture::openFile(){
    QFileDialog dialog(this,"fileDialog",true);dialog.setMode(QFileDialog::ExistingFile);
    if(dialog.exec()==QDialog::Accepted)status_->setText("file:"+dialog.selectedFile());
    else status_->setText("file:cancelled");
}
int main(int argc,char **argv){QApplication app(argc,argv);Fixture window;app.setMainWidget(&window);window.setCaption("Qt3 native backend fixture");window.show();printf("fixture-ready\n");fflush(stdout);return app.exec();}
