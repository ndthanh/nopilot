# Codex project instructions — Qt3 Automation Engine

## Current implementation context (2026-11-03)
- The user confirmed the existing Frida PoC is approved and requested a native backend loaded through Frida for user-run trials. Preparing that backend, loader, diagnostics, and lab tests is authorized.
- Current implementation is described by README.md, BUILD.md and docs/EXPERIMENTS.md. The retained research documents include historical proposals.
- Unknown production Qt/compiler ABI must not be guessed. Preserve profile matching and collect fingerprint evidence before preparing another native profile. Do not replace a target Qt DLL or introduce security-control bypasses.

## Mission
Develop a reliable Qt3-native automation research framework for a legacy closed-source Windows 32-bit application, using a reproducible Qt3 test application before any production integration.

## Constraints
- Target application ITC.exe uses `qt-mt.dll` (Qt3, 32-bit). Exact Qt build/compiler ABI remains unverified.
- Existing proof of concept uses Python + Frida JavaScript; two end-to-end workflows have succeeded when Windows is locked, started using Windows Task Scheduler, but failures are estimated at 20–30%.
- Target workstation offers Python and Node.js, but no C++ toolchain. Building native components on a separate dev machine and shipping approved precompiled artifacts is an option.
- Do not assume application source code, debug symbols, Qt plugin support or production permission to load a DLL.
- Cortex XDR quarantined a Frida component on attach to an already-running ITC.exe; do not design EDR evasion. Work on authorized lab applications and require security approval for deployment.
- Do not include real financial/customer data, proprietary binaries, credentials or internal hostnames in the repository.

## Engineering approach
- Favor a Python SDK with lazy, Playwright-inspired locators, a Qt3-aware backend, bounded waits, state verification, and structured JSONL tracing.
- Use selectors and short-lived object identities instead of caching raw QWidget pointers across workflow steps.
- Study QtWebDriver's guarded element references and stale-element handling as patterns; Qt3 uses QGuardedPtr, not modern QPointer.
- All Qt widget interactions must respect GUI-thread affinity and object lifetime. Check for ambiguous outcomes before retrying side-effecting actions.
- Prioritize reproducibility, lifecycle and synchronization tests on a locally controlled Qt3 simulator.
- Treat any illustrative pseudocode in documentation as design intent, not known working APIs.

## Workflow for Codex
1. Read docs/PROJECT_CONTEXT.md, docs/ARCHITECTURE.md and docs/RESEARCH.md.
2. Audit the repo and state verified facts vs hypotheses before implementing.
3. Begin with a feasibility report and test plan for a Qt3 Windows lab, including toolchain/DLL compatibility checks.
4. Create small, testable increments with automated tests; never claim test success without running tests.
5. Keep a changelog of experiments and observed outcomes.
