"""Build the pinned Windows x86 Qt3 lab using local, portable dependencies.

Requires Windows x64, Python 3.10+, curl.exe and tar.exe. No installer is run.
An unused drive letter is temporarily mapped to the work directory and removed.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
GCC_BASE = "https://downloads.sourceforge.net/project/mingw/MinGW/Base/gcc/Version3/Current%20Release_%20gcc-3.4.5-20060117-3/"
INPUTS = {
    "qt3-source.7z": ("https://downloads.sourceforge.net/project/qtwin/Unofficial%20Qtwin/qt-win-3.3.x-8/qt-3.3.x-p8.7z", "f8b50f6cc8ada5d135b5c80dc293e438c2fc61277cff1908a8d6de00e70b22b1"),
    "mingw-3.4.2.exe": ("https://downloads.sourceforge.net/project/qwinreloaded/MinGW-3.4.2.exe", "9c58a17b2f7c2e674e7ac1e542f8be433c8e59a6c03d94249fb88aa0366a3fa2"),
    "gcc-core-3.4.5.tar.gz": (GCC_BASE + "gcc-core-3.4.5-20060117-3.tar.gz", "be73c9428664b891fd45124de5ca78286cae2a6515890838f1347f77d21852ca"),
    "gcc-cpp-3.4.5.tar.gz": (GCC_BASE + "gcc-g%2B%2B-3.4.5-20060117-3.tar.gz", "cb1815cea431d4b5d2809743c617253ff5c1578876ef01a476550a082e484f08"),
    "7z-extra.7z": ("https://www.7-zip.org/a/7z2301-extra.7z", "db3a1cbe57a26fac81b65c6a2d23feaecdeede3e4c1fe8fb93a7b91d72d1094c"),
    "7z2301-x64.exe": ("https://www.7-zip.org/a/7z2301-x64.exe", "26cb6e9f56333682122fafe79dbcdfd51e9f47cc7217dccd29ac6fc33b5598cd"),
}
CONFIGURE = ["-release", "-shared", "-thread", "-no-opengl", "-no-tablet", "-no-sound",
             "-no-imgfmt-mng", "-no-imgfmt-jpeg", "-fast", "-nobuild"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command, *, cwd=None, env=None, log=None):
    print("Running:", subprocess.list2cmdline([str(x) for x in command]), flush=True)
    if log:
        with Path(log).open("w", encoding="utf-8") as output:
            subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, check=True)
    else:
        subprocess.run(command, cwd=cwd, env=env, check=True)


def safe_tar(archive, destination):
    listing = subprocess.check_output(["tar.exe", "-tf", str(archive)], text=True)
    for name in listing.splitlines():
        path = PurePosixPath(name.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts or ":" in name:
            raise ValueError(f"Unsafe archive path: {name}")
    destination.mkdir(parents=True, exist_ok=True)
    run(["tar.exe", "-xf", str(archive), "-C", str(destination)])


def prepare(work, cache):
    cache.mkdir(parents=True, exist_ok=True)
    for name, (url, expected) in INPUTS.items():
        target = cache / name
        bundled = ROOT / "vendor" / name
        if not target.exists() and bundled.exists():
            shutil.copy2(bundled, target)
        if not target.exists():
            run(["curl.exe", "-L", "--fail", "--retry", "2", "--max-time", "600", "-o", str(target), url])
        if sha(target) != expected:
            raise ValueError(f"SHA-256 mismatch for {target}; do not use this artifact")
    if (work / "deps").exists():
        raise ValueError("Prepare requires a new work directory; choose another --work-dir (no files are deleted)")
    deps = work / "deps"
    safe_tar(cache / "7z-extra.7z", deps / "7zip")
    run([str(deps / "7zip" / "7za.exe"), "x", str(cache / "7z2301-x64.exe"), "-o" + str(deps / "7zip-full"), "-y"])
    run([str(deps / "7zip-full" / "7z.exe"), "x", str(cache / "mingw-3.4.2.exe"), "-o" + str(deps / "mingw345"), "-y"])
    # Keep headers/binutils/runtime from the original bundle; replace BOTH GCC
    # core and C++ with their matching upstream 3.4.5 packages.
    safe_tar(cache / "gcc-core-3.4.5.tar.gz", deps / "mingw345")
    safe_tar(cache / "gcc-cpp-3.4.5.tar.gz", deps / "mingw345")
    safe_tar(cache / "qt3-source.7z", deps)
    source = deps / "qt-3.3.x-p8" / "src" / "qt.pro"
    text = source.read_text()
    text, count = re.subn(r"(?m)^VERSION\s*= 3\s*$", "VERSION =", text, count=1)
    if count != 1:
        raise ValueError("Qt DLL naming patch did not match the pinned source")
    text += "\n# Lab: disabled sound must not generate meta-object code for absent QSound.\nHEADERS -= $$KERNEL_H/qsound.h\n"
    source.write_text(text, encoding="utf-8")
    (work / "prepared.json").write_text(json.dumps({name: values[1] for name, values in INPUTS.items()}, indent=2))


def build(work, drive, jobs, resume):
    letter = drive.upper().rstrip(":")
    if not re.fullmatch("[D-Y]", letter):
        raise ValueError("Use an unused drive letter D through Y")
    mapping = letter + ":"
    if Path(mapping + "\\").exists():
        raise ValueError(f"{mapping} is in use; choose another --drive")
    evidence = ROOT / "evidence" / work.name
    evidence.mkdir(parents=True, exist_ok=True)
    run(["subst.exe", mapping, str(work)])
    try:
        base = Path(mapping + "\\")
        qt = base / "deps" / "qt-3.3.x-p8"
        compiler = base / "deps" / "mingw345" / "bin"
        env = os.environ.copy()
        system = Path(os.environ.get("SYSTEMROOT", r"C:\Windows"))
        env.update(QTDIR=str(qt), QMAKESPEC="win32-g++", COMSPEC=str(system / "System32" / "cmd.exe"),
                   PATH=";".join(map(str, [compiler, qt / "bin", system / "System32", system])))
        env.pop("MAKEFLAGS", None)
        run([str(compiler / "g++.exe"), "--version"], env=env, log=evidence / "compiler.log")
        smoke = base / "compiler-smoke.cpp"
        smoke.write_text('#include <iostream>\nint main(){std::cout << "compiler-ok" << std::endl;}\n')
        run([str(compiler / "g++.exe"), str(smoke), "-o", str(base / "compiler-smoke.exe")], env=env)
        run([str(base / "compiler-smoke.exe")], env=env, log=evidence / "compiler-smoke.log")
        if not resume or not (qt / ".qmake.cache").exists():
            run([str(system / "System32" / "cmd.exe"), "/d", "/c", "configure-mingw.bat", *CONFIGURE],
                cwd=qt, env=env, log=evidence / "qt-configure.log")
        parallel = [] if jobs == 1 else [f"-j{jobs}"]
        run([str(compiler / "mingw32-make.exe"), *parallel, "sub-src"],
            cwd=qt, env=env, log=evidence / "qt-build.log")
        if not (qt / "lib" / "qt-mt.dll").exists():
            raise RuntimeError("Qt build did not emit qt-mt.dll; inspect configure/build logs")
        native = base / "probe"
        native.mkdir(exist_ok=True)
        for item in (ROOT / "native").iterdir():
            if item.is_file():
                shutil.copy2(item, native / item.name)
        run([str(qt / "bin" / "qmake.exe"), "probe.pro"], cwd=native, env=env, log=evidence / "probe-qmake.log")
        run([str(compiler / "mingw32-make.exe"), *parallel], cwd=native, env=env, log=evidence / "probe-build.log")
        runtime = ROOT / "runtime"
        runtime.mkdir(exist_ok=True)
        for source in [native / "qt3-lab.exe", qt / "lib" / "qt-mt.dll", compiler / "mingwm10.dll"]:
            shutil.copy2(source, runtime / source.name)
        for source in runtime.glob("*.exe"):
            run([str(compiler / "objdump.exe"), "-p", str(source)], env=env, log=evidence / (source.name + ".pe.txt"))
        run([str(compiler / "objdump.exe"), "-p", str(runtime / "qt-mt.dll")], env=env, log=evidence / "qt-mt.dll.pe.txt")
        shutil.copy2(qt / ".qtwinconfig", evidence / "qtwinconfig.txt")
        shutil.copy2(qt / "include" / "qconfig.h", evidence / "qconfig.h")
        manifest = {"inputs": {n: {"url": u, "sha256": h} for n, (u, h) in INPUTS.items()},
                    "configure": CONFIGURE, "work": str(work), "drive": mapping, "requested_jobs": jobs,
                    "built_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "runtime": {p.name: {"sha256": sha(p), "bytes": p.stat().st_size} for p in runtime.iterdir() if p.is_file()}}
        (evidence / "build-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    finally:
        run(["subst.exe", mapping, "/d"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--cache", type=Path, default=ROOT / "vendor")
    parser.add_argument("--drive", default="Q")
    parser.add_argument("--jobs", type=int, default=1, choices=range(1, 33))
    parser.add_argument("--resume", action="store_true", help="Reuse a prepared build after an interrupted build")
    args = parser.parse_args()
    args.work_dir = args.work_dir.resolve()
    args.work_dir.mkdir(parents=True, exist_ok=True)
    if not args.resume:
        prepare(args.work_dir, args.cache.resolve())
    build(args.work_dir, args.drive, args.jobs, args.resume)
