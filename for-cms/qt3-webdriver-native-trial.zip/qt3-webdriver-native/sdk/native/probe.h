#ifndef QT3_LAB_PROBE_H
#define QT3_LAB_PROBE_H
#include <qmainwindow.h>
#include <qguardedptr.h>
#include <qmap.h>
#include <qserversocket.h>
#include <qsocket.h>
#include <qstringlist.h>
#include <windows.h>

class QLineEdit;
class QPushButton;
class QPopupMenu;
class LabWindow : public QMainWindow {
    Q_OBJECT
public:
    LabWindow(const QString &token);
    QString execute(const QStringList &args);
    QString info() const;
    QString runSelfTests();
public slots:
    void clicked();
    void timerFired();
private:
    QString registerObject(QObject *object);
    QObject *resolve(const QString &id, QString &error);
    void replaceEditor();
    QString token_, nonce_;
    DWORD guiThread_;
    unsigned long nextId_;
    int clicks_, ticks_, generation_;
    QLineEdit *editor_;
    QPushButton *button_;
    QMap<QString, QGuardedPtr<QObject> > handles_;
};

class Connection : public QObject {
    Q_OBJECT
public:
    Connection(int socket, LabWindow *lab, QObject *parent);
public slots:
    void ready();
    void disconnected();
private:
    QSocket *socket_;
    LabWindow *lab_;
};

class Server : public QServerSocket {
public:
    Server(unsigned short port, LabWindow *lab);
    void newConnection(int socket);
private:
    LabWindow *lab_;
};
#endif
