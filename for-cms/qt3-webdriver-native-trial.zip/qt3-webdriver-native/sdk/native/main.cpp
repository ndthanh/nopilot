// New Qt3 feasibility adapter. Pattern reference: Cisco QtWebDriver's
// QElementHandle and getElement(); no QtWebDriver source is compiled here.
#include "probe.h"
#include <qapplication.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qpopupmenu.h>
#include <qmenubar.h>
#include <qdialog.h>
#include <qobjectlist.h>
#include <qtimer.h>
#include <qhostaddress.h>
#include <stdio.h>
#include <new>

static QString quote(const QString &value) {
    QString out = "\"";
    for (unsigned int i=0; i<value.length(); ++i) {
        unsigned short c = value[i].unicode();
        if (c == '"') out += "\\\"";
        else if (c == '\\') out += "\\\\";
        else if (c < 32) out += QString("\\u%1").arg(c,4,16).replace(' ', '0');
        else out += value[i];
    }
    return out + "\"";
}
static QString ok(const QString &json) { return "{\"value\":" + json + "}"; }
static QString fail(const QString &code, const QString &message) {
    return "{\"error\":" + quote(code) + ",\"message\":" + quote(message) + "}";
}
static int hexDigit(char c) {
    if (c>='0' && c<='9') return c-'0';
    if (c>='a' && c<='f') return c-'a'+10;
    if (c>='A' && c<='F') return c-'A'+10;
    return -1;
}
static QString unescape(const QString &value) {
    QCString input=value.latin1(), output(input.length()+1);
    int n=0;
    for (unsigned int i=0; i<input.length(); ++i) {
        if (input[i]=='%' && i+2<input.length() && hexDigit(input[i+1])>=0 && hexDigit(input[i+2])>=0) {
            output[n++]=char(hexDigit(input[i+1])*16+hexDigit(input[i+2])); i+=2;
        } else output[n++]=input[i];
    }
    output[n]=0;
    return QString::fromUtf8(output, n);
}
static QString modulePath() {
    WCHAR path[32768];
    HMODULE module=GetModuleHandleW(L"qt-mt.dll");
    if (!module) return QString::null;
    DWORD n=GetModuleFileNameW(module,path,32768);
    return n && n<32768 ? QString::fromUcs2((unsigned short*)path) : QString::null;
}

LabWindow::LabWindow(const QString &token)
    : QMainWindow(0,"labWindow"), token_(token),
      nonce_(QString::number(GetCurrentProcessId())+"-"+QString::number(GetTickCount())),
      guiThread_(GetCurrentThreadId()), nextId_(0), clicks_(0), ticks_(0), generation_(0) {
    setCaption("Qt3 lifecycle / WebDriver feasibility lab");
    resize(520,160);
    editor_=new QLineEdit(this,"editor");
    editor_->setGeometry(20,45,300,30);
    editor_->setText("generation-0");
    button_=new QPushButton("Activate",this,"activate");
    button_->setGeometry(340,45,140,30);
    connect(button_,SIGNAL(clicked()),this,SLOT(clicked()));
    QTimer *timer=new QTimer(this,"heartbeat");
    connect(timer,SIGNAL(timeout()),this,SLOT(timerFired()));
    timer->start(10);
}
void LabWindow::clicked() { ++clicks_; }
void LabWindow::timerFired() { ++ticks_; }
void LabWindow::replaceEditor() {
    delete editor_;
    ++generation_;
    editor_=new QLineEdit(this,"editor");
    editor_->setGeometry(20,45,300,30);
    editor_->setText(QString("generation-%1").arg(generation_));
    editor_->show();
}
QString LabWindow::registerObject(QObject *object) {
    QMap<QString,QGuardedPtr<QObject> >::Iterator i;
    for (i=handles_.begin(); i!=handles_.end(); ++i)
        if (!i.data().isNull() && (QObject*)i.data()==object) return i.key();
    if (handles_.count()>=4096) return QString::null; // Keep bounded tombstones.
    QString id=nonce_+"-"+QString::number(++nextId_);
    handles_.insert(id,QGuardedPtr<QObject>(object));
    return id;
}
QObject *LabWindow::resolve(const QString &id, QString &error) {
    QMap<QString,QGuardedPtr<QObject> >::Iterator i=handles_.find(id);
    if (i==handles_.end()) { error="no such element"; return 0; }
    if (i.data().isNull()) { error="stale element reference"; return 0; }
    return (QObject*)i.data();
}
QString LabWindow::info() const {
    return "{\"qtCompile\":"+quote(QT_VERSION_STR)+",\"qtRuntime\":"+quote(qVersion())+
        ",\"compiler\":"+quote(__VERSION__)+",\"pointerBits\":"+QString::number(sizeof(void*)*8)+
        ",\"qtModule\":"+quote(modulePath())+",\"guiThread\":"+QString::number(guiThread_)+
        ",\"currentThread\":"+QString::number(GetCurrentThreadId())+
        ",\"clicks\":"+QString::number(clicks_)+",\"ticks\":"+QString::number(ticks_)+
        ",\"generation\":"+QString::number(generation_)+"}";
}
QString LabWindow::runSelfTests() {
    QObject *parent=new QObject(0,"testParent");
    QObject *child=new QObject(parent,"testChild");
    QString old=registerObject(child), error;
    QGuardedPtr<QObject> guard(child);
    delete parent;
    bool parentCascade=guard.isNull() && !resolve(old,error) && error=="stale element reference";
    QString before=registerObject(editor_);
    replaceEditor();
    QString after=registerObject(editor_);
    error=QString::null;
    bool replacement=before!=after && !resolve(before,error) && error=="stale element reference";
    union { double alignment; char bytes[sizeof(QObject)]; } storage;
    QObject *first=new (storage.bytes) QObject(0,"reusedAddress");
    QString firstId=registerObject(first);
    first->~QObject();
    QObject *second=new (storage.bytes) QObject(0,"reusedAddress");
    QString secondId=registerObject(second);
    error=QString::null;
    bool addressReuse=first==second && firstId!=secondId && !resolve(firstId,error)
        && error=="stale element reference";
    second->~QObject();
    QPopupMenu *menu=new QPopupMenu(this,"ephemeralMenu");
    QGuardedPtr<QPopupMenu> menuGuard(menu);
    QString menuId=registerObject(menu);
    menu->insertItem("Synthetic Save",this,SLOT(clicked()),0,73);
    bool menuIndex=menu->idAt(0)==73 && menu->indexOf(73)==0;
    int priorClicks=clicks_;
    menu->activateItemAt(menu->indexOf(73));
    bool menuActivated=clicks_==priorClicks+1;
    delete menu;
    error=QString::null;
    bool menuStale=menuGuard.isNull() && !resolve(menuId,error) && error=="stale element reference";
    QDialog *dialog=new QDialog(this,"ephemeralDialog",false);
    QGuardedPtr<QDialog> dialogGuard(dialog);
    dialog->show(); dialog->hide();
    bool hiddenLive=!dialogGuard.isNull();
    delete dialog;
    bool passed=parentCascade && replacement && addressReuse && menuIndex && menuActivated && menuStale && hiddenLive && dialogGuard.isNull();
    return "{\"passed\":"+QString(passed?"true":"false")+
        ",\"parentCascade\":"+QString(parentCascade?"true":"false")+
        ",\"replacement\":"+QString(replacement?"true":"false")+
        ",\"addressReuse\":"+QString(addressReuse?"true":"false")+
        ",\"menuIdIndex\":"+QString(menuIndex?"true":"false")+
        ",\"menuActivated\":"+QString(menuActivated?"true":"false")+
        ",\"menuDestroyed\":"+QString(menuStale?"true":"false")+
        ",\"hiddenDialogLives\":"+QString(hiddenLive?"true":"false")+
        ",\"dialogDestroyed\":"+QString(dialogGuard.isNull()?"true":"false")+"}";
}
QString LabWindow::execute(const QStringList &args) {
    if (GetCurrentThreadId()!=guiThread_) return fail("unknown error","Wrong GUI thread");
    if (args.count()<2 || args[0]!=token_) return fail("invalid argument","Invalid lab token");
    QString command=args[1];
    if (command=="INFO" && args.count()==2) return ok(info());
    if (command=="SELFTEST" && args.count()==2) return ok(runSelfTests());
    if (command=="REPLACE" && args.count()==2) { replaceEditor(); return ok(info()); }
    if (command=="QUIT" && args.count()==2) {
        QTimer::singleShot(50,qApp,SLOT(quit())); return ok("null");
    }
    if (command=="FIND" && args.count()==4) {
        QObjectList *found=queryList(args[3].isEmpty()?0:args[3].latin1(),args[2].latin1(),false,true);
        int count=found->count();
        QObject *object=count==1?found->first():0;
        delete found;
        if (!count) return fail("no such element","No matching object");
        if (count!=1) return fail("invalid selector","Ambiguous object selector");
        QString id=registerObject(object);
        if (id.isNull()) return fail("unknown error","Lab handle limit reached; restart process");
        return ok(quote(id));
    }
    if ((command=="TEXT" || command=="CLICK") && args.count()==3) {
        QString error;
        QObject *object=resolve(args[2],error);
        if (!object) return fail(error,"Object identity is unavailable");
        if (command=="TEXT") {
            if (object->inherits("QLineEdit")) return ok(quote(((QLineEdit*)object)->text()));
            if (object->inherits("QPushButton")) return ok(quote(((QPushButton*)object)->text()));
            return fail("invalid element state","Text adapter supports line edits and buttons");
        }
        if (!object->inherits("QPushButton")) return fail("invalid element state","Element is not a button");
        QPushButton *button=(QPushButton*)object;
        if (!button->isVisible() || !button->isEnabled() || QApplication::activeModalWidget())
            return fail("element not interactable","Button is hidden, disabled, or blocked by a modal dialog");
        QGuardedPtr<QPushButton> guard(button);
        // Qt3 has animateClick(), but not Qt4/5's synchronous click(). Use
        // widget-local Space events on the GUI thread, without screen coordinates.
        QKeyEvent press(QEvent::KeyPress,Qt::Key_Space,32,0);
        QApplication::sendEvent((QPushButton*)guard,&press);
        if (guard.isNull()) return fail("unknown error","Outcome unknown: receiver destroyed during press");
        QKeyEvent release(QEvent::KeyRelease,Qt::Key_Space,32,0);
        QApplication::sendEvent((QPushButton*)guard,&release);
        // Signal callbacks may destroy the receiver: do not access it again.
        return ok("null");
    }
    return fail("unknown command","Unsupported lab command or argument count");
}

Connection::Connection(int descriptor,LabWindow *lab,QObject *parent)
    : QObject(parent),socket_(new QSocket(this)),lab_(lab) {
    connect(socket_,SIGNAL(readyRead()),this,SLOT(ready()));
    connect(socket_,SIGNAL(connectionClosed()),this,SLOT(disconnected()));
    socket_->setSocket(descriptor);
}
void Connection::disconnected() { deleteLater(); }
void Connection::ready() {
    if (socket_->bytesAvailable()>8192) { socket_->close(); deleteLater(); return; }
    while (socket_->canReadLine()) {
        QString line=socket_->readLine();
        if (line.endsWith("\n")) line.truncate(line.length()-1);
        QStringList args=QStringList::split('\t',line,true);
        for (unsigned int i=0;i<args.count();++i) args[i]=unescape(args[i]);
        QCString result=(lab_->execute(args)+"\n").utf8();
        socket_->writeBlock(result.data(),result.length());
    }
}
Server::Server(unsigned short port,LabWindow *lab)
    : QServerSocket(QHostAddress("127.0.0.1"),port,4,lab),lab_(lab) {}
void Server::newConnection(int descriptor) { new Connection(descriptor,lab_,this); }

int main(int argc,char **argv) {
    QString token;
    unsigned short port=0;
    for (int i=1;i<argc;++i) {
        if (QString(argv[i])=="--token" && i+1<argc) token=argv[++i];
        else if (QString(argv[i])=="--port" && i+1<argc) {
            bool valid=false; unsigned int value=QString(argv[++i]).toUInt(&valid);
            if (!valid || value>65535) return 2;
            port=(unsigned short)value;
        } else { fprintf(stderr,"Usage: qt3-lab.exe --token TOKEN [--port PORT]\n"); return 2; }
    }
    if (token.length()<16) { fprintf(stderr,"Supply a lab token of at least 16 characters\n"); return 2; }
    QApplication app(argc,argv);
    LabWindow lab(token);
    app.setMainWidget(&lab);
    Server server(port,&lab);
    if (!server.ok()) { fprintf(stderr,"Loopback listener failed\n"); return 3; }
    lab.show();
    printf("{\"port\":%u,\"info\":%s}\n",server.port(),lab.info().utf8().data());
    fflush(stdout);
    return app.exec();
}
