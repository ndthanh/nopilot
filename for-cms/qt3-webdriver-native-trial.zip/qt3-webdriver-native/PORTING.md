# Current porting boundary

This milestone implements a Qt3-native widget backend and a small WebDriver-style HTTP facade. Frida only loads/bootstraps the native module and transports commands through its C interface. It does not traverse Qt containers, guess object offsets, invoke Qt C++ member functions from JavaScript, or cache QObject pointers there.

Qt3 adaptation includes `QGuardedPtr` instead of `QPointer`, `name()`/`inherits()`/`queryList()` and Qt3 widget collections instead of modern QObject APIs, key-event button activation instead of a nonexistent synchronous Qt3 `click()`, and `QMenuData` ID/index traversal instead of modern QWidget action lists. `QFileDialog` is handled as a Qt3 widget, separately from Windows native common dialogs.

The provided native binary is tied to the lab SDK. Matching the actual loaded Qt DLL and thread runtime bytes is a conservative admission condition for this binary; a DLL basename or version string is insufficient. The controller also verifies its backend artifact hash before loading it. These hashes do not authenticate a publisher and must not be edited to pretend another Qt build has been tested.

For another Qt3/compiler ABI, collect `fingerprint.json`, establish corresponding source/headers/compiler/build options, compile a separate backend profile, then validate its guards, GUI bootstrap, widget adapters, modal behavior and lifetime tests on a matching self-owned fixture. Runtime QString/container layouts are not parsed from JavaScript to avoid pretending ABI compatibility.

Upstream Cisco QtWebDriver server/session/Chromium dependencies are not ported in this milestone. The native backend and HTTP subset are new implementations of the relevant patterns. The earlier research remains useful as design context, with implementation details and limitations in README.md and docs/EXPERIMENTS.md.
