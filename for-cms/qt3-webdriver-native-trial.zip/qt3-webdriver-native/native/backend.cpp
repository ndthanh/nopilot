// GPL-2.0-or-later. Experimental Qt3 widget backend; no upstream QtWebDriver
// server code is compiled here. Frida transports only this C ABI.
#include "backend.h"
#include <qapplication.h>
#include <qwidget.h>
#include <qwidgetlist.h>
#include <qobjectlist.h>
#include <qlineedit.h>
#include <qbutton.h>
#include <qcheckbox.h>
#include <qpopupmenu.h>
#include <qmenubar.h>
#include <qfiledialog.h>
#include <qlabel.h>
#include <qtimer.h>
#include <qevent.h>
#include <stdio.h>
#include <string.h>

// Present in this pinned threaded Qt3 build. A scalar getter lets bootstrap
// reject a non-Qt GUI thread without reading or calling a QWidget there.
extern Q_EXPORT Qt::HANDLE qt_get_application_thread_id();

enum { SLOTS=32, MAX_REQUEST=8192, MAX_REPLY=262144 };
struct Packet { unsigned long id; int state; DWORD queued,started; char request[MAX_REQUEST]; char reply[MAX_REPLY]; };
static Packet packets[SLOTS];
static CRITICAL_SECTION mutex;
static LONG prepared=0, ready=0;
static unsigned long sequence=0;
static Engine *engine=0;

static QString quote(const QString &s) {
    QString out="\"";
    for (uint i=0;i<s.length();++i) {
        ushort c=s[i].unicode();
        if (c=='"') out+="\\\"";
        else if (c=='\\') out+="\\\\";
        else if (c<32) out+=QString("\\u%1").arg(c,4,16).replace(' ','0');
        else out+=s[i];
    }
    return out+"\"";
}
static QString success(const QString &json) { return "{\"value\":"+json+"}"; }
static QString failure(const QString &code,const QString &message) {
    return "{\"error\":"+quote(code)+",\"message\":"+quote(message)+"}";
}
static QString flag(bool b) { return b?"true":"false"; }
static QString address(QObject *object) { return QString::number((unsigned long)object,16); }
static int hex(char c) { if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1; }
static QString decode(const QString &s) {
    QCString input=s.latin1(),out(input.length()+1); int n=0;
    for(uint i=0;i<input.length();++i) {
        if(input[i]=='%'&&i+2<input.length()&&hex(input[i+1])>=0&&hex(input[i+2])>=0) {out[n++]=char(hex(input[i+1])*16+hex(input[i+2]));i+=2;}
        else out[n++]=input[i];
    }
    out[n]=0; return QString::fromUtf8(out,n);
}
static QString normalized(QString s) {
    s=s.section('\t',0,0).stripWhiteSpace();
    QString out;
    for(uint i=0;i<s.length();++i) {
        if(s[i]=='&') { if(i+1<s.length()&&s[i+1]=='&'){out+='&';++i;} }
        else out+=s[i];
    }
    return out; // Ellipses are significant; do not silently conflate labels.
}
Engine::Engine(bool actions):QObject(qApp,"qt3webdriver.dispatcher"),next_(0),gui_(GetCurrentThreadId()),actions_(actions),destroyed_(0),dropped_(0) {
    nonce_=QString::number(GetCurrentProcessId())+"-"+QString::number(GetTickCount());
    QTimer *timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(pump())); timer->start(10);
}
Engine::~Engine() { InterlockedExchange(&ready,0); }
QString Engine::add(QObject *object) {
    QString key=address(object),id=addresses_[key];
    if(!id.isEmpty()&&handles_.contains(id)&&!handles_[id].isNull()) return id;
    if(handles_.count()>=8192) return QString::null;
    id=nonce_+"-"+QString::number(++next_);
    handles_.insert(id,QGuardedPtr<QObject>(object)); addresses_.insert(key,id);
    connect(object,SIGNAL(destroyed(QObject*)),this,SLOT(destroyedObject(QObject*)));
    lifecycle("registered",id);
    return id;
}
void Engine::lifecycle(const QString &event,const QString &id) {
    if(events_.count()>=512){events_.pop_front();++dropped_;}
    events_.append("{\"event\":"+quote(event)+",\"id\":"+quote(id)+",\"guiThread\":"+QString::number(GetCurrentThreadId())+",\"tickMs\":"+QString::number(GetTickCount())+"}");
}
void Engine::destroyedObject(QObject *object) {
    // Do not read properties during destruction. QGuardedPtr owns invalidation.
    QString key=address(object);lifecycle("destroyed",addresses_[key]);
    addresses_.remove(key); ++destroyed_;
}
QObject *Engine::get(const QString &id,QString &error) {
    if(!handles_.contains(id)) {error="no such element";return 0;}
    if(handles_[id].isNull()) {error="stale element reference";return 0;}
    return (QObject*)handles_[id];
}
QString Engine::describe(QObject *object) {
    QGuardedPtr<QObject> guard(object);
    QString id=add(object);
    if(id.isNull()) return "null";
    QString out="{\"id\":"+quote(id)+",\"class\":"+quote(object->className())+",\"name\":"+quote(object->name());
    if(object->isWidgetType()) {
        QWidget *widget=(QWidget*)object;
        out+=",\"visible\":"+flag(widget->isVisible())+",\"enabled\":"+flag(widget->isEnabled());
        if(widget->isTopLevel()) out+=",\"caption\":"+quote(widget->caption())+",\"active\":"+flag(widget->isActiveWindow());
    }
    if(object->inherits("QLineEdit")) {
        QLineEdit *input=(QLineEdit*)object;
        bool secret=input->echoMode()!=QLineEdit::Normal;
        out+=",\"password\":"+flag(secret)+",\"readOnly\":"+flag(input->isReadOnly());
        if(!secret) out+=",\"text\":"+quote(input->text());
    } else if(object->inherits("QButton")) {
        out+=",\"text\":"+quote(((QButton*)object)->text());
        if(object->inherits("QCheckBox")) out+=",\"checked\":"+flag(((QCheckBox*)object)->isChecked());
    } else if(object->inherits("QLabel")) out+=",\"text\":"+quote(((QLabel*)object)->text());
    return out+"}";
}
void Engine::gather(QObject *root,const QString &parentId,int depth,QStringList &rows,bool &truncated) {
    if(!root||rows.count()>=512||depth>24) {truncated=true;return;}
    QGuardedPtr<QObject> guard(root);
    QString id=add(root);
    if(id.isNull()) {truncated=true;return;}
    // Bulk tree collection intentionally omits text values, including passwords.
    QString row="{\"id\":"+quote(id)+",\"parent\":"+quote(parentId)+",\"depth\":"+QString::number(depth)
        +",\"class\":"+quote(root->className())+",\"name\":"+quote(root->name());
    if(root->isWidgetType()) {QWidget *w=(QWidget*)root;row+=",\"visible\":"+flag(w->isVisible())+",\"enabled\":"+flag(w->isEnabled());}
    rows.append(row+"}");
    const QObjectList *children=root->children();
    if(!children)return;
    QPtrList<QObject> snapshot(*children);
    for(QObject *child=snapshot.first();child;child=snapshot.next()) {
        if(child->isWidgetType()&&((QWidget*)child)->isTopLevel()) continue; // Listed separately as a root.
        gather(child,id,depth+1,rows,truncated);
    }
}
bool Engine::actionable(QWidget *widget,QString &error) {
    if(!widget->isVisible()||!widget->isEnabled()){error="Element is hidden or disabled";return false;}
    QWidget *modal=QApplication::activeModalWidget();
    if(modal&&widget->topLevelWidget()!=modal) {error="Another modal window blocks this element";return false;}
    return true;
}
bool Engine::pressButton(QWidget *widget,QString &error) {
    if(!actionable(widget,error))return false;
    QGuardedPtr<QWidget> guard(widget);
    QKeyEvent down(QEvent::KeyPress,Qt::Key_Space,32,0);
    QApplication::sendEvent(widget,&down);
    if(guard.isNull()){error="Outcome unknown: destroyed during key press";return false;}
    QKeyEvent up(QEvent::KeyRelease,Qt::Key_Space,32,0);
    QApplication::sendEvent((QWidget*)guard,&up);
    return true; // Never access the receiver after activation callbacks.
}
QString Engine::menu(const QStringList &args) {
    if(args.count()<3)return failure("invalid argument","MENU requires a scope ID and path segments");
    QString error; QObject *scope=get(args[1],error);
    if(!scope)return failure(error,"Menu scope is unavailable");
    if(!scope->isWidgetType()||!actionable((QWidget*)scope,error))return failure("element not interactable","Menu scope is hidden, disabled, or blocked by a modal dialog");
    QObjectList *bars=scope->queryList("QMenuBar",0,false,true);
    if(bars->count()!=1) {delete bars;return failure("invalid selector","Scope must contain exactly one menu bar");}
    QGuardedPtr<QObject> owner(bars->first()); delete bars;
    QMenuData *data=(QMenuBar*)(QObject*)owner;
    for(uint part=2;part<args.count();++part) {
        if(owner.isNull())return failure("stale element reference","Menu owner was destroyed");
        int selected=-1,matches=0;
        for(uint index=0;index<data->count();++index) {
            int id=data->idAt(index); QMenuItem *item=data->findItem(id);
            if(item&&!item->isSeparator()&&normalized(data->text(id))==normalized(args[part])) {selected=id;++matches;}
        }
        if(!matches)return failure("no such element","Menu path segment is absent");
        if(matches!=1)return failure("invalid selector","Ambiguous menu path segment");
        if(!data->isItemEnabled(selected)||!data->isItemVisible(selected))return failure("element not interactable","Menu item is disabled or hidden");
        QMenuItem *item=data->findItem(selected);
        QGuardedPtr<QPopupMenu> next(item?item->popup():0);
        if(part+1<args.count()&&next.isNull())return failure("invalid selector","Intermediate menu segment is not a submenu");
        if(part+1==args.count()&&!next.isNull())return failure("invalid selector","Final menu segment is a submenu, not an action");
        data->activateItemAt(data->indexOf(selected)); // Show/populate submenu through Qt's normal behavior.
        if(part+1<args.count()) {
            if(next.isNull())return failure("stale element reference","Submenu replaced while opening; resolve again");
            owner=(QPopupMenu*)next; data=(QPopupMenu*)next;
        }
    }
    return success("{\"dispatched\":true,\"postconditionRequired\":true}");
}
QString Engine::execute(const QStringList &a) {
    if(GetCurrentThreadId()!=gui_)return failure("wrong thread","Command not on GUI thread");
    if(a.isEmpty())return failure("invalid argument","Missing command");
    QString command=a[0];
    if(command=="EVENTS"){
        QString result="{\"events\":["+events_.join(",")+"],\"dropped\":"+QString::number(dropped_)+"}";
        events_.clear();dropped_=0;return success(result);
    }
    if(command=="INFO")return success("{\"qt\":"+quote(qVersion())+",\"guiThread\":"+QString::number(gui_)
        +",\"qtApplicationThread\":"+QString::number((DWORD)qt_get_application_thread_id())
        +",\"currentThread\":"+QString::number(GetCurrentThreadId())+",\"actionsEnabled\":"+flag(actions_)
        +",\"registered\":"+QString::number(handles_.count())+",\"destroyed\":"+QString::number(destroyed_)+"}");
    if(command=="TREE") {
        QStringList rows; bool truncated=false;
        QWidgetList *roots=QApplication::topLevelWidgets();
        for(QWidget *w=roots->first();w;w=roots->next())gather(w,"",0,rows,truncated);
        delete roots;
        return success("{\"objects\":["+rows.join(",")+"],\"truncated\":"+flag(truncated)+"}");
    }
    if(command=="FIND"&&(a.count()==4||a.count()==6)) {
        QObject *scope=0;QString error;
        if(!a[1].isEmpty()){scope=get(a[1],error);if(!scope)return failure(error,"Scope unavailable");}
        QWidgetList *widgets=QApplication::allWidgets(); QObject *match=0;int matches=0;
        for(QWidget *w=widgets->first();w;w=widgets->next()) {
            bool inside=!scope;
            for(QObject *p=w;p&&!inside;p=p->parent()) if(p==scope)inside=true;
            bool selected=inside&&(a[2].isEmpty()||w->inherits(a[2].latin1()))&&(a[3].isEmpty()||QString(w->name())==a[3]);
            if(selected&&a.count()==6&&!a[4].isEmpty()) {
                QString text;
                if(w->inherits("QButton"))text=((QButton*)w)->text();
                else if(w->inherits("QLabel"))text=((QLabel*)w)->text();
                else if(w->inherits("QLineEdit")&&((QLineEdit*)w)->echoMode()==QLineEdit::Normal)text=((QLineEdit*)w)->text();
                selected=text==a[4];
            }
            if(selected&&a.count()==6&&!a[5].isEmpty())selected=w->isTopLevel()&&w->caption()==a[5];
            if(selected){match=w;++matches;}
        }
        delete widgets;
        if(!matches)return failure("no such element","No matching widget");
        if(matches!=1)return failure("invalid selector","Selector is ambiguous");
        QString id=add(match);if(id.isNull())return failure("resource limit","Registry full; restart the test process");
        return success(quote(id));
    }
    if(command=="DESCRIBE"&&a.count()==2){QString error;QObject *o=get(a[1],error);return o?success(describe(o)):failure(error,"Handle unavailable");}
    if(command=="MENU_ITEMS"&&a.count()==2) {
        QString error;QObject *o=get(a[1],error);if(!o)return failure(error,"Handle unavailable");
        QMenuData *menu=0;
        if(o->inherits("QPopupMenu"))menu=(QPopupMenu*)o;else if(o->inherits("QMenuBar"))menu=(QMenuBar*)o;
        if(!menu)return failure("invalid element state","Not a menu");
        QStringList rows;
        for(uint i=0;i<menu->count();++i){int id=menu->idAt(i);QMenuItem *item=menu->findItem(id);
            rows.append("{\"id\":"+QString::number(id)+",\"index\":"+QString::number(i)+",\"text\":"+quote(menu->text(id))
                +",\"enabled\":"+flag(menu->isItemEnabled(id))+",\"submenu\":"+flag(item&&item->popup())+"}");}
        return success("["+rows.join(",")+"]");
    }
    if(!actions_)return failure("actions disabled","Session was started in read-only mode");
    if(command=="MENU")return menu(a);
    if(a.count()<2)return failure("invalid argument","Action requires an element ID");
    QString error;QObject *object=get(a[1],error);
    if(!object)return failure(error,"Handle unavailable");
    if(!object->isWidgetType())return failure("invalid element state","Object is not a widget");
    QGuardedPtr<QWidget> guard((QWidget*)object); QWidget *widget=(QWidget*)object;
    if(command=="WINDOW"&&a.count()==2) {
        if(!widget->isTopLevel())return failure("invalid element state","Expected a top-level window");
        QWidget *modal=QApplication::activeModalWidget();
        if(modal&&modal!=widget)return failure("element not interactable","Another modal window is active");
        if(widget->isMinimized())widget->showNormal();else widget->show();
        if(guard.isNull())return failure("outcome unknown","Destroyed during show");
        guard->raise();if(guard.isNull())return failure("outcome unknown","Destroyed during raise");
        guard->setActiveWindow();
        return success("{\"dispatched\":true}");
    }
    if(!actionable(widget,error))return failure("element not interactable",error);
    if(command=="CLICK"&&a.count()==2) {
        if(!object->inherits("QButton"))return failure("invalid element state","Expected QButton");
        return pressButton(widget,error)?success("{\"dispatched\":true,\"postconditionRequired\":true}"):failure("outcome unknown",error);
    }
    if(command=="FILL"&&a.count()==3) {
        if(!object->inherits("QLineEdit"))return failure("invalid element state","Input adapter supports QLineEdit");
        QLineEdit *input=(QLineEdit*)object;
        if(input->isReadOnly())return failure("invalid element state","Input is read-only");
        input->setText(a[2]);
        if(guard.isNull())return failure("outcome unknown","Destroyed during textChanged");
        return input->text()==a[2]?success("{\"verified\":true}"):failure("outcome unknown","Input value changed during callback");
    }
    if(command=="CHECK"&&a.count()==3) {
        if(!object->inherits("QCheckBox")||(a[2]!="true"&&a[2]!="false"))return failure("invalid argument","CHECK expects a checkbox and true/false");
        QCheckBox *box=(QCheckBox*)object;bool desired=a[2]=="true";
        if(box->isTristate())return failure("unsupported operation","Tristate checkbox needs an explicit state adapter");
        if(box->isChecked()==desired)return success("{\"verified\":true,\"changed\":false}");
        if(!pressButton(box,error)||guard.isNull())return failure("outcome unknown","Checkbox changed or disappeared during activation");
        return box->isChecked()==desired?success("{\"verified\":true,\"changed\":true}"):failure("outcome unknown","Checkbox postcondition failed");
    }
    if(command=="FILE_PATH"&&a.count()==3) {
        if(!object->inherits("QFileDialog"))return failure("unsupported operation","Expected a Qt3 QFileDialog; native Windows dialogs need another adapter");
        QFileDialog *dialog=(QFileDialog*)object;dialog->setSelection(a[2]);
        if(guard.isNull())return failure("outcome unknown","File dialog destroyed during selection");
        return success("{\"selectedFile\":"+quote(dialog->selectedFile())+",\"postconditionRequired\":true}");
    }
    if(command=="FILE_ACCEPT"&&a.count()==2) {
        if(!object->inherits("QFileDialog"))return failure("unsupported operation","Expected a Qt3 QFileDialog");
        // Use the dialog's real default button path, including its validation.
        QKeyEvent enter(QEvent::KeyPress,Qt::Key_Return,13,0);
        QApplication::sendEvent(widget,&enter);
        return success("{\"dispatched\":true,\"postconditionRequired\":true}");
    }
    if(command=="DIALOG_CANCEL"&&a.count()==2) {
        if(!object->inherits("QDialog"))return failure("invalid element state","Expected QDialog");
        QKeyEvent escape(QEvent::KeyPress,Qt::Key_Escape,27,0);QApplication::sendEvent(widget,&escape);
        return success("{\"dispatched\":true}");
    }
    return failure("unsupported operation","Command/type/argument combination is unsupported");
}
void Engine::pump() {
    int selected=-1;char request[MAX_REQUEST];unsigned long id=0;DWORD queued=0,started=0;
    EnterCriticalSection(&mutex);
    for(int i=0;i<SLOTS;++i)if(packets[i].state==1){selected=i;break;}
    if(selected>=0){Packet &p=packets[selected];p.state=2;p.started=GetTickCount();id=p.id;queued=p.queued;started=p.started;strcpy(request,p.request);}
    LeaveCriticalSection(&mutex);
    if(selected<0)return;
    // A nested modal loop must be able to process a later dialog command.
    QTimer::singleShot(0,this,SLOT(pump()));
    QStringList args=QStringList::split('\t',QString::fromLatin1(request),true);
    for(uint i=0;i<args.count();++i)args[i]=decode(args[i]);
    QString result=execute(args);
    QString wrapped="{\"requestId\":"+QString::number(id)+",\"guiThread\":"+QString::number(gui_)
        +",\"queueMs\":"+QString::number((DWORD)(started-queued))+",\"executeMs\":"+QString::number((DWORD)(GetTickCount()-started))
        +",\"result\":"+result+"}";
    QCString bytes=wrapped.utf8();
    EnterCriticalSection(&mutex);
    Packet &packet=packets[selected];
    if(bytes.length()>=MAX_REPLY)strcpy(packet.reply,"{\"result\":{\"error\":\"resource limit\",\"message\":\"Reply too large\"}}");
    else strcpy(packet.reply,bytes.data());
    packet.state=3;
    LeaveCriticalSection(&mutex);
}

extern "C" __declspec(dllexport) int __cdecl qt3wd_prepare() {
    LONG state=InterlockedCompareExchange(&prepared,-1,0);
    if(state==1)return 1;if(state!=0)return 0;
    InitializeCriticalSection(&mutex);InterlockedExchange(&prepared,1);return 1;
}
extern "C" __declspec(dllexport) int __cdecl qt3wd_start(unsigned long hwnd,int actions) {
    if(prepared!=1||!qApp||sizeof(void*)!=4)return -1;
    DWORD pid=0,thread=GetWindowThreadProcessId((HWND)hwnd,&pid);
    if(!thread||pid!=GetCurrentProcessId()||thread!=GetCurrentThreadId())return -2;
    if((DWORD)qt_get_application_thread_id()!=GetCurrentThreadId())return -3;
    if(ready)return 2; // Existing backend retains its original read/action mode.
    engine=new Engine(actions!=0);InterlockedExchange(&ready,1);return 1;
}
extern "C" __declspec(dllexport) unsigned long __cdecl qt3wd_submit(const char *request) {
    if(prepared!=1||ready!=1||!request||strlen(request)>=MAX_REQUEST)return 0;
    EnterCriticalSection(&mutex);unsigned long id=0;
    for(int i=0;i<SLOTS;++i)if(packets[i].state==0){Packet &p=packets[i];id=++sequence;if(!id)id=++sequence;p.id=id;p.state=1;p.queued=GetTickCount();strcpy(p.request,request);break;}
    LeaveCriticalSection(&mutex);return id;
}
extern "C" __declspec(dllexport) int __cdecl qt3wd_poll(unsigned long id,char *output,unsigned long capacity) {
    if(prepared!=1||!output)return -1;int result=-1;
    EnterCriticalSection(&mutex);
    for(int i=0;i<SLOTS;++i)if(packets[i].id==id&&packets[i].state){Packet &p=packets[i];result=0;
        if(p.state==3){if(strlen(p.reply)+1>capacity)result=-2;else {strcpy(output,p.reply);p.state=0;result=1;}}break;}
    LeaveCriticalSection(&mutex);return result;
}
extern "C" __declspec(dllexport) int __cdecl qt3wd_cancel(unsigned long id) {
    if(prepared!=1)return -1;int result=-1;
    EnterCriticalSection(&mutex);
    for(int i=0;i<SLOTS;++i)if(packets[i].id==id&&packets[i].state){Packet &p=packets[i];
        if(p.state==1){p.state=0;result=1;}else result=0;break;}
    LeaveCriticalSection(&mutex);return result; // 0: may have run; reconcile, never replay.
}
