#ifndef QT3WD_BACKEND_H
#define QT3WD_BACKEND_H
#include <qobject.h>
#include <qguardedptr.h>
#include <qmap.h>
#include <qstringlist.h>
#include <windows.h>

class Engine : public QObject {
    Q_OBJECT
public:
    Engine(bool actions);
    ~Engine();
    QString execute(const QStringList &args);
public slots:
    void pump();
    void destroyedObject(QObject *object);
private:
    QString add(QObject *object);
    QObject *get(const QString &id, QString &error);
    QString describe(QObject *object);
    QString menu(const QStringList &args);
    bool actionable(QWidget *widget, QString &error);
    bool pressButton(QWidget *widget, QString &error);
    void lifecycle(const QString &event,const QString &id);
    void gather(QObject *root, const QString &parentId, int depth, QStringList &rows, bool &truncated);
    QMap<QString,QGuardedPtr<QObject> > handles_;
    QMap<QString,QString> addresses_;
    QString nonce_;
    unsigned long next_;
    DWORD gui_;
    bool actions_;
    unsigned long destroyed_;
    QStringList events_;
    unsigned long dropped_;
};
#endif
