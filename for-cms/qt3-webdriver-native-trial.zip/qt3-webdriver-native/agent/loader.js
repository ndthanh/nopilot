'use strict';
// Frida only inventories modules, loads the matched backend, and bootstraps it
// on an observed Windows GUI thread. All QObject access lives in the DLL.
let backend=null, api=null, boot={state:'not-started'}, hooks=[];
function inventory() {
  const modules=Process.enumerateModules();
  const qt=modules.filter(m => /^qt-mt[^\\/]*\.dll$/i.test(m.name));
  return {pid:Process.id,arch:Process.arch,pointerSize:Process.pointerSize,
    modules:modules.map(m=>({name:m.name,path:m.path,size:m.size})),
    qt:qt.map(m=>({name:m.name,path:m.path,size:m.size,version:m.version||null,
      importedModules:[...new Set(m.enumerateImports().map(e=>e.module).filter(Boolean))].sort(),
      exports:m.enumerateExports().map(e=>({name:e.name,type:e.type}))}))};
}
function begin(path, hwndText, actions) {
  if(boot.state!=='not-started')throw new Error('Bootstrap has already been attempted');
  if(Process.platform!=='windows'||Process.arch!=='ia32')throw new Error('Backend requires Windows x86');
  const hwnd=ptr(hwndText), user=Process.getModuleByName('user32.dll');
  const getThread=new NativeFunction(user.getExportByName('GetWindowThreadProcessId'),'uint',['pointer','pointer'],'stdcall');
  const pidOut=Memory.alloc(4),tid=getThread(hwnd,pidOut);
  if(!tid||pidOut.readU32()!==Process.id)throw new Error('Window does not belong to target');
  backend=Module.load(path);
  const fn=(name,result,args)=>new NativeFunction(backend.getExportByName(name),result,args,'mscdecl');
  api={prepare:fn('qt3wd_prepare','int',[]),start:fn('qt3wd_start','int',['ulong','int']),
    submit:fn('qt3wd_submit','ulong',['pointer']),poll:fn('qt3wd_poll','int',['ulong','pointer','ulong']),
    cancel:fn('qt3wd_cancel','int',['ulong'])};
  if(api.prepare()!==1)throw new Error('Transport preparation failed');
  boot={state:'armed',guiThread:tid,hwnd:hwndText};
  let starting=false;
  for(const name of ['PeekMessageW','PeekMessageA','GetMessageW','GetMessageA']) {
    const address=user.findExportByName(name);if(address===null)continue;
    hooks.push(Interceptor.attach(address,{onLeave() {
      if(starting||boot.state!=='armed'||Process.getCurrentThreadId()!==tid)return;
      starting=true;
      try {
        const result=api.start(hwnd.toUInt32(),actions?1:0);
        boot={state:result>0?'ready':'failed',guiThread:tid,startResult:result};
        send({event:'bootstrap',...boot});
      } catch(e) {boot={state:'failed',error:String(e)};send({event:'bootstrap',...boot});}
      setImmediate(()=>{for(const h of hooks)h.detach();hooks=[];});
    }}));
  }
  const post=new NativeFunction(user.getExportByName('PostMessageW'),'bool',['pointer','uint','pointer','pointer'],'stdcall');
  if(!post(hwnd,0,ptr(0),ptr(0)))throw new Error('Could not wake target GUI thread');
  return boot;
}
rpc.exports={
  inventory,
  begin,
  status(){return boot;},
  submit(request){if(boot.state!=='ready')throw new Error('Backend is not initialized');return api.submit(Memory.allocUtf8String(request));},
  poll(id){const buffer=Memory.alloc(262144);const state=api.poll(id,buffer,262144);return {state,reply:state===1?JSON.parse(buffer.readUtf8String()):null};},
  cancel(id){return api.cancel(id);},
  disarm(){for(const h of hooks)h.detach();hooks=[];return {state:'detached-hooks',backendRemainsLoaded:backend!==null};}
};
