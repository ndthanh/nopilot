"""Build the backend and standalone fixture against an existing matching Qt3 SDK."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sdk',type=Path,required=True)
    p.add_argument('--compiler',type=Path,required=True)
    p.add_argument('--work-dir',type=Path,required=True)
    a=p.parse_args()
    sdk,compiler,work=a.sdk.resolve(),a.compiler.resolve(),a.work_dir.resolve()
    work.mkdir(parents=True,exist_ok=True)
    evidence=ROOT/'evidence'/'build';evidence.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env.update(QTDIR=str(sdk),QMAKESPEC='win32-g++',
        PATH=';'.join(map(str,[compiler/'bin',sdk/'bin',Path(r'C:\Windows\System32'),Path(r'C:\Windows')])) )
    manifest={'qt_sha256':hashlib.sha256((sdk/'lib'/'qt-mt.dll').read_bytes()).hexdigest(),'artifacts':{}}
    runtime=ROOT/'runtime';runtime.mkdir(exist_ok=True)
    for folder,pro,artifact in [('native','backend.pro','qt3webdriver.dll'),('lab','fixture.pro','qt3-fixture.exe')]:
        build=work/folder;build.mkdir(exist_ok=True)
        for source in (ROOT/folder).iterdir():
            if source.is_file():shutil.copy2(source,build/source.name)
        with (evidence/(folder+'.log')).open('w',encoding='utf-8') as log:
            for command in [[str(sdk/'bin'/'qmake.exe'),pro],[str(compiler/'bin'/'mingw32-make.exe')]]:
                print(subprocess.list2cmdline(command),flush=True)
                subprocess.run(command,cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        shutil.copy2(build/artifact,runtime/artifact)
    # Qt is packaged only under the fixture folder. Never place this lab Qt DLL
    # beside the backend intended for an existing app, or replace the app's DLL.
    fixture=runtime/'fixture';fixture.mkdir(exist_ok=True)
    shutil.copy2(runtime/'qt3-fixture.exe',fixture/'qt3-fixture.exe')
    for path in [sdk/'lib'/'qt-mt.dll',compiler/'bin'/'mingwm10.dll']:
        shutil.copy2(path,fixture/path.name)
    shutil.copy2(compiler/'bin'/'mingwm10.dll',runtime/'mingwm10.dll')
    for path in runtime.rglob('*'):
        if path.is_file():manifest['artifacts'][str(path.relative_to(runtime))]=hashlib.sha256(path.read_bytes()).hexdigest()
    manifest['profile']='qtwin-p8-mingw345-lab'
    (ROOT/'profiles'/'lab.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (evidence/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
