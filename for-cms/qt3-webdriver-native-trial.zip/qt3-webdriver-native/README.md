# Qt3 native automation backend — bản thử nghiệm 0.2

Đây là backend native C++ cho Qt3, có DLL nạp bằng Frida, Python SDK với lazy locator, HTTP subset kiểu WebDriver và JSONL tracing. Frida làm nhiệm vụ inventory, nạp DLL, bootstrap trên GUI thread và chuyển lệnh qua giao diện C. Việc đọc QObject, quản lý `QGuardedPtr` và thao tác widget nằm trong DLL.

**Đây chưa phải toàn bộ Cisco QtWebDriver được port sang Qt3.** Đây là implementation mới của lớp widget/backend và một phần protocol, dùng các nguyên tắc guarded handle/stale element của QtWebDriver. Không có mã server upstream được biên dịch vào gói này.

**DLL cung cấp hiện chỉ được kiểm chứng với QtWin p8/MinGW 3.4.5 trong lab. Với app thật, cần chạy fingerprint trước rồi build/profile khớp DLL Qt của app. Gói không tự đoán ABI và không có tùy chọn bỏ qua kiểm tra hash.**

## Các thành phần đã có

| Thành phần | Cách thực hiện |
|---|---|
| Window | Tìm theo name/class/caption, giới hạn scope, show/raise/activate; giữ trạng thái maximize nếu không minimized |
| Button | Tìm semantic rồi gửi Space press/release trên GUI thread; không dùng tọa độ màn hình |
| Input | `QLineEdit.setText`, kiểm tra read-only và giá trị sau callback; hỗ trợ Unicode |
| Menu/submenu | Resolve từng đoạn text khi mở, chạy `aboutToShow`, ánh xạ ID sang index hiện tại; không cache menu-item pointer/index qua các bước |
| Checkbox | Kiểm tra trạng thái đích, không bấm nếu đã đúng; kích hoạt một lần rồi xác minh trạng thái |
| File dialog | Qt3 `QFileDialog`: đặt selection, dùng đường default button để xác nhận có validation, hoặc Escape để hủy |
| Object tree | Duyệt bằng API Qt trong process trên GUI thread; tối đa 512 object/24 tầng mỗi snapshot, có cờ truncated |
| Lifecycle | Opaque lifetime ID + `QGuardedPtr`, báo stale riêng với missing; log registered/destroyed |
| Timeout | Hủy được lệnh chưa dispatch; nếu có thể đã chạy, trả `outcome unknown` và ticket để reconcile, không tự replay |

Giới hạn: chưa có adapter cho Windows native common file dialog, `QTextEdit`, custom drawn controls hay checkbox ba trạng thái. Custom Qt dialog có thể thao tác qua các child `QLineEdit`/`QButton` được hỗ trợ. Không giả định native common dialog là `QFileDialog`.

## Cấu trúc

```text
Python SDK / HTTP subset
          ↕
Frida loader: module inventory + C ABI + GUI-thread bootstrap
          ↕
qt3webdriver.dll: queue → GUI dispatcher → guarded registry → widget adapters
          ↕
Qt3 application
```

`runtime/qt3webdriver.dll` là backend. `runtime/fixture/` là app Qt3 độc lập để kiểm thử; app này không biên dịch sẵn adapter. Không chép DLL Qt của fixture sang thư mục app thật và không thay DLL Qt của app thật.

## 1. Chuẩn bị Python

Yêu cầu: Windows, Python 3.10+ và Frida đã được phê duyệt trong môi trường của bạn. Phiên bản đã thử ở đây là Frida 17.25.1 với Python 3.14, điều khiển target x86 từ Python x64. Gói không tự cài thêm dependency trên máy đích.

Nếu môi trường cho phép cài phiên bản được ghi trong gói:

```powershell
python -m pip install -r requirements.txt
```

Nếu đang có Frida phiên bản được phê duyệt khác, ghi lại phiên bản đó cùng log khi thử. Lỗi attach/load sẽ được ghi và dừng; không có retry đổi cơ chế để vượt chặn, đổi tên công cụ hoặc thay đổi thiết lập EDR.

## 2. Bước đầu trên app thật: fingerprint

Với app đang chạy, dùng PID chính xác:

```powershell
python python/qt3wd.py --pid 1234 --probe-only --logs logs/probe-01
```

Nếu bạn chủ động chọn chạy app qua Frida spawn:

```powershell
python python/qt3wd.py --spawn "C:\Path\Application.exe" --probe-only --logs logs/probe-01
```

`--app-arg` có thể lặp lại để truyền tham số. Working directory mặc định là thư mục EXE; có thể đặt `--cwd`. Công cụ không tự chuyển attach thành spawn sau lỗi. Khi kết thúc, controller detach và để app chạy tiếp.

Probe dùng Frida inventory để thu kiến trúc process, tên/hash/version/import modules/exports của Qt và class của các top-level Windows window trong process. Không đọc object tree, không gọi API QObject, không nạp backend native ở chế độ này. Probe vẫn có Frida agent bên trong process theo cơ chế bạn đã phê duyệt.

Các file cần xem/gửi lại:

- `fingerprint.json`: xác định Qt/ABI và hướng build tiếp theo; đường dẫn được che mặc định.
- `trace.jsonl`: phiên bản Frida, các bước kết nối, lỗi và lý do dừng.

Nếu đang có một file dialog gây khó, có thể mở nó bằng tay rồi chạy probe để class cửa sổ được ghi nhận; không thu tiêu đề hoặc nội dung input bằng Win32 collector.

## 3. Đọc cây object khi profile đã khớp

```powershell
python python/qt3wd.py --pid 1234 --logs logs/inspect-01 --show-names
```

Lệnh này kiểm tra x86, đúng một Qt module, hash Qt, hash MinGW runtime và hash backend trước khi `Module.load`. Sau đó bootstrap được thực hiện tại một lần trở về từ Win32 message API trên thread sở hữu cửa sổ. DLL đối chiếu thêm với application thread ID do build Qt3 đã ghi nhận trước khi tạo Qt dispatcher; HWND của một GUI thread khác trong cùng process sẽ bị từ chối.

Nếu nhận `abi unsupported`, giữ `fingerprint.json` và `trace.jsonl` để phân tích. Không sửa hash trong profile để ép nạp. Matching profile phải xuất phát từ build/toolchain/headers tương ứng và kiểm thử thực tế.

`--show-names` chỉ in object names ra console tại máy đang chạy. File `tree.json` và trace vẫn được che nội dung mặc định. Lệnh CLI inspection không tự click/fill. `--enable-actions` là lựa chọn khởi tạo backend ở mode cho phép thao tác, dùng cùng mode với script workflow sau đó.

## 4. Dùng Python SDK cho workflow

Từ thư mục `python/`, ví dụ sau minh họa selector; thay selector bằng kết quả inspection của app của bạn:

```python
from qt3wd import Driver, Trace

trace = Trace("../logs/trial-01")
driver = Driver(trace, pid=1234, actions=True)
try:
    with trace.scenario("workflow-name"):
        window = driver.locator(class_name="QMainWindow", caption="Exact window title")
        window.activate()
        field = driver.locator(class_name="QLineEdit", name="fieldName", scope=window)
        field.fill("test value")
        driver.locator(class_name="QPushButton", text="Button label", scope=window).click()
        driver.locator(class_name="QCheckBox", name="optionName", scope=window).check(True)
        window.menu("File", "Submenu", "Action...")
        driver.drain_events()
        # Thêm kiểm tra postcondition cụ thể của workflow trước khi đánh dấu thành công.
finally:
    driver.close()
```

Name, class, text và caption dùng so khớp chính xác. Selector phải cho đúng một kết quả; không tự chọn phần tử đầu tiên nếu trùng. `scope` có thể là locator để window cũng được resolve lại khi bị tạo lại.

Đối với action mở dialog bằng `exec()`, lệnh mở có thể còn chờ đến khi dialog đóng. Chạy lệnh mở ở một Python thread/future và điều khiển dialog bằng request tiếp theo. GUI dispatcher cho phép xử lý request lồng trong modal loop. Có ví dụ hoàn chỉnh cho fixture tại `python/example_fixture.py`.

```python
dialog = driver.locator(class_name="QFileDialog", name="dialogName")
dialog.file_path(r"C:\TestData\sample.txt")
dialog.accept_file()
```

`accept_file()` xác nhận dispatch; workflow vẫn phải đợi dialog đóng và kiểm tra file/kết quả mong muốn. Với file dialog native Win32, cần adapter khác, không ép dùng API Qt3.

Nếu nhận `BackendError` có `code == "outcome unknown"`, giữ `error.ticket` và gọi `driver.reconcile(ticket)` để lấy kết quả muộn. Sau đó kiểm tra trạng thái nghiệp vụ. Không tự click lại.

## 5. HTTP subset nếu cần client WebDriver

```powershell
python python/http_server.py --pid 1234 --enable-actions --logs logs/http-01
```

Server chỉ bind loopback và in URL cùng bearer token dùng cho phiên chạy. Gửi header `Authorization: Bearer TOKEN`. Token không ghi vào trace.

Các route cơ bản: `GET /status`, `POST /session`, `DELETE /session/{sid}`, `POST /session/{sid}/element`, các route element `text`, `value`, `clear`, `click`, `selected`, `enabled`, `displayed`.

Locator Qt: `{"using":"qt","value":{"name":"inputName","className":"QLineEdit","scope":"optional-exported-window-id"}}`. Có thể dùng thêm `text` hoặc `caption`. CSS chỉ hỗ trợ dạng `QLineEdit[name="inputName"]`. Element IDs xuất ra là ID riêng từng session, không phải pointer hay ID dùng lại giữa các session.

Các extension `POST /session/{sid}/qt/...` nhận `element` là exported ID:

| Route | Body bổ sung |
|---|---|
| `window` | không cần |
| `menu` | `path: ["File", "Tools", "Open..."]` |
| `check` | `checked: true/false` |
| `file/path` | `path: "C:\\TestData\\sample.txt"` |
| `file/accept` | không cần |
| `dialog/cancel` | không cần |

`GET /session/{sid}/qt/tree` lấy snapshot. Server dùng nhiều thread để request đóng dialog vẫn được xử lý trong khi request mở dialog đang chờ. Đây là protocol subset, chưa phải WebDriver server conformant đầy đủ.

## Log và so sánh độ ổn định

Trace ghi run/correlation/request ID, queue/dispatch/reply, GUI thread ID, thời gian queue/execution, lỗi stale/missing/ambiguous, timeout trước dispatch, outcome unknown và reconcile. Lifecycle ring buffer lưu registered/destroyed, tối đa 512 sự kiện giữa hai lần drain; số dropped được ghi rõ. Gọi `drain_events()` định kỳ trong stress run dài. Registry giữ tối đa 8.192 lifetime handles, gồm tombstone; khi đầy phải restart app thử nghiệm.

Text/name/caption/path/arguments được thay bằng độ dài và hash riêng trong run. Password input không trả text, kể cả bật `--include-content`. Bulk tree không thu giá trị text của input. `--include-content` bỏ lớp che nội dung thông thường để debug cục bộ; không gửi các log đó nếu chứa dữ liệu thật.

```powershell
python python/summarize.py logs/trial-01 --out logs/trial-01/summary.json
```

Để so sánh agent cũ với backend native, chạy cùng workflow/dataset/session mode/số lần lặp, và dùng `Trace.scenario(...)` bao quanh workflow ở cả hai cách. Summary tách kết quả workflow khỏi lỗi native; lỗi stale chủ động trong test không phải workflow thất bại. Backend này đã qua kiểm thử lab nhưng chưa có số đo đối chiếu với agent cũ của bạn, nên chưa kết luận nó ổn định hơn trên app thật.

Element chưa xuất hiện trong một lần poll cũng có thể tạo lỗi missing trước khi locator thành công; không lấy tổng lỗi native làm tỷ lệ thất bại workflow. `QGuardedPtr` bảo vệ tham chiếu của backend, không sửa lỗi bên trong Qt hoặc callback của app.

## Chạy lại kiểm thử lab

```powershell
python python/test_native.py
```

Fixture được tạo riêng cho test và được dừng khi test xong. Không chạy test suite này trên app thật. Cả 18 kiểm thử đã qua: attach, spawn, menu đổi nội dung, 100 lần thay input, modal file dialog, timeout/reconcile, HTTP, profile mismatch và che log. Kết quả bản giao xem `RESULTS.json` và thư mục evidence được ghi trong đó.

## Build và vòng đời module

`scripts/build_native.py` nhận `--sdk`, `--compiler`, `--work-dir` để build backend/fixture. Nó tạo profile mới từ hash thực tế. Toolchain đã thử là QtWin p8 + GCC 3.4.5. `sdk/` chứa recipe/source archive của Qt lab từ milestone trước; xem `BUILD.md` để dựng lại. ABI MSVC hoặc Qt3 build khác cần SDK/compiler matching và profile được kiểm chứng riêng.

Sau khi controller detach, DLL và Qt dispatcher vẫn ở trong app đến khi app kết thúc bình thường. Gói không `FreeLibrary` trong lúc Qt có callback sống. Backend giữ mode read-only/actions từ lần khởi tạo đầu tiên; restart app thử nghiệm trước khi đổi mode hoặc thay DLL. Một process chỉ nên có một controller workflow chủ động.

Giới hạn còn lại: chưa kiểm thử app production, ABI của app của bạn, màn hình khóa, clean runtime VM, hoặc độ bền nhiều giờ. Không có DLL replacement, memory-offset guessing hay tính năng vượt kiểm soát bảo mật.
