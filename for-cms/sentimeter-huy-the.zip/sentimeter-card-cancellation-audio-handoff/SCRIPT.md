# Kịch bản huỷ thẻ và thắc mắc dư nợ trả góp — chờ duyệt

Giọng Quynh / Chi. Operator 1.10×; customer 1.12×. Timestamp dưới đây chỉ là dự kiến.

Các điều chỉnh cần duyệt: thống nhất dư nợ 3.294.163 đồng; không làm tròn tiền tất toán; chưa xác nhận huỷ thẻ thành công khi còn dư nợ; ưu đãi giữ thẻ là dữ liệu mock.

## verification
Xác thực và ghi nhận hai yêu cầu: huỷ thẻ, kiểm tra dư nợ trả góp.

| Thời gian trong đoạn | Nhân vật | Lời thoại |
|---|---|---|
| 00:00–00:06 | Tổng đài viên | Em chào chị. Em là Linh Anh, tổng đài Techcombank. Em có thể hỗ trợ gì cho chị ạ? |
| 00:06–00:20 | Khách hàng | Chào chị. Em muốn huỷ thẻ tín dụng. Hôm qua em đến ngân hàng thì được hướng dẫn liên hệ tổng đài. Em cũng đã thanh toán khoản trả góp rồi, nhưng ứng dụng vẫn hiện còn nợ hơn ba triệu đồng. Chị kiểm tra giúp em với ạ. |
| 00:20–00:31 | Tổng đài viên | Dạ, em sẽ kiểm tra khoản thanh toán, dư nợ trả góp và yêu cầu huỷ thẻ của chị. Trước tiên, chị vui lòng đọc số căn cước công dân để em đối chiếu thông tin ạ. |
| 00:31–00:36 | Khách hàng | Căn cước của em là không hai bảy, không chín bốn, không không một, hai ba bốn. |
| 00:36–00:41 | Tổng đài viên | Chị cho em xin họ tên và ngày tháng năm sinh của mình nữa nhé. |
| 00:41–00:47 | Khách hàng | Em là Ngô Thuỳ Chi, sinh ngày mười một tháng hai năm một nghìn chín trăm chín mươi tư. |
| 00:47–00:55 | Tổng đài viên | Dạ, thông tin đã khớp. Để xác định đúng thẻ, chị đọc giúp em sáu số đầu và bốn số cuối của thẻ thôi nhé. |
| 00:55–01:01 | Khách hàng | Sáu số đầu là bốn một hai ba bốn năm, bốn số cuối là sáu bảy tám chín. |
| 01:01–01:04 | Tổng đài viên | Dạ, hạn mức của thẻ này là bao nhiêu ạ? |
| 01:04–01:07 | Khách hàng | Một trăm sáu mươi bảy triệu đồng ạ. |
| 01:07–01:12 | Tổng đài viên | Em đã ghi nhận. Chị cho em biết thêm lý do muốn huỷ thẻ được không ạ? |
| 01:12–01:19 | Khách hàng | Em không còn nhu cầu sử dụng nữa. Nhưng em muốn hiểu vì sao hôm qua đã thanh toán mà vẫn còn dư nợ. |
| 01:19–01:25 | Tổng đài viên | Dạ, em xin phép chị chờ trong giây lát để đối chiếu khoản thanh toán và lịch trả góp nhé. |
| 01:25–01:28 | Khách hàng | Vâng, chị kiểm tra giúp em. |

## request
Giải thích sao kê đã thanh toán khác với dư nợ trả góp còn lại; xác nhận mong muốn huỷ thẻ.

| Thời gian trong đoạn | Nhân vật | Lời thoại |
|---|---|---|
| 00:00–00:14 | Tổng đài viên | Em cảm ơn chị đã chờ. Khoản chị thanh toán ngày mười bốn tháng mười đã được ghi nhận cho dư nợ sao kê kỳ trước. Thẻ còn ba triệu hai trăm chín mươi tư nghìn một trăm sáu mươi ba đồng từ phần trả góp còn lại ạ. |
| 00:14–00:19 | Khách hàng | Nhưng trên ứng dụng báo là em đã hoàn tất thanh toán rồi mà chị? |
| 00:19–00:29 | Tổng đài viên | Dạ, thông báo đó là đã thanh toán hết dư nợ sao kê đã phát hành. Thông báo này chưa bao gồm phần trả góp còn lại sẽ ghi nhận vào kỳ tiếp theo ạ. |
| 00:29–00:35 | Khách hàng | À, em thấy dòng đã thanh toán hết dư nợ sao kê nên tưởng là đã trả hết toàn bộ rồi. |
| 00:35–00:48 | Tổng đài viên | Dạ, ngày chốt sao kê của chị là ngày hai mươi tám hằng tháng. Khoản thanh toán vừa rồi được hạch toán cho sao kê ngày hai mươi tám tháng chín. Còn phần trả góp còn lại thuộc kỳ sao kê tiếp theo. |
| 00:48–00:59 | Khách hàng | Nhưng hôm qua ở quầy, em đã nói là muốn tất toán để huỷ thẻ. Các bạn báo hơn ba triệu, em đã trả rồi. Giờ lại còn hơn ba triệu nữa nên em chưa hiểu. |
| 00:59–01:18 | Tổng đài viên | Dạ, em hiểu điều khiến chị băn khoăn. Theo thông tin em vừa đối chiếu, khoản đã trả được ghi nhận cho sao kê tháng chín. Yêu cầu huỷ chương trình trả góp đã chuyển phần gốc còn lại sang dư nợ thẻ chờ lên sao kê. Đây là hai khoản riêng, không phải khoản thanh toán của chị bị mất hoặc bị tính lại ạ. |
| 01:18–01:22 | Khách hàng | Vậy em còn khoản trả góp cuối đó nữa, đúng không chị? |
| 01:22–01:38 | Tổng đài viên | Dạ đúng ạ. Số dư đang hiển thị là ba triệu hai trăm chín mươi tư nghìn một trăm sáu mươi ba đồng. Trước khi hướng dẫn thanh toán để hoàn tất huỷ thẻ, em sẽ kiểm tra số tiền tất toán chính xác và các khoản có thể còn chờ hạch toán. |
| 01:38–01:42 | Khách hàng | Vâng, em hiểu rồi. Chị hỗ trợ em làm yêu cầu huỷ thẻ nhé. |
| 01:42–01:52 | Tổng đài viên | Dạ, em xác nhận chị muốn huỷ thẻ vì không còn nhu cầu sử dụng. Chị cho em xin phép chờ thêm một chút để kiểm tra điều kiện huỷ thẻ nhé. |
| 01:52–01:55 | Khách hàng | Vâng ạ. |

## resolution
Trình bày ưu đãi giữ thẻ giả lập, tôn trọng quyết định khách và ghi nhận yêu cầu huỷ có điều kiện.

| Thời gian trong đoạn | Nhân vật | Lời thoại |
|---|---|---|
| 00:00–00:10 | Tổng đài viên | Em cảm ơn chị đã chờ. Em thấy thẻ của chị có ưu đãi miễn phí thường niên cho năm tiếp theo. Chị có muốn cân nhắc tiếp tục sử dụng thẻ không ạ? |
| 00:10–00:13 | Khách hàng | Không chị nhé, em vẫn muốn huỷ thẻ. |
| 00:13–00:30 | Tổng đài viên | Dạ, còn một ưu đãi em xin phép thông tin thêm: trong ba mươi ngày tới, nếu chị có ít nhất ba giao dịch với tổng giá trị từ một triệu năm trăm nghìn đồng, chị có thể được tặng một trăm năm mươi nghìn điểm Rewards theo điều kiện chương trình. Chị có muốn cân nhắc không ạ? |
| 00:30–00:33 | Khách hàng | Không ạ, em không còn nhu cầu nữa. |
| 00:33–00:49 | Tổng đài viên | Dạ, em tôn trọng quyết định của chị và ghi nhận yêu cầu huỷ thẻ. Hiện còn dư nợ nên yêu cầu chưa thể được xác nhận hoàn tất ngay. Em sẽ chuyển yêu cầu kiểm tra tất toán để xác nhận số tiền cần thanh toán và điều kiện còn lại cho chị. |
| 00:49–00:54 | Khách hàng | Vậy bây giờ mình mới ghi nhận yêu cầu, chứ thẻ chưa huỷ xong đúng không chị? |
| 00:54–01:07 | Tổng đài viên | Dạ đúng chị. Chỉ khi các điều kiện được đáp ứng và có xác nhận hoàn tất thì mình mới coi thẻ đã huỷ. Chị vẫn cần theo dõi sao kê và thực hiện nghĩa vụ thanh toán trong thời gian chờ xử lý ạ. |
| 01:07–01:10 | Khách hàng | Vâng, chị ghi nhận giúp em nhé. |
| 01:10–01:26 | Tổng đài viên | Dạ, em đã ghi nhận yêu cầu của chị. Chị theo dõi thông báo và các kỳ sao kê tiếp theo để đối chiếu những khoản còn phát sinh. Nếu cần hỗ trợ thêm, chị có thể liên hệ lại tổng đài. Em cảm ơn chị Chi và chúc chị một ngày tốt lành ạ. |
| 01:26–01:29 | Khách hàng | Vâng, cảm ơn chị. Chào chị. |
| 01:29–01:32 | Tổng đài viên | Dạ, em chào chị. |
