# Sentimeter — Card cancellation & installment balance

## Nội dung
- `transcript.vi.json`: transcript tiếng Việt, người nói, timestamp theo từng MP3 cuối.
- `01-verification.mp3`: xác thực khách Ngô Thuỳ Chi và ghi nhận yêu cầu.
- `02-request.mp3`: giải thích khoản đã trả cho sao kê khác với dư nợ trả góp còn lại.
- `03-resolution.mp3`: đề xuất giữ thẻ, tiếp nhận quyết định và ghi nhận yêu cầu huỷ chờ kiểm tra tất toán.
- `playback-manifest.json`: cue UI, gate, hai khoảng hold và contract playback.
- `timeline.aligned.json`: nội dung, dữ kiện mock và timing đã quy đổi sau tăng tốc.
- `alignment/`, `*.vi.vtt`: alignment và phụ đề của mỗi đoạn.
- `script.source.json`, `SCRIPT.md`: nguồn kịch bản đã duyệt; trạng thái/timestamp nguồn vẫn là snapshot lúc review.
- `generation-report.json`, `validation-report.json`, `CHECKSUMS.sha256`: cấu hình, QA và checksum.
- `preview.html`: mở trực tiếp để nghe từng đoạn và xem transcript/cue.

## Playback
Giọng operator Quynh 1.10x, customer Chi 1.12x, giữ cao độ. Đã xử lý tốc độ trong MP3, phát với playbackRate = 1.
Dùng actual_phase_seconds theo audio.currentTime; global call timestamps còn là planned. Không chạy cue theo lịch toàn cuộc gọi ước lượng. Giữ nguyên cấu trúc file khi bàn giao.

Sau đoạn 1: hold kiểm tra dư nợ/sao kê/trả góp. Sau đoạn 2: hold kiểm tra điều kiện đóng thẻ và ưu đãi. Chỉ resume khi check hoàn tất. Hold không nhúng trong MP3. Trước resolution-09 phải có ACK ghi nhận yêu cầu; nếu thất bại, dừng playback trước câu xác nhận đã ghi nhận. Không đánh dấu thẻ CLOSED.

## Dữ kiện
Toàn bộ dữ liệu và ưu đãi là mock. Số dư thống nhất 3.294.163 VND. Không làm tròn hoặc coi số dư hiển thị là báo giá tất toán chính thức. Khoản đã trả là dư nợ sao kê; phần trả góp còn lại thuộc kỳ tiếp theo. Kết thúc là yêu cầu huỷ chờ kiểm tra tất toán, không phải huỷ thẻ hoàn tất. Ưu đãi giữ thẻ cần được nghiệp vụ xác nhận trước dùng thật.

## Giới hạn và tích hợp
Timing lấy từ provider voice segments, rồi quy đổi theo độ dài PCM thực tế sau xử lý tempo, không phải forced alignment mới trên waveform cuối. Nghe và kiểm tra cue trước trình diễn; chưa có kiểm chứng nghe thủ công. Manifest sentimeter-audio-1.0 cần adapter frontend, không tự thay demo hiện có. Preview chỉ phát audio và highlight, không thực thi hành động hay hold. Các hệ thống/gate/action là mô tả ứng dụng, không phải event chuẩn AG-UI trực tiếp.
Không có API key hoặc cache provider trong package.
