# Qt3 native — gói chạy tối thiểu

Gói này dùng Python SDK để thu fingerprint/log và kết nối backend native qua Frida. Đã bỏ app lab, Qt SDK/DLL, source archive Qt, HTTP server và log kiểm thử. Python và Frida cài riêng; không cần compiler để chạy.

## 1. Cài dependency

Yêu cầu Windows và Python 3.10 trở lên. Mở terminal tại thư mục vừa giải nén:

```powershell
python -m pip install -r requirements.txt
```

Frida 17.25.1 là phiên bản đã kiểm thử. Dùng trong môi trường đã được phê duyệt cho Frida.

## 2. Chạy bước đầu trên app thật

Mở app, lấy PID của app trong Task Manager, thay `1234` dưới đây:

```powershell
python python/qt3wd.py --pid 1234 --probe-only --logs logs/probe-01
```

Bước này dùng Frida thu metadata, **chưa nạp DLL backend, chưa đọc QObject và chưa thao tác giao diện**. Gửi lại hai file:

```text
logs/probe-01/fingerprint.json
logs/probe-01/trace.jsonl
```

Không cần gửi EXE/DLL của app hoặc dữ liệu nghiệp vụ.

## 3. Khi có profile tương thích

DLL kèm theo hiện được build cho Qt3 lab, **chưa có ABI của app thật của bạn**. Nếu Qt/runtime không khớp profile, controller sẽ ghi `abi unsupported` và dừng trước khi nạp backend. Không sửa hash trong profile để ép nạp.

Khi profile đã được build/kiểm chứng phù hợp, dùng:

```powershell
python python/qt3wd.py --pid 1234 --logs logs/inspect-01 --show-names
```

Lệnh này lấy cây object, không tự click/fill. Tên object có thể hiện trên console; nội dung trong log vẫn được che mặc định.

Tạo workflow Python trong thư mục `python/`, dựa trên tên/class/caption thực tế đã inspection:

```python
from qt3wd import Driver, Trace

trace = Trace("../logs/trial-01")
driver = Driver(trace, pid=1234, actions=True)
try:
    with trace.scenario("my-workflow"):
        window = driver.locator(class_name="QMainWindow", caption="Exact window title")
        window.activate()
        driver.locator(name="inputName", scope=window).fill("test value")
        # Chọn các thao tác cụ thể và kiểm tra postcondition của workflow tại đây.
        driver.drain_events()
finally:
    driver.close()
```

Backend hỗ trợ window, button, QLineEdit, menu/submenu, checkbox hai trạng thái và Qt3 QFileDialog. Native Windows common file dialog chưa có adapter. Action mở modal dialog có thể chờ đến khi dialog đóng; dùng thread/future riêng cho lệnh mở, rồi điều khiển dialog qua request tiếp theo.

Nếu action trả `outcome unknown`, giữ ticket, dùng `driver.reconcile(ticket)` và kiểm tra kết quả. Không tự bấm lại. Backend giữ mode đọc/thao tác từ lần khởi tạo đầu; restart app thử nghiệm trước khi đổi mode hoặc thay DLL. Khi controller detach, DLL vẫn ở trong app đến khi app kết thúc bình thường.

## Log

```powershell
python python/summarize.py logs/trial-01 --out logs/trial-01/summary.json
```

Log mặc định che text/name/caption/path/arguments. Password không được trả ra. Giữ chế độ mặc định khi gửi log. `--include-content` chỉ dùng nếu bạn chủ động cần debug nội dung cục bộ.

Gói không mang theo `qt-mt.dll` hay `mingwm10.dll`: backend chỉ được nạp nếu Qt và runtime cần thiết **đã có trong process và khớp profile**. Không cài hoặc thay DLL của app thật bằng DLL lab.

## Các file cần thiết

| File | Vai trò |
|---|---|
| `requirements.txt` | Dependency Python |
| `python/qt3wd.py` | Controller, SDK và JSONL tracing |
| `python/summarize.py` | Tổng hợp log |
| `agent/loader.js` | Frida loader/transport |
| `runtime/qt3webdriver.dll` | Backend native |
| `profiles/lab.json` | Hash/profile đã kiểm chứng |
| `native/`, `LICENSE`, `THIRD_PARTY.md` | Source DLL và thông tin nguồn/giấy phép |

Backend đầy đủ đã qua 18 kiểm thử lab, gồm 100 lần thay widget. Gói rút gọn được kiểm tra lại việc probe, nạp DLL và thao tác từ đúng cấu trúc thư mục này. Chưa có đo lường độ ổn định so với agent cũ trên app thật.
