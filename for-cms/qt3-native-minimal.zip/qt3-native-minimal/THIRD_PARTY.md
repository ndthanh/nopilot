# Sources and notices

Backend, Python controller, Frida loader and support scripts are original project code under GPL-2.0-or-later; see LICENSE. Backend source and qmake project are included in native/.

The backend was built against the project's source-built QtWin p8 / MinGW GCC 3.4.5 lab SDK. Qt and MinGW runtime DLLs are not distributed in this minimal package; a validated matching target process must already have its own required modules loaded. The complete SDK/build recipe and corresponding Qt source archive remain in the separate full project package.

Original QtWin source: https://sourceforge.net/projects/qtwin/files/Unofficial%20Qtwin/qt-win-3.3.x-8/qt-3.3.x-p8.7z/download . SHA-256: f8b50f6cc8ada5d135b5c80dc293e438c2fc61277cff1908a8d6de00e70b22b1. Qt source retains its original Trolltech/contributor copyright and GPL/QPL notices.

Frida is an external installed dependency, not bundled here. Its documented module-loading/instrumentation APIs are used without a security-control bypass mechanism: https://frida.re/docs/javascript-api/ .

Cisco QtWebDriver is a design reference for guarded handles and stale elements. This package does not compile or redistribute its server code and is not a complete upstream port.
