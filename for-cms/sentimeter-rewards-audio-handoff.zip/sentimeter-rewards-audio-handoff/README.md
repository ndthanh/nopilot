# Sentimeter — Rewards audio handoff

## Nội dung
- `transcript.vi.json`: lời thoại tiếng Việt, người nói, timestamp cục bộ theo từng MP3 cuối cùng.
- `01-verification.mp3`: xác thực khách hàng.
- `02-request.mp3`: tiếp nhận yêu cầu và xin hold.
- `03-resolution.mp3`: giải thích kết quả sau điều tra.
- `playback-manifest.json`: cue/hành động UI, gate, hold interlude và đường dẫn audio.
- `timeline.aligned.json`: toàn bộ kịch bản, dữ kiện nghiệp vụ, comment và metadata đã cập nhật.
- `alignment/`: alignment từ provider đã quy đổi theo tốc độ; kèm mapping PCM.
- `*.vi.vtt`: phụ đề từng đoạn.
- `generation-report.json`, `validation-report.json`: cấu hình giọng và kết quả kiểm tra kỹ thuật.
- `preview.html`: mở trực tiếp để nghe và xem transcript/cue; không thực thi hành động UI.
- `CHECKSUMS.sha256`: kiểm tra tính toàn vẹn file.

## Giọng và tốc độ
Tổng đài viên Quynh: 1.10x. Khách hàng Chi: 1.12x. Tốc độ đã xử lý sẵn trong MP3, giữ cao độ. Khi phát đặt playbackRate = 1 để tránh tăng tốc lần nữa.

## Nghiệp vụ
A bị huỷ nên không được tích điểm. C xuất hiện giữa A và B, đưa điểm tháng từ 420.000 lên trần 500.000 (thực cộng 80.000). B thanh toán thành công nhưng không còn hạn mức điểm. Tất cả dữ liệu là giả lập.

## Đồng bộ
Dùng audio.currentTime của từng file và actual_phase_seconds của cue. Timestamp call toàn cục còn là planned vì thời gian chờ gate/hold có thể thay đổi. Sau đoạn 2, chạy hold và các bước kiểm tra; chỉ phát đoạn 3 sau khi hoàn tất và operator resume. Hold không được nhúng vào MP3.

Metadata thời gian đã được quy đổi từ provider alignment theo số mẫu PCM thực tế sau chỉnh tốc độ; không phải forced alignment mới trên waveform cuối. Cue dropdown minh hoạ vẫn cần kiểm tra trực quan. Nghe duyệt cách đọc trước trình diễn.

Manifest schema sentimeter-audio-1.0 cần adapter cho frontend cũ, không tự động thay thế manifest cũ. Giữ nguyên cấu trúc thư mục khi chuyển giao. Không có API key, source backend hoặc cache tạo giọng trong package.
