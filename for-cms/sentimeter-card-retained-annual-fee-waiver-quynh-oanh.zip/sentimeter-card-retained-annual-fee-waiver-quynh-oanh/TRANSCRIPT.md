# Card retained — Transcript tiếng Việt

Operator Linh Anh / Quynh 1.10×. Customer Ngô Thuỳ Chi / Oanh 1.12×. Timestamp cục bộ theo MP3 cuối.

## verification

| Thời gian (giây) | Người nói | Lời thoại |
|---|---|---|
| 0.00–4.22 | operator | Em chào chị. Em là Linh Anh, tổng đài Techcombank. Em có thể hỗ trợ gì cho chị ạ? |
| 4.22–15.72 | customer | Chào chị. Em muốn huỷ thẻ tín dụng. Hôm qua em đến ngân hàng thì được hướng dẫn liên hệ tổng đài. Em cũng đã thanh toán rồi, nhưng ứng dụng vẫn hiện còn nợ hơn ba triệu đồng. Chị kiểm tra giúp em với ạ. |
| 15.72–24.67 | operator | Dạ, em sẽ kiểm tra khoản thanh toán, dư nợ trả góp và hỗ trợ yêu cầu của chị. Trước tiên, chị vui lòng đọc số căn cước công dân để em đối chiếu thông tin ạ. |
| 24.67–31.26 | customer | Căn cước của em là không hai bảy, không chín bốn, không không một, hai ba bốn. |
| 31.26–34.32 | operator | Chị cho em xin họ tên và ngày tháng năm sinh của mình nữa nhé. |
| 34.32–39.47 | customer | Em là Ngô Thuỳ Chi, sinh ngày mười một tháng hai năm một nghìn chín trăm chín mươi tư. |
| 39.47–46.10 | operator | Dạ, thông tin đã khớp. Để xác định đúng thẻ, chị đọc giúp em sáu số đầu và bốn số cuối của thẻ thôi nhé. |
| 46.10–53.03 | customer | Sáu số đầu là bốn một hai ba bốn năm, bốn số cuối là sáu bảy tám chín. |
| 53.03–55.79 | operator | Dạ, hạn mức của thẻ này là bao nhiêu ạ? |
| 55.79–57.73 | customer | Một trăm sáu mươi bảy triệu đồng ạ. |
| 57.73–62.02 | operator | Em đã ghi nhận. Chị cho em biết thêm lý do muốn huỷ thẻ được không ạ? |
| 62.02–70.39 | customer | Dạo này em ít dùng thẻ, mà vẫn phải đóng phí thường niên nên em thấy hơi phí. Với lại em chưa hiểu khoản dư nợ đang hiện trên ứng dụng. |
| 70.39–76.36 | operator | Dạ, em hiểu rồi. Em xin phép chị chờ trong giây lát để kiểm tra khoản thanh toán và lịch trả góp nhé. |
| 76.36–78.16 | customer | Vâng, chị kiểm tra giúp em. |

## request

| Thời gian (giây) | Người nói | Lời thoại |
|---|---|---|
| 0.00–10.77 | operator | Em cảm ơn chị đã chờ. Khoản chị thanh toán ngày mười bốn tháng mười đã được ghi nhận cho dư nợ sao kê kỳ trước. Thẻ còn ba triệu hai trăm chín mươi tư nghìn một trăm sáu mươi ba đồng từ phần trả góp còn lại ạ. |
| 10.77–14.06 | customer | Nhưng trên ứng dụng báo là em đã thanh toán hết dư nợ rồi mà chị? |
| 14.06–23.67 | operator | Dạ, thông báo đó có nghĩa là chị đã thanh toán hết dư nợ của sao kê đã phát hành. Phần trả góp còn lại thuộc kỳ tiếp theo nên chưa nằm trong khoản sao kê chị vừa thanh toán ạ. |
| 23.67–30.75 | customer | Hôm qua ở quầy em đã nói muốn tất toán để huỷ thẻ. Em tưởng khoản hơn ba triệu em trả là hết toàn bộ rồi. |
| 30.75–48.51 | operator | Dạ, em hiểu điều khiến chị băn khoăn. Theo thông tin em vừa đối chiếu, khoản đã trả được ghi nhận cho sao kê tháng chín. Yêu cầu huỷ chương trình trả góp đã chuyển phần gốc còn lại sang dư nợ thẻ chờ lên sao kê. Đây là hai khoản riêng, không phải khoản thanh toán của chị bị mất hoặc bị tính lại ạ. |
| 48.51–52.15 | customer | À, vậy là em vẫn còn khoản trả góp cuối đó nữa. |
| 52.15–65.90 | operator | Dạ đúng chị. Số dư đang hiển thị là ba triệu hai trăm chín mươi tư nghìn một trăm sáu mươi ba đồng. Nếu chị muốn thanh toán trước kỳ sao kê, mình cần kiểm tra số tiền tất toán chính xác và các khoản còn chờ hạch toán trước ạ. |
| 65.90–71.98 | customer | Vâng, phần dư nợ thì em hiểu rồi. Còn thẻ thì em ít dùng nên không muốn trả thêm phí thường niên nữa. |
| 71.98–79.54 | operator | Dạ, em ghi nhận phí thường niên là điều chị đang cân nhắc. Em xin phép kiểm tra xem thẻ của chị có chương trình hỗ trợ phù hợp không nhé. |
| 79.54–81.35 | customer | Vâng, chị xem giúp em. |

## resolution

| Thời gian (giây) | Người nói | Lời thoại |
|---|---|---|
| 0.00–9.53 | operator | Em cảm ơn chị đã chờ. Em kiểm tra thấy thẻ của chị đủ điều kiện được miễn phí thường niên cho năm tiếp theo. Với ưu đãi này, chị có muốn giữ lại thẻ để tiếp tục sử dụng khi cần không ạ? |
| 9.53–14.46 | customer | Nghĩa là nếu em giữ thẻ thì năm tiếp theo em không phải trả phí thường niên đúng không chị? |
| 14.46–23.28 | operator | Dạ đúng ạ, ưu đãi áp dụng cho phí thường niên năm tiếp theo của thẻ này. Các khoản dư nợ và phí khác, nếu có, vẫn được áp dụng theo điều kiện sử dụng thẻ ạ. |
| 23.28–27.71 | customer | Còn khoản hơn ba triệu mình vừa nói thì em vẫn phải thanh toán riêng đúng không? |
| 27.71–37.24 | operator | Dạ đúng chị. Ưu đãi miễn phí thường niên không thay đổi khoản dư nợ trả góp còn lại. Chị vẫn cần thanh toán khoản đó theo thông tin và hạn thanh toán trên sao kê ạ. |
| 37.24–42.82 | customer | Vâng, em hiểu. Nếu được miễn phí thường niên năm tiếp theo thì em giữ lại thẻ, không huỷ nữa nhé. |
| 42.82–53.88 | operator | Dạ, em xin xác nhận: chị đồng ý giữ lại thẻ có bốn số cuối sáu bảy tám chín, không tiếp tục yêu cầu huỷ thẻ và đồng ý nhận ưu đãi miễn phí thường niên năm tiếp theo, đúng không ạ? |
| 53.88–56.10 | customer | Đúng rồi chị, chị đăng ký giúp em. |
| 56.10–60.83 | operator | Dạ, chị chờ em một chút để ghi nhận lựa chọn và đăng ký ưu đãi trên hệ thống nhé. |
| 60.83–68.91 | operator | Em đã nhận được xác nhận đăng ký ưu đãi thành công. Em cũng đã ghi nhận chị không tiếp tục yêu cầu huỷ thẻ. Chị giữ lại thẻ để sử dụng khi cần nhé. |
| 68.91–74.99 | customer | Vâng. Còn khoản trả góp thì em sẽ theo dõi sao kê để thanh toán. Cảm ơn chị đã giải thích. |
| 74.99–79.57 | operator | Dạ, em cảm ơn chị Chi đã liên hệ Techcombank. Chúc chị một ngày tốt lành ạ. |
| 79.57–81.29 | customer | Cảm ơn chị. Chào chị. |
| 81.29–82.75 | operator | Dạ, em chào chị. |
