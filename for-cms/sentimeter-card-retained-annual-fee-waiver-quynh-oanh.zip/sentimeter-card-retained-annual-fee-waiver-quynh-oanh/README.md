# Sentimeter — Credit card RETAINED / Annual fee waiver

Khách Ngô Thuỳ Chi ban đầu muốn huỷ thẻ vì ít dùng và phí thường niên. Sau khi được giải thích dư nợ và giới thiệu miễn phí thường niên năm tiếp theo, khách đồng ý GIỮ THẺ. Đây là nhánh RETAINED, khác bundle khách vẫn quyết định huỷ.

## Audio
- Operator Linh Anh: voice Quynh, 1.10x.
- Customer Ngô Thuỳ Chi: voice Oanh, 1.12x (khác voice Chi của case trước).
- Tốc độ đã xử lý trong MP3, giữ cao độ; playbackRate = 1.
- `01-verification.mp3`: xác thực và ghi nhận yêu cầu/lý do.
- `02-request.mp3`: giải thích dư nợ và nhu cầu hỗ trợ phí.
- `03-resolution.mp3`: khách đồng ý giữ thẻ, xác nhận đăng ký ưu đãi.

## File
`transcript.vi.json` có lời thoại, speaker và timestamp từng MP3. `playback-manifest.json` có cue/gate/interlude; `timeline.aligned.json` chứa toàn bộ dữ kiện và comment. `alignment/` có timestamp provider đã quy đổi tốc độ. Mỗi MP3 có VTT. `script.source.json` là kịch bản nguồn đã duyệt. `generation-report.json`, `validation-report.json` và `CHECKSUMS.sha256` để truy vết. Mở `preview.html` để nghe và xem transcript/cue.

## Quy tắc đồng bộ và backend
Dùng actual_phase_seconds theo audio.currentTime của từng đoạn; timestamp call toàn cục chỉ là planned. Hai khoảng hold sau đoạn 1 và 2 không nằm trong MP3; backend quyết định lúc hoàn tất các check và operator resume.
Trong đoạn 3, sau resolution-09 và trước resolution-10, PAUSE chờ cả hai ACK: đăng ký miễn phí thường niên và rút yêu cầu huỷ thẻ. Nếu lỗi, không phát câu xác nhận thành công. Gate được mô tả trong playback_contract.mid_phase_gates. Scheduler phải chặn trước ranh giới lời thoại, không chỉ dựa vào callback timeupdate chậm. Preview là nghe nội dung, không chạy gate hay thao tác backend.
Outcome: Card retained · Annual fee waiver registered. Dư nợ trả góp 3.294.163 VND vẫn phải thanh toán; không bị xoá bởi ưu đãi. Giữ thẻ không tự khôi phục chương trình trả góp đã huỷ. Không thực hiện đóng/khoá thẻ.

## Giới hạn
Dữ liệu khách, ưu đãi và kết quả backend là mock. Không khẳng định chương trình ngân hàng hiện hành. Manifest sentimeter-audio-1.0 cần adapter frontend. Alignment đã được quy đổi theo độ dài PCM sau chỉnh tốc độ, không phải forced alignment mới trên waveform cuối; cần nghe duyệt cách đọc và cue. Chưa kiểm chứng nghe thủ công. Không có API key hoặc cache provider trong ZIP.
