# VROL Visa — native async Playwright

Start with the standalone [deployment guide](DEPLOYMENT.md) and [technical handover](../TECHNICAL_HANDOVER.md) and
[production guide](../PRODUCTION_GUIDE.md). The tracked config.sample.xlsx has
trace_enabled=NO and allow_final_submit=NO; real credentials stay local.

Run commands in **Windows CMD**. Install with `install.cmd`.

| Command | Purpose |
|---|---|
| `run_async_parallel_case_review.cmd` | Run the configured queue, headful |
| `run_vrol_from_ops.cmd "C:\...\manifest.json"` | Consume a paired FC + GUID2PAN input bundle |
| `configure_paths.cmd --otp-dir "D:\VisaOTP" --workers 5` | Configure this project without Dashboard imports |
| `run_scheduled.cmd` | Wait for today's evening READY contract; honor Final Submit config |
| `run_async_native_test.cmd` | Bounded PI-only diagnostic |
| `run_async_case_test.cmd --guid GUID` | Questionnaire diagnostic, forced stop before Final Submit |
| `run_offline_tests.cmd` | Offline regression checks |
| `run_guid_markers.cmd "C:\...\run_id"` | Rebuild markers/review index without opening Visa |

Workers read `async_worker_count` from config.xlsx (sample 5, fallback 3, cap 5).
Each worker owns its tab and popup descendants; there is no global case/PI popup lock.
Chrome and questionnaires maximize before use. OTP is polled from the configured
folder only when Visa requests it. `allow_final_submit=NO` remains the default.

New GUID folders finish as `PI_DOWNLOADED_<GUID>`, `NO_CB_<GUID>`,
`FRAUD_<GUID>`, `CONSUMER_<GUID>` or `REVIEW_REQUIRED_<GUID>`.
PI aggregate copies are in `<run_dir>/documents`; per-GUID evidence is under
`<run_dir>/groups/<OUTCOME>_<GUID>`.

Associated Transactions stops for review with ROL and screenshot, without submitting
that screen. Unresolved case side effects are held against automatic recreation.
After all workers finish, a fresh ROL500 download reconciles the run's output Excel
by invoice/QT, preserving draft decisions and unresolved observations.

Read the [operations and dashboard guide](docs/OPS_INTEGRATION_2026-11-20.md)
for input pairing, reporting, review holds and postflight reconciliation.
The [sync business rules](docs/BUSINESS_RULES_SYNC_13_9_13_1_10_4.md) remain the
reference, with the requested GUID-wide PI=Yes priority and local age recheck.

Historical release notes are in [docs/legacy](docs/legacy).
The sync reference and compatibility modules remain because native code/tests
still use their parsers, matching rules and questionnaire contracts.

Local config, input, OTP, profile, registry and runtime evidence are excluded from
Git. Source checkpoint before cleanup: tag `before-cleanup-2026-11-20` (`65454fe`).
