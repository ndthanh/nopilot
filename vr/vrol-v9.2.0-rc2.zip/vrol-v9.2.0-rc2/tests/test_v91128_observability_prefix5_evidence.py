from pathlib import Path
def test_observability_and_excel_prefix5_gate():
 w=Path('async_runtime/worker.py').read_text(encoding='utf-8')
 e=Path('async_runtime/excel_store.py').read_text(encoding='utf-8')
 assert 'INPUT GROUP | GUID=' in w and 'BOT DECISION |' in w
 assert 'pan_prefix_5_groups_filtered' in e
 assert "full_pan.startswith('5')" not in w
