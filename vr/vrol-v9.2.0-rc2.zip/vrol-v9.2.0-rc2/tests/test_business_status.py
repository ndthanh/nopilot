import json,shutil
from datetime import date,datetime
from pathlib import Path
from zipfile import ZipFile
from unittest.mock import patch
import pytest
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from async_runtime.business_status import BusinessState,groups,result_label,prepare_input_columns
from async_runtime.excel_store import load_groups,CentralWriter
from async_runtime.models import RuntimeEvent

def amend(path,fn):
    wb=load_workbook(path);fn(wb['Sheet1']);wb.save(path);wb.close()

@pytest.mark.parametrize('mark',['SKIP','PI','Review: timeout questionnaire','Assoc D'])
def test_mark_on_ineligible_row_skips_whole_guid_even_requested(case_workbook,mark):
    source=case_workbook([{'GUID':'A'},{'GUID':'A','CHECK SALE':'HOLD'},{'GUID':'B'}])
    amend(source,lambda ws:ws.cell(5,39,mark))
    selected,stats,_=load_groups(source,run_date=date(2026,11,20),requested_guids={'A','B'},mapping={'A':'4111111111111234','B':'4111111111111234'})
    assert [x.guid for x in selected]==['B']
    assert stats['am_marked_groups_skipped']==1
    assert {x['row_no'] for x in stats['exclusions'] if x['reason']=='INPUT_AM_ALREADY_MARKED'}=={4,5}

def test_skip_on_eligible_sale_blocks_whole_guid_but_unmarked_hold_does_not(case_workbook):
    source=case_workbook([{'GUID':'A','INVOICENUM':'123'}, {'GUID':'A','INVOICENUM':'456'},
                          {'GUID':'B'}, {'GUID':'B','CHECK SALE':'HOLD'}])
    amend(source,lambda ws:ws.cell(4,39,'SKIP'))
    selected,_,_=load_groups(source,run_date=date(2026,11,20))
    assert [g.guid for g in selected]==['B'] and selected[0].source_rows==[6]

@pytest.mark.parametrize('result,label',[
    ({'status':'NO_CHARGEBACK_REQUIRED'},'NO_CB'),
    ({'status':'NO_CHARGEBACK_REQUIRED','reason_code':'GROUP_CONTAINS_ASSOC_DISPUTE_D'},'Assoc D'),
    ({'status':'NO_CHARGEBACK_REQUIRED','invoice_results':[{'pi_status':'DOWNLOADED'}]},'PI'),
    ({'status':'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT','issuer_action':'Fraud'},'FRAUD - chờ Final Submit'),
    ({'status':'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT','issuer_action':'Consumer'},'consumer - chờ Final Submit'),
    ({'status':'FINAL_SUBMIT_COMPLETED','issuer_action':'Fraud'},'FRAUD'),
    ({'status':'FINAL_SUBMIT_COMPLETED','issuer_action':'Consumer'},'consumer'),
])
def test_exact_business_labels(result,label):assert result_label(result)==label

def test_writer_master_all_rows_date_case_and_frozen_snapshot(case_workbook,tmp_path):
    master=case_workbook([{'GUID':'G'},{'GUID':'G','CHECK SALE':'HOLD'}])
    frozen=tmp_path/'frozen.xlsx';shutil.copy2(master,frozen);frozen_bytes=frozen.read_bytes()
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'state.db',master,run)
    try:
        working=state.prepare(frozen)
        writer=CentralWriter(working,run/'out.xlsx',run/'events.jsonl',run/'reviewed.txt',1,business_state=state)
        result=dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action='Fraud',rol='1234567890',invoice_results=[])
        writer.apply(RuntimeEvent('CASE_RESULT',guid='G',status=result['status'],data=dict(source_rows=[4],result=result)))
        writer.close()
        wb=load_workbook(master);ws=wb['Sheet1']
        for row in [4,5]:
            assert ws.cell(row,37).value=='1234567890'
            assert ws.cell(row,38).value.date()==date.today()
            assert ws.cell(row,39).value=='FRAUD - chờ Final Submit'
        wb.close()
        assert frozen.read_bytes()==frozen_bytes
        assert (run/'master_backups'/master.name).is_file()
        assert not load_groups(master,run_date=date(2026,11,20))[0]
    finally:state.close()

def test_restore_new_upstream_only_when_identity_matches_and_skip_wins(case_workbook,tmp_path):
    master=case_workbook([{}, {'GUID':'OTHER'}]);run=tmp_path/'run';run.mkdir()
    state=BusinessState(tmp_path/'state.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        working=state.prepare(master)
        assert not load_groups(working,run_date=date(2026,11,20))[0][0].guid=='G'
        amend(master,lambda ws:ws.cell(4,39,'SKIP'))
        working=state.prepare(master)
        assert load_workbook(working)['Sheet1'].cell(4,39).value=='SKIP'
        assert state.sync()['status']=='CONFLICT'
        amend(master,lambda ws:(setattr(ws.cell(4,39),'value',None),ws.cell(4,3,'999999')))
        working=state.prepare(master)
        assert 'G' in {g.guid for g in load_groups(working,run_date=date(2026,11,20))[0]}
    finally:state.close()

def test_live_skip_added_after_contract_and_no_resume_does_not_restore_ledger(case_workbook,tmp_path):
    master=case_workbook([{}]);frozen=tmp_path/'snapshot.xlsx';shutil.copy2(master,frozen)
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        working=state.prepare(frozen,restore=False)
        assert len(load_groups(working,run_date=date(2026,11,20))[0])==1
        amend(master,lambda ws:ws.cell(4,39,'SKIP'))
        working=state.prepare(frozen,restore=False)
        assert not load_groups(working,run_date=date(2026,11,20))[0]
    finally:state.close()

def test_locked_master_defers_but_ledger_survives_and_postflight_rol_merges(case_workbook,tmp_path):
    master=case_workbook([{}]);run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        with patch('async_runtime.business_status.os.replace',side_effect=PermissionError('Excel open')):
            assert state.sync()['status']=='PENDING'
        assert state.records()['G']['label']=='NO_CB'
        output=tmp_path/'postflight.xlsx';shutil.copy2(master,output)
        amend(output,lambda ws:ws.cell(4,37,'1234567890'))
        assert state.sync(output)['status']=='UPDATED'
        wb=load_workbook(master);assert wb['Sheet1'].cell(4,37).value=='1234567890';wb.close()
    finally:state.close()

def test_master_patch_preserves_formula_cache_custom_part_and_cell_style(case_workbook,tmp_path):
    master=case_workbook([{}])
    def style(ws):
        ws['AL4'].fill=PatternFill('solid',fgColor='FFFF00');ws['AO4']='=1+1'
    amend(master,style)
    replacement=tmp_path/'cached.xlsx'
    with ZipFile(master) as src,ZipFile(replacement,'w') as dst:
        for info in src.infolist():
            data=src.read(info.filename)
            if info.filename=='xl/worksheets/sheet1.xml':
                import re
                data=re.sub(rb'(<f>1\+1</f>)\s*<v\s*/>|(<f>1\+1</f>)\s*<v></v>',b'<f>1+1</f><v>2</v>',data)
            dst.writestr(info,data)
        dst.writestr('custom/opaque.bin',b'preserve me')
    replacement.replace(master)
    with ZipFile(master) as src:original={n:src.read(n) for n in src.namelist() if n not in {'xl/worksheets/sheet1.xml','xl/styles.xml'}}
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        assert state.sync()['status']=='UPDATED'
        wb=load_workbook(master,data_only=True);ws=wb['Sheet1'];assert ws['AO4'].value==2;assert ws['AL4'].fill.fgColor.rgb=='00FFFF00';wb.close()
        with ZipFile(master) as src:assert original=={n:src.read(n) for n in original}
    finally:state.close()

def test_registry_cleanup_only_deduplicates(case_workbook,tmp_path):
    source=case_workbook([{}, {'GUID':'LEGACY'}]);run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',source,run)
    registry=tmp_path/'reviewed.txt';registry.write_text('G\nG|123|QT|10.4\nABSENT\nLEGACY\nLEGACY\n')
    try:
        wb=load_workbook(source);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        report=state.cleanup(registry,source)
        # Review 2026-11-20: de-duplicate only; never drop protection for GUIDs
        # absent from today's input or managed by a (possibly different) ledger.
        assert report['registry_before']==5 and registry.read_text()=='ABSENT\nG\nG|123|QT|10.4\nLEGACY\n'
        assert (run/'registry_backups'/registry.name).read_text().startswith('G\n')
    finally:state.close()

def test_concurrent_master_edit_defers_and_original_backup_is_not_replaced(case_workbook,tmp_path):
    master=case_workbook([{}]);run=tmp_path/'run';run.mkdir();original=master.read_bytes()
    state=BusinessState(tmp_path/'s.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close()
        with patch('async_runtime.business_status.file_hash',side_effect=['before','changed']):
            assert state.sync()['status']=='PENDING'
        assert master.read_bytes()==original
        assert state.sync()['status']=='UPDATED'
    finally:state.close()
    backup=run/'master_backups'/master.name
    assert backup.read_bytes()==original
    amend(master,lambda ws:setattr(ws['AM4'],'value',None))
    state=BusinessState(tmp_path/'s.db',master,run)
    # Review 2026-11-20: a user who empties a bot-written AM is not overwritten.
    try:report=state.sync();assert report['status']=='USER_CLEARED' and report['user_cleared']==['G']
    finally:state.close()
    assert backup.read_bytes()==original

def test_existing_rol_and_manual_result_are_not_overwritten(case_workbook,tmp_path):
    master=case_workbook([{}]);run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        wb=load_workbook(master);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED',rol='1234567890'));wb.close()
        amend(master,lambda ws:ws.cell(4,37,'9999999999'))
        assert state.sync()['status']=='CONFLICT'
        wb=load_workbook(master);assert wb['Sheet1']['AK4'].value=='9999999999';assert wb['Sheet1']['AM4'].value is None;wb.close()
    finally:state.close()

def test_narrow_upstream_preflight_never_occupies_am_with_bot_metadata(case_workbook,tmp_path):
    from src.vrol.reports.rol500 import enrich_classified
    from unittest.mock import Mock
    source=case_workbook([{}]);original=source.read_bytes()
    working=prepare_input_columns(source,tmp_path/'working.xlsx')
    output=tmp_path/'enriched.xlsx';enrich_classified(working,[],output,Mock())
    selected,_,_=load_groups(output,run_date=date(2026,11,20))
    assert len(selected)==1
    wb=load_workbook(output);assert wb['Sheet1']['AM2'].value=='CB reject';assert wb['Sheet1']['AM4'].value is None;wb.close()
    assert source.read_bytes()==original

def test_changed_live_identity_blocks_stale_contract_but_explicit_skip_still_wins(case_workbook,tmp_path):
    master=case_workbook([{}]);frozen=tmp_path/'frozen.xlsx';shutil.copy2(master,frozen)
    amend(master,lambda ws:ws.cell(4,4,'13.1'))
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        working=state.prepare(frozen)
        assert (run/'master_input_conflicts.json').is_file() and state.excluded=={'G':'MASTER_INPUT_IDENTITY_CHANGED'}
        assert not load_groups(working,run_date=date(2026,11,20),blocked=state.excluded)[0]
        amend(master,lambda ws:ws.cell(4,39,'SKIP'))
        working=state.prepare(frozen)
        assert not load_groups(working,run_date=date(2026,11,20))[0]
    finally:state.close()


def test_migration_moves_registry_and_holds_into_am_without_touching_existing_am(case_workbook,tmp_path):
    from async_runtime.migrate_registry import main,LEGACY_LABEL
    master=case_workbook([{'GUID':'DONE'},{'GUID':'HELD'},{'GUID':'OLD'},{'GUID':'MANUAL'},{'GUID':'NEW'}])
    amend(master,lambda ws:ws.cell(7,39,'SKIP'))
    registry=tmp_path/'reviewed_guids.txt';registry.write_text('DONE\nOLD|123|QT|10.4\nMANUAL\nABSENT\n',encoding='utf-8')
    holds=tmp_path/'holds';holds.mkdir()
    (holds/'HELD.json').write_text(json.dumps(dict(guid='HELD',disposition='HOLD_REVIEW',reason_code='EXISTING_CASE_REQUIRES_QUESTIONNAIRE_REVIEW',rol='2707000001')),encoding='utf-8')
    run=tmp_path/'runs'/'20261120_010101_x'/'groups'/'PI_DONE';run.mkdir(parents=True)
    (run/'guid_result.json').write_text(json.dumps(dict(guid='DONE',completed_at='20.11.2026 01:02:03',result=dict(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',invoice_results=[{'pi_status':'DOWNLOADED'}]))),encoding='utf-8')
    args=['--master',str(master),'--registry',str(registry),'--holds',str(holds),'--runs',str(tmp_path/'runs'),'--ledger',str(tmp_path/'l.db'),'--report-dir',str(tmp_path/'rep')]
    main(args);assert load_workbook(master)['Sheet1']['AM4'].value is None  # dry run writes nothing
    main(args+['--apply'])
    ws=load_workbook(master)['Sheet1']
    assert ws['AM4'].value=='PI' and ws['AL4'].value.date()==date(2026,11,20)
    assert ws['AM5'].value=='Review: EXISTING_CASE_REQUIRES_QUESTIONNAIRE_REVIEW' and ws['AK5'].value=='2707000001'
    assert ws['AM6'].value==LEGACY_LABEL and ws['AM7'].value=='SKIP' and ws['AM8'].value is None
    assert [g.guid for g in load_groups(master,{g:'4111111111111234' for g in ['DONE','HELD','OLD','MANUAL','NEW']},run_date=date(2026,11,20))[0]]==['NEW']


def test_rol500_chargebacks_become_da_cb_in_am_and_block_later_runs(case_workbook,tmp_path):
    import csv
    from async_runtime.existing_chargebacks import rol500_outcomes,ROL500_LABEL,ROL500_REVERSAL_LABEL
    master=case_workbook([{'GUID':'CB','INVOICENUM':'0356309062957107'},{'GUID':'REV','INVOICENUM':'0306239068254605'},
                          {'GUID':'AMB'},{'GUID':'USER','INVOICENUM':'0111'},{'GUID':'NEW','INVOICENUM':'0222'}])
    def enrich(ws):
        for row,status,rol in [(4,'ALREADY_CHARGEBACK_IN_ROL500','2705853214'),(5,'ALREADY_CHARGEBACK_IN_ROL500','5604474723'),
                               (6,'ROL500_AMBIGUOUS_MULTIPLE_CASES','1 | 2'),(7,'ALREADY_CHARGEBACK_IN_ROL500','2700000007'),(8,'NOT_FOUND_IN_ROL500',None)]:
            ws.cell(row,10,status);ws.cell(row,37,rol)
        ws.cell(7,39,'SKIP')
    enriched=tmp_path/'enriched.xlsx';import shutil;shutil.copy2(master,enriched);amend(enriched,enrich)
    amend(master,lambda ws:ws.cell(7,39,'SKIP'))
    report=tmp_path/'ROL500.csv'
    with report.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(['h']*28)
        w.writerow(['BASE II','Dispute Financial','','','QT','2705853214','','','','','','356309062957107']+['']*16)
        w.writerow(['BASE II','Dispute Financial Reversal','','','QT','5604474723','','','','','','306239068254605']+['']*16)
    items={x['guid']:x for x in rol500_outcomes(enriched,report)}
    assert items['CB']['label']==ROL500_LABEL and items['CB']['rols']==['2705853214']
    assert items['REV']['label']==ROL500_REVERSAL_LABEL and 'AMB' not in items and 'NEW' not in items
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        assert sorted(state.seed_outcomes(list(items.values())))==['CB','REV']  # USER keeps its SKIP
        assert state.sync()['status']=='UPDATED'
        ws=load_workbook(master)['Sheet1']
        assert (ws['AM4'].value,ws['AK4'].value)==(ROL500_LABEL,'2705853214') and ws['AL4'].value.date()==date.today()
        assert ws['AM5'].value==ROL500_REVERSAL_LABEL and ws['AM7'].value=='SKIP' and ws['AM8'].value is None
        selected=load_groups(state.prepare(master),{g:'4111111111111234' for g in ['CB','REV','AMB','USER','NEW']},run_date=date(2026,11,20))[0]
        assert sorted(g.guid for g in selected)==['AMB','NEW']
    finally:state.close()


@pytest.mark.parametrize('result,label',[
    ({'status':'ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED','reason_code':'ASSOCIATED_TRANSACTIONS_SCREEN','issuer_action':'Consumer'},'Có associated transactions'),
    ({'status':'UNDEFINED_CASE','reason_code':'ELIGIBLE_ROW_NOT_UNIQUE','invoice_results':[{'reason_code':'SALE_ROW_NOT_UNIQUE:2'}]},'Nhiều dòng Sale'),
    ({'status':'UNDEFINED_CASE','reason_code':'ELIGIBLE_ROW_NOT_UNIQUE','invoice_results':[{'reason_code':'CASH_ROW_NOT_UNIQUE:2'}]},'Trả user: nhiều Sale/Cash cho một invoice; cần kiểm tra thủ công'),
])
def test_return_to_user_labels_2026_11_21(result,label):
    from async_runtime.guid_markers import classify
    assert result_label(result)==label
    assert ('MULTIPLE_SALE_ROWS' in classify(result)['markers'])==(label=='Nhiều dòng Sale')


def test_multi_rol_ak_written_by_bot_is_not_a_conflict_on_next_sync(case_workbook,tmp_path):
    master=case_workbook([{'GUID':'M','INVOICENUM':'111'},{'GUID':'M','INVOICENUM':'222'}]);run=tmp_path/'run';run.mkdir()
    state=BusinessState(tmp_path/'s.db',master,run)
    try:
        assert state.seed_outcomes([dict(guid='M',label='Đã CB',rols=['2705853239','2705853240'],reason='ALREADY_CHARGEBACK_IN_ROL500')])==['M']
        assert state.sync()['status']=='UPDATED'
        assert load_workbook(master)['Sheet1']['AK4'].value=='2705853239 | 2705853240'
        report=state.sync()  # 2026-11-21 real run: 62 multi-ROL GUIDs were flagged CONFLICT here
        assert report['status']=='UNCHANGED' and report['conflicts']==[]
    finally:state.close()
