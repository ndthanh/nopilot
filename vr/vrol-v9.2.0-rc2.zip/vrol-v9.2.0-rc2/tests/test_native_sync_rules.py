"""Differential business tests against the actual v9.0.60 sync precheck."""
import asyncio, importlib.util
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from src.vrol.transaction_table import TransactionRow
from async_runtime import native_precheck as native

SOURCE=Path(__file__).resolve().parents[2]/'visa-review-v9.0.60/visa-review-v9.0.60/src/review/guid_group.py'
if not SOURCE.is_file():SOURCE=Path(__file__).parent/'fixtures'/'sync_guid_group_v9060.py'
spec=importlib.util.spec_from_file_location('sync_business_reference',SOURCE)
sync=importlib.util.module_from_spec(spec);spec.loader.exec_module(sync)

class Checkbox:
    first=property(lambda self:self)
    def __init__(self):self.checked=False
    def get_by_role(self,*a,**k):return self
    def count(self):return 1
    def check(self):self.checked=True
    def is_checked(self):return self.checked
class AsyncCheckbox(Checkbox):
    async def count(self):return 1
    async def check(self):self.checked=True
    async def is_checked(self):return self.checked
class Rows:
    def __init__(self,count):self.length=count
    def count(self):return self.length
    def nth(self,index):return index
class AsyncRows(Rows):
    async def count(self):return self.length
class Body:
    def __init__(self,rows):self.rows=rows
    def locator(self,*a,**k):return self.rows

def transactions(records,asynchronous):
    result=[]
    for record in records:
        values=dict(tran_type='Sale',pi='No',assoc_dispute='',eci='7')
        values.update(record)
        result.append(TransactionRow(AsyncCheckbox() if asynchronous else Checkbox(),values,record.get('id','123'),''))
    return result

def invoke(monkeypatch,tmp_path,code,records,*,asynchronous=False,items=None):
    module=native if asynchronous else sync;txs=transactions(records,asynchronous)
    body=Body(AsyncRows(len(txs)) if asynchronous else Rows(len(txs)))
    def constant(value):
        if asynchronous:
            async def call(*a,**k):return value
        else:
            def call(*a,**k):return value
        return call
    for name in ['open_transaction_inquiry','fill_transaction_inquiry_pan','wait_transaction_results']:
        monkeypatch.setattr(module,name,constant(body))
    monkeypatch.setattr(module,'fill_transaction_inquiry_start_date',constant((body,'07/23/26')))
    monkeypatch.setattr(module,'click_transaction_inquiry_submit',constant(True))
    monkeypatch.setattr(module,'_no_matching_transaction_message',constant(''))
    monkeypatch.setattr(module,'_transaction_scan_strategy',constant(dict(strategy='DIRECT_DOM',reported_transactions=len(txs))))
    monkeypatch.setattr(module,'schema_from_dom',constant([]))
    if asynchronous:
        async def parse(index,*a):return txs[index]
    else:
        def parse(index,*a):return txs[index]
    monkeypatch.setattr(module,'parse_row_for_code',parse)
    group=dict(guid='G',pan='4111111111111234',start_date='20260723',items=items or [dict(row_no=4,qt='Q',code=code,invoice='000123')])
    fn=module.precheck_guid_group
    args=(SimpleNamespace(screenshot=Mock()),None,group,{},tmp_path/('native' if asynchronous else 'sync'),Mock())
    result=asyncio.run(fn(*args)) if asynchronous else fn(*args)
    return {k:v for k,v in result.items() if not k.startswith('_runtime_')}

@pytest.mark.parametrize('code,records,status,reason',[
 ('10.4',[{}],'READY_FOR_ISSUER_ACTION_REVIEW',None),
 ('13.1',[{'tran_type':'Sale - WT','eci':'5'}],'READY_FOR_ISSUER_ACTION_REVIEW',None),
 ('13.9',[{'tran_type':'Cash'}],'READY_FOR_ISSUER_ACTION_REVIEW',None),
 ('10.4',[{'pi':'Yes','eci':'5','assoc_dispute':'D'},{'tran_type':'Credit'}],'READY_FOR_PI_EVIDENCE_REVIEW',None),
 ('13.1',[{'pi':'YES'},{'tran_type':'Credit'}],'READY_FOR_PI_EVIDENCE_REVIEW',None),
 ('13.9',[{'tran_type':'Cash','pi':'Yes'},{'tran_type':'Cash Rev'}],'READY_FOR_PI_EVIDENCE_REVIEW',None),
 ('13.1',[{},{'tran_type':'Credit'}],'NO_CHARGEBACK_REQUIRED','GROUP_REJECT_TRAN_TYPE'),
 ('13.9',[{'tran_type':'Cash'},{'tran_type':'Cash Rev'}],'NO_CHARGEBACK_REQUIRED','GROUP_REJECT_TRAN_TYPE'),
 ('10.4',[{'assoc_dispute':'D'}],'NO_CHARGEBACK_REQUIRED','GROUP_CONTAINS_ASSOC_DISPUTE_D'),
 ('13.1',[{'assoc_dispute':'M'}],'UNDEFINED_CASE','UNDEFINED_ASSOC_DISPUTE_VALUE'),
 ('10.4',[{'eci':''}],'NO_CHARGEBACK_REQUIRED','GROUP_REJECT_MOTO_ECI'),
 ('10.4',[{'eci':'5'}],'NO_CHARGEBACK_REQUIRED','GROUP_REJECT_MOTO_ECI'),
 ('10.4',[{'eci':'6'}],'NO_CHARGEBACK_REQUIRED','GROUP_REJECT_MOTO_ECI'),
 ('10.4',[{'pi':'','response_code':'05'}],'READY_FOR_ISSUER_ACTION_REVIEW',None),
 ('13.1',[{'tran_type':'Sale - WT'},{'tran_type':'Sale Dispute Financial - WT'}],'READY_FOR_ISSUER_ACTION_REVIEW',None),
 ('13.1',[{'tran_type':'Auth'}],'NO_CHARGEBACK_REQUIRED','NO_MATCHING_SALE_TRANSACTION'),
])
def test_native_matches_sync(monkeypatch,tmp_path,code,records,status,reason):
    old=invoke(monkeypatch,tmp_path,code,records)
    new=invoke(monkeypatch,tmp_path,code,records,asynchronous=True)
    if any(str(x.get('pi','')).casefold()=='yes' for x in records):
        # User override adds GUID-wide discovery and explicit transaction identity.
        assert new['status']==old['status']
        assert new['issuer_action_required']==old['issuer_action_required']==False
    elif reason=='NO_MATCHING_SALE_TRANSACTION':
        assert old['reason_code']=='ELIGIBLE_ROW_NOT_UNIQUE'
        assert new['issuer_action_required'] is False
    elif new['status']=='NO_CHARGEBACK_REQUIRED':
        # User-confirmed labels and veto-before-uniqueness supersede the legacy
        # descriptive payload; routing/selected identities still match sync.
        keys=['status','decision','issuer_action_required','reason_code','selected_count_before_stop','selected_transaction_ids']
        assert {k:new.get(k) for k in keys}=={k:old.get(k) for k in keys}
    else:assert new==old
    assert new['status']==status and new.get('reason_code')==reason

@pytest.mark.parametrize('pi_position',[0,2])
def test_pi_overrides_group_stop_before_or_after_invoice(monkeypatch,tmp_path,pi_position):
    items=[dict(row_no=4,qt='Q1',code='13.1',invoice='000123'),dict(row_no=5,qt='Q2',code='13.1',invoice='000456'),dict(row_no=6,qt='Q3',code='13.1',invoice='000789')]
    records=[{'id':'123'},{'id':'456'},{'id':'456','tran_type':'Credit'},{'id':'789'}]
    records[0 if pi_position==0 else 3]['pi']='Yes'
    old=invoke(monkeypatch,tmp_path,'13.1',records,items=items)
    new=invoke(monkeypatch,tmp_path,'13.1',records,asynchronous=True,items=items)
    assert old['status']=='NO_CHARGEBACK_REQUIRED'
    assert new['status']=='READY_FOR_PI_EVIDENCE_REVIEW'
    assert new['pi_pending_count']==1 and not new['issuer_action_required']
    assert len(new['invoice_results'])==3

@pytest.mark.parametrize('veto',[{'assoc_dispute':'D'},{'tran_type':'Credit'}])
@pytest.mark.parametrize('reverse',[False,True])
def test_group_veto_beats_other_invoice_multiple_sales(monkeypatch,tmp_path,veto,reverse):
    items=[dict(row_no=4,qt='Q1',code='13.1',invoice='123'),dict(row_no=5,qt='Q2',code='13.1',invoice='456')]
    records=[{'id':'123'},{'id':'123'},{'id':'456',**veto}]
    result=invoke(monkeypatch,tmp_path,'13.1',records,asynchronous=True,items=list(reversed(items)) if reverse else items)
    assert result['status']=='NO_CHARGEBACK_REQUIRED'
    assert result['reason_code']==('GROUP_CONTAINS_ASSOC_DISPUTE_D' if 'assoc_dispute' in veto else 'GROUP_REJECT_TRAN_TYPE')
    assert not result['issuer_action_clicked'] and result['selected_count_before_stop']==0

@pytest.mark.parametrize('pi',[False,True])
def test_explicit_truncated_300_is_manual_backlog_but_pi_still_first(monkeypatch,tmp_path,pi):
    async def text(*a):return '300+ Transactions Found. Only the first 300 matching transactions are returned.'
    monkeypatch.setattr(native,'_transaction_result_text',text)
    result=invoke(monkeypatch,tmp_path,'13.1',[dict(pi='Yes' if pi else 'No')],asynchronous=True)
    assert result['status']==('READY_FOR_PI_EVIDENCE_REVIEW' if pi else 'MANUAL_REVIEW_REQUIRED')
    if not pi:assert result['reason_code']=='TRANSACTION_RESULTS_TRUNCATED_300_PLUS'

@pytest.mark.parametrize('records',[
    [{'pi':'Yes'},{'id':'123-02'}],
    [{'pi':'Yes','tran_type':'Auth'}],
    [{'pi':'Yes'},{'pi':'Yes','id':'123-02'}],
])
def test_pi_bypasses_sale_uniqueness_and_type(monkeypatch,tmp_path,records):
    old=invoke(monkeypatch,tmp_path,'13.1',records)
    new=invoke(monkeypatch,tmp_path,'13.1',records,asynchronous=True)
    assert old['status']=='UNDEFINED_CASE'
    assert new['status']=='READY_FOR_PI_EVIDENCE_REVIEW'
    assert new['pi_pending_count']==sum(x.get('pi')=='Yes' for x in records)

def test_pi_auth_and_sale_for_same_invoice_download_financial_once(monkeypatch,tmp_path):
    new=invoke(monkeypatch,tmp_path,'13.1',[{'id':'123','pi':'Yes','tran_type':'Auth'},
        {'id':'123-01','pi':'Yes','tran_type':'Sale'}],asynchronous=True)
    assert new['pi_pending_count']==1
    assert new['invoice_results'][0]['transaction_id']=='123-01'
    assert new['invoice_results'][0]['tran_type']=='Sale'


@pytest.mark.parametrize('code,records,label',[
    ('10.4',[{'eci':''}],'lỗi dữ liệu - ECI = 5/6/blank'),
    ('10.4',[{'eci':'5'}],'lỗi dữ liệu - ECI = 5/6/blank'),
    ('10.4',[{'eci':'6'}],'lỗi dữ liệu - ECI = 5/6/blank'),
    ('10.4',[{'assoc_dispute':' D '}],'Duplicate - assoc dispute = D'),
    ('13.1',[{'assoc_dispute':'D'}],'Duplicate - assoc dispute = D'),
    ('13.9',[{'tran_type':'Cash','assoc_dispute':'D'}],'Duplicate - assoc dispute = D'),
    ('10.4',[{'tran_type':'Credit'}],'Refund - tran type = Credit'),
    ('13.1',[{'tran_type':'Credit'}],'Refund - tran type = Credit'),
    ('13.9',[{'tran_type':'Cash Rev'}],'Refund - tran type = Cash Rev'),
    ('13.1',[{'assoc_dispute':'D'},{'id':'123-02'}],'Duplicate - assoc dispute = D'),
])
def test_user_confirmed_non_submit_labels_before_uniqueness(monkeypatch,tmp_path,code,records,label):
    result=invoke(monkeypatch,tmp_path,code,records,asynchronous=True)
    assert result['status']=='NO_CHARGEBACK_REQUIRED' and result['cb_reject']==label
    assert not result['issuer_action_required'] and not result['issuer_action_clicked']


@pytest.mark.parametrize('code,tran_type',[('10.4','Sale'),('13.1','Sale'),('13.9','Cash')])
@pytest.mark.parametrize('eci',['','5','6'])
def test_pi_yes_overrides_all_user_non_submit_conditions(monkeypatch,tmp_path,code,tran_type,eci):
    refund='Cash Rev' if code=='13.9' else 'Credit'
    result=invoke(monkeypatch,tmp_path,code,[dict(tran_type=tran_type,pi='Yes',eci=eci,assoc_dispute='D'),dict(tran_type=refund)],asynchronous=True)
    assert result['status']=='READY_FOR_PI_EVIDENCE_REVIEW'
    assert result['pi_pending_count']==1 and not result['issuer_action_required']


@pytest.mark.parametrize('code,tran_type',[('13.1','Sale'),('13.9','Cash')])
@pytest.mark.parametrize('eci',['','5','6'])
def test_eci_gate_is_exclusive_to_excel_code_104(monkeypatch,tmp_path,code,tran_type,eci):
    result=invoke(monkeypatch,tmp_path,code,[dict(tran_type=tran_type,eci=eci)],asynchronous=True)
    assert result['status']=='READY_FOR_ISSUER_ACTION_REVIEW'
