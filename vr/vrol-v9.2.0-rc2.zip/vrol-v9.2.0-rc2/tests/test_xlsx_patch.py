import re
from datetime import date
from zipfile import ZipFile
from openpyxl import Workbook,load_workbook
from async_runtime.xlsx_patch import patch_cells

def test_patch_sparse_rows_and_namespaces_preserves_untouched_row_bytes(tmp_path):
    original=tmp_path/'original.xlsx';wb=Workbook();ws=wb.active;ws.title='Sheet1';ws['A4']='Original';ws['A10']='=1+1';wb.save(original);epoch=wb.epoch;wb.close()
    source=tmp_path/'prefixed.xlsx'
    with ZipFile(original) as zin,ZipFile(source,'w') as zout:
        for info in zin.infolist():
            data=zin.read(info.filename)
            if info.filename=='xl/worksheets/sheet1.xml':
                data=re.sub(rb'<(/?)([A-Za-z][\w]*)(?=[\s/>])',rb'<\1x:\2',data)
                data=data.replace(b'xmlns=',b'xmlns:x=',1).replace(b'<x:worksheet ',b'<x:worksheet xmlns:extra="urn:test-extra" ',1)
                data=data.replace(b'<x:row r="4"',b'<x:row extra:keep="yes" r="4"')
                data=data.replace(b'<x:f>1+1</x:f><x:v></x:v>',b'<x:f>1+1</x:f><x:v>2</x:v>')
            if info.filename=='xl/styles.xml':
                data=re.sub(rb'<(/?)([A-Za-z][\w]*)(?=[\s/>])',rb'<\1s:\2',data).replace(b'xmlns=',b'xmlns:s=',1)
            zout.writestr(info,data)
    target=tmp_path/'patched.xlsx'
    patch_cells(source,target,'Sheet1',dict(AL4=date(2026,11,20),AM4='PI',AK8='1234567890',AM20='NO_CB'),epoch)
    with ZipFile(source) as zin,ZipFile(target) as zout:
        a=zin.read('xl/worksheets/sheet1.xml');b=zout.read('xl/worksheets/sheet1.xml')
        assert re.search(rb'<x:row r="10".*?</x:row>',a).group()==re.search(rb'<x:row r="10".*?</x:row>',b).group()
        assert b'extra:keep="yes"' in b
    wb=load_workbook(target,data_only=False);ws=wb['Sheet1']
    assert ws['A10'].value=='=1+1' and ws['AK8'].value=='1234567890'
    assert ws['AL4'].value.date()==date(2026,11,20) and ws['AM20'].value=='NO_CB'
    assert ws.max_row==20 and ws.max_column==39;wb.close()

def test_patch_empty_sheet_inserts_sheet_data_rows(tmp_path):
    source=tmp_path/'empty.xlsx';wb=Workbook();wb.active.title='Sheet1';epoch=wb.epoch;wb.save(source);wb.close()
    target=tmp_path/'result.xlsx';patch_cells(source,target,'Sheet1',{'AM4':'SKIP'},epoch)
    wb=load_workbook(target);assert wb['Sheet1']['AM4'].value=='SKIP';wb.close()

def test_rows_in_extension_payload_are_preserved_when_inserting_missing_row(tmp_path):
    from xml.etree import ElementTree as ET
    source=tmp_path/'original.xlsx';wb=Workbook();wb.active.title='Sheet1';wb.active['A4']='Original';epoch=wb.epoch;wb.save(source);wb.close()
    extended=tmp_path/'extension.xlsx';opaque=b'<extra:row r="20"><extra:c>keep exactly</extra:c></extra:row>'
    with ZipFile(source) as zin,ZipFile(extended,'w') as zout:
        for info in zin.infolist():
            data=zin.read(info.filename)
            if info.filename=='xl/worksheets/sheet1.xml':
                data=data.replace(b'<worksheet ',b'<worksheet xmlns:extra="urn:test-extension" ',1)
                data=data.replace(b'</worksheet>',b'<extLst><ext uri="test">'+opaque+b'</ext></extLst></worksheet>')
            zout.writestr(info,data)
    target=tmp_path/'result.xlsx';patch_cells(extended,target,'Sheet1',{'AM20':'NO_CB'},epoch)
    with ZipFile(target) as z:
        xml=z.read('xl/worksheets/sheet1.xml');assert opaque in xml
        ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        cells=ET.fromstring(xml).findall('s:sheetData/s:row/s:c',ns)
        assert any(c.attrib['r']=='AM20' for c in cells)


def test_new_date_style_clones_xf_node_without_deepcopy_of_document(tmp_path):
    """2026-11-21 rehearsal: deepcopy(minidom node) walked the whole styles.xml -> RecursionError."""
    from datetime import date
    from openpyxl import Workbook, load_workbook
    from async_runtime.xlsx_patch import patch_cells
    source=tmp_path/'s.xlsx';target=tmp_path/'t.xlsx'
    wb=Workbook();ws=wb.active;ws.title='Sheet1'
    for r in range(1,300):ws.cell(r,1,f'x{r}')
    wb.save(source);epoch=wb.epoch;wb.close()
    src=(__import__('pathlib').Path(__file__).resolve().parents[1]/'async_runtime'/'xlsx_patch.py').read_text(encoding='utf-8')
    assert 'deepcopy(' not in src and 'cloneNode(True)' in src
    patch_cells(source,target,'Sheet1',{f'AL{r}':date(2026,11,21) for r in range(4,300)},epoch)
    ws=load_workbook(target)['Sheet1'];assert ws['AL4'].value.date()==date(2026,11,21) and ws['AL4'].number_format!='General'
