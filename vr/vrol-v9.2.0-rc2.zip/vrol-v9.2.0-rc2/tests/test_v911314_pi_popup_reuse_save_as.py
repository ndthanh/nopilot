from pathlib import Path

def test_pi_popup_supports_reused_page():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 assert 'def _open_pi_detail_popup' in t and 'PI DETAIL POPUP READY' in t

def test_download_uses_direct_chrome_folder():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 assert 'Browser.setDownloadBehavior' in t and 'download.save_as' not in t[t.index('def download_pi_document'):t.index('def _transaction_count_from_page')]
