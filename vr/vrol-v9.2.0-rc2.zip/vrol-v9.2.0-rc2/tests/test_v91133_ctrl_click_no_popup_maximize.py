from pathlib import Path
def test_base_and_worker_vrol_use_ctrl_click():
 t=Path('async_runtime/browser.py').read_text(encoding='utf-8')
 base=t[t.index('async def open_vrol('):t.index('async def open_vrol_worker_tab_from_portal')]
 worker=t[t.index('async def open_vrol_worker_tab_from_portal'):t.index('async def close_report_windows')]
 assert "link.click(modifiers=['Control'])" in base and "link.click(modifiers=['Control'])" in worker
# Maximize behavior is covered by test_native_window.py and the headful local
# probe: primary windows and questionnaire only; ordinary popups stay native.
