from pathlib import Path

def test_rol500_does_not_use_first_for_duplicate_submenus():
    text=Path('async_runtime/rol500_preflight.py').read_text(encoding='utf-8')
    segment=text[text.index('async def _open_parameters'):text.index('async def download')]
    assert "vrol.locator('a[data-menu-id=\"reportmenu_sub3\"]').first" not in segment
    assert "await _visible_match(vrol,'a[data-menu-id=\"reportmenu_sub3\"]'" in segment
    assert "await _visible_match(vrol,'a[data-js*=\"reportSid/33\"]',10000)" in segment
    assert 'matches.nth(index)' in text
