import asyncio,json
from datetime import datetime,timedelta
from unittest.mock import Mock
import pytest
from async_runtime import scheduled_input


def manifest(root,name,fc,gp,**extra):
    folder=root/name;folder.mkdir()
    data=dict(schema='vrol-input/1',status='READY',business_date=fc.date().isoformat(),
        source_fc_completed_at=fc.isoformat(),source_guid2pan_completed_at=gp.isoformat(),**extra)
    path=folder/'manifest.json';path.write_text(json.dumps(data));return path


def test_evening_selection_ignores_morning_and_old_metadata(tmp_path,monkeypatch):
    now=datetime.now(scheduled_input.VIETNAM).replace(hour=19,minute=40)
    morning=now.replace(hour=8)
    manifest(tmp_path,'morning',morning,morning)
    old=tmp_path/'old';old.mkdir();(old/'manifest.json').write_text(json.dumps(dict(status='READY',business_date=now.date().isoformat())))
    valid=manifest(tmp_path,'evening',now-timedelta(minutes=5),now-timedelta(minutes=2))
    monkeypatch.setattr(scheduled_input,'validate_contract',lambda p:None)
    assert scheduled_input.select_contract(tmp_path,now=now)==valid.resolve()


def test_corrupt_newest_does_not_fall_back_to_valid_older_bundle(tmp_path,monkeypatch):
    now=datetime.now(scheduled_input.VIETNAM).replace(hour=20)
    manifest(tmp_path,'old',now-timedelta(minutes=10),now-timedelta(minutes=10))
    latest=manifest(tmp_path,'new',now-timedelta(minutes=1),now-timedelta(minutes=1))
    def validate(path):
        assert path==latest
        raise ValueError('VROL_INPUT_SNAPSHOT_CHANGED:mapping')
    monkeypatch.setattr(scheduled_input,'validate_contract',validate)
    with pytest.raises(ValueError,match='SNAPSHOT_CHANGED'):scheduled_input.select_contract(tmp_path,now=now)


def test_waiting_monitor_and_timeout_before_login(tmp_path):
    monitor=Mock();log=Mock()
    with pytest.raises(RuntimeError,match='SCHEDULED_INPUT_TIMEOUT'):
        asyncio.run(scheduled_input.wait_for_contract(dict(scheduled_input_wait_seconds=.02,scheduled_input_poll_seconds=.01),tmp_path,monitor,log))
    assert monitor.update.call_args.kwargs['stage']=='WAITING_INPUT'


def test_waiter_observes_late_atomic_publication(tmp_path,monkeypatch):
    path=tmp_path/'ready.json';calls=[]
    def select(*args):
        calls.append(1)
        if len(calls)<2:raise ValueError('WAITING')
        return path
    monkeypatch.setattr(scheduled_input,'select_contract',select)
    actual=asyncio.run(scheduled_input.wait_for_contract(dict(scheduled_input_wait_seconds=1,scheduled_input_poll_seconds=.01),tmp_path,Mock(),Mock()))
    assert actual==path and len(calls)==2
