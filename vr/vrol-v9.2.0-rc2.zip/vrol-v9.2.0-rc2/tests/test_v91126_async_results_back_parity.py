from pathlib import Path

def test_async_worker_ports_exact_sync_back_contract():
    text=Path('async_runtime/worker.py').read_text(encoding='utf-8')
    assert 'button#editButton[data-action="editQuery"]' in text
    assert "el => { el.focus(); el.click(); }" in text
    assert 'transaction_results_back_timeout_ms' in text
    assert 'stable>=2' in text
    assert 'await ensure_transaction_inquiry_form(state,log)' in text


# Superseded source-layout assertions: behavioral coverage in test_native_runtime.py.
