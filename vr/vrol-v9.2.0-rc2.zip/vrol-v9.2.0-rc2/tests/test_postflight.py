import asyncio
import csv
from pathlib import Path
from unittest.mock import Mock
from openpyxl import load_workbook
from async_runtime.rol500_postflight import reconcile,run
from src.vrol.reports.rol500 import parse_rol500


def report(path, entries):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(['Column'+str(i) for i in range(12)])
        for qt,rol,tran in entries:
            row=['']*12;row[4]=qt;row[5]=rol;row[11]=tran;writer.writerow(row)


def test_postflight_invoice_qt_parity_preserves_bot_decisions_and_drafts(case_workbook,tmp_path):
    path=case_workbook([dict(INVOICENUM='000123',**{'BUT TOAN':'QT1'}),dict(INVOICENUM='000456',**{'BUT TOAN':'QT2'}),
                        dict(INVOICENUM='000789',**{'BUT TOAN':'QT3'}),dict(INVOICENUM='000999',**{'BUT TOAN':'QT4'}),
                        dict(INVOICENUM='000888',**{'BUT TOAN':'QT5'})])
    wb=load_workbook(path);ws=wb['Sheet1'];ws.cell(2,37,'ROL CASE');ws.cell(2,38,'VROL');ws.cell(2,39,'BOT REVIEW STATUS');ws.cell(2,40,'BOT PI PATH')
    ws.cell(4,39,'FINAL_SUBMIT_COMPLETED');ws.cell(4,40,'PI_DOWNLOADED_G/documents/keep.pdf')
    ws.cell(6,38,'CASE_OBSERVED_DIRECTLY');ws.cell(7,38,'DRAFT_CASE');ws.cell(7,39,'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT')
    ws.cell(8,38,'SUBMITTED_CASE');ws.cell(8,39,'FINAL_SUBMIT_COMPLETED');wb.save(path);wb.close()
    csv_file=tmp_path/'postflight'/'ROL500.csv'
    report(csv_file,[('QT1','111111111','123'),('OTHER_QT','999999999','123'),('QT2','222222222','DIFFERENT_INVOICE'),
                     ('QT3','333333333','789'),('QT3','444444444','789')])
    result=reconcile(path,parse_rol500(csv_file),csv_file,csv_file.parent)
    assert result['stats']==dict(rows_checked=5,matched=1,unmatched=3,ambiguous=1,qt_only=0,submitted_not_found=1,qt_invoice_conflicts=1)
    wb=load_workbook(path);ws=wb['Sheet1'];h={ws.cell(2,c).value:c for c in range(1,ws.max_column+1)}
    assert ws.cell(4,37).value=='111111111' and ws.cell(4,h['VROL']).value=='111111111'
    assert ws.cell(5,h['BOT ROL500 POST MATCH KEY']).value=='QT_INVOICE_CONFLICT'
    assert ws.cell(5,h['BOT ROL500 POST STATUS']).value=='ROL500_QT_INVOICE_CONFLICT'
    assert ws.cell(5,h['VROL']).value is None
    assert ws.cell(6,h['VROL']).value=='CASE_OBSERVED_DIRECTLY'
    assert ws.cell(7,h['VROL']).value=='DRAFT_CASE' and ws.cell(7,h['BOT REVIEW STATUS']).value=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT'
    assert ws.cell(8,h['VROL']).value=='SUBMITTED_CASE'
    assert ws.cell(4,h['BOT PI PATH']).value=='PI_DOWNLOADED_G/documents/keep.pdf'
    assert ws.cell(4,h['BOT ROL500 POST SOURCE']).value==str(csv_file.resolve())
    wb.close()


def test_async_postflight_downloads_fresh_report_before_reconciliation(case_workbook,tmp_path,monkeypatch):
    from async_runtime import rol500_postflight
    path=case_workbook([{}]);calls=[]
    async def download(page,context,settings,folder,log):
        calls.append('fresh_download');csv_file=folder/'ROL500.csv';report(csv_file,[('QT','123456789','123')]);return csv_file,dict(financial_type='O')
    monkeypatch.setattr(rol500_postflight,'download',download)
    result=asyncio.run(run(object(),object(),{},path,tmp_path/'run',Mock()))
    assert calls==['fresh_download'] and result['stats']['matched']==1
    assert Path(result['csv_path']).name=='ROL500.csv' and result['status']=='SUCCESS'
