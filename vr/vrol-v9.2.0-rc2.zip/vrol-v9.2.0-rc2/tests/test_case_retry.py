import asyncio,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from async_runtime.case_retry import may_retry_case
from async_runtime.models import GuidGroup,WorkerState
from async_runtime import worker,native_ui,browser,popup_scope

@pytest.mark.parametrize('reason,stage,flag,allowed',[
    ('ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY','CASE_CREATION_SUBMIT_DISPATCHED',False,True),
    ('QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT','CASE_TRANSITION_REVIEW_REQUIRED',False,True),
    ('OWNED_CASE_CREATION_OR_QUESTIONNAIRE_NOT_FOUND','ISSUER_ACTION_DISPATCHING',False,True),
    ('QUESTIONNAIRE_INVOICE_MISMATCH','QUESTIONNAIRE_READY',False,False),
    ('QUESTIONNAIRE_MASKED_CARD_MISMATCH','QUESTIONNAIRE_READY',False,False),
    ('QUESTIONNAIRE_SCREEN_NAME_MISMATCH','QUESTIONNAIRE_READY',False,False),
    ('FOREIGN_POPUP','QUESTIONNAIRE_READY',False,False),
    ('ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY','FINAL_SUBMIT_DISPATCHING',False,False),
    ('QUESTIONNAIRE_NOT_STABLE_BEFORE_FILL','QUESTIONNAIRE_READY',True,False),
])
def test_case_retry_policy(reason,stage,flag,allowed):
    assert may_retry_case(RuntimeError(reason),dict(stage=stage,final_submit_clicked=flag)) is allowed

@pytest.mark.parametrize('reason,succeed',[
    ('ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY',True),
    ('ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY',False),
    ('QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT',True),
    ('QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT',False),
    ('QUESTIONNAIRE_INVOICE_MISMATCH',False),
])
def test_worker_retries_one_chain_retains_first_attempt_and_stops(monkeypatch,tmp_path,reason,succeed):
    class Page:
        def is_closed(self):return False
        async def close(self):pass
        async def screenshot(self,path,**kwargs):Path(path).write_bytes(b'fixture')
    class Registry:
        def pages(self,root):return [root]
        async def cleanup(self,root):pass
        def forget(self,root):pass
        def register(self,*a):pass
    calls=[]
    async def engine(page,registry,group,settings,folder,log):
        calls.append(page)
        if len(calls)==1 or not succeed:
            (folder/'case_checkpoint.json').write_text(json.dumps(dict(stage='CASE_TRANSITION_REVIEW_REQUIRED',issuer_action_clicked=True,submit_dispatched=True,final_submit_clicked=False)))
            raise RuntimeError(reason)
        return dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action='Consumer',issuer_action_clicked=True,rol='1234567890',invoice_results=[])
    async def fresh(*a):return Page()
    async def noop(*a,**k):pass
    monkeypatch.setattr(worker,'run_native_group',engine)
    monkeypatch.setattr(browser,'open_vrol_worker_tab_from_portal',fresh)
    monkeypatch.setattr(native_ui,'open_transaction_inquiry',noop)
    monkeypatch.setattr(popup_scope,'install',noop)
    from async_runtime import associated_transactions
    monkeypatch.setattr(associated_transactions,'on_page',noop)
    async def scenario():
        queue=asyncio.Queue();session=SimpleNamespace(tab_lock=asyncio.Lock(),snapshot=lambda:SimpleNamespace(portal=Page()))
        state=WorkerState('W01',Page(),settings=dict(_async_run_dir=str(tmp_path),_review_hold_dir=str(tmp_path/'holds')),registry=Registry(),session=session)
        group=GuidGroup('G','','4111111111111234',['20261103'],[dict(row_no=4,invoice='000123',qt='QT',code='13.1')],[4])
        await worker.process_group(state,group,queue,None,Mock())
        events=[]
        while not queue.empty():events.append(await queue.get())
        result=next(e.data['result'] for e in events if e.event=='CASE_RESULT')
        should_retry=reason!='QUESTIONNAIRE_INVOICE_MISMATCH'
        assert len(calls)==(2 if should_retry else 1)
        assert result.get('case_retry_count',0)==int(should_retry)
        if should_retry:
            archive=state.artifact_dir/'case_attempt_01'
            assert (archive/'case_checkpoint.json').is_file()
            assert (archive/'before_retry_page01.png').is_file()
            assert json.loads((state.artifact_dir/'case_retry_history.json').read_text())[0]['reason']==reason
        assert result['status']==('QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT' if succeed else 'LOGIC_REVIEW_REQUIRED')
    asyncio.run(scenario())

@pytest.mark.parametrize('saved,shared_expiry',[
    ({},True),
    ({'stage':'QUESTIONNAIRE_IDENTITY_VERIFIED_AFTER_FILL'},False),
    ({'stage':'FUTURE_CASE_STAGE','issuer_action_clicked':True},False),
    ({'stage':'FINAL_SUBMIT_DISPATCHED'},False),
])
def test_session_expiry_after_case_side_effect_cannot_replay_case(monkeypatch,tmp_path,saved,shared_expiry):
    from async_runtime import native_engine
    from async_runtime.session import SharedSessionExpired
    from unittest.mock import AsyncMock
    (tmp_path/'case_checkpoint.json').write_text(json.dumps(saved))
    monkeypatch.setattr(native_engine,'is_session_expired',AsyncMock(side_effect=[False,True]))
    monkeypatch.setattr(native_engine,'precheck_guid_group',AsyncMock(side_effect=RuntimeError('INQUIRY_FAILED')))
    group=GuidGroup('G','','4111111111111234',['20261103'],[],[4])
    async def scenario():
        error=SharedSessionExpired if shared_expiry else RuntimeError
        with pytest.raises(error) as found:
            await native_engine.run_native_group(SimpleNamespace(context=None),None,group,{},tmp_path,Mock())
        assert isinstance(found.value,SharedSessionExpired) is shared_expiry
    asyncio.run(scenario())


def test_window_layout_not_stable_retries_case_chain_only_before_final_submit():
    from async_runtime.case_retry import may_retry_case
    error=RuntimeError("WINDOW_LAYOUT_NOT_STABLE:{'innerWidth': 1894}")
    assert may_retry_case(error,dict(stage='QUESTIONNAIRE_READY',rol='2707870929'))
    assert not may_retry_case(error,dict(stage='QUESTIONNAIRE_READY',final_submit_clicked=True))
    assert not may_retry_case(error,dict(stage='FINAL_SUBMIT_DISPATCHED'))
