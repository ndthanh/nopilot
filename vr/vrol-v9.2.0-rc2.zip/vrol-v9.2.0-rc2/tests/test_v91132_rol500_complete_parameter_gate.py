from pathlib import Path
def test_complete_form_is_atomic_and_stable():
 t=Path('async_runtime/rol500_preflight.py').read_text(encoding='utf-8')
 assert 'async def _wait_parameter_controls' in t
 assert "'financial':'select[aria-label=\"Financial Type\"]'" in t
 assert "'from':'input[name=\"dateFromTxt\"]'" in t
 assert "'to':'input[name=\"dateToTxt\"]'" in t
 assert 'stable_required' in t and "_,fin,fr,to=await _wait_parameter_controls" in t
 assert "_,fr,_=await _visible" not in t
