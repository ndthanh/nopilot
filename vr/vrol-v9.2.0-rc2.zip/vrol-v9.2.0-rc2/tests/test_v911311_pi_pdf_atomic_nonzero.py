from pathlib import Path

def test_pi_download_atomic_publish_from_direct_chrome_file():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 segment=t[t.index('def download_pi_document'):t.index('def _transaction_count_from_page')]
 for value in ['_wait_invoice_pdf_file','shutil.copyfile','temp_target','os.replace',"copied_signature!=b'%PDF-'"]:
  assert value in segment
