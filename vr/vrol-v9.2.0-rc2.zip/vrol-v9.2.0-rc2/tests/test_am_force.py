import json
from datetime import date
from unittest.mock import patch
import pytest
from openpyxl import load_workbook
from async_runtime.excel_store import load_groups,CentralWriter
from async_runtime.business_status import BusinessState
from async_runtime.models import RuntimeEvent

def mark(path,*values):
    wb=load_workbook(path)
    for row,value in enumerate(values,4):wb['Sheet1'].cell(row,39,value)
    wb.save(path);wb.close()

def test_force_overrides_only_upstream_for_whole_guid_and_preserves_excel_code(case_workbook):
    path=case_workbook([{'VALID CHARGEBACK':'N','CODE CB':'13.1','INVOICENUM':'123'},
                       {'VALID CHARGEBACK':'N','CODE CB':'13.1','INVOICENUM':'456'}])
    mark(path,' force ')
    result,stats,_=load_groups(path,{'G':'4111111111111234'},run_date=date(2026,11,20))
    assert len(result)==1 and len(result[0].items)==2
    assert {i['code'] for i in result[0].items}=={'13.1'}
    assert all(i['input_am_force'] and i['upstream_filter_overridden'] for i in result[0].items)
    assert stats['am_force_groups']==1

@pytest.mark.parametrize('record,reason',[
    ({'CHECK SALE':'HOLD'},'INPUT_CHECK_SALE_NOT_SALE'),
    ({'NGAY GD':'20261110'},'TI_DATE_NOT_OLDER_THAN_15_DAYS'),
    ({'BOT ROL500 STATUS':'ALREADY_CHARGEBACK_IN_ROL500'},'ALREADY_CHARGEBACK_IN_ROL500'),
    ({'CODE CB':'99'},'INVALID_CASE_INPUT'),
])
def test_force_keeps_sale_age_rol_and_supported_code_gates(case_workbook,record,reason):
    path=case_workbook([dict(record,**{'VALID CHARGEBACK':'N'})]);mark(path,'FORCE')
    selected,stats,_=load_groups(path,{'G':'4111111111111234'},run_date=date(2026,11,20))
    assert not selected and reason in {x['reason'] for x in stats['exclusions']}

def test_skip_wins_over_force(case_workbook):
    path=case_workbook([{},{}]);mark(path,'FORCE','SKIP')
    assert not load_groups(path,{'G':'4111111111111234'},run_date=date(2026,11,20))[0]

@pytest.mark.parametrize('other',['PI','NO_CB','Review: timeout questionnaire','FRAUD - chờ Final Submit'])
def test_force_reruns_guid_over_old_bot_result(case_workbook,other):
    # 2026-11-21: AM is the only control surface (registry/holds retired): SKIP > FORCE > anything else.
    path=case_workbook([{},{'INVOICENUM':'456'}]);mark(path,'FORCE',other)
    selected,stats,_=load_groups(path,{'G':'4111111111111234'},run_date=date(2026,11,20))
    assert [g.guid for g in selected]==['G'] and selected[0].source_rows==[4,5] and stats['am_force_groups']==1

def test_force_still_requires_mapping_and_respects_registry(case_workbook):
    path=case_workbook([{}]);mark(path,'FORCE')
    assert not load_groups(path,run_date=date(2026,11,20))[0]
    selected,stats,_=load_groups(path,{'G':'4111111111111234'},reviewed={'G'},run_date=date(2026,11,20))
    assert not selected and stats['reviewed_rows_skipped']==1

def test_force_is_consumed_by_new_outcome_and_deferred_writeback_survives_restart(case_workbook,tmp_path):
    path=case_workbook([{}]);mark(path,'FORCE');run=tmp_path/'run';run.mkdir()
    state=BusinessState(tmp_path/'s.db',path,run)
    working=state.prepare(path)
    writer=CentralWriter(working,run/'out.xlsx',run/'events.jsonl',run/'registry.txt',20,business_state=state)
    writer.apply(RuntimeEvent('CASE_RESULT',guid='G',status='NO_CHARGEBACK_REQUIRED',data=dict(source_rows=[4],result=dict(status='NO_CHARGEBACK_REQUIRED'))))
    with patch('async_runtime.business_status.os.replace',side_effect=PermissionError('Excel open')):
        assert state.sync()['status']=='PENDING'
    writer.wb.close();state.close()
    state=BusinessState(tmp_path/'s.db',path,run)
    try:
        assert state.sync()['status']=='UPDATED'
        wb=load_workbook(path);assert wb['Sheet1']['AM4'].value=='NO_CB';wb.close()
        # A fresh FORCE marker must not be consumed by a previous completed run.
        mark(path,'FORCE')
        assert state.sync()['status']=='CONFLICT'
        wb=load_workbook(path);assert wb['Sheet1']['AM4'].value=='FORCE';wb.close()
    finally:state.close()

def test_force_report_is_separate_and_keeps_excel_code(tmp_path):
    from async_runtime.guid_request import build_report
    (tmp_path/'am_force_request.json').write_text(json.dumps(dict(request_id='RUN_AM_FORCE',guids=['G'],input_contract='source.xlsx')))
    (tmp_path/'queue_manifest.json').write_text(json.dumps([dict(guid='G',codes=['13.1'],upstream_filter_overridden=True)]))
    folder=tmp_path/'groups'/'CONSUMER_G';folder.mkdir(parents=True)
    (folder/'guid_result.json').write_text(json.dumps(dict(guid='G',status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',folder=str(folder),result=dict(issuer_action='Consumer',rol='1234567890'))))
    report=build_report(tmp_path)
    assert report['rows'][0]['codes']=='13.1' and report['rows'][0]['upstream_filter_overridden']
    assert (tmp_path/'am_force_report.csv').is_file() and not (tmp_path/'requested_guid_report.csv').exists()

def test_force_cannot_use_stale_code_from_contract(case_workbook,tmp_path):
    import shutil
    path=case_workbook([{}]);snapshot=tmp_path/'snapshot.xlsx';shutil.copy2(path,snapshot)
    wb=load_workbook(path);wb['Sheet1'].cell(4,4,'13.1');wb['Sheet1'].cell(4,39,'FORCE');wb.save(path);wb.close()
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',path,run)
    try:
        working=state.prepare(snapshot)
        # Changed identity excludes only this GUID (no run-wide abort, no stale FORCE).
        assert state.excluded=={'G':'MASTER_INPUT_IDENTITY_CHANGED'}
        assert not load_groups(working,run_date=date(2026,11,20),blocked=state.excluded)[0]
    finally:state.close()

def test_clearing_force_in_live_master_cancels_frozen_request(case_workbook,tmp_path):
    import shutil
    path=case_workbook([{'VALID CHARGEBACK':'N'}]);mark(path,'FORCE')
    snapshot=tmp_path/'snapshot.xlsx';shutil.copy2(path,snapshot)
    wb=load_workbook(path);wb['Sheet1']['AM4']=None;wb.save(path);wb.close()
    run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',path,run)
    try:
        working=state.prepare(snapshot)
        assert not load_groups(working,{'G':'4111111111111234'},run_date=date(2026,11,20))[0]
    finally:state.close()

def test_pending_force_writeback_cannot_queue_same_guid_on_next_run(case_workbook,tmp_path):
    import os
    from pathlib import Path
    path=case_workbook([{'VALID CHARGEBACK':'N'}]);mark(path,'FORCE');run=tmp_path/'run';run.mkdir()
    state=BusinessState(tmp_path/'s.db',path,run)
    wb=load_workbook(path);state.record(wb['Sheet1'],'G',dict(status='NO_CHARGEBACK_REQUIRED'));wb.close();state.close()
    state=BusinessState(tmp_path/'s.db',path,run);real_replace=os.replace
    def locked_master(source,destination):
        if Path(destination).resolve()==path.resolve():raise PermissionError('Excel open')
        return real_replace(source,destination)
    try:
        with patch('async_runtime.business_status.os.replace',side_effect=locked_master):
            working=state.prepare(path)
            assert not load_groups(working,{'G':'4111111111111234'},run_date=date(2026,11,20))[0]
        wb=load_workbook(path);assert wb['Sheet1']['AM4'].value=='FORCE';wb.close()
        assert state.sync()['status']=='UPDATED'
    finally:state.close()
