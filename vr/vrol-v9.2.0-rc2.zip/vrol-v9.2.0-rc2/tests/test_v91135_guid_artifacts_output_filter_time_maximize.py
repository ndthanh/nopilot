from pathlib import Path
def test_guid_folder_and_invoice_output():
 t=Path('async_runtime/worker.py').read_text(encoding='utf-8')
 assert "Path(str(state.settings.get('_async_run_dir')))/'groups'/group.guid" in t
 assert "t.add_row(f'Invoice {index}',detail)" in t
 assert "'%d.%m.%Y %H:%M'" in t
 assert "full_pan.startswith('5')" not in t
def test_shared_browser_not_closed_by_bridge():
 t=Path('async_runtime/sync_parity_engine.py').read_text(encoding='utf-8')
 assert 'browser.close()' not in t
# Native geometry and selective maximization: see test_native_window.py and
# diagnostics/check_browser_windows.py; exact CDP source-string counts obsolete.
def test_top_level_timestamp():
 t=Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
 assert "strftime('%d.%m.%Y %H:%M')" in t

# Superseded source-layout assertions: behavioral coverage in test_native_runtime.py.
