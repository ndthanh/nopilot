import asyncio
from unittest.mock import AsyncMock
import pytest
from async_runtime.session import SharedSessionManager

class Context:
    def __init__(self,events):self.events=events
    def on(self,*a):pass
    def remove_listener(self,*a):pass
    async def close(self):self.events.append('close')

def test_start_ready_and_concurrent_relogin_only_once():
    async def scenario():
        events=[];calls=0
        async def login():
            nonlocal calls
            calls+=1;events.append('login')
            return type('PW',(),{'stop':AsyncMock()})(),Context(events),object()
        session=SharedSessionManager(login);first=await session.start()
        assert (await asyncio.wait_for(session.ensure_current(0),1)).generation==1
        a,b=await asyncio.gather(session.relogin_once(first.generation),session.relogin_once(first.generation))
        assert calls==2 and a.generation==b.generation==2
        assert events[:3]==['login','close','login']
        await session.close()
    asyncio.run(scenario())

def test_relogin_waits_for_active_case():
    async def scenario():
        events=[]
        async def login():return type('PW',(),{'stop':AsyncMock()})(),Context(events),object()
        session=SharedSessionManager(login);await session.start()
        entered=asyncio.Event();release=asyncio.Event()
        async def worker():
            async with session.lease():entered.set();await release.wait()
        task=asyncio.create_task(worker());await entered.wait()
        reconnect=asyncio.create_task(session.relogin_once(1));await asyncio.sleep(0)
        assert not reconnect.done() and 'close' not in events
        release.set();await task;await reconnect;assert session.snapshot().generation==2
        await session.close()
    asyncio.run(scenario())

def test_failed_relogin_wakes_waiters():
    async def scenario():
        calls=0
        async def login():
            nonlocal calls
            calls+=1
            if calls>1:raise ValueError('login unavailable')
            return type('PW',(),{'stop':AsyncMock()})(),Context([]),object()
        session=SharedSessionManager(login);await session.start()
        with pytest.raises(ValueError):await session.relogin_once(1)
        with pytest.raises(RuntimeError,match='SHARED_SESSION_RELOGIN_FAILED'):
            await asyncio.wait_for(session.ensure_current(1),1)
        await session.close()
    asyncio.run(scenario())
