from pathlib import Path
def test_questionnaire_sync_contract_and_cleanup():
 t=Path('async_runtime/sync_parity_engine.py').read_text(encoding='utf-8')
 assert "settings['validate_dispute_amount']='NO'" in t
 assert 'QUESTIONNAIRE FILL COMPLETE' in t
 assert 'FINAL NOT SUBMITTED' not in t
 assert 'extra.close()' in t
def test_next_guid_returns_to_ti_and_tables():
 t=Path('async_runtime/worker.py').read_text(encoding='utf-8')
 assert 'await ensure_transaction_inquiry_form(state,log)' in t
 assert 'GUID INPUT' in t and 'GUID OUTPUT' in t
 assert "t.add_row('Folder'" in t and "t.add_row('Questionnaire'" in t
def test_displayed_version():
 assert Path('VERSION.txt').read_text(encoding='utf-8').strip()=='v9.2.0-rc2'
 assert "root/'VERSION.txt'" in Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
