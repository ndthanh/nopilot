"""Review 2026-11-20 regression tests (fixed findings).

Each test is xfail(strict=True): it FAILS today (documenting the defect). When
the fix lands the test XPASSes, strict mode turns that into a failure, and the
xfail marker must be removed so the test becomes a normal regression test.
Run: .venv\\Scripts\\python.exe -m pytest docs\\review_2026-11-20 -q
"""
import asyncio, shutil
from pathlib import Path
from datetime import date
from unittest.mock import patch
import pytest
from openpyxl import load_workbook, Workbook
from async_runtime.business_status import BusinessState
from async_runtime.excel_store import load_groups, CentralWriter
from async_runtime.models import RuntimeEvent, WorkerState, GuidGroup

def amend(path, fn):
    wb = load_workbook(path); fn(wb['Sheet1']); wb.save(path); wb.close()

def am(path, row):
    wb = load_workbook(path); v = wb['Sheet1'].cell(row, 39).value; wb.close(); return v

def run_one(master, tmp_path, name, result, prepare_source=None):
    run = tmp_path / name; run.mkdir()
    state = BusinessState(tmp_path / 's.db', master, run)
    try:
        w = CentralWriter(state.prepare(prepare_source or master), run / 'out.xlsx', run / 'ev.jsonl', run / 'rev.txt', 1, business_state=state)
        w.apply(RuntimeEvent('CASE_RESULT', guid='G', status=result['status'], data=dict(source_rows=[4], result=result)))
        w.close()
    finally:
        state.close()

# P0-1: test/diagnostic checkpoints must not write AM/ledger
@pytest.mark.parametrize('status,reason', [('ISSUER_ACTION_DEFERRED_TEST_MODE', 'TEST_PI_ONLY_NO_CASE_CREATED'),
                                           ('INQUIRY_ONLY_CHECKPOINT', 'TEST_STOP_BEFORE_VIEW_OR_ISSUER')])
def test_checkpoint_statuses_do_not_mark_master(case_workbook, tmp_path, status, reason):
    master = case_workbook([{'GUID': 'G'}])
    run_one(master, tmp_path, 'run', dict(status=status, reason_code=reason))
    assert am(master, 4) in (None, '')
    assert [g.guid for g in load_groups(master, run_date=date(2026, 11, 20))[0]] == ['G']

# P0-2: transient technical failure must stay retryable
def test_transient_failure_without_side_effect_stays_retryable(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}])
    run_one(master, tmp_path, 'run', dict(status='LOGIC_REVIEW_REQUIRED', reason_code='TRANSACTION_RESULTS_TIMEOUT'))
    assert [g.guid for g in load_groups(master, run_date=date(2026, 11, 20))[0]] == ['G']

# P0-3: one GUID error must not kill the worker task
def test_artifact_error_does_not_kill_worker(tmp_path):
    from async_runtime import worker as W
    class Reg:
        def pages(self, root): return [root]
        async def cleanup(self, root): pass
    class Page:
        def is_closed(self): return False
        async def screenshot(self, **k): pass
    events = []
    async def scenario():
        state = WorkerState('W01', Page(), settings={'_async_run_dir': str(tmp_path)}, registry=Reg())
        q = asyncio.Queue(); ev = asyncio.Queue()
        g = GuidGroup('G', '411111...1234', '4111111111111234', ['20261101'], [dict(row_no=4, invoice='1', qt='Q', code='10.4')], [4])
        await q.put(g); await q.put(None)
        async def boom(*a, **k): raise RuntimeError('TRANSACTION_RESULTS_TIMEOUT')
        def locked(*a, **k): raise PermissionError('[WinError 5] Access is denied')
        with patch.object(W, 'run_native_group', boom), patch.object(W, 'finalize_folder', locked):
            await W.worker_loop(state, q, ev, None, lambda *a: None)
        while not ev.empty(): events.append(ev.get_nowait())
    asyncio.run(scenario())
    assert any(e.event == 'CASE_RESULT' and e.guid == 'G' for e in events)

# P0-4: identity change excludes that GUID only
def test_identity_change_excludes_only_that_guid(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'A'}, {'GUID': 'B', 'INVOICENUM': '999'}])
    snap = tmp_path / 'snap.xlsx'; shutil.copy2(master, snap)
    amend(master, lambda ws: setattr(ws.cell(5, 3), 'value', '888'))
    run = tmp_path / 'run'; run.mkdir(); state = BusinessState(tmp_path / 's.db', master, run)
    try:
        working = state.prepare(snap); blocked = dict(state.excluded)
    finally:
        state.close()
    assert [g.guid for g in load_groups(working, run_date=date(2026, 11, 20), blocked=blocked)[0]] == ['A']

# P1-8: user SKIP must carry to a fresh upstream file
def test_user_skip_carried_to_new_upstream_file(case_workbook, tmp_path):
    day1 = case_workbook([{'GUID': 'G'}]); amend(day1, lambda ws: setattr(ws.cell(4, 39), 'value', 'SKIP'))
    run = tmp_path / 'r1'; run.mkdir(); s = BusinessState(tmp_path / 's.db', day1, run)
    try: s.prepare(day1)
    finally: s.close()
    day2 = tmp_path / 'day2.xlsx'; wb = load_workbook(day1); wb['Sheet1'].cell(4, 39).value = None; wb.save(day2); wb.close()
    run = tmp_path / 'r2'; run.mkdir(); s = BusinessState(tmp_path / 's.db', day2, run)
    try: working = s.prepare(day2)
    finally: s.close()
    assert load_groups(working, run_date=date(2026, 11, 20))[0] == []

# P1-8: clearing a bot-written AM must not be silently reverted
def test_user_cleared_am_is_not_silently_restored(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}])
    run_one(master, tmp_path, 'run1', dict(status='NO_CHARGEBACK_REQUIRED'))
    amend(master, lambda ws: setattr(ws.cell(4, 39), 'value', None))
    run = tmp_path / 'run2'; run.mkdir(); s = BusinessState(tmp_path / 's.db', master, run)
    try: s.prepare(master)
    finally: s.close()
    assert am(master, 4) in (None, '')

# P1-14: Settings is authoritative over legacy RunSettings
def test_settings_sheet_wins_over_runsettings(tmp_path):
    from async_runtime.config import load_settings
    wb = Workbook(); s = wb.active; s.title = 'Settings'; s.append(['key', 'value']); s.append(['async_worker_count', 3])
    r = wb.create_sheet('RunSettings'); r.append(['key', 'value']); r.append(['async_worker_count', 5])
    p = tmp_path / 'c.xlsx'; wb.save(p)
    assert load_settings(p)['async_worker_count'] == 3


def test_transient_written_only_after_max_attempts(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}])
    failure = dict(status='LOGIC_REVIEW_REQUIRED', reason_code='TRANSACTION_RESULTS_TIMEOUT')
    for i in (1, 2):
        run_one(master, tmp_path, f'run{i}', dict(failure))
        assert am(master, 4) in (None, '')
    run_one(master, tmp_path, 'run3', dict(failure))
    assert am(master, 4) == 'Review: TRANSACTION_RESULTS_TIMEOUT (đã thử 3 lần)'

def test_failure_after_case_side_effect_is_user_review_not_retried(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}])
    run_one(master, tmp_path, 'run', dict(status='LOGIC_REVIEW_REQUIRED', reason_code='TRANSACTION_RESULTS_TIMEOUT',
                                         case_checkpoint=dict(stage='CASE_CREATION_SUBMIT_DISPATCHED')))
    assert am(master, 4) == 'Review: TRANSACTION_RESULTS_TIMEOUT'

def test_diagnostic_readonly_state_never_touches_master(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}]); before = master.read_bytes()
    run = tmp_path / 'run'; run.mkdir(); state = BusinessState(tmp_path / 's.db', master, run, readonly=True)
    try:
        w = CentralWriter(state.prepare(master), run / 'out.xlsx', run / 'ev.jsonl', run / 'rev.txt', 1, business_state=state)
        r = dict(status='NO_CHARGEBACK_REQUIRED')
        w.apply(RuntimeEvent('CASE_RESULT', guid='G', status=r['status'], data=dict(source_rows=[4], result=r))); w.close()
        assert state.sync()['status'] == 'READ_ONLY'
    finally:
        state.close()
    assert master.read_bytes() == before

def test_contained_failure_when_tab_reopen_fails(tmp_path):
    """worker_loop survives a failure outside process_group (e.g. reopening a tab)."""
    from async_runtime import worker as W
    from contextlib import asynccontextmanager
    class Session:
        tab_lock = asyncio.Lock()
        @asynccontextmanager
        async def lease(self):
            yield type('S', (), dict(generation=2, portal=None))()
    class Reg:
        crashed = set()
        def forget(self, p): pass
    class Page:
        def is_closed(self): return True
        async def close(self): pass
    events = []
    async def scenario():
        state = WorkerState('W01', Page(), settings={'_async_run_dir': str(tmp_path)}, registry=Reg(), session=Session(), generation=1)
        q = asyncio.Queue(); ev = asyncio.Queue()
        g = GuidGroup('G', '', '4111111111111234', ['20261101'], [dict(row_no=4, invoice='1', qt='Q', code='10.4')], [4])
        await q.put(g); await q.put(None)
        async def boom(*a, **k): raise RuntimeError('VISA_ACCESS_LINK_NOT_FOUND')
        with patch('async_runtime.browser.open_vrol_worker_tab_from_portal', boom):
            await W.worker_loop(state, q, ev, None, lambda *a: None)
        while not ev.empty(): events.append(ev.get_nowait())
    asyncio.run(scenario())
    assert [e.reason_code for e in events if e.event == 'CASE_RESULT'] == ['WORKER_CONTAINED_FAILURE']


def test_headless_window_is_sized_not_maximized():
    """Headless has no OS window: maximize_window must size it explicitly and not raise."""
    from playwright.async_api import async_playwright
    from async_runtime import window_layout
    async def scenario():
        window_layout.HEADLESS_SIZE = (1600, 900)
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True, args=['--window-size=1600,900'])
                page = await (await browser.new_context(no_viewport=True)).new_page()
                await page.set_content('<html><body>ok</body></html>')
                report = await window_layout.maximize_window(page, label='T')
                await browser.close()
                return report
        finally:
            window_layout.HEADLESS_SIZE = None
    report = asyncio.run(scenario())
    assert report['headless'] and report['geometry']['innerWidth'] > 1000


def test_writer_records_flush_timings(case_workbook, tmp_path):
    master = case_workbook([{'GUID': 'G'}])
    run = tmp_path / 'run'; run.mkdir()
    w = CentralWriter(master, run / 'out.xlsx', run / 'ev.jsonl', run / 'rev.txt', 1)
    r = dict(status='NO_CHARGEBACK_REQUIRED')
    w.apply(RuntimeEvent('CASE_RESULT', guid='G', status=r['status'], data=dict(source_rows=[4], result=r))); w.close()
    assert w.flush_count >= 1 and w.last_flush_ms is not None


def test_dashboard_status_v2_tracks_progress_buckets_review_and_drafts(tmp_path):
    import json
    from types import SimpleNamespace
    from async_runtime.dashboard_status import DashboardStatus,SCHEMA
    d=DashboardStatus(tmp_path,run_id='R',mode=dict(pre_submit_only=True))
    d.set_queue(4,[dict(reason='ALREADY_CHARGEBACK_IN_ROL500'),dict(reason='ALREADY_CHARGEBACK_IN_ROL500')],existing_cb_rol500=1)
    d.session=SimpleNamespace(_generation=2,restart_after=100)
    d.worker_states=[SimpleNamespace(worker_id='W01',current=SimpleNamespace(guid='D'),stage='PRECHECK')]
    d.on_event(RuntimeEvent('CASE_ASSIGNED','W01','A'))
    for guid,result in [('A',dict(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',invoice_results=[{'pi_status':'DOWNLOADED'}])),
                        ('B',dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action='Fraud',rol='2707000001')),
                        ('C',dict(status='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED',reason_code='ASSOCIATED_TRANSACTIONS_SCREEN',issuer_action_clicked=True,rol='2707000002'))]:
        d.on_event(RuntimeEvent('CASE_RESULT','W01',guid,result['status'],result.get('reason_code',''),data=dict(result=result,folder='F'+guid,screenshots=['s.png'])))
    d.snapshot(dict(stage='PROCESSING_GUIDS',status='RUNNING',pid=1),dict(cpu_total_pct=10))
    data=json.loads((tmp_path/'dashboard_status.json').read_text(encoding='utf-8'))
    assert data['schema']==SCHEMA and data['stage']=='PROCESSING_GUIDS' and data['session']['restarts']==1
    assert data['progress']['done']==3 and data['progress']['pending']==1 and data['progress']['running']==1
    assert data['buckets']['pi']==1 and data['buckets']['draft']==1 and data['buckets']['review']==1
    assert data['drafts'][0]['rol']=='2707000001' and data['review'][0]['group']=='Có associated transactions' and data['review'][0]['hint']
    assert data['queue']['excluded']=={'ALREADY_CHARGEBACK_IN_ROL500':2} and data['labels']['FRAUD - chờ Final Submit']==1
    d.finish('SUCCESS_WITH_REVIEWS',dict(completed_at='x'))
    data=json.loads((tmp_path/'dashboard_status.json').read_text(encoding='utf-8'))
    assert data['status']=='SUCCESS_WITH_REVIEWS' and data['stage']=='FINISHED' and data['progress']['running']==0


def test_manual_dashboard_bundle_passes_bot_contract_validation(case_workbook,tmp_path):
    import hashlib,json,shutil
    from async_runtime.input_contract import validate_contract
    from async_runtime.excel_store import business_date
    source=case_workbook([{}]);mapping=tmp_path/'input.txt';mapping.write_text('G|4111111111111234\n',encoding='utf-8')
    bundle=tmp_path/'ops_inputs'/'manual_x';bundle.mkdir(parents=True);files={}
    for key,src,name in [('workbook',source,'09_chargeback_classified.xlsx'),('mapping',mapping,'input.txt')]:
        shutil.copyfile(src,bundle/name)
        files[key]=dict(path=str(bundle/name),sha256=hashlib.sha256((bundle/name).read_bytes()).hexdigest(),size=(bundle/name).stat().st_size,source_path=str(src))
    manifest=bundle/'manifest.json'
    manifest.write_text(json.dumps(dict(schema='vrol-input/1',status='READY',origin='MANUAL_USER_SELECTED',bundle_id='manual_x',business_date=business_date().isoformat(),
        source_fc_run_id='MANUAL:09.xlsx',source_guid2pan_run_id='MANUAL:input.txt',files=files)),encoding='utf-8')
    data,checked=validate_contract(manifest)
    assert data['origin']=='MANUAL_USER_SELECTED' and checked['workbook'].parent==bundle and data['files']['workbook']['source_path']==str(source)
    src=(Path(__file__).resolve().parents[1]/'run_async_parallel_case_review.py').read_text(encoding='utf-8')
    assert "contract.get('origin')=='MANUAL_USER_SELECTED'" in src and 'master_raw=getattr(args,\'master_workbook\',None) or manual_master' in src


def test_wait_layout_retries_on_the_same_page_before_failing():
    from async_runtime import window_layout
    class Scope:
        def __init__(self,unstable):self.calls=0;self.unstable=unstable
        async def evaluate(self,_):
            self.calls+=1
            height=974+(self.calls if self.calls<=self.unstable else 0)  # keeps reflowing, then settles
            return dict(innerWidth=1894,innerHeight=974,clientWidth=1894,clientHeight=974,scrollWidth=1894,scrollHeight=height,devicePixelRatio=1,readyState='complete')
    slow=Scope(unstable=4)
    metrics=asyncio.run(window_layout.wait_layout(slow,timeout_ms=250,attempts=3))
    assert metrics['layout_attempts']>=2
    never=Scope(unstable=10**6)
    with pytest.raises(RuntimeError,match='WINDOW_LAYOUT_NOT_STABLE.*layout_attempts'):
        asyncio.run(window_layout.wait_layout(never,timeout_ms=150,attempts=2))


def test_dashboard_pi_only_mode_maps_to_pi_only_with_master_writeback(tmp_path):
    from async_runtime.dashboard_status import DashboardStatus
    launcher=(Path(__file__).resolve().parents[1]/'run_vrol_from_ops.cmd').read_text(encoding='utf-8')
    assert 'if /i "%RPA_OPS_RUN_MODE%"=="PI_ONLY" set "MODE_ARGS=--pi-only --write-master"' in launcher and '%MODE_ARGS%' in launcher
    assert '--headful' not in launcher  # headless/headful comes from config.xlsx
    d=DashboardStatus(tmp_path,run_id='R',mode=dict(pi_only=True))
    d.on_event(RuntimeEvent('CASE_RESULT','W01','G','ISSUER_ACTION_DEFERRED_TEST_MODE','TEST_PI_ONLY_NO_CASE_CREATED',data=dict(result=dict(status='ISSUER_ACTION_DEFERRED_TEST_MODE',reason_code='TEST_PI_ONLY_NO_CASE_CREATED'))))
    assert d.data['buckets']['diagnostic']==1 and d.data['rows'][0]['label']=='Cần tạo case – chạy chế độ đầy đủ'


def test_scheduled_run_shows_waiting_input_on_dashboard_before_contract_is_ready(tmp_path):
    import json
    from async_runtime.dashboard_status import DashboardStatus
    src=(Path(__file__).resolve().parents[1]/'run_async_parallel_case_review.py').read_text(encoding='utf-8')
    assert src.index('monitor.dashboard=DashboardStatus(') < src.index('contract_path=await wait_for_contract(')
    d=DashboardStatus(tmp_path,run_id='R',mode=dict(scheduled=True))
    d.snapshot(dict(stage='WAITING_INPUT',status='RUNNING',pid=1,input_wait_reason='WAITING_TODAY_READY_FC_GUID2PAN_AFTER_19:30',contract_directory='C:/ops'))
    data=json.loads((tmp_path/'dashboard_status.json').read_text(encoding='utf-8'))
    assert data['stage']=='WAITING_INPUT' and data['input_wait_reason'].startswith('WAITING_TODAY') and data['mode']['scheduled']
    d.snapshot(dict(stage='LOGIN',status='RUNNING',pid=1))
    assert 'input_wait_reason' not in d.data and [x['stage'] for x in d.data['stage_history']]==['STARTING','WAITING_INPUT','LOGIN']


def test_dashboard_run_overrides_sit_between_config_and_command_line(tmp_path):
    import json
    from async_runtime import run_overrides
    from async_runtime.workers_config import resolve_workers
    assert run_overrides.load(tmp_path)=={}
    target=run_overrides.path_for(tmp_path);target.parent.mkdir(parents=True)
    target.write_text(json.dumps(dict(schema=run_overrides.SCHEMA,final_submit='yes',workers=9,headless=True,updated_at='t')),encoding='utf-8')
    overrides=run_overrides.load(tmp_path)
    settings=dict(allow_final_submit='NO',async_worker_count=3,async_worker_max=5,headless=False)
    sources=run_overrides.apply(settings,overrides)
    assert settings['allow_final_submit']=='YES' and settings['headless'] is True and sources=={'final_submit':'dashboard','workers':'dashboard','headless':'dashboard'}
    assert resolve_workers(settings)['effective']==9 and resolve_workers(settings,4)['effective']==4  # CLI --workers still wins
    target.write_text(json.dumps(dict(final_submit=None,workers=50,headless='maybe')),encoding='utf-8')  # invalid -> config
    assert run_overrides.load(tmp_path)=={}
    src=(Path(__file__).resolve().parents[1]/'run_async_parallel_case_review.py').read_text(encoding='utf-8')
    # flags are applied after the dashboard override, so --headful/--pre-submit-only/--workers keep priority
    assert src.index('run_overrides.apply(settings,overrides)') < src.index("if args.headful:settings['headless']=False")
    assert "if args.pre_submit_only or args.pi_only or args.inquiry_only:sources['final_submit']='command_line'" in src
