import asyncio
import pytest
from playwright.async_api import async_playwright
from async_runtime.native_ui import fill_test_questionnaire,wait_transaction_results
from async_runtime.native_case import _case_submit,_questionnaire,open_case_and_fill
from async_runtime.popup_registry import PopupRegistry
from async_runtime.native_table import parse_row_for_code,schema_from_dom
from async_runtime.final_submit import final_submit
from unittest.mock import Mock

@pytest.mark.parametrize('code',['13.9','13.1','10.4'])
def test_questionnaire_values_and_no_final_submit(code):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            screen='Fraud' if code=='10.4' else 'Consumer'
            html=f'<span ng-bind="disputeData.screenName">{screen} Dispute Questionnaire</span><input name="memberCaseNumber"><input name="disputeAmount" value="100"><dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd>'
            if code=='10.4':html+='<p>10.4 Fraud - Card Absent Environment</p><input type="checkbox" name="CardholderDeniesAuthorizingInd"><select name="FraudTypeCode"><option value="FT6">FT6</option></select>'
            else:html+='<select name="DisputeDueTo"><option value="NR">NR</option><option value="CL">CL</option></select><select name="WhatWasNotReceived"><option value="S">Services</option><option value="C">C</option></select>'
            if code=='13.1':
                for name,value in [('NonFiatCurrencyNotDelivered','N'),('ThirdPartyGiftCardInd','N'),('DidMerchantCancelInd','N'),('MerchantInBankruptcyLiquidationInd','N'),('DidCardholderCancelPriorExpectedDate','N'),('CardholderAttemptToResolve','Y')]:
                    html+=f'<input type="radio" name="{name}" value="{value}">'
                html+='<textarea name="PurchasedInfo"></textarea><input name="ExpectedReceiptDate"><input name="ExpectedReceiptTime">'
            html+='<button onclick="window.submits=(window.submits||0)+1">Submit</button>'
            await page.set_content(html)
            filled=await fill_test_questionnaire(page.main_frame,code,{'validate_dispute_amount':'NO','allow_final_submit':'NO'},dict(invoice='000123',qt='QT-TEST',start_date='20261103'))
            assert await page.locator('[name="memberCaseNumber"]').input_value()=='QT-TEST'
            assert not await page.evaluate('window.submits || 0') and not filled['submit_inspection']['clicked']
            assert filled['submit_inspection']['found'] and filled['submit_inspection']['visible']
            if code=='13.1':
                assert await page.locator('[name="ExpectedReceiptDate"]').input_value()=='11/03/2026'
                assert await page.locator('[name="CardholderAttemptToResolve"]').is_checked()
            elif code=='13.9':assert await page.locator('[name="DisputeDueTo"]').input_value()=='CL'
            else:assert await page.locator('[name="CardholderDeniesAuthorizingInd"]').is_checked()
            await browser.close()
    asyncio.run(scenario())

def test_case_selection_ignores_foreign_page_and_follows_descendant():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);context=await browser.new_context();registry=PopupRegistry(context)
            root=await context.new_page();registry.register(root,'A')
            foreign=await context.new_page();registry.register(foreign,'B')
            await foreign.set_content('<title>Case Creation</title><p>Create Dispute</p><button>Submit</button>')
            assert await _case_submit(registry,root) is None
            async with root.expect_popup() as pending:await root.evaluate('window.open("about:blank")')
            own=await pending.value
            await own.set_content('<title>Case Creation</title><p>Create Dispute</p><button>Submit</button>')
            assert (await _case_submit(registry,root))[0] is own
            async with own.expect_popup() as pending:await own.evaluate('window.open("about:blank")')
            questionnaire=await pending.value;await own.close()
            await questionnaire.set_content('<p>Fraud Dispute Questionnaire</p><p>VROL Case Number 123456789</p><button>Submit</button>')
            result=await _questionnaire(registry,root)
            assert result[0] is questionnaire and result[2]=='123456789'
            await registry.close();await browser.close()
    asyncio.run(scenario())

def test_rol897_without_results_table():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            await page.set_content('<iframe name="bodyframe" srcdoc="<span class=errorSummary>ROL-897: No matching transactions found</span>"></iframe>')
            frame=await wait_transaction_results(page,{'transaction_results_timeout_ms':2000})
            assert frame is page.frame(name='bodyframe')
            await browser.close()
    asyncio.run(scenario())

def test_transaction_locator_stays_inside_bodyframe():
    async def scenario():
        from src.vrol.transaction_table import EXPECTED_HEADER_BY_INDEX
        headers=['Column '+str(i) for i in range(31)]
        for i,name in EXPECTED_HEADER_BY_INDEX.items():headers[i]=name
        cells=['' for _ in headers];cells[0]='<input type="checkbox">';cells[7]='Sale';cells[23]='123456789012345-01 / 789'
        html='<table id="results"><thead><tr>'+''.join('<th>'+x+'<span style="display:none">hidden tooltip</span></th>' for x in headers)+'</tr></thead><tbody><tr id="stable-row" data-action="summaryGridRow">'+''.join('<td>'+x+'</td>' for x in cells)+'</tr></tbody></table>'
        html=html.replace('</tbody>','<tr class="expanded-details"><td colspan="31"><table><tr><td>Decorative</td><td>detail</td><td>row</td></tr></table></td></tr></tbody>')
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            await page.set_content('<iframe name="bodyframe"></iframe>');frame=page.frame(name='bodyframe')
            await frame.set_content(html)
            tx=await parse_row_for_code(frame.locator('#stable-row'),await schema_from_dom(frame),'10.4')
            assert await tx.locator.count()==1
            await tx.locator.get_by_role('checkbox').check()
            assert await frame.locator('#stable-row input').is_checked()
            from async_runtime.native_precheck import _invoice_transactions
            parsed=await _invoice_transactions(frame,dict(invoice='123456789012345',code='10.4'),{},dict(strategy='DIRECT_DOM'),await schema_from_dom(frame),Mock())
            assert len(parsed)==1 and parsed[0].transaction_id=='123456789012345-01'
            await browser.close()
    asyncio.run(scenario())

def test_final_submit_disabled_and_result_screenshot(tmp_path):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);context=await browser.new_context();registry=PopupRegistry(context)
            page=await context.new_page();registry.register(page,'A')
            await page.set_content('<p>Fraud Dispute Questionnaire</p><button ng-click="trigger(Buttons.SUBMIT,true)" ng-show="isBtnVisible(Buttons.SUBMIT)" onclick="document.body.innerHTML=\'<h1>Dispute Submitted successfully</h1>\'">Submit</button>')
            with pytest.raises(RuntimeError,match='DISABLED'):
                await final_submit(page,page,page.main_frame,registry,{'allow_final_submit':'NO'},tmp_path,Mock())
            assert await page.get_by_role('button',name='Submit').count()==1
            result=await final_submit(page,page,page.main_frame,registry,{'allow_final_submit':'YES'},tmp_path,Mock())
            assert result['status']=='FINAL_SUBMIT_COMPLETED' and result['final_submit_clicked']
            assert (tmp_path/'06_before_final_submit.png').is_file() and (tmp_path/'07_final_submit_result.png').is_file()
            await registry.close();await browser.close()
    asyncio.run(scenario())

@pytest.mark.parametrize('capture_setting',['YES','NO'])
def test_full_case_chain_fills_and_captures_without_final_submit(tmp_path,monkeypatch,capture_setting):
    from async_runtime import native_case
    before_fill=[]
    async def observe_fill(scope,*args,**kwargs):
        session=await scope.page.context.new_cdp_session(scope.page)
        try:state=(await session.send('Browser.getWindowForTarget'))['bounds']['windowState']
        finally:await session.detach()
        assert state=='maximized','Questionnaire was filled before maximize'
        assert scope.page.viewport_size is None
        before_fill.append(await scope.evaluate('innerWidth'))
        return await fill_test_questionnaire(scope,*args,**kwargs)
    monkeypatch.setattr(native_case,'fill_test_questionnaire',observe_fill)
    async def scenario():
        import json
        questionnaire='''<span ng-bind="disputeData.screenName">Fraud Dispute Questionnaire</span>
        <p>VROL Case Number 123456789</p><p>10.4 Fraud - Card Absent Environment</p>
        <dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd>
        <input name="memberCaseNumber"><input name="CardholderDeniesAuthorizingInd" type="checkbox">
        <select name="FraudTypeCode"><option value="FT6">FT6</option></select>
        <button ng-click="trigger(Buttons.SUBMIT,true)" ng-show="isBtnVisible(Buttons.SUBMIT)" onclick="window.finalWasClicked=true">Submit</button>'''
        case='<title>Case Creation</title><h1>Case Creation</h1><label><input type="checkbox">Create Dispute</label><button id="submit">Submit</button>'
        bootstrap='''<script>document.querySelector('#submit').onclick=()=>{let child=window.open('about:blank');child.document.write(QUESTIONNAIRE);child.document.close();window.close();};</script>'''.replace('QUESTIONNAIRE',json.dumps(questionnaire))
        case+=bootstrap
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);context=await browser.new_context(no_viewport=True);registry=PopupRegistry(context)
            page=await context.new_page();registry.register(page,'A')
            await page.set_content('<iframe name="buttons"></iframe><div style="display:none"><span>Chargeback/Dispute</span><a>Fraud</a></div><div id="menu" style="display:none"><span>Chargeback / Dispute</span><a id="fraud">Fraud</a></div>')
            await page.frame(name='buttons').set_content('<button onclick="parent.document.querySelector(\'#menu\').style.display=\'block\'">Issuer Action</button>')
            await page.locator('#fraud').evaluate('(el,html)=>el.onclick=()=>{let child=window.open("about:blank");child.document.write(html);child.document.close()}',case)
            result=await open_case_and_fill(page,registry,dict(code='10.4',qt='QT',invoice='000123'),dict(selected_count=1,selected_transaction_ids=['123']),
                dict(allow_final_submit='YES',_pre_submit_only=True,questionnaire_maximize_before_capture=capture_setting),tmp_path,Mock())
            assert result['status']=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT'
            assert not result['final_submit_clicked'] and (tmp_path/'04_questionnaire_filled_final_submit_not_clicked_10_4.png').exists()
            q=(await _questionnaire(registry,page))[0]
            assert q.viewport_size is None and before_fill and before_fill[0]>0
            assert result['questionnaire_layout']['window']['bounds']['windowState']=='maximized'
            assert not await q.evaluate('window.finalWasClicked || false')
            await registry.close();await browser.close()
    asyncio.run(scenario())

@pytest.mark.parametrize('body,status',[
    ('<h1>Reject Details</h1><p>VISA rejected</p>','FINAL_SUBMIT_REJECTED'),
    ('<div vcr-display-error><span ng-bind-html="currentError.message">Required field missing</span></div>','FINAL_SUBMIT_FORM_ERROR'),
    ('<h1>Waiting for response</h1>','FINAL_SUBMIT_RECONCILIATION_REQUIRED'),
])
def test_final_submit_result_errors_are_captured_without_resend(tmp_path,body,status):
    async def scenario():
        import json
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();registry=PopupRegistry(context)
            page=await context.new_page();registry.register(page,'A')
            await page.set_content('<button ng-click="trigger(Buttons.SUBMIT,true)" ng-show="isBtnVisible(Buttons.SUBMIT)">Submit</button>')
            await page.locator('button').evaluate('(el,body)=>el.onclick=()=>{window.sends=(window.sends||0)+1;document.body.innerHTML=body}',body)
            result=await final_submit(page,page,page.main_frame,registry,dict(allow_final_submit='YES',final_submit_outcome_timeout_ms=300),tmp_path,Mock())
            assert result['status']==status and result['final_submit_clicked']
            assert await page.evaluate('window.sends')==1
            assert json.loads((tmp_path/'case_checkpoint.json').read_text())['stage']==status
            assert list(tmp_path.glob('07_final_submit*.png'))
            await registry.close();await browser.close()
    asyncio.run(scenario())
