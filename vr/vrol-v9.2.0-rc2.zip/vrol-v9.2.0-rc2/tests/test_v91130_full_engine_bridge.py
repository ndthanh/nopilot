from pathlib import Path
def test_full_engine_contract():
 t=Path('async_runtime/sync_parity_engine.py').read_text(encoding='utf-8')
 for x in ['precheck_guid_group','download_pi_document','open_case_and_prepare','fill_test_questionnaire','QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',"allow_final_submit']='NO'"]:assert x in t
def test_async_worker_invokes_full_engine():
 t=Path('async_runtime/worker.py').read_text(encoding='utf-8')
 assert 'asyncio.to_thread(run_full_group' in t
 assert 'PENDING_SYNC_DECISION_ENGINE' not in t
