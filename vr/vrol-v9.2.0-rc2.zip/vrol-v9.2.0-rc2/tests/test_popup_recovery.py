import asyncio
from unittest.mock import AsyncMock
import pytest
from playwright.async_api import async_playwright
from async_runtime.popup_registry import PopupRegistry
from async_runtime.popup_scope import install,context_script
from async_runtime.native_case import validate_identity
from async_runtime.native_ui import _validate_131_questionnaire
from async_runtime.run_monitor import RunMonitor


def test_five_workers_same_named_window_and_nested_form():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();await context.add_init_script(script=context_script())
            registry=PopupRegistry(context)
            async def flow(index):
                root=await context.new_page();registry.register(root,str(index));await install(root,'W'+str(index))
                async with root.expect_popup() as pending:
                    await root.evaluate('window.open("about:blank","sameCaseWindow")')
                child=await pending.value
                await child.set_content('<form target="sameQuestionnaire" action="about:blank"><button>Continue</button></form>')
                # set_content does not navigate, so the inherited script remains active.
                async with child.expect_popup() as pending:
                    await child.locator('form').evaluate('el=>el.submit()')
                grandchild=await pending.value
                registry.assert_owned(root,grandchild)
                return root,child,grandchild
            chains=await asyncio.gather(*(flow(i) for i in range(5)))
            assert len({p for chain in chains for p in chain})==15
            for root,child,grandchild in chains:
                assert set(registry.pages(root))=={root,child,grandchild}
            await registry.cleanup(chains[0][0])
            assert not chains[1][2].is_closed()
            await registry.close();await browser.close()
    asyncio.run(scenario())


def test_questionnaire_identity_all_codes_and_no_amount_lookup():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            for code in ['10.4','13.1','13.9']:
                screen=('Fraud' if code=='10.4' else 'Consumer')+' Dispute Questionnaire'
                await page.set_content(f'<span ng-bind="disputeData.screenName">{screen}</span><p>VROL Case Number 1234567</p><dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123456789-01</dd>')
                item=dict(code=code,invoice='000123456789')
                assert (await validate_identity(page.main_frame,item,'1234567'))['invoice_verified']
                with pytest.raises(RuntimeError,match='INVOICE_MISMATCH'):
                    await validate_identity(page.main_frame,dict(code=code,invoice='999'),'1234567')
                if code=='13.1':
                    # Existing 13.1 amount validator expects an exact invoice;
                    # isolate the missing optional amount-field regression.
                    await page.locator('dd').evaluate('el=>el.textContent="123456789"')
                    result=await _validate_131_questionnaire(page.main_frame,item,{'validate_dispute_amount':'NO'})
                    assert result['amount_selector'] is None
            with pytest.raises(RuntimeError,match='SCREEN_NAME_MISMATCH'):
                await validate_identity(page.main_frame,dict(code='10.4',invoice='123456789'),'1234567')
            await page.set_content('<span ng-bind="disputeData.screenName">Consumer Dispute Questionnaire</span><p>VROL Case Number 1234567</p><dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd><dl><dt>Card/Account Number:</dt><dd>4890-44xx-xxxx-0642</dd><dt>Tran Date:</dt><dd>11/03/2026</dd></dl>')
            item=dict(code='13.1',invoice='123',_expected_card_bin6='489044',_expected_card_last4='0642',_expected_summary_date='11/03/26 12:01:00')
            assert (await validate_identity(page.main_frame,item,'1234567'))['transaction_date_verified']
            with pytest.raises(RuntimeError,match='MASKED_CARD_MISMATCH'):
                await validate_identity(page.main_frame,dict(item,_expected_card_last4='9999'),'1234567')
            with pytest.raises(RuntimeError,match='TRANSACTION_DATE_MISMATCH'):
                await validate_identity(page.main_frame,dict(item,_expected_summary_date='11/04/26'),'1234567')
            await browser.close()
    asyncio.run(scenario())


def test_heartbeat_survives_transient_write_failure(tmp_path,monkeypatch):
    from pathlib import Path
    monitor=RunMonitor(tmp_path)
    original=Path.replace
    monkeypatch.setattr(Path,'replace',lambda *_:(_ for _ in ()).throw(PermissionError('busy')))
    assert monitor.update(stage='PROCESSING') is False
    monkeypatch.setattr(Path,'replace',original)
    assert monitor.update() is True


def test_large_table_filter_readiness_uses_atomic_snapshot():
    from async_runtime.native_ui import wait_datatables_ready_for_invoice_filter
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            await page.set_content('<iframe name="bodyframe"></iframe>');frame=page.frame(name='bodyframe')
            await frame.set_content('<div id="dtheaderSearch"><input class="search-box" aria-label="Transaction ID / Retrieval Ref #"></div><table id="results"><tbody>'+''.join(f'<tr id="row{i}" data-action="summaryGridRow"><td>data</td></tr>' for i in range(500))+'</tbody></table>')
            ready=await wait_datatables_ready_for_invoice_filter(frame,{'invoice_filter_ready_timeout_ms':3000,'invoice_filter_ready_poll_ms':50})
            assert ready
            await browser.close()
    asyncio.run(scenario())


def test_periodic_session_restart_drains_active_leases():
    from async_runtime.session import SharedSessionManager
    async def scenario():
        manager=SharedSessionManager(AsyncMock());manager.restart_after=2
        async def replace():manager._generation+=1;manager._issued=0
        manager._replace_session=replace
        await manager.start();entered=asyncio.Event();release=asyncio.Event()
        async def active():
            async with manager.lease():entered.set();await release.wait()
        task=asyncio.create_task(active());await entered.wait()
        async with manager.lease():pass
        waiting=asyncio.create_task(manager.lease().__aenter__())
        await asyncio.sleep(.05);assert manager._generation==1
        release.set();await task;await waiting
        assert manager._generation==2
    asyncio.run(scenario())


@pytest.mark.parametrize('checkpoint',[{'rol':'1234567'},{'issuer_action_clicked':True},{'final_submit_clicked':True},
 {'submit_dispatched':True},{'stage':'CASE_CREATION_SUBMIT_DISPATCHING'},{'stage':'QUESTIONNAIRE_READY'},
 {'stage':'FINAL_SUBMIT_DISPATCHING'},{'stage':'STOPPED_AT_ASSOCIATED_TRANSACTIONS'}])
def test_read_only_retry_rejects_case_side_effects(checkpoint):
    from async_runtime.worker import can_retry_read_only
    assert not can_retry_read_only(checkpoint)
    assert can_retry_read_only({'stage':'ISSUER_ACTION_PENDING','final_submit_clicked':False})


def test_rol749_waits_for_old_warning_to_leave(tmp_path):
    from async_runtime.native_case import open_case_and_fill
    from unittest.mock import Mock
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);context=await browser.new_context(no_viewport=True)
            registry=PopupRegistry(context);root=await context.new_page();registry.register(root,'A')
            await root.set_content('<iframe name="buttons"></iframe><div id="menu"><span>Chargeback / Dispute</span><a id="fraud">Fraud</a></div>')
            await root.frame(name='buttons').set_content('<button>Issuer Action</button>')
            questionnaire='''<span ng-bind="disputeData.screenName">Fraud Dispute Questionnaire</span><p>VROL Case Number 1234567</p>
            <dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd><p>10.4 Fraud - Card Absent Environment</p>
            <input name="memberCaseNumber"><input type="checkbox" name="CardholderDeniesAuthorizingInd">
            <select name="FraudTypeCode"><option value="FT6">FT6</option></select><button ng-click="trigger(Buttons.SUBMIT,true)">Submit</button>'''
            await root.locator('#fraud').evaluate('''(el,q)=>el.onclick=()=>{
              const c=window.open('about:blank');c.q=q;
              c.document.write('<title>Case Creation</title><p>ROL-749 Potential Duplicate Cases</p><button id="ok">OK</button>');c.document.close();
              c.document.querySelector('#ok').onclick=()=>setTimeout(()=>{
                c.document.body.innerHTML='<h1>Case Creation</h1><label><input type="checkbox">Create Dispute</label><button id="send">Submit</button>';
                c.document.querySelector('#send').onclick=()=>{const p=c.open('about:blank');p.document.write(c.q);p.document.close();};
              },700);
            }''',questionnaire)
            result=await open_case_and_fill(root,registry,dict(code='10.4',invoice='123',qt='TEST'),dict(selected_count=1,selected_transaction_ids=['123']),
                dict(_pre_submit_only=True),tmp_path,Mock())
            assert result['status']=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT'
            assert len(result['duplicate_screenshots'])==1 and not result['final_submit_clicked']
            await registry.close();await browser.close()
    asyncio.run(scenario())
