import asyncio
from unittest.mock import Mock
import pytest
from playwright.async_api import async_playwright
from async_runtime.popup_registry import PopupRegistry
from async_runtime.questionnaire_submit import probe_submit
from async_runtime.final_submit import final_submit
from async_runtime.native_case import open_case_and_fill


@pytest.mark.parametrize('code',['10.4','13.1','13.9'])
def test_config_yes_completes_owned_case_chain_for_each_excel_code(tmp_path,code):
    async def scenario():
        import json
        action='Fraud' if code=='10.4' else 'Consumer'
        html=f'''<span ng-bind="disputeData.screenName">{action} Dispute Questionnaire</span>
            <p>VROL Case Number 123456789</p><dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd>
            <dl><dt>Card/Account Number:</dt><dd>411111-xx-xxxx-1234</dd><dt>Tran Date:</dt><dd>11/03/2026</dd></dl>
            <input name="memberCaseNumber">'''
        if code=='10.4':html+='<p>10.4 Fraud - Card Absent Environment</p><input type="checkbox" name="CardholderDeniesAuthorizingInd"><select name="FraudTypeCode"><option value="FT6">FT6</option></select>'
        else:html+='<select name="DisputeDueTo"><option value="NR">NR</option><option value="CL">CL</option></select><select name="WhatWasNotReceived"><option value="S">S</option><option value="C">C</option></select>'
        if code=='13.1':
            for name,value in [('NonFiatCurrencyNotDelivered','N'),('ThirdPartyGiftCardInd','N'),('DidMerchantCancelInd','N'),('MerchantInBankruptcyLiquidationInd','N'),('DidCardholderCancelPriorExpectedDate','N'),('CardholderAttemptToResolve','Y')]:
                html+=f'<input type="radio" name="{name}" value="{value}">'
            html+='<textarea name="PurchasedInfo"></textarea><input name="ExpectedReceiptDate"><input name="ExpectedReceiptTime">'
        html+='''<button ng-click="trigger(Buttons.SUBMIT,true)" onclick="window.sends=(window.sends||0)+1;document.body.innerHTML='<h1>Case Confirmation</h1>'">Submit</button>'''
        case='<title>Case Creation</title><h1>Case Creation</h1><label><input type="checkbox">Create Dispute</label><button id="submit">Submit</button>'
        case+='''<script>document.querySelector('#submit').onclick=()=>{let q=window.open('about:blank');q.document.write(QUESTIONNAIRE);q.document.close();window.close();};</script>'''.replace('QUESTIONNAIRE',json.dumps(html))
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context(no_viewport=True);registry=PopupRegistry(context);page=await context.new_page();registry.register(page,'W01')
            await page.set_content(f'''<iframe name="buttons"></iframe><div id="menu" style="display:none"><span>Chargeback / Dispute</span><a id="action">{action}</a></div>''')
            await page.frame(name='buttons').set_content('<button onclick="parent.document.querySelector(\'#menu\').style.display=\'block\'">Issuer Action</button>')
            await page.locator('#action').evaluate('(el,html)=>el.onclick=()=>{let c=window.open("about:blank");c.document.write(html);c.document.close()}',case)
            item=dict(code=code,invoice='000123',qt='QT',start_date='20261103',_expected_card_bin6='411111',_expected_card_last4='1234',_expected_summary_date='11/03/2026')
            result=await open_case_and_fill(page,registry,item,dict(selected_count=1,selected_transaction_ids=['123']),dict(allow_final_submit='YES',final_submit_outcome_timeout_ms=5000),tmp_path,Mock())
            assert result['status']=='FINAL_SUBMIT_COMPLETED' and result['final_submit_clicked']
            assert result['questionnaire']['submit_inspection']['exact_contract']['dispatch_ready']
            if code!='10.4':
                expected='NR' if code=='13.1' else 'CL'
                assert any(f.get('value')==expected for f in result['questionnaire']['fields'])
            assert (tmp_path/'07_final_submit_result.png').exists()
            await registry.close();await browser.close()
    asyncio.run(scenario())


def test_exact_probe_matches_dispatch_and_waits_for_slow_result(tmp_path):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();page=await context.new_page();registry=PopupRegistry(context);registry.register(page,'W01')
            await page.set_content('''<button ng-click="trigger(Buttons.SUBMIT,true)" onclick="window.sends=(window.sends||0)+1;
                document.body.innerHTML='<h1>Case Confirmation</h1><div aria-busy=true>Loading</div>';
                setTimeout(()=>{document.body.innerHTML='<h1>Case Confirmation</h1><p id=result>FINAL RESULT LOADED</p>'},650)">Submit</button>''')
            probe=await probe_submit(page.main_frame)
            assert probe['dispatch_ready'] and probe['visible_count']==1
            assert probe['contract']['action']=='trigger(Buttons.SUBMIT,true)'
            seen=[];original=page.screenshot
            async def screenshot(**kwargs):
                if str(kwargs['path']).endswith('07_final_submit_result.png'):
                    seen.append(await page.locator('#result').inner_text())
                return await original(**kwargs)
            page.screenshot=screenshot
            result=await final_submit(page,page,page.main_frame,registry,dict(allow_final_submit='YES',final_submit_outcome_timeout_ms=5000),tmp_path,Mock())
            assert result['status']=='FINAL_SUBMIT_COMPLETED' and seen==['FINAL RESULT LOADED']
            assert await page.evaluate('window.sends')==1
            await registry.close();await browser.close()
    asyncio.run(scenario())


def test_duplicate_submit_controls_are_never_dispatched(tmp_path):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();page=await context.new_page();registry=PopupRegistry(context);registry.register(page,'W01')
            await page.set_content('<button ng-click="trigger(Buttons.SUBMIT,true)" onclick="window.sent=true">Submit</button>'*2)
            assert not (await probe_submit(page.main_frame))['dispatch_ready']
            with pytest.raises(RuntimeError,match='NOT_UNIQUE_OR_ENABLED'):
                await final_submit(page,page,page.main_frame,registry,dict(allow_final_submit='YES'),tmp_path,Mock())
            assert not await page.evaluate('window.sent || false')
            await registry.close();await browser.close()
    asyncio.run(scenario())
