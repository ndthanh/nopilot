from __future__ import annotations
import json,re,time
from collections import OrderedDict
from pathlib import Path
from openpyxl import load_workbook
from src.io.mapping import mask_pan
from src.io.group_review_output import review_key
from src.vrol.workflow import (open_transaction_inquiry,fill_transaction_inquiry_pan,
 fill_transaction_inquiry_start_date,click_transaction_inquiry_submit,wait_transaction_results,
 normalize_invoice_number,apply_invoice_filter,_list_setting,BusinessReview,UnknownScenario)
from src.vrol.transaction_table import schema_from_dom,parse_row_for_code,transaction_id_matches_invoice,normalize_transaction_id_for_invoice

def clean(v): return str(v or '').strip()
def norm_code(v):
    v=clean(v)
    return v[:-2] if v.endswith('.0') else v

def load_guid_groups(path:Path,mapping:dict):
    wb=load_workbook(path,data_only=True,read_only=True);ws=wb['Sheet1']
    headers=list(next(ws.iter_rows(min_row=2,max_row=2,values_only=True)))
    h={clean(v):i for i,v in enumerate(headers) if v is not None}
    required={'BUT TOAN','NGAY GD','GUID','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'}
    valid_cb_col=h.get('VALID CHARGEBACK')
    if valid_cb_col is not None and valid_cb_col!=33:
        raise ValueError(f'CASE_REVIEW_VALID_CHARGEBACK_NOT_COLUMN_AH:index={valid_cb_col+1}')
    missing=required-set(h)
    if missing: raise ValueError('CASE_REVIEW_MISSING_HEADERS:'+','.join(sorted(missing)))
    rows=[];filter_stats={'total_data_rows':0,'u_sale_rows':0,'u_not_sale_rows':0,'ah_y_rows':0,'ah_not_y_rows':0,'eligible_code_rows':0}
    for row_no,row in enumerate(ws.iter_rows(min_row=4,values_only=True),start=4):
        filter_stats['total_data_rows']+=1
        check_sale=clean(row[h['CHECK SALE']]).upper()
        if check_sale!='SALE':
            filter_stats['u_not_sale_rows']+=1
            continue
        filter_stats['u_sale_rows']+=1
        valid_cb=clean(row[h['VALID CHARGEBACK']]).upper()
        if valid_cb!='Y':
            filter_stats['ah_not_y_rows']+=1
            continue
        filter_stats['ah_y_rows']+=1
        guid=clean(row[h['GUID']]).upper();qt=clean(row[h['BUT TOAN']]);invoice=clean(row[h['INVOICENUM']])
        if not guid or not qt or not invoice: continue
        code=norm_code(row[h['CODE CB']])
        if code not in {'13.1','10.4','13.9'}: continue
        filter_stats['eligible_code_rows']+=1
        d=clean(row[h['NGAY GD']])
        if not re.fullmatch(r'\d{8}',d): d=''
        review_status=clean(row[h['BOT REVIEW STATUS']]).upper() if 'BOT REVIEW STATUS' in h else ''
        rows.append({'row_no':row_no,'qt':qt,'guid':guid,'invoice':invoice,'code':code,'start_date':d,'review_key':review_key(guid,invoice,qt,code),'review_status':review_status,
                     'pi':clean(row[h['PI']]) if 'PI' in h else '',
                     'merchant':clean(row[h['TERMOWNER']]) if 'TERMOWNER' in h else ''})
    rows.sort(key=lambda x:(x['guid'],x['row_no']))
    grouped=OrderedDict()
    for item in rows: grouped.setdefault(item['guid'],[]).append(item)
    groups=[]
    for index,(guid,items) in enumerate(grouped.items(),1):
        pan=mapping.get(guid.upper())
        dates=[x['start_date'] for x in items if x['start_date']]
        groups.append({'group_index':index,'guid':guid,'pan':pan or '','masked_pan':mask_pan(pan) if pan else '',
                       'start_date':min(dates) if dates else '', 'items':items})
    return groups,filter_stats

def _checked_inventory(frame):
    checked=frame.locator('table#results input[type="checkbox"]:checked')
    ids=[]
    for i in range(checked.count()):
        try:
            row=checked.nth(i).locator('xpath=ancestor::tr[1]')
            ids.append(row.get_attribute('id') or row.inner_text()[:80])
        except Exception: ids.append('checked')
    return ids

def _no_matching_transaction_message(frame):
    selectors=['span.errorSummary','td span.errorSummary','.errorSummary']
    for selector in selectors:
        try:
            loc=frame.locator(selector)
            for i in range(loc.count()):
                text=' '.join((loc.nth(i).inner_text() or '').split())
                if re.search(r'ROL-897\s*:\s*No matching transactions found',text,re.I):
                    return text
        except Exception:pass
    return ''

def _no_matching_result(group,message):
    return {'status':'MANUAL_REVIEW_REQUIRED','decision':'MANUAL_REVIEW_REQUIRED',
            'reason_code':'ROL_897_NO_MATCHING_TRANSACTIONS','reason_detail':message,
            'issuer_action_required':False,'issuer_action_clicked':False,'selected_count':0,
            'invoice_results':[{'row_no':x['row_no'],'qt':x['qt'],'code':x['code'],'invoice_raw':x['invoice'],
              'scan_status':'NO_MATCHING_TRANSACTIONS_AT_PAN_DATE_SEARCH','tran_types':[],'sale_selected':False} for x in group['items']]}

def _safe_filename(value):
    text=re.sub(r'[<>:"/\\|?*]+','_',str(value or '').strip())
    text=re.sub(r'\s+',' ',text).strip(' ._')
    return text[:120] or 'UNKNOWN_MERCHANT'

def download_pi_document(page,context,tx,item,group,group_dir,settings,logger):
    """Download PI evidence through View > Tran Details > Save as PDF before Issuer Action."""
    invoice=str(item.get('invoice') or 'UNKNOWN_INVOICE')
    folder=group_dir/'documents'/invoice;folder.mkdir(parents=True,exist_ok=True)
    last4=str(group.get('pan') or '')[-4:]
    merchant=_safe_filename(item.get('merchant') or 'UNKNOWN_MERCHANT')
    target=folder/f'{last4}_{merchant}.pdf'
    # The selected row must remain checked. View is in iframe#buttons, not Issuer Action.
    checkbox=tx.locator.get_by_role('checkbox').first
    if checkbox.count() and not checkbox.is_checked():checkbox.check()
    button_frame=page.frame(name='buttons')
    if button_frame is None:raise UnknownScenario('PI_BUTTONS_IFRAME_NOT_FOUND')
    view=button_frame.locator('button#view[data-action="showViewMenu"]').first
    view.wait_for(state='visible',timeout=int(settings.get('pi_view_timeout_ms',10000)));view.click()
    menu=None
    deadline=time.monotonic()+int(settings.get('pi_view_menu_timeout_ms',10000))/1000
    while time.monotonic()<deadline and menu is None:
        for scope in [page]+[f for f in page.frames if f!=page.main_frame]:
            try:
                loc=scope.get_by_role('menuitem',name=re.compile(r'^Tran Details$',re.I),exact=True).first
                if loc.count() and loc.is_visible():menu=loc;break
                label=scope.locator('span#tranTxt').first
                if label.count() and label.is_visible():
                    parent=label.locator('xpath=ancestor::*[self::a or self::button or @role="menuitem"][1]')
                    menu=parent if parent.count() else label
                    break
            except Exception:pass
        if menu is None:page.wait_for_timeout(150)
    if menu is None:raise UnknownScenario('PI_TRAN_DETAILS_MENU_NOT_FOUND')
    with context.expect_page(timeout=int(settings.get('pi_popup_timeout_ms',15000))) as popup_info:menu.click()
    detail=popup_info.value;detail.wait_for_load_state('domcontentloaded')
    pdf=detail.locator('button#pdfButton[data-action="saveAsPDF"]').first
    pdf.wait_for(state='visible',timeout=int(settings.get('pi_save_pdf_timeout_ms',15000)))
    with detail.expect_download(timeout=int(settings.get('pi_download_timeout_ms',30000))) as download_info:pdf.click()
    download=download_info.value;download.save_as(str(target))
    if not target.exists() or target.stat().st_size==0:raise UnknownScenario('PI_EVIDENCE_DOWNLOAD_EMPTY')
    try:detail.close()
    except Exception:pass
    result={'required':True,'status':'DOWNLOADED','file_name':target.name,'original_name':download.suggested_filename,'path':str(target),'bytes':target.stat().st_size,'invoice':invoice}
    logger.info('PI EVIDENCE DOWNLOADED | guid=%s | qt=%s | invoice=%s | file=%s | bytes=%s | via=View>Tran Details>Save as PDF',group.get('guid'),item.get('qt'),invoice,target,target.stat().st_size)
    return result

def _transaction_count_from_page(body):
    """Read the VROL reported transaction count without mutating DataTables."""
    try:
        text=' '.join((body.locator('body').inner_text(timeout=1500) or '').split())
        match=re.search(r'([0-9,]+)\s+Transactions?\s+Found',text,re.I)
        if match:return int(match.group(1).replace(',',''))
    except Exception:pass
    return None

def _transaction_scan_strategy(body,settings,logger):
    reported=_transaction_count_from_page(body)
    dom_rows=body.locator('table#results tbody tr').count()
    threshold=int(settings.get('transaction_direct_scan_max_rows',25))
    # Never call DataTables API. Large result sets always use the stable human-facing
    # invoice filter. Small fully-rendered tables use fast direct DOM matching.
    use_filter=reported is None or reported>threshold or dom_rows<reported
    strategy='INVOICE_FILTER' if use_filter else 'DIRECT_DOM'
    reason='count_unknown' if reported is None else ('reported_above_threshold' if reported>threshold else ('dom_rows_less_than_reported' if dom_rows<reported else 'small_table_fully_rendered'))
    logger.info('TRANSACTION SCAN STRATEGY | strategy=%s | reported_transactions=%s | dom_rows=%s | direct_scan_max_rows=%s | reason=%s | datatables_api_used=false',strategy,reported,dom_rows,threshold,reason)
    return {'strategy':strategy,'reported_transactions':reported,'dom_rows':dom_rows,'threshold':threshold,'reason':reason}

def precheck_guid_group(page,context,group,settings,group_dir:Path,logger):
    group_dir.mkdir(parents=True,exist_ok=True)
    if not group.get('pan'):
        result={'status':'UNDEFINED_CASE','decision':'MANUAL_REVIEW_REQUIRED','reason_code':'GUID_PAN_MAPPING_NOT_FOUND','issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':[{'row_no':x['row_no'],'qt':x['qt'],'code':x['code'],'invoice_raw':x['invoice'],'scan_status':'NOT_SCANNED_MAPPING_MISSING','tran_types':[],'sale_selected':False} for x in group['items']]}
        (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        logger.warning('GUID GROUP MAPPING MISSING | guid=%s | rows=%s | review_required=true',group['guid'],[x['row_no'] for x in group['items']])
        return result
    if not group.get('start_date'):
        return {'status':'UNDEFINED_CASE','reason_code':'GROUP_START_DATE_MISSING','invoice_results':[]}
    body=open_transaction_inquiry(page,settings)
    body=fill_transaction_inquiry_pan(page,group['pan'],settings)
    body,date_value=fill_transaction_inquiry_start_date(page,group['start_date'],settings)
    click_transaction_inquiry_submit(page,settings);body=wait_transaction_results(page,settings)
    no_match=_no_matching_transaction_message(body)
    if no_match:
        result=_no_matching_result(group,no_match)
        logger.warning('ROL-897 NO MATCHING TRANSACTIONS | guid=%s | pan_bin6_last4=%s | start_date=%s | rows=%s | issuer_action_required=false',group['guid'],group.get('masked_pan'),group.get('start_date'),[x['row_no'] for x in group['items']])
        (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        try:page.screenshot(path=str(group_dir/'rol_897_no_matching_transactions.png'),full_page=True)
        except Exception:pass
        try:(group_dir/'rol_897_no_matching_transactions.html').write_text(body.content(),encoding='utf-8')
        except Exception:pass
        return result
    invoice_results=[];selected=[];selected_txs=[];stop=None
    stop_types_by_code={'10.4':{'credit'},'13.1':{'credit'},'13.9':{'cash rev'}}
    # Read the Transaction Inquiry HTML table directly. The DataTables text filter is
    # only a human UI aid; using it per invoice causes redraw races and hidden-row state
    # errors. All invoice matching and rule checks are now performed against DOM rows.
    scan=_transaction_scan_strategy(body,settings,logger)
    headers=schema_from_dom(body)
    result_rows=body.locator('table#results tbody tr')
    total_result_rows=result_rows.count()
    logger.info('TRANSACTION TABLE SCAN START | guid=%s | strategy=%s | reported_transactions=%s | dom_rows=%s | invoices=%s',group['guid'],scan['strategy'],scan['reported_transactions'],total_result_rows,len(group['items']))
    for position,item in enumerate(group['items'],1):
        settings['active_case_code']=item['code']
        inv=normalize_invoice_number(item['invoice']);parsed=[]
        if scan['strategy']=='INVOICE_FILTER':
            body,inv,filtered_rows=apply_invoice_filter(body,item['invoice'],settings);headers=schema_from_dom(body)
            for i in range(filtered_rows.count()):
                try:tx=parse_row_for_code(filtered_rows.nth(i),headers,item['code'])
                except Exception:continue
                if transaction_id_matches_invoice(tx.transaction_id,inv):parsed.append(tx)
            logger.info('FILTERED INVOICE MATCH | guid=%s | invoice=%s | invoice_search=%s | matched_rows=%s | reported_transactions=%s',group['guid'],item['invoice'],inv,len(parsed),scan['reported_transactions'])
        else:
            for i in range(total_result_rows):
                row=result_rows.nth(i)
                try:tx=parse_row_for_code(row,headers,item['code'])
                except Exception:continue
                if transaction_id_matches_invoice(tx.transaction_id,inv):parsed.append(tx)
            logger.info('DIRECT INVOICE MATCH | guid=%s | invoice=%s | invoice_search=%s | matched_rows=%s | html_rows=%s',group['guid'],item['invoice'],inv,len(parsed),total_result_rows)
        tran_types=[x.tran_type for x in parsed]
        record={'row_no':item['row_no'],'qt':item['qt'],'code':item['code'],'invoice_raw':item['invoice'],
                'invoice_search':inv,'pi_input_excel':str(item.get('pi') or ''),'scan_status':'SCANNED','tran_types':tran_types,'assoc_disputes':sorted({x.assoc_dispute for x in parsed if x.assoc_dispute}),'sale_selected':False}
        invoice_results.append(record)
        expected='Cash' if item['code']=='13.9' else 'Sale'
        # Assoc Dispute D is a group-level stop gate and must be checked before
        # eligible-row uniqueness. VROL may label the original sale as Sale - WT,
        # while a companion row is Sale Dispute Financial - WT. The former is the
        # sale-family row; the latter must not be treated as the original Sale.
        if expected=='Sale':
            sale_family=[x for x in parsed if re.match(r'^Sale(?:\s*-\s*WT)?$',str(x.tran_type or '').strip(),re.I)]
        else:
            sale_family=[x for x in parsed if str(x.tran_type or '').strip().casefold()=='cash']
        eligible=sale_family
        if len(eligible)!=1:
            record['scan_status']='UNDEFINED';record['reason_code']=f'{expected.upper()}_ROW_NOT_UNIQUE:{len(eligible)}'
            return {'status':'UNDEFINED_CASE','reason_code':'ELIGIBLE_ROW_NOT_UNIQUE','invoice_results':invoice_results,
                    'selected_count':len(selected),'date_value':date_value}
        tx=eligible[0]
        pi_value=str(tx.pi or '').strip();record['pi_input']=pi_value;record['pi_source']='VROL_TRANSACTION_TABLE'
        # PI is the highest-priority branch for 10.4, 13.1 and 13.9. When PI=Yes,
        # evidence download wins over MOTO/ECI, refund/reversal and Assoc Dispute gates.
        if pi_value.casefold()=='yes':
            record['pi_status']='PENDING_USER_ACTION';record['scan_status']='PI_DOWNLOAD_REVIEW_REQUIRED'
            record['planned_pre_issuer_action']='View > Tran Details > Save as PDF'
            record['transaction_id']=tx.transaction_id;record['assoc_dispute']=str(tx.assoc_dispute or '').strip().upper()
            selected_txs.append((tx,item))
            logger.info('PI YES OVERRIDES EXCLUSION RULES | guid=%s | invoice=%s | code=%s | transaction_id=%s | precedence=PI_FIRST',group['guid'],item['invoice'],item['code'],tx.transaction_id)
            continue
        record['pi_status']='NOT_REQUIRED'
        stop_matches=[x for x in parsed if x.tran_type.casefold() in stop_types_by_code.get(item['code'],set())]
        if stop_matches:
            trigger=stop_matches[0].tran_type
            stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':trigger,
                  'reason_code':'GROUP_REJECT_TRAN_TYPE','cb_reject':'Refund - Tran Type = '+trigger}
            logger.info('GUID GROUP STOP ON FIRST REFUND | guid=%s | invoice=%s | tran_type=%s | scanned=%s/%s',group['guid'],item['invoice'],trigger,position,len(group['items']))
            break
        assoc=str(tx.assoc_dispute or '').strip().upper();record['assoc_dispute']=assoc
        if assoc=='D':
            record['scan_status']='STOPPED_ASSOC_DISPUTE_D'
            stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':tx.tran_type,
                  'trigger_assoc_dispute':'D','trigger_transaction_id':tx.transaction_id,'reason_code':'GROUP_CONTAINS_ASSOC_DISPUTE_D','cb_reject':'Duplicate - Assoc Dispute = D'}
            logger.info('GUID GROUP STOP ON ASSOC DISPUTE D | guid=%s | invoice=%s | tran_type=%s | transaction_id=%s | scanned=%s/%s',group['guid'],item['invoice'],tx.tran_type,tx.transaction_id,position,len(group['items']))
            break
        if assoc not in {'','D'}:
            record['scan_status']='UNDEFINED_ASSOC_DISPUTE_VALUE'
            return {'status':'UNDEFINED_CASE','decision':'MANUAL_REVIEW_REQUIRED','reason_code':'UNDEFINED_ASSOC_DISPUTE_VALUE','reason_detail':'Unexpected Assoc Dispute value: '+assoc,'issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':invoice_results}
        if item['code']=='10.4':
            moto_eci=str(tx.moto_eci or '').strip();record['moto_eci']=moto_eci
            if moto_eci in {'','5','6'}:
                reject='Lỗi dữ liệu - MOTO/ECI '+('rỗng' if not moto_eci else '= '+moto_eci)
                record['scan_status']='STOPPED_GROUP_REJECT';record['cb_reject']=reject
                stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':tx.tran_type,'reason_code':'GROUP_REJECT_MOTO_ECI','cb_reject':reject,'trigger_moto_eci':moto_eci}
                break
        cb=tx.locator.get_by_role('checkbox').first
        if not cb.count():
            return {'status':'UNDEFINED_CASE','reason_code':'TRANSACTION_CHECKBOX_NOT_FOUND','invoice_results':invoice_results}
        cb.check();record['sale_selected']=True;record['transaction_id']=tx.transaction_id;selected.append(tx.transaction_id);selected_txs.append((tx,item))
        # The invoice column remains filtered while each invoice is scanned. Older
        # validation counted only checked rows present in the filtered DOM, so selections
        # made for prior invoices were incorrectly reported as lost. Verify the checkbox
        # just selected and keep the cumulative transaction IDs as the authoritative state.
        current_checked=bool(cb.is_checked())
        if not current_checked:
            return {'status':'UNDEFINED_CASE','reason_code':'CURRENT_SALE_SELECTION_FAILED','invoice_results':invoice_results,
                    'expected_selected':len(selected),'selected_transaction_ids':selected}
        logger.info('SALE SELECTION RECORDED | guid=%s | invoice=%s | selected_transaction_id=%s | cumulative_selected=%s/%s | selected_transaction_ids=%s',group['guid'],item['invoice'],tx.transaction_id,len(selected),len(group['items']),selected)
    if stop:
        scanned_rows={x['row_no'] for x in invoice_results}
        for item in group['items']:
            if item['row_no'] not in scanned_rows:
                invoice_results.append({'row_no':item['row_no'],'qt':item['qt'],'code':item['code'],'invoice_raw':item['invoice'],
                                        'scan_status':'NOT_SCANNED_AFTER_GROUP_STOP','tran_types':[],'sale_selected':False})
        result={'status':'NO_CHARGEBACK_REQUIRED','decision':'NO_CHARGEBACK_REQUIRED','issuer_action_required':False,
                'selected_count_before_stop':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,**stop}
        if stop.get('reason_code')=='GROUP_CONTAINS_ASSOC_DISPUTE_D':
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID do Invoice '+str(stop.get('trigger_invoice',''))+' có Assoc Dispute = D'
        elif stop.get('cb_reject'):
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID: '+stop['cb_reject']
        else:
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID do Invoice '+str(stop.get('trigger_invoice',''))+' có Tran Type '+str(stop.get('trigger_tran_type',''))
    else:
        status='READY_FOR_MULTI_ISSUER_ACTION_REVIEW' if len(selected)>1 else 'READY_FOR_ISSUER_ACTION_REVIEW'
        codes=sorted({x['code'] for x in group['items']})
        planned='Issuer Action > Chargeback/Dispute > Fraud' if codes==['10.4'] else ('Issuer Action > Chargeback/Dispute > Consumer' if set(codes).issubset({'13.1','13.9'}) else 'UNDEFINED_MIXED_CODE_ISSUER_ACTION')
        pi_pending=[x for x in invoice_results if x.get('pi_status')=='PENDING_USER_ACTION']
        if pi_pending:
            status='READY_FOR_PI_EVIDENCE_REVIEW'
            result={'status':status,'decision':status,'issuer_action_required':False,'issuer_action_clicked':False,
                    'planned_review_action':'View > Tran Details > Save as PDF','planned_issuer_action':'Không áp dụng do PI = Yes','pi_pending_count':len(pi_pending),
                    'selected_count':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,'date_value':date_value}
        else:
            result={'status':status,'decision':status,'issuer_action_required':True,'issuer_action_clicked':False,'planned_issuer_action':planned,
                    'selected_count':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,'date_value':date_value}
    (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    if not stop:
        result['_runtime_selected_txs']=selected_txs
        if selected_txs:
            # All matching checkboxes are already selected. One representative row is
            # sufficient to open the shared Issuer Action menu for the multi-selection.
            result['_runtime_tx']=selected_txs[0][0];result['_runtime_item']=selected_txs[0][1]
    try: page.screenshot(path=str(group_dir/'group_precheck.png'),full_page=True)
    except Exception: pass
    return result
