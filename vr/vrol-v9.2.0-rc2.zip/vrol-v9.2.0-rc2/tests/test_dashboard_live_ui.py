import asyncio
import json
import os
from pathlib import Path
import pytest

# Review 2026-11-20: the dashboard is a separate project; point DASHBOARD_ROOT at it.
DASHBOARD=Path(os.environ.get('DASHBOARD_ROOT') or Path(__file__).resolve().parents[2]/'rpa_ops-dashboard-v0.13.4')
pytestmark=pytest.mark.skipif(not (DASHBOARD/'static'/'app.js').is_file(),reason='dashboard checkout not available (set DASHBOARD_ROOT)')
from playwright.async_api import async_playwright


def test_guid_table_filters_and_interval_updates_without_real_bot():
    async def scenario():
        script=DASHBOARD/'static'/'app.js'
        latest=dict(run_id='RUN',status='RUNNING',resources={},metrics=dict(group_count=2,completed_groups=1),guid_results=[
            dict(guid='GUID_A',status='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED',needs_user_review=True,folder='C:/run/groups/REVIEW_REQUIRED_GUID_A',screenshots=[]),
            dict(guid='GUID_B',status='QUEUED',needs_user_review=False)])
        data=dict(title='Offline Visa UI',workflow_order=['vrol_master'],bots=dict(vrol_master=dict(display_name='VROL Visa',root_path='C:/visa',latest=latest,runs=[latest],operations={})),workflow_inputs={})
        latest['guid_results'] += [dict(guid=f'EXTRA_{i:03d}',status='QUEUED',needs_user_review=False) for i in range(205)]
        live=json.loads(json.dumps(latest));live['guid_results'][1]['status']='RUNNING';live['guid_results'][1]['action_stage']='CASE_CREATION_SUBMIT_DISPATCHED'
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            polls=[]
            async def serve(route):
                url=route.request.url
                if url.endswith('/api/vrol/live'):
                    polls.append(url);await route.fulfill(json=dict(latest=live,runs=[live],poll_seconds=2))
                elif '/api/' in url:await route.fulfill(json=dict(ok=True,text='',complete=False,offset=0,next_offset=0,size=0))
                else:await route.fulfill(body='<div id="app"></div>',content_type='text/html')
            await page.route('http://visa.test/**',serve);await page.goto('http://visa.test/')
            await page.evaluate('data=>window.RPA_DATA=data',data);await page.add_script_tag(path=str(script))
            await page.locator('[data-id="vrol_master"]').click();await page.locator('[data-tab="outputs"]').click()
            assert await page.locator('#outputs').get_by_text('GUID_A',exact=True).count()==1
            assert await page.locator('#outputs').get_by_text('GUID_B',exact=True).count()==1
            await page.locator('[data-filter="review"]').click()
            assert await page.locator('#outputs').get_by_text('GUID_B',exact=True).count()==0
            assert await page.locator('#outputs [data-action="open-folder"]').count()==1
            await page.locator('[data-filter="all"]').click()
            await page.locator('#outputs').get_by_text('CASE_CREATION_SUBMIT_DISPATCHED',exact=False).wait_for(timeout=10000)
            assert polls and await page.locator('#outputs').is_visible()
            assert await page.locator('#outputs').get_by_text('EXTRA_204',exact=True).count()==0
            await page.locator('#visaSearch').fill('EXTRA_204');await page.locator('[data-action="visa-search"]').click()
            assert await page.locator('#outputs').get_by_text('EXTRA_204',exact=True).count()==1
            await browser.close()
    asyncio.run(scenario())

def test_simple_vrol_actions_result_counts_and_no_live_log_requests(tmp_path):
    from datetime import datetime
    async def scenario():
        dashboard=Path(__file__).resolve().parents[2]/'rpa_ops-dashboard-v0.13.4'
        labels=['PI','FRAUD','consumer','NO_CB','Assoc D','Review: timeout questionnaire']
        latest=dict(run_id='RUN_EXAMPLE',status='SUCCESS_WITH_REVIEWS',started_at=datetime.now().astimezone().isoformat(),
                    resources={key:dict(path=path,exists=True) for key,path in [('final_output','C:/run/result.xlsx'),('pi_documents','C:/run/20261120_documents'),('process_log','C:/run/console.log')]},
                    metrics=dict(group_count=6,completed_groups=6,pi_pdf_count=2,review_required_count=1,worker_count=5),
                    guid_results=[dict(guid=f'EXAMPLE_{i}',business_result=label,status='LOGIC_REVIEW_REQUIRED' if i==5 else 'COMPLETED',needs_user_review=i==5,folder=f'C:/run/groups/EXAMPLE_{i}',screenshots=[]) for i,label in enumerate(labels)])
        data=dict(title='RPA Ops',workflow_order=['vrol_master'],bots=dict(vrol_master=dict(display_name='VROL Visa',root_path='C:/visa',latest=latest,runs=[latest],operations=dict(status='SUCCESS_WITH_REVIEWS',success_count=1,failed_count=0,runs_today=1))),workflow_inputs={})
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page(viewport=dict(width=1440,height=1100))
            requests=[]
            async def serve(route):
                request=route.request;requests.append((request.url,request.post_data))
                if request.url.endswith('/api/vrol/live'):await route.fulfill(json=dict(latest=latest,poll_seconds=5))
                elif '/api/' in request.url:await route.fulfill(json=dict(ok=True))
                else:await route.fulfill(body='<div id="app"></div>',content_type='text/html')
            await page.route('http://visa.test/**',serve);await page.goto('http://visa.test/')
            await page.evaluate('data=>window.RPA_DATA=data',data)
            await page.add_style_tag(path=str(dashboard/'static'/'app.css'))
            await page.add_script_tag(path=str(dashboard/'static'/'app.js'))
            await page.locator('[data-id="vrol_master"]').click()
            await page.locator('#outputs').wait_for(state='visible')
            assert await page.locator('#outputs').is_visible()
            assert not await page.locator('[data-tab="logs"]').is_visible()
            output=page.locator('#outputs')
            for label,path in [('Mở Excel kết quả','C:/run/result.xlsx'),('Mở documents','C:/run/20261120_documents'),('Mở log','C:/run/console.log')]:
                await output.get_by_role('button',name=label,exact=True).click()
                await page.wait_for_timeout(50)
                assert any(payload and json.loads(payload).get('path')==path for url,payload in requests if '/api/open-' in url)
            await output.locator('[data-filter="status:PI"]').click()
            assert await output.get_by_text('EXAMPLE_0',exact=True).count()==1
            assert await output.get_by_text('EXAMPLE_1',exact=True).count()==0
            await output.locator('[data-filter="review"]').click()
            assert await output.get_by_text('EXAMPLE_5',exact=True).count()==1
            await output.get_by_role('button',name='Mở thư mục GUID',exact=True).click()
            await page.wait_for_timeout(50)
            assert any(payload and json.loads(payload).get('path')=='C:/run/groups/EXAMPLE_5' for url,payload in requests if url.endswith('/api/open-folder'))
            await output.locator('[data-filter="all"]').click()
            await page.screenshot(path=str(tmp_path/'vrol_results.png'),full_page=True)
            assert not any('/runs/' in url and '/log?' in url for url,_ in requests)
            await browser.close()
    asyncio.run(scenario())
