import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from playwright.async_api import async_playwright
from async_runtime.associated_transactions import find, on_page
from async_runtime.native_case import open_case_and_fill, _case_submit
from async_runtime.popup_registry import PopupRegistry
from async_runtime.worker import finalize_guid_artifacts
from async_runtime.guid_markers import build_report
from async_runtime.review_holds import held_guids
from async_runtime.models import RuntimeEvent
from async_runtime.excel_store import CentralWriter
from async_runtime.run_monitor import RunLock


def associated_html(rol):
    # Sanitized structural fixture: never execute the uploaded page's scripts.
    return f'''<title>UAT - Associated Transactions</title><div class="form-title">Associated Transactions</div>
    <form id="submit_ti_atr_selection" action="/rolrfc/web/casefolder/submit-ti-atr-selection.action">
      <input type="hidden" name="businessObjects[0].caseNumber" value="{rol}">
      <p>Which of the listed transactions are associated with the selected transaction?</p>
      <table id="results"><tr><th>Associated</th><th>Merchant</th></tr><tr><td><input type="radio" name="assoc" value="Y"></td><td>Any shop</td></tr></table>
      <button type="button" onclick="window.submits=(window.submits||0)+1">Submit</button>
      <button type="button" onclick="window.submits=(window.submits||0)+1">Submit for Review</button>
    </form>'''


@pytest.mark.parametrize('code,action,rol',[('13.1','Consumer','123456789'),('10.4','Fraud','987654321')])
def test_associated_stops_before_any_submit_and_keeps_foreign_worker(tmp_path,code,action,rol):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();registry=PopupRegistry(context)
            root=await context.new_page();registry.register(root,'W01')
            foreign=await context.new_page();registry.register(foreign,'W02')
            await foreign.set_content('<p>Consumer Dispute Questionnaire</p><aside>Associated Transactions</aside><button>Submit</button>')
            assert await on_page(foreign) is None
            await root.set_content(f'<iframe name="buttons"></iframe><div id="menu" hidden><span>Chargeback / Dispute</span><a id="route">{action}</a></div>')
            await root.frame(name='buttons').set_content('<button onclick="parent.document.querySelector(\'#menu\').hidden=false">Issuer Action</button>')
            await root.locator('#route').evaluate('(el,html)=>el.onclick=()=>{let child=window.open("about:blank");child.document.write(html);child.document.close()}',associated_html(rol))
            folder=tmp_path/'run'/'groups'/'G';folder.mkdir(parents=True)
            settings=dict(allow_final_submit='YES',_current_guid='G',_review_hold_dir=str(tmp_path/'holds'))
            result=await open_case_and_fill(root,registry,dict(code=code),dict(selected_count=1),settings,folder,Mock())
            popup=(await find(registry,root))[0]
            assert await _case_submit(registry,root) is None
            assert not await popup.evaluate('window.submits || 0')
            assert not await popup.locator('input[type=radio]').is_checked()
            assert result['status']=='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED' and result['rol']==rol
            assert not result['final_submit_clicked']
            assert Path(result['associated_transactions_screenshot']).is_file()
            checkpoint=json.loads((folder/'case_checkpoint.json').read_text())
            assert checkpoint['stage']=='STOPPED_AT_ASSOCIATED_TRANSACTIONS'
            # Holds retired 2026-11-21: the stop is a USER_REVIEW outcome, so AM/ledger block re-creation.
            from async_runtime.outcome_policy import outcome_class,USER_REVIEW
            from async_runtime.business_status import result_label
            assert outcome_class(result)==USER_REVIEW and result_label(result)=='Có associated transactions'
            assert not (tmp_path/'holds').exists()
            await registry.cleanup(root)
            assert popup.is_closed() and not foreign.is_closed() and not root.is_closed()
            await registry.close();await browser.close()
    asyncio.run(scenario())


def test_pi_folder_rename_updates_excel_manifest_shots_and_report(case_workbook,tmp_path):
    source=case_workbook([{}]);run=tmp_path/'run';folder=run/'groups'/'G';docs=folder/'documents';docs.mkdir(parents=True)
    pdf=docs/'000123_1234_Shop.pdf';pdf.write_bytes(b'evidence')
    shot=folder/'evidence.png';shot.write_bytes(b'screenshot')
    result=dict(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',invoice_results=[dict(row_no=4,pi_status='DOWNLOADED',pi_path=str(pdf))])
    (folder/'pi_manifest.json').write_text(json.dumps(dict(path=str(pdf))))
    (folder/'debug.jsonl').write_text(json.dumps(dict(path=str(pdf)))+'\n')
    shots=[str(shot)];state=SimpleNamespace(artifact_dir=folder,worker_id='W01',settings={})
    record=finalize_guid_artifacts(state,SimpleNamespace(guid='G',items=[]),result,'PI downloaded',shots,1)
    final=run/'groups'/'PI_DOWNLOADED_G'
    assert not folder.exists() and state.artifact_dir==final
    assert Path(result['invoice_results'][0]['pi_path']).read_bytes()==b'evidence'
    assert Path(shots[0]).is_file() and record['folder']==str(final)
    assert json.loads((final/'pi_manifest.json').read_text())['path']==str(final/'documents'/pdf.name)
    assert json.loads((final/'debug.jsonl').read_text())['path']==str(final/'documents'/pdf.name)
    writer=CentralWriter(source,run/'out.xlsx',run/'events.jsonl',run/'reviewed.txt')
    writer.apply(RuntimeEvent('CASE_RESULT',guid='G',status=result['status'],data=dict(source_rows=[4],result=result,screenshots=shots)))
    assert Path(writer.ws.cell(4,writer.h['BOT PI PATH']).value).exists()
    writer.close()
    index=build_report(run)
    assert index['category_counts']=={'PI_DOWNLOADED':1}
    assert json.loads((run/'guid_outcomes.json').read_text())['records'][0]['folder']==str(final)


def test_os_run_lock_rejects_second_process_handle_and_releases(tmp_path):
    path=tmp_path/'vrol.lock'
    with RunLock(path):
        with pytest.raises(RuntimeError,match='VROL_ALREADY_RUNNING'):
            with RunLock(path):pass
    with RunLock(path):pass


def test_read_only_rerun_does_not_replay_any_known_case_action(tmp_path):
    from async_runtime.review_holds import read_only_recheck_guids
    def save(run,guid,result):
        path=tmp_path/run/'groups'/guid/'guid_result.json';path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(dict(guid=guid,result=result)))
    save('001','PI',dict(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION'))
    save('001','NCB',dict(status='NO_CHARGEBACK_REQUIRED'))
    save('001','CASE',dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action_clicked=True,rol='123456789'))
    save('002','CASE',dict(status='NO_CHARGEBACK_REQUIRED'))
    assert read_only_recheck_guids(tmp_path)=={'PI','NCB'}


def test_interrupted_case_checkpoint_without_final_record_becomes_review_outcome(tmp_path,case_workbook):
    from async_runtime.review_holds import interrupted_side_effects
    from async_runtime.business_status import BusinessState
    from async_runtime.excel_store import load_groups
    from datetime import date
    folder=tmp_path/'runs'/'001'/'groups'/'G';folder.mkdir(parents=True)
    (folder/'guid_state.json').write_text(json.dumps(dict(guid='G')))
    (folder/'case_checkpoint.json').write_text(json.dumps(dict(issuer_action_clicked=True,stage='CASE_CREATION_SUBMIT_DISPATCHED',rol='123456789')))
    items=interrupted_side_effects(tmp_path/'runs')
    assert [(x['guid'],x['rols']) for x in items]==[('G',['123456789'])]
    master=case_workbook([{}]);run=tmp_path/'run';run.mkdir();state=BusinessState(tmp_path/'s.db',master,run)
    try:
        assert state.seed_outcomes(items)==['G']
        assert state.seed_outcomes(items)==[]  # never overwrites an existing (e.g. later FORCE) outcome
        working=state.prepare(master)
        assert not load_groups(working,{'G':'4111111111111234'},run_date=date(2026,11,20))[0]
        state.sync()
        from openpyxl import load_workbook
        wb=load_workbook(master);ws=wb['Sheet1']
        assert ws['AM4'].value=='Review: INTERRUPTED_AFTER_ISSUER_ACTION' and ws['AK4'].value=='123456789';wb.close()
    finally:state.close()
