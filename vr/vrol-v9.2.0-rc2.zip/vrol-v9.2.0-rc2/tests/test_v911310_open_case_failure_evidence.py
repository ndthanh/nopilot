from pathlib import Path

def test_open_case_failure_immediate_evidence():
 t=Path('src/vrol/workflow.py').read_text(encoding='utf-8')
 segment=t[t.index('# Batch-safety wrapper'):]
 assert 'OPEN_CASE_WORKFLOW_FAILED_{invoice}_page{index:02d}.png' in segment
 assert 'OPEN_CASE_WORKFLOW_FAILED_{invoice}.txt' in segment
 assert 'candidate.screenshot' in segment
 assert "'workflow_error_screenshots':captured" in segment
 assert 'OPEN CASE FAILURE EVIDENCE' in segment
