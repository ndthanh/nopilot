import asyncio, json
from datetime import date
from pathlib import Path
from unittest.mock import Mock
import pytest
from async_runtime.excel_store import load_groups,CentralWriter
from async_runtime.models import GuidGroup,WorkerState,RuntimeEvent
from async_runtime.worker import finalize_guid_artifacts
from async_runtime.pi_artifacts import pi_filename,publish_pi,inspect_pdf,contains_transaction
from async_runtime.popup_registry import PopupRegistry
from playwright.async_api import async_playwright

def pdf_bytes(transaction_id):
    import pymupdf
    doc=pymupdf.open();page=doc.new_page()
    page.insert_text((60,70),'Visa Transaction ID: '+transaction_id)
    payload=doc.tobytes();doc.close();return payload

def test_age_boundaries_and_earliest_date(case_workbook):
    path=case_workbook([{'NGAY GD':d,'INVOICENUM':str(i)} for i,d in enumerate(
        ['20261105','20261104','20261103','20260723','20260722','20261120','bad'],1)])
    groups,stats,_=load_groups(path,run_date=date(2026,11,19))
    assert [x['row_no'] for x in groups[0].items]==[6,7]
    assert groups[0].start_date=='20260723'
    assert stats['ti_date_too_young']==2 and stats['ti_date_too_old']==1
    assert stats['ti_date_future']==1 and stats['ti_date_invalid']==1
    assert len(stats['exclusions'])==5

def test_rol500_blocks_whole_guid_before_age_filter(case_workbook):
    path=case_workbook([{'NGAY GD':'20261118','BOT ROL500 STATUS':'ALREADY_CHARGEBACK_IN_ROL500'},{}])
    groups,stats,_=load_groups(path,run_date=date(2026,11,19))
    assert not groups and stats['rol500_groups_skipped']==1
    assert {r['reason'] for r in stats['exclusions']}=={'ALREADY_CHARGEBACK_IN_ROL500'}

def test_prefix5_and_invalid_code_excluded(case_workbook):
    path=case_workbook([{'GUID':'A','FULL PAN':'5111111111111234'},{'GUID':'B','CODE CB':'99'},{'GUID':'C'}])
    groups,stats,_=load_groups(path,run_date=date(2026,11,19))
    assert [g.guid for g in groups]==['C']
    assert stats['pan_prefix_5_groups_filtered']==1


def test_check_sale_prefilter_rejects_non_sale_rows_including_mixed_guid(case_workbook):
    path=case_workbook([{'GUID':'MIXED','CHECK SALE':'SALE'},
        {'GUID':'MIXED','CHECK SALE':'HOLD'},{'GUID':'MIXED','CHECK SALE':'REVERT'},
        {'GUID':'CANCEL_ONLY','CHECK SALE':'CANCEL'},{'GUID':'EMPTY_ONLY','CHECK SALE':''}])
    groups,stats,_=load_groups(path,run_date=date(2026,11,19))
    assert [g.guid for g in groups]==['MIXED']
    assert groups[0].source_rows==[4]
    assert {r['row_no'] for r in stats['exclusions'] if r['reason']=='INPUT_CHECK_SALE_NOT_SALE'}=={5,6,7,8}

def test_termowner_carried_and_pan_conflict(case_workbook):
    path=case_workbook([{'TERMOWNER':'Merchant Tiếng Việt'}])
    groups,_,_=load_groups(path,run_date=date(2026,11,19))
    assert groups[0].items[0]['merchant']=='Merchant Tiếng Việt'
    # Review 2026-11-20: a PAN conflict excludes that GUID instead of aborting the run.
    groups,stats,_=load_groups(path,{'G':'4111111111119999'},run_date=date(2026,11,19))
    assert groups==[] and {r['reason'] for r in stats['exclusions']}=={'GUID_PAN_SOURCE_CONFLICT'}

def test_pi_naming_publication_and_wrong_identity(tmp_path):
    assert pi_filename('000123','4111111111110007','A/B: Tiếng Việt')=='000123_0007_A_B_ Tiếng Việt.pdf'
    with pytest.raises(ValueError,match='TERMOWNER'):pi_filename('123','4111111111110007','')
    source=tmp_path/'source.pdf';source.write_bytes(pdf_bytes('123456789012345-01'))
    run=tmp_path/'run';group=run/'groups'/'G';group.mkdir(parents=True)
    ev=publish_pi(source,run,group,'00123456789012345','4111111111110007','Shop','123456789012345-01',100)
    assert Path(ev['path'])==group/'documents'/'00123456789012345_0007_Shop.pdf'
    assert Path(ev['central_path']).read_bytes()==Path(ev['path']).read_bytes()==source.read_bytes()
    assert json.loads((group/'pi_manifest.json').read_text())['00123456789012345']['pdf_identity_verified']
    with pytest.raises(ValueError,match='TRANSACTION_ID_MISMATCH'):inspect_pdf(source,'999999999999999',100)
    assert not contains_transaction('Tran ID 123456789012345-02','123456789012345-01')
    source.write_bytes(pdf_bytes('999999999999999\nAssociated Transaction: 123456789012345-01'))
    with pytest.raises(ValueError,match='TRANSACTION_ID_MISMATCH'):inspect_pdf(source,'123456789012345-01',100)
    source.write_bytes(pdf_bytes('999999999999999'))
    with pytest.raises(ValueError,match='COLLISION'):
        publish_pi(source,run,group,'00123456789012345','4111111111110007','Shop','999999999999999',100)

def test_review_folder_and_pi_retry_is_review(tmp_path):
    folder=tmp_path/'groups'/'G';folder.mkdir(parents=True);shot=folder/'evidence.png';shot.write_bytes(b'evidence')
    group=GuidGroup('G','','',[],[],[]);state=WorkerState('W01',None,artifact_dir=folder)
    result={'status':'PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED','reason_code':'PI_DOWNLOAD_FAILED'}
    record=finalize_guid_artifacts(state,group,result,'failure',[str(shot)],1)
    final=folder.parent/'REVIEW_REQUIRED_G'
    assert record['review_required'] and state.artifact_dir==final and (final/shot.name).exists()
    assert record['screenshots']==[str(final/shot.name)]

def test_writer_preserves_invoice_results_and_partial_registry(case_workbook,tmp_path):
    path=case_workbook([{}, {'NGAY GD':'20261118'}]);run=tmp_path/'run';run.mkdir()
    writer=CentralWriter(path,run/'out.xlsx',run/'events.jsonl',run/'reviewed.txt',persistent_reviewed=tmp_path/'registry.txt')
    result={'status':'PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION','invoice_results':[{'row_no':4,'pi_status':'DOWNLOADED','pi_file':'file.pdf','pi_path':'group/file.pdf','pi_central_path':'run/file.pdf'}]}
    writer.apply(RuntimeEvent('CASE_RESULT',guid='G',status=result['status'],data={'source_rows':[4],'result':result,'review_keys':['G|123|QT|10.4'],'deferred_rows':[5]}))
    assert writer.ws.cell(4,writer.h['BOT PI PATH']).value=='group/file.pdf'
    assert (tmp_path/'registry.txt').read_text().splitlines()==['G|123|QT|10.4']
    writer.apply(RuntimeEvent('CASE_RESULT',guid='FAILED',status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',data={'source_rows':[5]}))
    assert 'FAILED' not in (tmp_path/'registry.txt').read_text()
    writer.close()

def test_exclusions_record_reasons_without_repeated_workbook_saves(case_workbook,tmp_path):
    path=case_workbook([{'CHECK SALE':'OTHER'},{'VALID CHARGEBACK':'N'},{}])
    _,stats,_=load_groups(path,run_date=date(2026,11,19))
    assert {x['reason'] for x in stats['exclusions']}=={'INPUT_CHECK_SALE_NOT_SALE','UPSTREAM_VALID_CHARGEBACK_NOT_Y'}
    writer=CentralWriter(path,tmp_path/'out.xlsx',tmp_path/'events.jsonl',tmp_path/'reviewed.txt',flush_every=1)
    original=writer.flush;writer.flush=Mock(wraps=original)
    for _ in range(25):writer.apply(RuntimeEvent('ROW_EXCLUDED',guid='G',status='EXCLUDED',data={'source_rows':[4]}))
    writer.flush.assert_not_called()
    writer.close()

def test_one_settings_switch_enables_final_despite_legacy_duplicate(tmp_path):
    from openpyxl import Workbook
    from async_runtime.config import load_settings
    w=Workbook();s=w.active;s.title='Settings';s.append(['Key','Value']);s.append(['allow_final_submit','YES'])
    legacy=w.create_sheet('RunSettings');legacy.append(['Key','Value']);legacy.append(['allow_final_submit','NO'])
    path=tmp_path/'config.xlsx';w.save(path);w.close()
    settings=load_settings(path)
    assert settings['allow_final_submit']=='YES' and settings['_allow_final_submit_source']=='Settings'

def test_independent_popup_chains_and_downloads(tmp_path):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context(accept_downloads=True);registry=PopupRegistry(context)
            a=await context.new_page();b=await context.new_page();registry.register(a,'A');registry.register(b,'B')
            async def popup(root):
                async with root.expect_popup() as pending:await root.evaluate('window.open("about:blank", "_blank")')
                return await pending.value
            pa,pb=await asyncio.gather(popup(a),popup(b))
            ca=await popup(pa)
            await pa.close()
            assert ca in registry.pages(a) and pb in registry.pages(b)
            with pytest.raises(RuntimeError,match='FOREIGN_POPUP'):registry.assert_owned(a,pb)
            import base64
            async def download(page,tx):
                payload=base64.b64encode(pdf_bytes(tx)).decode()
                await page.set_content('<a id="download" download="same.pdf">PDF</a>')
                await page.locator('#download').evaluate('(el,b64)=>el.href=URL.createObjectURL(new Blob([Uint8Array.from(atob(b64),c=>c.charCodeAt(0))],{type:"application/pdf"}))',payload)
                async with page.expect_download() as pending:await page.locator('#download').click()
                dl=await pending.value;assert dl.page is page
                target=tmp_path/(tx+'.pdf');await dl.save_as(target)
                assert inspect_pdf(target,tx,100)['pdf_identity_verified']
            await asyncio.gather(download(ca,'123456789012345'),download(pb,'987654321098765'))
            await registry.cleanup(a)
            assert ca.is_closed() and not pb.is_closed()
            await registry.close();await browser.close()
    asyncio.run(scenario())

@pytest.mark.parametrize('workers',[2,5])
def test_native_pi_flows_download_concurrently_from_own_details(tmp_path,monkeypatch,workers):
    from types import SimpleNamespace
    from async_runtime import native_pi
    import base64
    async def current(page,tx,*args,**kwargs):return tx
    monkeypatch.setattr(native_pi,'reacquire_transaction',current)
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context(accept_downloads=True);registry=PopupRegistry(context)
            async def flow(owner,identity):
                page=await context.new_page();registry.register(page,owner)
                await page.set_content('<iframe name="bodyframe"></iframe><iframe name="buttons"></iframe>')
                body=page.frame(name='bodyframe');buttons=page.frame(name='buttons')
                await body.set_content('<table id="results"><tbody><tr><td><input type="checkbox"></td></tr></tbody></table>')
                await buttons.set_content('<button id="view" data-action="showViewMenu" onclick="let menu=document.querySelector(\'a\');menu.hidden=!menu.hidden">View</button><a role="menuitem" data-js="top.bodyframe.viewDetails()" hidden><span id="tranTxt">Tran Details</span></a>')
                detail='<p>Tran ID '+identity+'</p><img id="piSpinner" style="display:none"><button id="pdfButton" data-action="saveAsPDF">PDF</button><a id="save" download="same.pdf"></a>'
                payload=base64.b64encode(pdf_bytes(identity)).decode()
                await body.evaluate('''data=>window.viewDetails=()=>{
                    window.piHandlerCalls=(window.piHandlerCalls||0)+1;
                    const child=window.open('about:blank','_blank');child.document.write(data.html);child.document.close();
                    const link=child.document.querySelector('#save');
                    link.href=child.URL.createObjectURL(new child.Blob([Uint8Array.from(atob(data.pdf),c=>c.charCodeAt(0))],{type:'application/pdf'}));
                    child.document.querySelector('button').onclick=()=>link.click();
                }''',dict(html=detail,pdf=payload))
                tx=SimpleNamespace(locator=body.locator('tr'),transaction_id=identity,tran_type='Sale')
                group=SimpleNamespace(guid=owner,full_pan='4111111111110007')
                folder=tmp_path/'groups'/owner;folder.mkdir(parents=True)
                item=dict(invoice='000'+identity,termowner='Shop',code='13.1')
                for _ in range(2):
                    ev=await native_pi.download_pi(page,registry,tx,item,group,dict(_async_run_dir=str(tmp_path),pi_download_minimum_pdf_bytes=100),folder,Mock())
                assert inspect_pdf(ev['path'],identity,100)['pdf_identity_verified']
                assert Path(ev['central_path']).read_bytes()==Path(ev['path']).read_bytes()
                assert await body.evaluate('window.piHandlerCalls')==2
                return ev
            evidence=await asyncio.gather(*(flow(f'W{i+1}',str(123456789012340+i)) for i in range(workers)))
            assert len({x['transaction_id'] for x in evidence})==workers
            await registry.close();await browser.close()
    asyncio.run(scenario())
