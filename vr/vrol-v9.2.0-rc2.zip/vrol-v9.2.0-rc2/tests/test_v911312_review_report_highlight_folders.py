from pathlib import Path


def test_consolidated_review_reports():
 t=Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
 assert 'def build_review_required_reports' in t
 assert "review_required_cases.csv" in t
 assert "review_required_cases.json" in t
 assert 'REVIEW REQUIRED REPORT' in t

# Superseded source-layout assertions: behavioral coverage in test_native_runtime.py.
