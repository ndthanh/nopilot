import sys
from pathlib import Path
import pytest
from openpyxl import Workbook
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))

@pytest.fixture
def case_workbook(tmp_path):
    def build(records):
        wb=Workbook();ws=wb.active;ws.title='Sheet1'
        names=['GUID','BUT TOAN','INVOICENUM','CODE CB','NGAY GD','CHECK SALE','FULL PAN','PAN','TERMOWNER','BOT ROL500 STATUS']
        names += ['UNUSED'+str(i) for i in range(33-len(names))]+['VALID CHARGEBACK']
        for col,name in enumerate(names,1):ws.cell(2,col,name)
        for row_no,record in enumerate(records,4):
            row={'GUID':'G','BUT TOAN':'QT','INVOICENUM':'000123','CODE CB':'10.4','NGAY GD':'20261103','CHECK SALE':'SALE','VALID CHARGEBACK':'Y','FULL PAN':'4111111111111234','TERMOWNER':'TEST SHOP'}
            row.update(record)
            for col,name in enumerate(names,1):ws.cell(row_no,col,row.get(name))
        path=tmp_path/'cases.xlsx';wb.save(path);return path
    return build
