from datetime import date
import json
import pytest
from async_runtime.excel_store import load_groups
from async_runtime.guid_request import load_request,build_report
from async_runtime.input_contract import digest


def test_requested_guid_bypasses_upstream_only_and_preserves_excel_code(case_workbook):
    path=case_workbook([{'VALID CHARGEBACK':'N','CODE CB':'13.1','INVOICENUM':str(i)} for i in range(36)]+[{'GUID':'OTHER','VALID CHARGEBACK':'Y'}])
    mapping={'G':'4111111111111234','OTHER':'4111111111111234'}
    normal,_,_=load_groups(path,mapping,run_date=date(2026,11,20))
    assert [g.guid for g in normal]==['OTHER']
    selected,stats,_=load_groups(path,mapping,run_date=date(2026,11,20),requested_guids=['G'])
    assert len(selected)==1 and len(selected[0].items)==36
    assert {x['code'] for x in selected[0].items}=={'13.1'}
    assert all(x['upstream_filter_overridden'] for x in selected[0].items)


def test_requested_guid_keeps_sale_age_rol_registry_and_mapping_guards(case_workbook):
    path=case_workbook([{'GUID':'HOLD','CHECK SALE':'HOLD'}, {'GUID':'YOUNG','NGAY GD':'20261110'},
        {'GUID':'ROL','BOT ROL500 STATUS':'ALREADY_CHARGEBACK_IN_ROL500'}, {'GUID':'DONE'}, {'GUID':'NO_PAN'}])
    wanted=['HOLD','YOUNG','ROL','DONE','NO_PAN','MISSING'];mapping={g:'4111111111111234' for g in wanted if g!='NO_PAN'}
    selected,stats,_=load_groups(path,mapping,run_date=date(2026,11,20),reviewed={'DONE'},requested_guids=wanted)
    assert not selected
    reasons={x['guid']:x['reason'] for x in stats['exclusions']}
    assert reasons==dict(HOLD='INPUT_CHECK_SALE_NOT_SALE',YOUNG='TI_DATE_NOT_OLDER_THAN_15_DAYS',ROL='ALREADY_CHARGEBACK_IN_ROL500',
        DONE='ALREADY_PROCESSED_IN_REGISTRY',NO_PAN='GUID_PAN_MAPPING_MISSING_OR_INVALID',MISSING='REQUESTED_GUID_NOT_IN_WORKBOOK')


def test_request_rejects_code_override_and_changed_input(tmp_path):
    manifest=tmp_path/'manifest.json';manifest.write_text('{}');path=tmp_path/'request.json'
    data=dict(schema='vrol-guid-request/1',request_id='TEST',requested_at='2026-11-20T20:00:00+07:00',input_contract=str(manifest),manifest_sha256=digest(manifest),guids=['G'])
    path.write_text(json.dumps(data));assert load_request(path,manifest)['guids']==['G']
    path.write_text(json.dumps(data|dict(code='13.9')))
    with pytest.raises(ValueError,match='SCHEMA_INVALID'):load_request(path,manifest)
    path.write_text(json.dumps(data));manifest.write_text('{"changed":true}')
    with pytest.raises(ValueError,match='CONTRACT_CHANGED'):load_request(path,manifest)


def test_separate_report_includes_completed_skipped_and_unfinished(tmp_path):
    def write(name,data):
        path=tmp_path/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data))
    write('guid_request.json',dict(request_id='TEST',input_contract='manifest',guids=['A','B','C']))
    write('queue_manifest.json',[dict(guid='A',codes=['13.1'],upstream_filter_overridden=True),dict(guid='C',codes=['10.4'])])
    write('input_exclusions.json',[dict(guid='B',reason='REQUESTED_GUID_NOT_IN_WORKBOOK')])
    write('groups/NO_CB_A/guid_result.json',dict(guid='A',status='NO_CHARGEBACK_REQUIRED',result={},folder='NO_CB_A'))
    result=build_report(tmp_path);by={r['guid']:r for r in result['rows']}
    assert by['A']['codes']=='13.1' and by['A']['upstream_filter_overridden']
    assert by['B']['status']=='SKIPPED' and by['C']['status']=='NOT_PROCESSED'
    assert result['requested_count']==3 and result['completed_count']==1 and result['skipped_count']==1
    assert (tmp_path/'requested_guid_report.csv').is_file()
