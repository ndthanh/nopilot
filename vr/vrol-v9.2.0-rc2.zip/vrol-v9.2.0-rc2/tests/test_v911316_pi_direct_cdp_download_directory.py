from pathlib import Path

def test_pi_sets_direct_chrome_download_directory():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 assert "Browser.setDownloadBehavior" in t
 assert "'downloadPath':str(download_dir)" in t
 assert "group_dir/'_pi_download_tmp'/invoice_prefix" in t
 assert '_wait_invoice_pdf_file' in t
 assert ".crdownload" in t

def test_pi_temp_is_isolated_per_invoice():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 segment=t[t.index('def download_pi_document'):t.index('def _transaction_count_from_page')]
 assert "download_dir=group_dir/'_pi_download_tmp'/invoice_prefix" in segment
 assert 'PI TEMP DOWNLOAD CLEANUP FAILED' in segment
