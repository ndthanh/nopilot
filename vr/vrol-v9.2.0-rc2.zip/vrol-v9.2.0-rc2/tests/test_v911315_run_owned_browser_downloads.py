from pathlib import Path

def test_browser_still_accepts_downloads():
 t=Path('async_runtime/browser.py').read_text(encoding='utf-8')
 assert 'accept_downloads=True' in t

def test_pi_uses_invoice_specific_cdp_download_folder():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 assert 'Browser.setDownloadBehavior' in t and '_wait_invoice_pdf_file' in t
