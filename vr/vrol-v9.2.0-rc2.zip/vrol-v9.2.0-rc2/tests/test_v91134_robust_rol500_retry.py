from pathlib import Path
def test_inner_menu_retry_is_robust():
 t=Path('async_runtime/rol500_preflight.py').read_text(encoding='utf-8')
 assert "rol500_menu_open_attempts') or 4" in t
 assert 'rol500_submenu_reveal_cycles' in t
 assert "MouseEvent('mouseenter'" in t
 assert 'ROL500 Financial submenu still hidden' in t
 assert 'await _wait_rol500_retry_ready' in t
def test_full_preflight_reopens_fresh_vrol_tab():
 t=Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
 assert "rol500_full_preflight_attempts') or 3" in t
 assert 'await base_vrol.close()' in t
 assert 'base_vrol=await open_vrol(portal,settings)' in t
 assert 'ROL500 fresh VROL tab ready for retry' in t
