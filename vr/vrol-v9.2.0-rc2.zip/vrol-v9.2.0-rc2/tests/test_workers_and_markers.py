import csv,json
from pathlib import Path
from types import SimpleNamespace
import pytest
from async_runtime.workers_config import resolve_workers
from async_runtime.guid_markers import classify,build_report,start_guid
from async_runtime.worker import finalize_guid_artifacts

@pytest.mark.parametrize('count',[3,4,5])
def test_excel_worker_count_controls_parallelism(count):
    result=resolve_workers(dict(async_worker_count=count,async_worker_max=5))
    assert result['effective']==count and not result['capped']

def test_worker_cli_override_and_cap_are_explicit():
    result=resolve_workers(dict(async_worker_count=3,async_worker_max=5),5)
    assert result['effective']==5 and result['configured']==3
    result=resolve_workers(dict(async_worker_count=3,async_worker_max=4),5)
    assert result['effective']==4 and result['capped'] and result['requested']==5

@pytest.mark.parametrize('value',[0,-1,2.5,'bad',True])
def test_invalid_worker_values_are_rejected(value):
    with pytest.raises(ValueError,match='POSITIVE_INTEGER'):
        resolve_workers(dict(async_worker_count=value,async_worker_max=5))

@pytest.mark.parametrize('action,code',[('Fraud','10.4'),('Consumer','13.1'),('Consumer','13.9')])
def test_case_route_is_marked_as_draft_until_final_confirmation(action,code):
    result=dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action_clicked=True,
        issuer_action=action,final_submit_clicked=False,invoice_results=[dict(code=code)])
    outcome=classify(result)
    assert outcome['category']==action.upper()
    assert 'AWAITING_FINAL_SUBMIT' in outcome['markers'] and 'FINAL_SUBMITTED' not in outcome['markers']
    assert outcome['needs_user_review'] and not outcome['review_required']
    result.update(status='FINAL_SUBMIT_COMPLETED',final_submit_clicked=True)
    assert classify(result)['final_submit_confirmed']

def test_planned_fraud_does_not_mean_dispatched_fraud():
    result=dict(status='NO_CHARGEBACK_REQUIRED',planned_issuer_action='Issuer Action > Chargeback/Dispute > Fraud',
        issuer_action_clicked=False,invoice_results=[dict(code='10.4')])
    outcome=classify(result)
    assert outcome['category']=='NO_CHARGEBACK' and 'FRAUD' not in outcome['markers']

def test_partial_pi_and_missing_evidence_require_review(tmp_path):
    pdf=tmp_path/'invoice.pdf';pdf.write_bytes(b'evidence')
    result=dict(status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',invoice_results=[
        dict(pi_status='DOWNLOADED',pi_path=str(pdf)),dict(pi_status='DOWNLOAD_FAILED')])
    outcome=classify(result)
    assert outcome['category']=='REVIEW_REQUIRED' and outcome['pi_downloaded']==1
    assert set(outcome['markers'])=={'PI_DOWNLOADED','PI_PARTIAL','REVIEW_REQUIRED'}
    pdf.unlink()
    result['status']='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION'
    result['invoice_results']=result['invoice_results'][:1]
    outcome=classify(result)
    assert outcome['missing_pi_files']==1 and 'PI_DOWNLOADED' not in outcome['markers']

def test_unknown_final_result_is_not_marked_final_submitted():
    result=dict(status='FINAL_SUBMIT_RECONCILIATION_REQUIRED',issuer_action_clicked=True,
        issuer_action='Consumer',final_submit_clicked=True)
    outcome=classify(result)
    assert outcome['category']=='REVIEW_REQUIRED' and outcome['final_submit_clicked']
    assert not outcome['final_submit_confirmed'] and 'FINAL_SUBMITTED' not in outcome['markers']

def finalize(folder,result):
    folder.mkdir(parents=True,exist_ok=True)
    state=SimpleNamespace(artifact_dir=folder,worker_id='W01')
    existing=folder/'guid_result.json'
    guid=json.loads(existing.read_text(encoding='utf-8'))['guid'] if existing.exists() else folder.name
    group=SimpleNamespace(guid=guid,items=[])
    return finalize_guid_artifacts(state,group,result,'detail',[],1)

def test_folder_prefix_follows_outcome_and_preserves_documents(tmp_path):
    folder=tmp_path/'groups'/'G';folder.mkdir(parents=True)
    evidence=folder/'documents';evidence.mkdir();(evidence/'keep.pdf').write_bytes(b'keep')
    start_guid(folder,'G');assert (folder/'__IN_PROGRESS__.txt').is_file()
    draft=dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action='Fraud',issuer_action_clicked=True)
    record=finalize(folder,draft)
    folder=Path(record['folder']);evidence=folder/'documents'
    assert folder.name=='FRAUD_G'
    assert (folder/'__FRAUD__.txt').is_file() and (folder/'__AWAITING_FINAL_SUBMIT__.txt').is_file()
    assert not (folder/'__IN_PROGRESS__.txt').exists()
    assert record['outcome']['category']=='FRAUD'
    record=finalize(folder,dict(status='NO_CHARGEBACK_REQUIRED',reason_code='GROUP_REJECT_TRAN_TYPE'))
    folder=Path(record['folder']);evidence=folder/'documents'
    assert folder.name=='NO_CB_G'
    assert (folder/'__NO_CHARGEBACK__.txt').is_file()
    assert not (folder/'__FRAUD__.txt').exists() and not (folder/'__AWAITING_FINAL_SUBMIT__.txt').exists()
    assert (evidence/'keep.pdf').read_bytes()==b'keep'

def test_run_index_covers_drafts_errors_and_unfinished_guids(tmp_path):
    finalize(tmp_path/'groups'/'A',dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',issuer_action='Consumer',issuer_action_clicked=True,rol='123456789'))
    finalize(tmp_path/'groups'/'B',dict(status='UNDEFINED_CASE',reason_code='ELIGIBLE_ROW_NOT_UNIQUE'))
    (tmp_path/'groups'/'C').mkdir()
    report=build_report(tmp_path)
    assert report['group_count']==3 and report['category_counts']=={'CONSUMER':1,'REVIEW_REQUIRED':2}
    assert report['needs_user_review_count']==3 and report['awaiting_final_submit_count']==1
    with Path(report['csv']).open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    assert len(rows)==3 and {r['guid'] for r in rows}=={'A','B','C'}
    assert (tmp_path/'groups'/'C'/'__REVIEW_REQUIRED__.txt').exists()
    assert json.loads((tmp_path/'groups'/'CONSUMER_A'/'guid_result.json').read_text(encoding='utf-8'))['outcome']['category']=='CONSUMER'
