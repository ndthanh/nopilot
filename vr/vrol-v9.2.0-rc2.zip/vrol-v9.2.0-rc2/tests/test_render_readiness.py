import asyncio,time
import pytest
from playwright.async_api import async_playwright
from async_runtime.native_pi import wait_for_pi_spinner
from async_runtime.native_table import parse_row_for_code
from src.vrol.transaction_table import EXPECTED_HEADER_BY_INDEX

def test_spinner_requires_presence_and_display_none_stably_in_all_frames():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            settings=dict(pi_spinner_hidden_timeout_ms=350,pi_spinner_hidden_poll_ms=30)
            for html in ['', '<img id="piSpinner" style="visibility:hidden">','<img id="piSpinner" style="opacity:0">']:
                await page.set_content(html)
                with pytest.raises(RuntimeError,match='PI_SPINNER_NOT_HIDDEN'):await wait_for_pi_spinner(page,settings)
            await page.set_content('<script>setTimeout(()=>{document.body.innerHTML=\'<img id="piSpinner">\';setTimeout(()=>document.querySelector("img").style.display="none",200)},200)</script>')
            start=time.monotonic()
            await wait_for_pi_spinner(page,dict(settings,pi_spinner_hidden_timeout_ms=2000))
            assert time.monotonic()-start>=.35
            await page.set_content('<img id="piSpinner" style="display:none"><iframe></iframe>')
            await page.frames[1].set_content('<img id="piSpinner">')
            with pytest.raises(RuntimeError,match='PI_SPINNER_NOT_HIDDEN'):await wait_for_pi_spinner(page,settings)
            await page.frames[1].locator('img').evaluate('el=>el.style.display="none"')
            await wait_for_pi_spinner(page,settings)
            await browser.close()
    asyncio.run(scenario())

def test_transaction_row_waits_for_td_render_instead_of_misclassifying():
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True);page=await browser.new_page()
            headers=['']*32
            for index,value in EXPECTED_HEADER_BY_INDEX.items():headers[index]=value
            # Visa appends cells after creating the visible TR. Reproduce the
            # 8/32 partial row found in the production feedback.
            await page.set_content('<table id="results"><tr id="tx" data-action="summaryGridRow">'+''.join('<td></td>' for _ in range(8))+'</tr></table>')
            await page.evaluate('''() => setTimeout(()=>{const row=document.querySelector('tr');while(row.children.length<32)row.appendChild(document.createElement('td'));},200)''')
            start=time.monotonic();tx=await parse_row_for_code(page.locator('tr'),headers,'13.1')
            assert time.monotonic()-start>=.15
            assert tx is not None
            await browser.close()
    asyncio.run(scenario())
