import json
from pathlib import Path
import pytest
from openpyxl import load_workbook
from async_runtime.pi_export import export_documents
from async_runtime.run_outcome import completed_status

def setup_run(tmp_path,name='RUN',payload=b'PDF fixture'):
    run=tmp_path/name;documents=run/'documents';documents.mkdir(parents=True)
    pdf=documents/'000123_1234_Shop.pdf';pdf.write_bytes(payload)
    return run,pdf

def test_export_renames_copies_and_rebases_json_excel_without_changing_group_documents(case_workbook,tmp_path):
    run,pdf=setup_run(tmp_path);destination=tmp_path/'share';destination.mkdir()
    group=run/'groups'/'PI_DOWNLOADED_G';(group/'documents').mkdir(parents=True)
    (group/'documents'/pdf.name).write_bytes(pdf.read_bytes())
    (group/'group_result.json').write_text(json.dumps(dict(invoice_results=[dict(pi_central_path=str(pdf))])))
    (group/'pi_manifest.json').write_text(json.dumps(dict(G=dict(central_path=str(pdf)))))
    frozen=run/'snapshot.xlsx';frozen.write_bytes(b'untouched snapshot')
    workbook=case_workbook([{}]);wb=load_workbook(workbook);wb['Sheet1'].cell(2,40,'BOT PI CENTRAL PATH');wb['Sheet1'].cell(4,40,str(pdf));wb.save(workbook);wb.close()
    result=export_documents(run,dict(pi_documents_export_dir=str(destination),_run_business_date='2026-11-20'),workbook)
    assert result['status']=='EXPORTED' and result['copied']==1
    local=run/'20261120_documents'/pdf.name;copied=destination/'20261120_documents'/pdf.name
    assert local.read_bytes()==copied.read_bytes()==b'PDF fixture'
    assert not (run/'documents').exists()
    assert (group/'documents'/pdf.name).read_bytes()==b'PDF fixture'
    assert json.loads((group/'group_result.json').read_text())['invoice_results'][0]['pi_central_path']==str(local)
    wb=load_workbook(workbook);assert wb['Sheet1'].cell(4,40).value==str(local);wb.close()
    assert frozen.read_bytes()==b'untouched snapshot'
    repeated=export_documents(run,dict(pi_documents_export_dir=str(destination),_run_business_date='2026-11-20'),workbook)
    assert repeated['status']=='EXPORTED' and repeated['identical']==1 and repeated['copied']==0

@pytest.mark.parametrize('raw,status',[('', 'SKIPPED_NOT_CONFIGURED'),(None,'SKIPPED_NOT_CONFIGURED'),('absent','SKIPPED_DESTINATION_NOT_FOUND')])
def test_unconfigured_or_missing_destination_skips_without_renaming(tmp_path,raw,status):
    run,pdf=setup_run(tmp_path)
    settings=dict(_run_business_date='2026-11-20',_config_path=str(tmp_path/'config.xlsx'))
    if raw is not None:settings['pi_documents_export_dir']=raw
    result=export_documents(run,settings)
    assert result['status']==status and pdf.exists()
    assert not (tmp_path/'absent').exists()

def test_same_day_runs_merge_identical_files_and_reject_different_pdf(tmp_path):
    destination=tmp_path/'share';destination.mkdir()
    settings=dict(pi_documents_export_dir=str(destination),_run_business_date='2026-11-20')
    a,_=setup_run(tmp_path,'A');assert export_documents(a,settings)['status']=='EXPORTED'
    b,_=setup_run(tmp_path,'B');assert export_documents(b,settings)['identical']==1
    c,pdf=setup_run(tmp_path,'C',b'different PDF')
    result=export_documents(c,settings)
    assert result['status']=='FAILED' and 'CONFLICT' in result['error']
    assert pdf.exists() and (destination/'20261120_documents'/pdf.name).read_bytes()==b'PDF fixture'

def test_failed_or_skipped_postflight_does_not_export(tmp_path):
    destination=tmp_path/'share';destination.mkdir();run,pdf=setup_run(tmp_path)
    for status in ['FAILED','SKIPPED']:
        result=export_documents(run,dict(pi_documents_export_dir=str(destination)),postflight_status=status)
        assert result['status']=='SKIPPED_POSTFLIGHT_NOT_SUCCESS' and pdf.exists()
    assert not list(destination.iterdir())

@pytest.mark.parametrize('post,outcome,writeback,export,status',[
    ('SUCCESS',{},None,None,'SUCCESS'),
    ('SUCCESS',{'needs_user_review_count':3},None,None,'SUCCESS_WITH_REVIEWS'),
    ('FAILED',{'needs_user_review_count':3},None,None,'FAILED'),
    ('SUCCESS',{},dict(status='PENDING'),None,'SUCCESS_WITH_REVIEWS'),
    ('SUCCESS',{},None,dict(status='FAILED'),'SUCCESS_WITH_REVIEWS'),
    ('SUCCESS',{},None,dict(status='SKIPPED_NOT_CONFIGURED'),'SUCCESS'),
])
def test_run_success_is_independent_of_business_reviews(post,outcome,writeback,export,status):
    assert completed_status(dict(status=post),outcome,writeback=writeback,pi_export=export)==status
