import asyncio
from types import SimpleNamespace
import pytest
from playwright.async_api import async_playwright
from async_runtime.browser import launch_browser_context
from async_runtime.window_layout import maximize_window


def test_persistent_context_has_native_viewport_and_confirmed_maximize(tmp_path):
    async def scenario():
        async with async_playwright() as pw:
            context=await launch_browser_context(pw,dict(user_data_dir=str(tmp_path/'profile'),browser_channel='chrome',headless=True,headless_fixed_window='NO'),tmp_path)
            try:
                page=context.pages[0]
                assert page.viewport_size is None
                report=await maximize_window(page)
                assert report['bounds']['windowState']=='maximized'
                assert report['geometry']['innerWidth']>0 and report['geometry']['innerHeight']>0
            finally:await context.close()
    asyncio.run(scenario())


class Session:
    def __init__(self,state='normal',ignore_maximize=False):
        self.state=state;self.ignore_maximize=ignore_maximize;self.transitions=[];self.detached=False
    async def send(self,method,params=None):
        if method=='Browser.getWindowForTarget':return dict(windowId=1)
        if method=='Browser.getWindowBounds':return dict(bounds=dict(windowState=self.state,width=1400,height=900))
        if method=='Browser.setWindowBounds':
            state=params['bounds']['windowState'];self.transitions.append(state)
            if not self.ignore_maximize:self.state=state
        return {}
    async def detach(self):self.detached=True


def page_for(session):
    async def attach(page):return session
    async def geometry(script):return dict(innerWidth=1400,innerHeight=800,clientWidth=1400,clientHeight=800,scrollWidth=1400,scrollHeight=800,readyState='complete')
    return SimpleNamespace(context=SimpleNamespace(new_cdp_session=attach),evaluate=geometry)


def test_minimized_window_is_restored_before_maximizing():
    session=Session(state='minimized')
    report=asyncio.run(maximize_window(page_for(session)))
    assert report['bounds']['windowState']=='maximized'
    assert session.transitions==['normal','maximized'] and session.detached


def test_failed_native_maximize_stops_with_bounded_error():
    session=Session(ignore_maximize=True)
    with pytest.raises(RuntimeError,match='WINDOW_MAXIMIZE_NOT_CONFIRMED'):
        asyncio.run(maximize_window(page_for(session),timeout_ms=150))
    assert session.detached
