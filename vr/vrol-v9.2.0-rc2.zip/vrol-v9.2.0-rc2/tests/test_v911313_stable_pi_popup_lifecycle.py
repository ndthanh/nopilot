from pathlib import Path

def test_pi_and_issuer_share_popup_lock():
 t=Path('async_runtime/sync_parity_engine.py').read_text(encoding='utf-8')
 for x in ['_VROL_POPUP_LOCK=Lock()','_ISSUER_LOCK=_VROL_POPUP_LOCK','_PI_LOCK=_VROL_POPUP_LOCK','with _PI_LOCK:','PI POPUP LOCK ACQUIRED']:
  assert x in t

def test_cleanup_preserves_foreign_popups():
 t=Path('async_runtime/sync_parity_engine.py').read_text(encoding='utf-8')
 for x in ['opener=extra.opener','if opener is page:','FOREIGN POPUP PRESERVED']:
  assert x in t

def test_popup_closes_after_final_pdf_persistence_gate():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 start=t.index('def download_pi_document');end=t.index('def _transaction_count_from_page',start);segment=t[start:end]
 assert segment.index('PI_EVIDENCE_POST_SAVE_VALIDATION_FAILED') < segment.index('PI DETAIL POPUP CLOSE')
 assert 'persisted=true' in segment
 assert 'reason=pdf_persisted_and_validated' in segment
