from pathlib import Path

def test_launcher_allows_excel_worker_count_and_cli_override():
 t=Path('run_async_parallel_case_review.cmd').read_text(encoding='utf-8')
 assert '--workers' not in t and '%*' in t
def test_runtime_logs_worker_resolution_and_dynamic_version():
 t=Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
 assert 'Worker configuration resolved' in t
 assert 'resolve_workers(settings,args.workers)' in t
 assert "root/'VERSION.txt'" in t
