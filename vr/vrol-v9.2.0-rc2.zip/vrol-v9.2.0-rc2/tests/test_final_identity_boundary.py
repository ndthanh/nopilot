import asyncio
from unittest.mock import Mock
import pytest
from playwright.async_api import async_playwright
from async_runtime.popup_registry import PopupRegistry
from async_runtime.native_case import validate_identity
from async_runtime.final_submit import final_submit


def test_final_submit_rechecks_identity_after_evidence_capture(tmp_path,monkeypatch):
    async def scenario():
        async with async_playwright() as pw:
            browser=await pw.chromium.launch(channel='chrome',headless=True)
            context=await browser.new_context();registry=PopupRegistry(context)
            page=await context.new_page();registry.register(page,'W01');scope=page.main_frame
            await page.set_content('''<span ng-bind="disputeData.screenName">Consumer Dispute Questionnaire</span>
                <p>VROL Case Number 1234567</p><dd ng-bind="data.pinnedOriginalTransaction.visaTransactionId">123</dd>
                <button ng-click="trigger(Buttons.SUBMIT,true)" ng-show="isBtnVisible(Buttons.SUBMIT)" onclick="window.submitted=true">Submit</button>''')
            item={'code':'13.1','invoice':'123'}
            await validate_identity(scope,item,'1234567')
            async def capture(**kwargs):
                await page.locator('dd').evaluate('e=>e.textContent="999"')
                return b''
            monkeypatch.setattr(page,'screenshot',capture)
            async def verify():await validate_identity(scope,item,'1234567')
            with pytest.raises(RuntimeError,match='QUESTIONNAIRE_INVOICE_MISMATCH'):
                await final_submit(page,page,scope,registry,{'allow_final_submit':'YES'},tmp_path,Mock(),verify_identity=verify)
            assert not await page.evaluate('window.submitted || false')
            assert not (tmp_path/'case_checkpoint.json').exists()
            await registry.close();await browser.close()
    asyncio.run(scenario())
