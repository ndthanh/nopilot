from pathlib import Path
from openpyxl import load_workbook

def test_pi_spinner_before_pdf():
 t=Path('src/review/guid_group.py').read_text(encoding='utf-8')
 assert 'def _wait_pi_spinner_hidden' in t
 start=t.index('def download_pi_document')
 assert t.index('_wait_pi_spinner_hidden(detail,settings,logger)',start) < t.index('with detail.expect_download',start)
 assert "locator('#piSpinner')" in t and 'stable_required' in t

def test_guid_log_separation():
 t=Path('async_runtime/worker.py').read_text(encoding='utf-8')
 for x in ['guid_case.log','GUID CASE {phase}','CASE START','INPUT |','OUTPUT |']:
  assert x in t
 assert "[GUID={group.guid}]" in t

def test_run_log_and_default_workers():
 t=Path('run_async_parallel_case_review.py').read_text(encoding='utf-8')
 assert "_RUN_LOG_PATH=run_dir/'logs'/'run.log'" in t
 assert "'%d.%m.%Y %H:%M:%S.%f'" in t
 # Review 2026-11-20: check the tracked sample, not the private config.xlsx.
 wb=load_workbook('config.sample.xlsx',data_only=True,read_only=True);ws=wb['Settings']
 values={str(r[0]).strip():r[1] for r in ws.iter_rows(min_row=2,values_only=True) if r and r[0]}
 assert 1<=int(values['async_worker_count'])<=int(values['async_worker_max'])==5
 wb.close()
