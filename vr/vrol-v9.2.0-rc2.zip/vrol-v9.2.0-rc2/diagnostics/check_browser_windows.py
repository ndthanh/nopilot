"""Local headful check: no Visa connection, credentials, OTP or real case."""
import argparse
import asyncio
import html
import json
import logging
import struct
import sys
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from playwright.async_api import async_playwright
from rich.console import Console
from async_runtime.browser import launch_browser_context,maximize_initial_login_window
from async_runtime.window_layout import maximize_window,wait_layout
from async_runtime.final_submit import prepare_questionnaire,capture_questionnaire
from async_runtime.native_ui import fill_test_questionnaire
from async_runtime.console_log import ConsoleLog

LOG=logging.getLogger('window_probe')
C=Console()

async def bounds(page):
    session=await page.context.new_cdp_session(page)
    try:return (await session.send('Browser.getWindowForTarget'))['bounds']
    finally:await session.detach()

async def popup(parent,name,features):
    async with parent.expect_popup() as pending:
        await parent.evaluate('(args)=>{window.open("about:blank",args.name,args.features)}',dict(name=name,features=features))
    return await pending.value

async def resized(page,width,height):
    session=await page.context.new_cdp_session(page)
    try:
        window_id=(await session.send('Browser.getWindowForTarget'))['windowId']
        await session.send('Browser.setWindowBounds',dict(windowId=window_id,bounds=dict(windowState='normal')))
        await session.send('Browser.setWindowBounds',dict(windowId=window_id,bounds=dict(width=width,height=height)))
    finally:await session.detach()
    return await wait_layout(page)

async def check_cycle(pw,output,cycle):
    folder=output/f'cycle_{cycle:02d}';folder.mkdir()
    settings=dict(user_data_dir=str(output/'profile'),browser_channel='chrome',headless=False,async_backend='native_async')
    context=await launch_browser_context(pw,settings,folder)
    try:
        main=context.pages[0]
        initial=await maximize_initial_login_window(main)
        await main.set_content('<style>body{margin:0}header{width:100%;background:#204080;color:white;padding:20px 0}</style><header>LOCAL WINDOW TEST — NOT VISA</header>')
        assert main.viewport_size is None,'Fixed viewport is still enabled'
        small=max(600,initial['bounds']['width']//2);large=max(small+160,int(initial['bounds']['width']*.8))
        a=await resized(main,small,650);b=await resized(main,large,750)
        assert abs((b['innerWidth']-a['innerWidth'])-(b['outerWidth']-a['outerWidth']))<=2,'Viewport did not follow native resize'
        assert b['innerWidth']>a['innerWidth'],'Native resize had no effect on content'
        main_layout=await maximize_window(main,LOG,label='MAIN_PROBE')
        await main.screenshot(path=str(folder/'01_main_maximized.png'))

        details=await popup(main,'local_pi','popup,width=560,height=400')
        await details.set_content('<h1>Local PI popup</h1><p>Keep native size.</p>')
        details_before=await bounds(details)
        creation=await popup(main,'local_creation','popup,width=620,height=480')
        await creation.set_content('<h1>Local Case Creation</h1><p>Keep native size.</p>')
        creation_before=await bounds(creation)
        assert details_before['windowState']=='normal' and creation_before['windowState']=='normal'

        questionnaire=await popup(creation,'local_questionnaire','popup,width=650,height=500')
        form='''<style>body{margin:0;font:16px Arial}main{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;padding:16px}section{min-width:0;background:#eef3f9;padding:20px;min-height:1050px}input,select{max-width:100%}header,footer{padding:18px;background:#dce7f5}footer{text-align:right}@media(max-width:900px){main{grid-template-columns:1fr}}</style>
        <header><span ng-bind="disputeData.screenName">Fraud Dispute Questionnaire</span><p>LOCAL TEST — NOT VISA</p><p>10.4 Fraud - Card Absent Environment</p><p>VROL Case Number 123456789</p></header>
        <main><section>Transaction information<input name="disputeAmount" value="100"></section><section>Member Case Number<input name="memberCaseNumber"><p><label><input type="checkbox" name="CardholderDeniesAuthorizingInd">Cardholder denies authorization</label></p><select name="FraudTypeCode"><option value="FT6">FT6</option></select></section><section>Comments and documents</section></main>
        <footer><button onclick="window.finalClicked=true">Submit</button></footer>
        <script>document.addEventListener('input',()=>{if(!window.firstFillWidth)window.firstFillWidth=innerWidth;});</script>'''
        await questionnaire.set_content('<style>body{margin:0}iframe{border:0;width:100%;height:500px;display:block}</style><iframe name="q" srcdoc="'+html.escape(form,quote=True)+'"></iframe>')
        scope=questionnaire.frame(name='q')
        await scope.locator('[name="memberCaseNumber"]').wait_for()
        before=await bounds(questionnaire)
        assert before['windowState']=='normal'
        layout=await prepare_questionnaire(questionnaire,scope,LOG)
        assert layout['window']['bounds']['windowState']=='maximized'
        assert questionnaire.viewport_size is None
        await fill_test_questionnaire(scope,'10.4',dict(validate_dispute_amount='NO',allow_final_submit='NO'),dict(qt='LOCAL-ONLY',invoice='000123'))
        first_fill=await scope.evaluate('window.firstFillWidth')
        assert abs(first_fill-layout['content']['innerWidth'])<=2,'Form was filled before the maximized layout settled'
        assert await scope.locator('[name="memberCaseNumber"]').input_value()=='LOCAL-ONLY'
        assert not await scope.evaluate('window.finalClicked || false')
        image=folder/'02_questionnaire_filled_maximized.png'
        capture=await capture_questionnaire(questionnaire,scope,image,LOG)
        size=list(struct.unpack('>II',image.read_bytes()[16:24]))
        final=await wait_layout(questionnaire);content=await wait_layout(scope)
        (folder/'capture_geometry.json').write_text(json.dumps(dict(size=size,before_capture=capture,final=final,content=content,bounds=await bounds(questionnaire)),indent=2),encoding='utf-8')
        assert final['scrollWidth']<=final['clientWidth']+1,'Content overflows the maximized window horizontally'
        assert abs(size[0]-capture['scrollWidth']*capture['devicePixelRatio'])<=2,'Full-page screenshot width does not match document CSS width and DPI at capture'
        right=await scope.locator('button').evaluate('el=>el.getBoundingClientRect().right')
        assert right<=min(content['innerWidth'],size[0]/capture['devicePixelRatio'])+1,'Submit is horizontally clipped'
        for other,old in ((details,details_before),(creation,creation_before)):
            new=await bounds(other)
            assert all(new[k]==old[k] for k in ('width','height','windowState')),'An ordinary popup was resized'
        assert (await bounds(main))['windowState']=='maximized'
        report=dict(cycle=cycle,status='PASS',main=main_layout,resize_samples=[a,b],ordinary_popups_native=True,
            questionnaire_before=before,questionnaire_before_fill=layout,first_fill_width=first_fill,
            questionnaire_after_capture=final,screenshot=str(image),screenshot_size=size,final_submit_clicked=False)
        (folder/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        C.print(f'[green]PASS cycle {cycle}[/green] | native viewport | questionnaire maximized BEFORE fill | PNG {size[0]}x{size[1]} | PI/Case Creation unchanged')
        return report
    finally:await context.close()

async def main(cycles):
    output=ROOT/'runtime/window_layout'/datetime.now().strftime('%Y%m%d_%H%M%S');output.mkdir(parents=True)
    reports=[]
    try:
        async with async_playwright() as pw:
            for cycle in range(1,cycles+1):reports.append(await check_cycle(pw,output,cycle))
    except Exception as exc:
        (output/'result.json').write_text(json.dumps(dict(status='FAILED',error=str(exc),reports=reports),indent=2),encoding='utf-8')
        raise
    (output/'result.json').write_text(json.dumps(dict(status='PASS',cycles=cycles,reports=reports),indent=2),encoding='utf-8')
    C.print(f'[bold green]All {cycles} cycles passed[/bold green]\nOutput: {output}')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--cycles',type=int,default=3)
    args=parser.parse_args()
    if args.cycles<1:parser.error('--cycles must be at least 1')
    with ConsoleLog(ROOT/'runtime/test_sessions/window_layout_probe.log'):
        C.file=sys.stdout
        logging.basicConfig(level=logging.INFO,format='%(message)s')
        try:asyncio.run(main(args.cycles))
        except Exception:
            C.print_exception()
            raise SystemExit(1)
