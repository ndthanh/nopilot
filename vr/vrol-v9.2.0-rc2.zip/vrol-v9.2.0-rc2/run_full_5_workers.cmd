@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONUNBUFFERED=1"
set "PYTHONIOENCODING=utf-8"
set "RPA_OPS_SELECTED_INPUT="
set "RPA_OPS_GUID_REQUEST="
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --workers 5 --source-workbook "09_chargeback_classified.xlsx" --mapping-file "input.txt" %*
set "RC=%ERRORLEVEL%"
echo Visa full run exit code: %RC%
pause
exit /b %RC%
