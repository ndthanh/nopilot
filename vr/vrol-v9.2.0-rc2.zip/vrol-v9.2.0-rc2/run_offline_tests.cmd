@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m pytest tests -q %*
set RC=%ERRORLEVEL%
echo Test exit code: %RC%
pause
exit /b %RC%
