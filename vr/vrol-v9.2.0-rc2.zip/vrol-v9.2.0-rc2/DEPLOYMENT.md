> **v9.2.0 / dashboard v0.14.0:** dùng [HUONG_DAN_TRIEN_KHAI_VROL_DASHBOARD.md](HUONG_DAN_TRIEN_KHAI_VROL_DASHBOARD.md) (lịch 19:40, contract v2, AM SKIP/FORCE, Final Submit, worker). Phần dưới là ghi chú bản cũ; registry/review holds đã bỏ.

# Triển khai Visa độc lập

Copy riêng project này vào đường dẫn cố định, ví dụ D:\Bots\Visa. Không cần Dashboard
hay deployment ở cạnh. Dùng Windows/Python 64-bit, Chrome headful trong phiên user
đã đăng nhập. CMD:

```bat
install.cmd
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --workers 5
```

Project có .venv riêng. Configure tạo config.xlsx từ config.sample.xlsx nếu thiếu,
backup config.before_paths.xlsx rồi chỉnh paths. Điền credentials/SecurityQuestions
trong config.xlsx. Mẫu trace_enabled=NO, allow_final_submit=NO. Configure giữ
credentials/công tắc hiện có. Copy file OTP mới khi console yêu cầu.

Mẫu dùng FOLDER_FILENAME, *.txt, mã 8 số, poll 5 giây/timeout 180 giây. Sau
WAITING_OTP tạo file mới `YYYYMMDD_HHMMSS_12345678.txt` (thay số minh họa bằng OTP
thực). Ưu tiên cụm số cuối filename; fallback đọc nội dung `OTP: 12345678`. Giữ file
cũ hoặc mtime cũ có thể bị bỏ qua. Đổi min/max digits nếu môi trường có mã dài khác.

Dashboard cấu hình visa-root trỏ về project này, xuất bundle vào runtime\ops_inputs\
<bundle_id>\manifest.json: snapshot file 09 và input.txt GUID|PAN, SHA256, lineage
FC/GUID2PAN, source completion. input.txt upstream thường cố định đường dẫn;
run dùng snapshot riêng. Không chọn hai raw file mới nhất.

```bat
run_vrol_from_ops.cmd "D:\Bots\Visa\runtime\ops_inputs\BUNDLE\manifest.json"
```

Ca upstream 19:30: Task Scheduler gọi run_scheduled.cmd lúc 19:40 (19:35 cũng được),
Start in = root Visa, Run only when user is logged on. Không cần PowerShell. Launcher
chờ READY trước login, có heartbeat WAITING_INPUT. Settings:

Task Action Program/script = C:\Windows\System32\cmd.exe; Add arguments =
`/d /c ""D:\Bots\Visa\run_scheduled.cmd""`; Start in = D:\Bots\Visa (không dấu
nháy). Chọn Do not start a new instance nếu task còn chạy; không đặt stop-after
ngắn hoặc tự restart khi case chưa rõ. Lần đầu Run task với Final NO và xem CMD/OTP.

| Key | Default |
|---|---|
| scheduled_contract_dir | runtime\ops_inputs |
| scheduled_source_not_before | 19:30, theo giờ Việt Nam |
| scheduled_input_wait_seconds | 1800 |
| scheduled_input_poll_seconds | 10 |
| async_worker_count / async_worker_max | 5 / 5 |
| async_restart_after_guids | 100 sau configure |
| rol500_preflight_enabled / rol500_postflight_enabled | YES / YES |

Cả hai source phải hoàn tất hôm nay từ cutoff trở đi. Timeout chưa READY thì lỗi
trước mở Visa. Đổi contract directory cần Dashboard VROL_INPUT_CONTRACT_DIR khớp.
Dashboard cần xuất contract; sau đó Visa không phụ thuộc HTTP.

Bật gửi case mới đủ điều kiện: đổi **Settings allow_final_submit=YES**, dùng
run_scheduled.cmd hoặc run_vrol_from_ops.cmd. Nút exact Submit đã probe trên Visa;
chưa gửi Final thật trong môi trường thử. Runtime kiểm tra identity, nút unique/
visible/enabled, chờ kết quả ổn định rồi chụp 07_final_submit_result.png. Kết quả chưa
rõ thì hold/reconcile, không bấm lại. --pre-submit-only/launcher diagnostic luôn
thắng config YES. Flip switch không tự gửi lại draft/case đã tạo trong run cũ.

Output runtime\async_parallel\<run_id>: Excel kết quả, documents tổng hợp PI,
groups\<OUTCOME>_<GUID> chứa ảnh/PI/checkpoint, guid_outcomes.csv/json,
postflight\ROL500.csv và reconciliation. Sau workers tải ROL500 mới để cập nhật
Excel theo invoice/QT. Dashboard đọc progress filesystem, poll mặc định 5 giây.

Khi tiếp tục dữ liệu cũ, import state, không ghi đè hold đã có:

```bat
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --migration-state-dir "D:\Handoff\migration_state"
```

Giữ config/registry/runtime review_holds và artifact khi nâng cấp. Không xóa hold
để ép tạo lại case. Regression: run_offline_tests.cmd, không gửi Visa thật.
Bản ZIP kèm TECHNICAL_HANDOVER.md trong project này để tra module/rules/retry.
