@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONUNBUFFERED=1"
set "PYTHONIOENCODING=utf-8"
set "RPA_OPS_SELECTED_INPUT="
set "RPA_OPS_GUID_REQUEST="
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async --scheduled %*
exit /b %ERRORLEVEL%
