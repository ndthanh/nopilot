@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
call sync_master_status.cmd --cleanup %*
exit /b %ERRORLEVEL%
