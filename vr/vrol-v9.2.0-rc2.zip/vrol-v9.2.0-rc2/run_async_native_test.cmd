@echo off
setlocal
cd /d "%~dp0"
title VROL Native Async - PI Test - OTP Console
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  pause
  exit /b 1
)
echo NATIVE ASYNC TEST - 3 GUIDs - PI DOWNLOAD - NO ISSUER ACTION
".venv\Scripts\python.exe" -u run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --workers 3 --limit-groups 3 --pi-only %*
set RC=%ERRORLEVEL%
echo.
echo Test exit code: %RC%
pause
exit /b %RC%
