from __future__ import annotations


def maximize_page_window(page, logger=None, wait_ms=500):
    """Maximize the native Chrome window owning a VROL popup."""
    methods=[]
    try:
        session=page.context.new_cdp_session(page)
        try:
            info=session.send('Browser.getWindowForTarget')
            window_id=info.get('windowId')
            if window_id is not None:
                session.send('Browser.setWindowBounds',{'windowId':window_id,'bounds':{'windowState':'maximized'}})
                methods.append('CDP_BROWSER_SET_WINDOW_BOUNDS')
        finally:
            try:session.detach()
            except Exception:pass
    except Exception as exc:
        if logger:logger.warning('VROL WINDOW CDP MAXIMIZE FAILED | error=%s',exc)
    try:
        page.evaluate('''() => { try { window.moveTo(0,0); window.resizeTo(screen.availWidth,screen.availHeight); return true; } catch(e) { return false; } }''')
        methods.append('WINDOW_RESIZE_FALLBACK')
    except Exception as exc:
        if logger:logger.warning('VROL WINDOW JS RESIZE FALLBACK FAILED | error=%s',exc)
    try:page.bring_to_front()
    except Exception:pass
    try:page.wait_for_timeout(int(wait_ms))
    except Exception:pass
    try:metrics=page.evaluate('''() => ({outerWidth,outerHeight,innerWidth,innerHeight,availWidth:screen.availWidth,availHeight:screen.availHeight})''')
    except Exception:metrics={}
    if logger:logger.info('VROL POPUP WINDOW MAXIMIZED | methods=%s | metrics=%s | url=%s',methods,metrics,page.url)
    return {'methods':methods,'metrics':metrics}
