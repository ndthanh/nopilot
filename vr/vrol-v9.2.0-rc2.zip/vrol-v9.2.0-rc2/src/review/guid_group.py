from __future__ import annotations
import json,re,time,shutil,os
from collections import OrderedDict
from pathlib import Path
from openpyxl import load_workbook
from src.io.mapping import mask_pan
from src.io.group_review_output import review_key
from src.vrol.workflow import (open_transaction_inquiry,fill_transaction_inquiry_pan,
 fill_transaction_inquiry_start_date,click_transaction_inquiry_submit,wait_transaction_results,
 normalize_invoice_number,apply_invoice_filter,_list_setting,BusinessReview,UnknownScenario)
from src.vrol.transaction_table import schema_from_dom,parse_row_for_code,transaction_id_matches_invoice,normalize_transaction_id_for_invoice

def clean(v): return str(v or '').strip()
def norm_code(v):
    v=clean(v)
    return v[:-2] if v.endswith('.0') else v

def load_guid_groups(path:Path,mapping:dict):
    wb=load_workbook(path,data_only=True,read_only=True);ws=wb['Sheet1']
    headers=list(next(ws.iter_rows(min_row=2,max_row=2,values_only=True)))
    h={clean(v):i for i,v in enumerate(headers) if v is not None}
    required={'BUT TOAN','NGAY GD','GUID','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'}
    valid_cb_col=h.get('VALID CHARGEBACK')
    if valid_cb_col is not None and valid_cb_col!=33:
        raise ValueError(f'CASE_REVIEW_VALID_CHARGEBACK_NOT_COLUMN_AH:index={valid_cb_col+1}')
    missing=required-set(h)
    if missing: raise ValueError('CASE_REVIEW_MISSING_HEADERS:'+','.join(sorted(missing)))
    rows=[];filter_stats={'total_data_rows':0,'u_sale_rows':0,'u_not_sale_rows':0,'ah_y_rows':0,'ah_not_y_rows':0,'eligible_code_rows':0}
    for row_no,row in enumerate(ws.iter_rows(min_row=4,values_only=True),start=4):
        filter_stats['total_data_rows']+=1
        check_sale=clean(row[h['CHECK SALE']]).upper()
        if check_sale!='SALE':
            filter_stats['u_not_sale_rows']+=1
            continue
        filter_stats['u_sale_rows']+=1
        valid_cb=clean(row[h['VALID CHARGEBACK']]).upper()
        if valid_cb!='Y':
            filter_stats['ah_not_y_rows']+=1
            continue
        filter_stats['ah_y_rows']+=1
        guid=clean(row[h['GUID']]).upper();qt=clean(row[h['BUT TOAN']]);invoice=clean(row[h['INVOICENUM']])
        if not guid or not qt or not invoice: continue
        code=norm_code(row[h['CODE CB']])
        if code not in {'13.1','10.4','13.9'}: continue
        filter_stats['eligible_code_rows']+=1
        d=clean(row[h['NGAY GD']])
        if not re.fullmatch(r'\d{8}',d): d=''
        review_status=clean(row[h['BOT REVIEW STATUS']]).upper() if 'BOT REVIEW STATUS' in h else ''
        rows.append({'row_no':row_no,'qt':qt,'guid':guid,'invoice':invoice,'code':code,'start_date':d,'review_key':review_key(guid,invoice,qt,code),'review_status':review_status,
                     'pi':clean(row[h['PI']]) if 'PI' in h else '',
                     'merchant':clean(row[h['TERMOWNER']]) if 'TERMOWNER' in h else ''})
    rows.sort(key=lambda x:(x['guid'],x['row_no']))
    grouped=OrderedDict()
    for item in rows: grouped.setdefault(item['guid'],[]).append(item)
    groups=[]
    for index,(guid,items) in enumerate(grouped.items(),1):
        pan=mapping.get(guid.upper())
        dates=[x['start_date'] for x in items if x['start_date']]
        groups.append({'group_index':index,'guid':guid,'pan':pan or '','masked_pan':mask_pan(pan) if pan else '',
                       'start_date':min(dates) if dates else '', 'items':items})
    return groups,filter_stats

def _checked_inventory(frame):
    checked=frame.locator('table#results input[type="checkbox"]:checked')
    ids=[]
    for i in range(checked.count()):
        try:
            row=checked.nth(i).locator('xpath=ancestor::tr[1]')
            ids.append(row.get_attribute('id') or row.inner_text()[:80])
        except Exception: ids.append('checked')
    return ids

def _no_matching_transaction_message(frame):
    selectors=['span.errorSummary','td span.errorSummary','.errorSummary']
    for selector in selectors:
        try:
            loc=frame.locator(selector)
            for i in range(loc.count()):
                text=' '.join((loc.nth(i).inner_text() or '').split())
                if re.search(r'ROL-897\s*:\s*No matching transactions found',text,re.I):
                    return text
        except Exception:pass
    return ''

def _no_matching_result(group,message):
    return {'status':'MANUAL_REVIEW_REQUIRED','decision':'MANUAL_REVIEW_REQUIRED',
            'reason_code':'ROL_897_NO_MATCHING_TRANSACTIONS','reason_detail':message,
            'issuer_action_required':False,'issuer_action_clicked':False,'selected_count':0,
            'invoice_results':[{'row_no':x['row_no'],'qt':x['qt'],'code':x['code'],'invoice_raw':x['invoice'],
              'scan_status':'NO_MATCHING_TRANSACTIONS_AT_PAN_DATE_SEARCH','tran_types':[],'sale_selected':False} for x in group['items']]}

def _safe_filename(value):
    text=re.sub(r'[<>:"/\\|?*]+','_',str(value or '').strip())
    text=re.sub(r'\s+',' ',text).strip(' ._')
    return text[:120] or 'UNKNOWN_MERCHANT'

def _wait_pi_spinner_hidden(detail,settings,logger):
    """Wait for PI content generation to finish before Save as PDF."""
    timeout_ms=int(settings.get('pi_spinner_hidden_timeout_ms',45000))
    poll_ms=int(settings.get('pi_spinner_hidden_poll_ms',200))
    stable_required=int(settings.get('pi_spinner_hidden_stable_polls',3))
    deadline=time.monotonic()+timeout_ms/1000;stable=0;history=[]
    while time.monotonic()<deadline:
        found=False;all_hidden=True;observed=[]
        for scope in [detail]+[f for f in detail.frames if f!=detail.main_frame]:
            try:
                loc=scope.locator('#piSpinner')
                for index in range(loc.count()):
                    found=True
                    state=loc.nth(index).evaluate("""el => {const cs=getComputedStyle(el);const r=el.getBoundingClientRect();return {inlineDisplay:(el.style.display||'').toLowerCase(),computedDisplay:(cs.display||'').toLowerCase(),visibility:(cs.visibility||'').toLowerCase(),hidden:!!el.hidden,width:r.width,height:r.height};}""")
                    hidden=(state['hidden'] or state['inlineDisplay'] in ('hidden','none') or state['computedDisplay']=='none' or state['visibility']=='hidden' or (state['width']==0 and state['height']==0))
                    all_hidden=all_hidden and hidden;observed.append(state)
            except Exception as exc:observed.append({'probe_error':str(exc).splitlines()[0]})
        ready=(not found) or all_hidden
        stable=stable+1 if ready else 0
        history.append({'found':found,'all_hidden':all_hidden,'observed':observed[-3:]})
        if stable>=stable_required:
            logger.info('PI SPINNER HIDDEN - SAVE AS PDF READY | stable_polls=%s | spinner_found=%s | observed=%s',stable,found,observed[-3:])
            return
        detail.wait_for_timeout(poll_ms)
    raise UnknownScenario('PI_SPINNER_NOT_HIDDEN_BEFORE_SAVE_AS_PDF:'+repr(history[-5:]))

def _open_pi_detail_popup(context,menu,settings,logger,group,invoice):
    """Open or reacquire the PI detail popup without relying only on expect_page.

    VROL/Chrome can reuse a transaction-details popup, so no new page event is
    guaranteed. Track existing pages and URLs, click, then accept either a new
    page or a reused live page whose URL/content becomes transaction details.
    """
    timeout_ms=int(settings.get('pi_popup_timeout_ms',20000))
    poll_ms=int(settings.get('pi_popup_poll_ms',150))
    before={id(p):(p.url if not p.is_closed() else '') for p in context.pages}
    menu.click()
    deadline=time.monotonic()+timeout_ms/1000;observed=[]
    while time.monotonic()<deadline:
        for candidate in reversed(context.pages):
            try:
                if candidate.is_closed():continue
                url=str(candidate.url or '')
                title=''
                try:title=candidate.title()
                except Exception:pass
                is_new=id(candidate) not in before
                is_detail=('ti-detail' in url.lower() or 'transaction detail' in title.lower() or candidate.locator('button#pdfButton[data-action="saveAsPDF"]').count()>0)
                observed.append({'new':is_new,'url':url,'title':title})
                if candidate is not None and is_detail:
                    logger.info('PI DETAIL POPUP READY | guid=%s | invoice=%s | new_page=%s | url=%s',group.get('guid'),invoice,is_new,url)
                    return candidate
            except Exception as exc:observed.append({'error':str(exc).splitlines()[0]})
        time.sleep(poll_ms/1000)
    raise UnknownScenario('PI_DETAIL_POPUP_NOT_READY:'+repr(observed[-10:]))

def _snapshot_download_dir(folder):
    snapshot={}
    if folder.exists():
        for path in folder.iterdir():
            if path.is_file():
                try:snapshot[path.name]=(path.stat().st_mtime_ns,path.stat().st_size)
                except Exception:pass
    return snapshot

def _configure_pi_download_directory(detail,download_dir,logger,group,invoice):
    """Route this popup's Chrome download directly to a dedicated invoice folder."""
    session=None
    try:
        session=detail.context.new_cdp_session(detail)
        session.send('Browser.setDownloadBehavior',{
            'behavior':'allow',
            'downloadPath':str(download_dir),
            'eventsEnabled':True,
        })
        logger.info('PI CDP DOWNLOAD DIRECTORY SET | guid=%s | invoice=%s | path=%s',group.get('guid'),invoice,download_dir)
        return session
    except Exception as exc:
        if session:
            try:session.detach()
            except Exception:pass
        raise UnknownScenario('PI_CDP_DOWNLOAD_DIRECTORY_FAILED:'+str(exc))

def _wait_invoice_pdf_file(download_dir,before,settings,detail,logger,group,invoice):
    timeout_ms=int(settings.get('pi_browser_download_ready_timeout_ms',60000))
    poll_ms=int(settings.get('pi_browser_download_poll_ms',250))
    stable_required=int(settings.get('pi_download_file_stable_polls',4))
    minimum_bytes=int(settings.get('pi_download_minimum_pdf_bytes',1000))
    deadline=time.monotonic()+timeout_ms/1000;states={};history=[]
    while time.monotonic()<deadline:
        candidates=[];crdownloads=[]
        for path in download_dir.iterdir() if download_dir.exists() else []:
            try:
                if not path.is_file():continue
                if path.name.endswith('.crdownload'):
                    crdownloads.append((path.name,path.stat().st_size));continue
                stat=path.stat();old=before.get(path.name)
                if old is not None and stat.st_mtime_ns<=old[0] and stat.st_size==old[1]:continue
                with path.open('rb') as handle:signature=handle.read(5)
                if stat.st_size<minimum_bytes or signature!=b'%PDF-':continue
                previous=states.get(str(path),(-1,0));stable=previous[1]+1 if previous[0]==stat.st_size else 1
                states[str(path)]=(stat.st_size,stable);candidates.append((stat.st_mtime_ns,path,stat.st_size,stable,signature))
            except Exception:pass
        if candidates:
            candidates.sort(reverse=True,key=lambda x:x[0]);_,path,size,stable,signature=candidates[0]
            history.append({'file':str(path),'size':size,'stable':stable,'crdownloads':crdownloads})
            if stable>=stable_required:
                logger.info('PI INVOICE DOWNLOAD FILE READY | guid=%s | invoice=%s | path=%s | bytes=%s | stable_polls=%s',group.get('guid'),invoice,path,size,stable)
                return path,size,signature
        else:history.append({'files':0,'crdownloads':crdownloads})
        detail.wait_for_timeout(poll_ms)
    raise UnknownScenario('PI_INVOICE_DOWNLOAD_FILE_NOT_READY:'+repr(history[-12:]))

def download_pi_document(page,context,tx,item,group,group_dir,settings,logger):
    """Download PI evidence through View > Tran Details > Save as PDF before Issuer Action."""
    # Reacquire by full transaction identity after every invoice filter redraw.
    live,_,rows=apply_invoice_filter(page.frame(name='bodyframe'),item['invoice'],settings)
    headers=schema_from_dom(live);matches=[]
    for index in range(rows.count()):
        current=parse_row_for_code(rows.nth(index),headers,item['code'])
        if current.transaction_id==tx.transaction_id and current.tran_type==tx.tran_type:matches.append(current)
    if len(matches)!=1:raise UnknownScenario('PI_TRANSACTION_IDENTITY_NOT_UNIQUE')
    tx=matches[0]
    invoice=str(item.get('invoice') or 'UNKNOWN_INVOICE')
    folder=group_dir/'documents';folder.mkdir(parents=True,exist_ok=True)
    invoice_prefix=_safe_filename(invoice)
    last4=str(group.get('pan') or '')[-4:]
    merchant_raw=clean(item.get('merchant') or item.get('termowner') or item.get('TERMOWNER'))
    merchant=_safe_filename(merchant_raw or 'UNKNOWN_MERCHANT')
    if merchant=='UNKNOWN_MERCHANT':
        logger.warning('PI MERCHANT MISSING | guid=%s | invoice=%s | row_no=%s | available_item_keys=%s',group.get('guid'),invoice,item.get('row_no'),sorted(item.keys()))
    else:
        logger.info('PI MERCHANT RESOLVED | guid=%s | invoice=%s | termowner=%s | pdf_suffix=%s',group.get('guid'),invoice,merchant_raw,merchant)
    from async_runtime.pi_artifacts import pi_filename,publish_pi
    target=folder/pi_filename(invoice,group.get('pan'),merchant_raw)
    # The selected row must remain checked. View is in iframe#buttons, not Issuer Action.
    checkbox=tx.locator.get_by_role('checkbox').first
    if checkbox.count() and not checkbox.is_checked():checkbox.check()
    button_frame=page.frame(name='buttons')
    if button_frame is None:raise UnknownScenario('PI_BUTTONS_IFRAME_NOT_FOUND')
    view=button_frame.locator('button#view[data-action="showViewMenu"]').first
    view.wait_for(state='visible',timeout=int(settings.get('pi_view_timeout_ms',10000)));view.click()
    menu=None
    deadline=time.monotonic()+int(settings.get('pi_view_menu_timeout_ms',10000))/1000
    while time.monotonic()<deadline and menu is None:
        for scope in [page]+[f for f in page.frames if f!=page.main_frame]:
            try:
                loc=scope.get_by_role('menuitem',name=re.compile(r'^Tran Details$',re.I),exact=True).first
                if loc.count() and loc.is_visible():menu=loc;break
                label=scope.locator('span#tranTxt').first
                if label.count() and label.is_visible():
                    parent=label.locator('xpath=ancestor::*[self::a or self::button or @role="menuitem"][1]')
                    menu=parent if parent.count() else label
                    break
            except Exception:pass
        if menu is None:page.wait_for_timeout(150)
    if menu is None:raise UnknownScenario('PI_TRAN_DETAILS_MENU_NOT_FOUND')
    detail=_open_pi_detail_popup(context,menu,settings,logger,group,invoice)
    try:detail.wait_for_load_state('domcontentloaded',timeout=int(settings.get('pi_popup_load_timeout_ms',20000)))
    except Exception:pass
    pdf=detail.locator('button#pdfButton[data-action="saveAsPDF"]').first
    pdf.wait_for(state='visible',timeout=int(settings.get('pi_save_pdf_timeout_ms',15000)))
    _wait_pi_spinner_hidden(detail,settings,logger)
    download_dir=group_dir/'_pi_download_tmp'/invoice_prefix
    download_dir.mkdir(parents=True,exist_ok=True)
    for stale in list(download_dir.iterdir()):
        try:
            if stale.is_file():stale.unlink()
        except Exception:pass
    download_before=_snapshot_download_dir(download_dir)
    cdp_session=_configure_pi_download_directory(detail,download_dir,logger,group,invoice)
    logger.info('PI SAVE AS PDF CLICK | guid=%s | invoice=%s | download_dir=%s',group.get('guid'),invoice,download_dir)
    try:
        with detail.expect_download(timeout=int(settings.get('pi_download_timeout_ms',30000))) as download_info:pdf.click()
        download=download_info.value
        failure=download.failure()
        if failure:raise UnknownScenario('PI_EVIDENCE_BROWSER_DOWNLOAD_FAILED:'+str(failure))
        minimum_bytes=int(settings.get('pi_download_minimum_pdf_bytes',1000))
        source_path,source_size,signature=_wait_invoice_pdf_file(download_dir,download_before,settings,detail,logger,group,invoice)
    finally:
        try:cdp_session.detach()
        except Exception:pass
    temp_target=target.with_suffix(target.suffix+'.part')
    if temp_target.exists():temp_target.unlink()
    shutil.copyfile(source_path,temp_target)
    copied_size=temp_target.stat().st_size
    with temp_target.open('rb') as handle:copied_signature=handle.read(5)
    if copied_size!=source_size or copied_size<minimum_bytes:raise UnknownScenario(f'PI_EVIDENCE_COPY_SIZE_INVALID:source={source_size}:copied={copied_size}')
    if copied_signature!=b'%PDF-':raise UnknownScenario('PI_EVIDENCE_INVALID_PDF_SIGNATURE:'+repr(copied_signature))
    os.replace(temp_target,target)
    final_size=target.stat().st_size
    if final_size!=copied_size:raise UnknownScenario(f'PI_EVIDENCE_FINAL_SIZE_INVALID:source={source_size}:copied={copied_size}:final={final_size}')
    logger.info('PI DOWNLOAD FILE STABLE | guid=%s | invoice=%s | browser_file=%s | source_bytes=%s | final_bytes=%s | pdf_signature=%s',group.get('guid'),invoice,source_path,source_size,final_size,copied_signature)
    # Final persistence gate must pass before the PI popup is allowed to close.
    with target.open('rb') as final_handle:
        final_signature=final_handle.read(5)
        final_handle.seek(0,2);persisted_bytes=final_handle.tell()
    if final_signature!=b'%PDF-' or persisted_bytes<minimum_bytes:
        raise UnknownScenario(f'PI_EVIDENCE_POST_SAVE_VALIDATION_FAILED:signature={final_signature}:bytes={persisted_bytes}')
    result={'required':True,'status':'DOWNLOADED','file_name':target.name,'original_name':download.suggested_filename,'path':str(target),'bytes':persisted_bytes,'invoice':invoice}
    result.update(publish_pi(target,settings.get('_async_run_dir') or group_dir.parent.parent,
        group_dir,invoice,group.get('pan'),merchant_raw,tx.transaction_id,minimum_bytes))
    logger.info('PI EVIDENCE DOWNLOADED | guid=%s | qt=%s | invoice=%s | file=%s | bytes=%s | persisted=true | via=View>Tran Details>Save as PDF',group.get('guid'),item.get('qt'),invoice,target,persisted_bytes)
    try:
        for temp_file in list(download_dir.iterdir()):
            if temp_file.is_file():temp_file.unlink()
        download_dir.rmdir()
        parent=download_dir.parent
        if parent.exists() and not any(parent.iterdir()):parent.rmdir()
    except Exception as cleanup_exc:logger.warning('PI TEMP DOWNLOAD CLEANUP FAILED | guid=%s | invoice=%s | error=%s',group.get('guid'),invoice,cleanup_exc)
    try:
        if not detail.is_closed():
            logger.info('PI DETAIL POPUP CLOSE | guid=%s | invoice=%s | reason=pdf_persisted_and_validated',group.get('guid'),invoice)
            detail.close()
    except Exception as close_exc:logger.warning('PI DETAIL POPUP CLOSE FAILED | guid=%s | invoice=%s | error=%s',group.get('guid'),invoice,close_exc)
    return result

def _transaction_count_from_page(body):
    """Read the VROL reported transaction count without mutating DataTables."""
    try:
        text=' '.join((body.locator('body').inner_text(timeout=1500) or '').split())
        match=re.search(r'([0-9,]+)\s+Transactions?\s+Found',text,re.I)
        if match:return int(match.group(1).replace(',',''))
    except Exception:pass
    return None

def _transaction_scan_strategy(body,settings,logger):
    reported=_transaction_count_from_page(body)
    dom_rows=body.locator('table#results tbody tr').count()
    threshold=int(settings.get('transaction_direct_scan_max_rows',25))
    # Never call DataTables API. Large result sets always use the stable human-facing
    # invoice filter. Small fully-rendered tables use fast direct DOM matching.
    use_filter=reported is None or reported>threshold or dom_rows<reported
    strategy='INVOICE_FILTER' if use_filter else 'DIRECT_DOM'
    reason='count_unknown' if reported is None else ('reported_above_threshold' if reported>threshold else ('dom_rows_less_than_reported' if dom_rows<reported else 'small_table_fully_rendered'))
    logger.info('TRANSACTION SCAN STRATEGY | strategy=%s | reported_transactions=%s | dom_rows=%s | direct_scan_max_rows=%s | reason=%s | datatables_api_used=false',strategy,reported,dom_rows,threshold,reason)
    return {'strategy':strategy,'reported_transactions':reported,'dom_rows':dom_rows,'threshold':threshold,'reason':reason}

def precheck_guid_group(page,context,group,settings,group_dir:Path,logger):
    group_dir.mkdir(parents=True,exist_ok=True)
    if not group.get('pan'):
        result={'status':'UNDEFINED_CASE','decision':'MANUAL_REVIEW_REQUIRED','reason_code':'GUID_PAN_MAPPING_NOT_FOUND','issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':[{'row_no':x['row_no'],'qt':x['qt'],'code':x['code'],'invoice_raw':x['invoice'],'scan_status':'NOT_SCANNED_MAPPING_MISSING','tran_types':[],'sale_selected':False} for x in group['items']]}
        (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        logger.warning('GUID GROUP MAPPING MISSING | guid=%s | rows=%s | review_required=true',group['guid'],[x['row_no'] for x in group['items']])
        return result
    if not group.get('start_date'):
        return {'status':'UNDEFINED_CASE','reason_code':'GROUP_START_DATE_MISSING','invoice_results':[]}
    body=open_transaction_inquiry(page,settings)
    body=fill_transaction_inquiry_pan(page,group['pan'],settings)
    body,date_value=fill_transaction_inquiry_start_date(page,group['start_date'],settings)
    click_transaction_inquiry_submit(page,settings);body=wait_transaction_results(page,settings)
    no_match=_no_matching_transaction_message(body)
    if no_match:
        result=_no_matching_result(group,no_match)
        logger.warning('ROL-897 NO MATCHING TRANSACTIONS | guid=%s | pan_bin6_last4=%s | start_date=%s | rows=%s | issuer_action_required=false',group['guid'],group.get('masked_pan'),group.get('start_date'),[x['row_no'] for x in group['items']])
        (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        try:page.screenshot(path=str(group_dir/'rol_897_no_matching_transactions.png'),full_page=True)
        except Exception:pass
        try:(group_dir/'rol_897_no_matching_transactions.html').write_text(body.content(),encoding='utf-8')
        except Exception:pass
        return result
    invoice_results=[];selected=[];selected_txs=[];stop=None
    stop_types_by_code={'10.4':{'credit'},'13.1':{'credit'},'13.9':{'cash rev'}}
    # Read the Transaction Inquiry HTML table directly. The DataTables text filter is
    # only a human UI aid; using it per invoice causes redraw races and hidden-row state
    # errors. All invoice matching and rule checks are now performed against DOM rows.
    scan=_transaction_scan_strategy(body,settings,logger)
    headers=schema_from_dom(body)
    result_rows=body.locator('table#results tbody tr')
    total_result_rows=result_rows.count()
    logger.info('TRANSACTION TABLE SCAN START | guid=%s | strategy=%s | reported_transactions=%s | dom_rows=%s | invoices=%s',group['guid'],scan['strategy'],scan['reported_transactions'],total_result_rows,len(group['items']))
    for position,item in enumerate(group['items'],1):
        settings['active_case_code']=item['code']
        inv=normalize_invoice_number(item['invoice']);parsed=[]
        if scan['strategy']=='INVOICE_FILTER':
            body,inv,filtered_rows=apply_invoice_filter(body,item['invoice'],settings);headers=schema_from_dom(body)
            for i in range(filtered_rows.count()):
                try:tx=parse_row_for_code(filtered_rows.nth(i),headers,item['code'])
                except Exception:continue
                if transaction_id_matches_invoice(tx.transaction_id,inv):parsed.append(tx)
            logger.info('FILTERED INVOICE MATCH | guid=%s | invoice=%s | invoice_search=%s | matched_rows=%s | reported_transactions=%s',group['guid'],item['invoice'],inv,len(parsed),scan['reported_transactions'])
        else:
            for i in range(total_result_rows):
                row=result_rows.nth(i)
                try:tx=parse_row_for_code(row,headers,item['code'])
                except Exception:continue
                if transaction_id_matches_invoice(tx.transaction_id,inv):parsed.append(tx)
            logger.info('DIRECT INVOICE MATCH | guid=%s | invoice=%s | invoice_search=%s | matched_rows=%s | html_rows=%s',group['guid'],item['invoice'],inv,len(parsed),total_result_rows)
        tran_types=[x.tran_type for x in parsed]
        record={'row_no':item['row_no'],'qt':item['qt'],'code':item['code'],'invoice_raw':item['invoice'],
                'invoice_search':inv,'pi_input_excel':str(item.get('pi') or ''),'scan_status':'SCANNED','tran_types':tran_types,'assoc_disputes':sorted({x.assoc_dispute for x in parsed if x.assoc_dispute}),'sale_selected':False}
        invoice_results.append(record)
        expected='Cash' if item['code']=='13.9' else 'Sale'
        # Assoc Dispute D is a group-level stop gate and must be checked before
        # eligible-row uniqueness. VROL may label the original sale as Sale - WT,
        # while a companion row is Sale Dispute Financial - WT. The former is the
        # sale-family row; the latter must not be treated as the original Sale.
        if expected=='Sale':
            sale_family=[x for x in parsed if re.match(r'^Sale(?:\s*-\s*WT)?$',str(x.tran_type or '').strip(),re.I)]
        else:
            sale_family=[x for x in parsed if str(x.tran_type or '').strip().casefold()=='cash']
        eligible=sale_family
        if len(eligible)!=1:
            record['scan_status']='UNDEFINED';record['reason_code']=f'{expected.upper()}_ROW_NOT_UNIQUE:{len(eligible)}'
            return {'status':'UNDEFINED_CASE','reason_code':'ELIGIBLE_ROW_NOT_UNIQUE','invoice_results':invoice_results,
                    'selected_count':len(selected),'date_value':date_value}
        tx=eligible[0]
        pi_value=str(tx.pi or '').strip();record['pi_input']=pi_value;record['pi_source']='VROL_TRANSACTION_TABLE'
        # PI is the highest-priority branch for 10.4, 13.1 and 13.9. When PI=Yes,
        # evidence download wins over MOTO/ECI, refund/reversal and Assoc Dispute gates.
        if pi_value.casefold()=='yes':
            record['pi_status']='PENDING_USER_ACTION';record['scan_status']='PI_DOWNLOAD_REVIEW_REQUIRED'
            record['planned_pre_issuer_action']='View > Tran Details > Save as PDF'
            record['transaction_id']=tx.transaction_id;record['assoc_dispute']=str(tx.assoc_dispute or '').strip().upper()
            selected_txs.append((tx,item))
            logger.info('PI YES OVERRIDES EXCLUSION RULES | guid=%s | invoice=%s | code=%s | transaction_id=%s | precedence=PI_FIRST',group['guid'],item['invoice'],item['code'],tx.transaction_id)
            continue
        record['pi_status']='NOT_REQUIRED'
        stop_matches=[x for x in parsed if x.tran_type.casefold() in stop_types_by_code.get(item['code'],set())]
        if stop_matches:
            trigger=stop_matches[0].tran_type
            stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':trigger,
                  'reason_code':'GROUP_REJECT_TRAN_TYPE','cb_reject':'Refund - Tran Type = '+trigger}
            logger.info('GUID GROUP STOP ON FIRST REFUND | guid=%s | invoice=%s | tran_type=%s | scanned=%s/%s',group['guid'],item['invoice'],trigger,position,len(group['items']))
            break
        assoc=str(tx.assoc_dispute or '').strip().upper();record['assoc_dispute']=assoc
        if assoc=='D':
            record['scan_status']='STOPPED_ASSOC_DISPUTE_D'
            stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':tx.tran_type,
                  'trigger_assoc_dispute':'D','trigger_transaction_id':tx.transaction_id,'reason_code':'GROUP_CONTAINS_ASSOC_DISPUTE_D','cb_reject':'Duplicate - Assoc Dispute = D'}
            logger.info('GUID GROUP STOP ON ASSOC DISPUTE D | guid=%s | invoice=%s | tran_type=%s | transaction_id=%s | scanned=%s/%s',group['guid'],item['invoice'],tx.tran_type,tx.transaction_id,position,len(group['items']))
            break
        if assoc not in {'','D'}:
            record['scan_status']='UNDEFINED_ASSOC_DISPUTE_VALUE'
            return {'status':'UNDEFINED_CASE','decision':'MANUAL_REVIEW_REQUIRED','reason_code':'UNDEFINED_ASSOC_DISPUTE_VALUE','reason_detail':'Unexpected Assoc Dispute value: '+assoc,'issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':invoice_results}
        if item['code']=='10.4':
            moto_eci=str(tx.moto_eci or '').strip();record['moto_eci']=moto_eci
            if moto_eci in {'','5','6'}:
                reject='Lỗi dữ liệu - MOTO/ECI '+('rỗng' if not moto_eci else '= '+moto_eci)
                record['scan_status']='STOPPED_GROUP_REJECT';record['cb_reject']=reject
                stop={'trigger_invoice':item['invoice'],'trigger_invoice_search':inv,'trigger_tran_type':tx.tran_type,'reason_code':'GROUP_REJECT_MOTO_ECI','cb_reject':reject,'trigger_moto_eci':moto_eci}
                break
        cb=tx.locator.get_by_role('checkbox').first
        if not cb.count():
            return {'status':'UNDEFINED_CASE','reason_code':'TRANSACTION_CHECKBOX_NOT_FOUND','invoice_results':invoice_results}
        cb.check();record['sale_selected']=True;record['transaction_id']=tx.transaction_id;selected.append(tx.transaction_id);selected_txs.append((tx,item))
        # The invoice column remains filtered while each invoice is scanned. Older
        # validation counted only checked rows present in the filtered DOM, so selections
        # made for prior invoices were incorrectly reported as lost. Verify the checkbox
        # just selected and keep the cumulative transaction IDs as the authoritative state.
        current_checked=bool(cb.is_checked())
        if not current_checked:
            return {'status':'UNDEFINED_CASE','reason_code':'CURRENT_SALE_SELECTION_FAILED','invoice_results':invoice_results,
                    'expected_selected':len(selected),'selected_transaction_ids':selected}
        logger.info('SALE SELECTION RECORDED | guid=%s | invoice=%s | selected_transaction_id=%s | cumulative_selected=%s/%s | selected_transaction_ids=%s',group['guid'],item['invoice'],tx.transaction_id,len(selected),len(group['items']),selected)
    if stop:
        scanned_rows={x['row_no'] for x in invoice_results}
        for item in group['items']:
            if item['row_no'] not in scanned_rows:
                invoice_results.append({'row_no':item['row_no'],'qt':item['qt'],'code':item['code'],'invoice_raw':item['invoice'],
                                        'scan_status':'NOT_SCANNED_AFTER_GROUP_STOP','tran_types':[],'sale_selected':False})
        result={'status':'NO_CHARGEBACK_REQUIRED','decision':'NO_CHARGEBACK_REQUIRED','issuer_action_required':False,
                'selected_count_before_stop':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,**stop}
        if stop.get('reason_code')=='GROUP_CONTAINS_ASSOC_DISPUTE_D':
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID do Invoice '+str(stop.get('trigger_invoice',''))+' có Assoc Dispute = D'
        elif stop.get('cb_reject'):
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID: '+stop['cb_reject']
        else:
            result['reason_detail']='Không tiếp tục toàn bộ cụm GUID do Invoice '+str(stop.get('trigger_invoice',''))+' có Tran Type '+str(stop.get('trigger_tran_type',''))
    else:
        status='READY_FOR_MULTI_ISSUER_ACTION_REVIEW' if len(selected)>1 else 'READY_FOR_ISSUER_ACTION_REVIEW'
        codes=sorted({x['code'] for x in group['items']})
        planned='Issuer Action > Chargeback/Dispute > Fraud' if codes==['10.4'] else ('Issuer Action > Chargeback/Dispute > Consumer' if set(codes).issubset({'13.1','13.9'}) else 'UNDEFINED_MIXED_CODE_ISSUER_ACTION')
        pi_pending=[x for x in invoice_results if x.get('pi_status')=='PENDING_USER_ACTION']
        if pi_pending:
            status='READY_FOR_PI_EVIDENCE_REVIEW'
            result={'status':status,'decision':status,'issuer_action_required':False,'issuer_action_clicked':False,
                    'planned_review_action':'View > Tran Details > Save as PDF','planned_issuer_action':'Không áp dụng do PI = Yes','pi_pending_count':len(pi_pending),
                    'selected_count':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,'date_value':date_value}
        else:
            result={'status':status,'decision':status,'issuer_action_required':True,'issuer_action_clicked':False,'planned_issuer_action':planned,
                    'selected_count':len(selected),'selected_transaction_ids':selected,'invoice_results':invoice_results,'date_value':date_value}
    (group_dir/'group_precheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    if not stop:
        result['_runtime_selected_txs']=selected_txs
        if selected_txs:
            # All matching checkboxes are already selected. One representative row is
            # sufficient to open the shared Issuer Action menu for the multi-selection.
            result['_runtime_tx']=selected_txs[0][0];result['_runtime_item']=selected_txs[0][1]
    try: page.screenshot(path=str(group_dir/'group_precheck.png'),full_page=True)
    except Exception: pass
    return result
