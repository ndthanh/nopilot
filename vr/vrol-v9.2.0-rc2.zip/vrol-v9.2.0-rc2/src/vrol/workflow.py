import re,time,logging
from pathlib import Path
from src.browser_window import maximize_page_window
from .selectors import body,buttons
from .transaction_table import schema_from_dom,parse_row,parse_row_for_code,normalize_transaction_id_for_invoice,transaction_id_matches_invoice,split_transaction_ref,visible_rows,wait_stable_visible_rows,TableContractError
from .table_column_probe import probe_table_column_mapping
from ..core.config import as_bool

LOGGER=logging.getLogger("vrol")

class UnknownScenario(Exception): pass
class BusinessReview(Exception):
    def __init__(self,code,detail=''):
        super().__init__(code); self.code=code; self.detail=detail

def _batch_capture(page,settings,name):
    raw=str(settings.get('batch_test_case_evidence_dir') or '').strip()
    if not raw:return ''
    path=Path(raw)/name;path.parent.mkdir(parents=True,exist_ok=True)
    try:page.screenshot(path=str(path),full_page=True);return path.name
    except Exception:return ''
def _select_test_value(scope,selector,value,field,aliases=None,timeout_ms=12000):
    """Select an Angular questionnaire value, allowing delayed/hidden native selects."""
    value=str(value or '').strip()
    if not value or value.upper().startswith('CHANGE_ME'):return None
    selectors=[]
    for item in [selector]+list(aliases or []):
        item=str(item or '').strip()
        if item and item not in selectors:selectors.append(item)
    deadline=time.monotonic()+timeout_ms/1000
    last_inventory=[]
    while time.monotonic()<deadline:
        for current in selectors:
            try:
                loc=scope.locator(current).first
                if not loc.count():continue
                # Native Angular select can exist before becoming visible; select_option still works.
                try:loc.select_option(value=value,force=True)
                except Exception:
                    try:loc.select_option(label=value,force=True)
                    except Exception:
                        # Set value and dispatch Angular-observed change/input events as final fallback.
                        applied=loc.evaluate("""(e,v)=>{const opts=[...e.options];const o=opts.find(x=>x.value===v||x.text.trim()===v);if(!o)return false;e.value=o.value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('blur',{bubbles:true}));return true;}""",value)
                        if not applied:continue
                actual=''
                selected_text=''
                try:
                    actual=loc.input_value()
                    selected_text=loc.locator('option:checked').inner_text().strip()
                except Exception:pass
                # The requested setting can be either the DOM value (for example S)
                # or the visible label (for example Services). Verify against both.
                if actual==value or selected_text==value:
                    LOGGER.info('QUESTIONNAIRE SELECTED | field=%s | requested=%s | actual=%s | selected_text=%s | selector=%s',field,value,actual,selected_text,current)
                    return {'field':field,'selector':current,'value':value,'actual':actual,'selected_text':selected_text,'visible':loc.is_visible()}
            except Exception:
                pass
        try:
            inventory=scope.locator('select')
            last_inventory=[]
            for i in range(min(inventory.count(),50)):
                el=inventory.nth(i)
                last_inventory.append(el.evaluate("e=>({name:e.name||'',id:e.id||'',model:e.getAttribute('ng-model')||'',visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length),options:[...e.options].map(o=>({value:o.value,text:o.text.trim()}))})"))
        except Exception:pass
        try:scope.page.wait_for_timeout(250)
        except Exception:time.sleep(.25)
    LOGGER.error('QUESTIONNAIRE SELECT DIAGNOSTIC | field=%s | requested=%s | selectors=%s | selects=%s',field,value,selectors,last_inventory)
    raise UnknownScenario('QUESTIONNAIRE_FIELD_NOT_FOUND:'+field)

def _digits(v):return re.sub(r'[^0-9]','',str(v or ''))
def _amount_decimal(v):
    raw=str(v or '').strip().replace(',','').replace(' ','')
    m=re.search(r'\d+(?:\.\d+)?',raw)
    if not m:return None
    from decimal import Decimal,InvalidOperation
    try:return Decimal(m.group(0))
    except InvalidOperation:return None

def _find_visible(scope,selectors,field):
    for selector in selectors:
        try:
            loc=scope.locator(selector).first
            if loc.count() and loc.is_visible():return loc,selector
        except Exception:pass
    raise UnknownScenario('QUESTIONNAIRE_FIELD_NOT_FOUND:'+field)

def _validate_131_questionnaire(scope,record,settings=None):
    # Screen identity
    screen=scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not screen.count() or not screen.is_visible():raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name=' '.join(screen.inner_text().split())
    if screen_name!='Consumer Dispute Questionnaire':raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:'+screen_name)
    # Invoice / Visa Transaction ID displayed without the source leading zero.
    invoice_expected=_digits((record or {}).get('invoice')).lstrip('0') or '0'
    invoice_loc=scope.locator('dd[ng-bind="data.pinnedOriginalTransaction.visaTransactionId"]').first
    if not invoice_loc.count() or not invoice_loc.is_visible():raise UnknownScenario('QUESTIONNAIRE_INVOICE_NOT_FOUND')
    invoice_actual=_digits(invoice_loc.inner_text()).lstrip('0') or '0'
    if invoice_actual!=invoice_expected:raise UnknownScenario(f'QUESTIONNAIRE_INVOICE_MISMATCH:expected={invoice_expected}:actual={invoice_actual}')
    # Amount belongs to the VROL questionnaire display. Case Review development mode
    # intentionally does not compare it with Excel because the grouped review record does
    # not carry a trusted expected amount. Production can re-enable strict comparison via
    # validate_dispute_amount=YES.
    amount_loc,amount_selector=_find_visible(scope,['input[name="disputeAmount"]','input[ng-model="disputeRequest.disputeAmount.amount"]'],'13_1_dispute_amount')
    validate_amount=str((settings or {}).get('validate_dispute_amount','YES')).strip().upper()=='YES'
    expected_amount=_amount_decimal((record or {}).get('amount'))
    actual_raw=amount_loc.input_value();actual_amount=_amount_decimal(actual_raw)
    if validate_amount:
        if expected_amount is None:raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount!=expected_amount:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=13.1 | expected=%s | actual=%s',expected_amount,actual_amount)
    else:
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=13.1 | reason=validate_dispute_amount_NO | actual=%s',actual_raw)
    return {'screen_name':screen_name,'invoice_expected':invoice_expected,'invoice_actual':invoice_actual,'amount_validation':'VALIDATED' if validate_amount else 'SKIPPED','amount_expected':str(expected_amount) if expected_amount is not None else None,'amount_actual':str(actual_amount) if actual_amount is not None else actual_raw,'amount_selector':amount_selector}

def _validate_consumer_139_questionnaire(scope,record,settings=None):
    screen=scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not screen.count() or not screen.is_visible():raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name=' '.join(screen.inner_text().split())
    if screen_name!='Consumer Dispute Questionnaire':raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:'+screen_name)
    validate_amount=str((settings or {}).get('validate_dispute_amount','YES')).strip().upper()=='YES'
    if validate_amount:
        amount_loc,amount_selector=_find_visible(scope,['input[name="disputeAmount"]','input[ng-model="disputeRequest.disputeAmount.amount"]'],'13_9_dispute_amount')
        expected_amount=_amount_decimal((record or {}).get('amount'));actual_raw=amount_loc.input_value();actual_amount=_amount_decimal(actual_raw)
        if expected_amount is None:raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount!=expected_amount:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=13.9 | expected=%s | actual=%s',expected_amount,actual_amount)
    else:
        amount_selector=None;expected_amount=None;actual_amount=None;actual_raw=None
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=13.9 | reason=validate_dispute_amount_NO | field_lookup=false')
    return {'screen_name':screen_name,'amount_validation':'VALIDATED' if validate_amount else 'SKIPPED','amount_expected':str(expected_amount) if expected_amount is not None else None,'amount_actual':str(actual_amount) if actual_amount is not None else actual_raw,'amount_selector':amount_selector}

def _validate_fraud_104_questionnaire(scope,record,settings=None):
    screen=scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not screen.count() or not screen.is_visible():raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name=' '.join(screen.inner_text().split())
    if screen_name!='Fraud Dispute Questionnaire':raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:'+screen_name)
    validate_amount=str((settings or {}).get('validate_dispute_amount','YES')).strip().upper()=='YES'
    if validate_amount:
        amount_loc,amount_selector=_find_visible(scope,['input[name="disputeAmount"]','input[ng-model="disputeRequest.disputeAmount.amount"]'],'10_4_dispute_amount')
        expected_amount=_amount_decimal((record or {}).get('amount'));actual_raw=amount_loc.input_value();actual_amount=_amount_decimal(actual_raw)
        if expected_amount is None:raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount!=expected_amount:raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=10.4 | expected=%s | actual=%s',expected_amount,actual_amount)
    else:
        amount_selector=None;expected_amount=None;actual_amount=None;actual_raw=None
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=10.4 | reason=validate_dispute_amount_NO | field_lookup=false')
    condition=scope.get_by_text(re.compile(r'^10\.4 Fraud - Card Absent Environment$',re.I),exact=True).first
    if not condition.count() or not condition.is_visible():raise UnknownScenario('QUESTIONNAIRE_10_4_CONDITION_NOT_FOUND')
    return {'screen_name':screen_name,'amount_validation':'VALIDATED' if validate_amount else 'SKIPPED','amount_expected':str(expected_amount) if expected_amount is not None else None,'amount_actual':str(actual_amount) if actual_amount is not None else actual_raw,'amount_selector':amount_selector,'condition':'10.4 Fraud - Card Absent Environment'}

def _check_checkbox(scope,selector,field,checked=True,timeout_ms=12000):
    loc=scope.locator(selector).first
    loc.wait_for(state='attached',timeout=timeout_ms)
    if checked:loc.check(force=True)
    else:loc.uncheck(force=True)
    if bool(loc.is_checked())!=bool(checked):raise UnknownScenario('QUESTIONNAIRE_CHECKBOX_STATE_FAILED:'+field)
    LOGGER.info('QUESTIONNAIRE CHECKBOX SET | field=%s | checked=%s | selector=%s',field,checked,selector)
    return {'field':field,'selector':selector,'value':checked}

def _fill_member_case_number(scope,record):
    qt=str((record or {}).get('qt') or (record or {}).get('member_case') or '').strip()
    if not qt:raise UnknownScenario('QUESTIONNAIRE_MEMBER_CASE_NUMBER_MISSING')
    return _fill_text_value(scope,'input[name="memberCaseNumber"]',qt,'member_case_number')

def _expected_receipt_date_from_record(record):
    """Read Excel column D/NGAY GD supplied in yyyyMMdd and convert for VROL MM/dd/yyyy."""
    raw=str((record or {}).get('start_date') or (record or {}).get('date') or '').strip()
    if not re.fullmatch(r'\d{8}',raw):
        raise UnknownScenario('QUESTIONNAIRE_EXPECTED_RECEIPT_DATE_INVALID_YYYYMMDD:'+raw)
    try:
        parsed=time.strptime(raw,'%Y%m%d')
        return time.strftime('%m/%d/%Y',parsed)
    except ValueError:
        raise UnknownScenario('QUESTIONNAIRE_EXPECTED_RECEIPT_DATE_INVALID_YYYYMMDD:'+raw)

def _fill_text_value(scope,selector,value,field,timeout_ms=12000):
    value=str(value or '').strip()
    if not value:return None
    loc=scope.locator(selector).first
    loc.wait_for(state='attached',timeout=timeout_ms)
    loc.fill(value,force=True)
    LOGGER.info('QUESTIONNAIRE FIELD FILLED | field=%s | selector=%s',field,selector)
    return {'field':field,'selector':selector,'value':value}

def _check_radio_value(scope,name,value,field,timeout_ms=12000):
    selector='input[type="radio"][name="%s"][value="%s"]'%(name,value)
    loc=scope.locator(selector).first
    loc.wait_for(state='attached',timeout=timeout_ms)
    loc.check(force=True)
    if not loc.is_checked():raise UnknownScenario('QUESTIONNAIRE_RADIO_NOT_CHECKED:'+field)
    LOGGER.info('QUESTIONNAIRE RADIO CHECKED | field=%s | value=%s',field,value)
    return {'field':field,'selector':selector,'value':value}

def _inspect_final_submit(scope,settings):
    selectors=[
        'button[ng-click="trigger(Buttons.SUBMIT,true)"]',
        'button:has-text("Submit")',
        'input[type="submit"][value="Submit"]',
    ]
    found=None
    for selector in selectors:
        try:
            loc=scope.locator(selector).filter(has_text=re.compile(r'^\\s*Submit\\s*$',re.I)).first if selector.startswith('button') else scope.locator(selector).first
            if loc.count():
                found={'selector':selector,'visible':bool(loc.is_visible())}
                break
        except Exception:pass
    allow=as_bool(settings.get('allow_final_submit','NO'))
    LOGGER.info('FINAL SUBMIT INSPECTION | found=%s | visible=%s | allow_final_submit=%s | clicked=false',bool(found),found.get('visible') if found else False,'YES' if allow else 'NO')
    return {'found':bool(found),'visible':found.get('visible') if found else False,'selector':found.get('selector') if found else None,'allow_final_submit':allow,'clicked':False}

def fill_test_questionnaire(scope,code,settings,record=None):
    """Fill confirmed questionnaire values and inspect Final Submit without clicking it."""
    fields=[];validation={};submit_inspection={}
    if code=='10.4':
        validation=_validate_fraud_104_questionnaire(scope,record or {},settings)
        fields.append(_fill_member_case_number(scope,record))
        fields.append(_check_checkbox(scope,'input[type="checkbox"][name="CardholderDeniesAuthorizingInd"]','10_4_cardholder_denies_authorizing',True))
        x=_select_test_value(scope,str(settings.get('10_4_fraud_type_selector','select[name="FraudTypeCode"]')),settings.get('10_4_fraud_type','FT6'),'10_4_fraud_type',aliases=['select[name="FraudTypeCode"]','select[ng-model="data.FraudTypeCode"]'])
        if x:fields.append(x)
        submit_inspection=_inspect_final_submit(scope,settings)
        LOGGER.info('QUESTIONNAIRE 10.4 HAPPY CASE FILLED | screen=%s | amount=%s | member_case=%s | fraud_type=FT6 | certification_checked=true | submit_found=%s | final_submit_clicked=false',validation['screen_name'],validation['amount_actual'],(record or {}).get('qt') or (record or {}).get('member_case'),submit_inspection['found'])
    elif code=='13.1':
        validation=_validate_131_questionnaire(scope,record or {},settings)
        fields.append(_fill_member_case_number(scope,record))
        x=_select_test_value(scope,str(settings.get('13_1_dispute_due_selector','select[name="DisputeDueTo"]')),settings.get('13_1_dispute_due','NR'),'13_1_dispute_due',aliases=['select[name="DisputeDueTo"]','select[name="disputeDueTo"]','select[ng-model="disputeRequest.relatedInfo.DisputeDueTo"]','select:has(option[value="NR"])'])
        if x:fields.append(x)
        # Happy case supplied by user: Services; N/N/N; description; N; receipt date;
        # cancellation=N; attempted merchant resolution=Y and its visible follow-up fields.
        x=_select_test_value(scope,'select[name="WhatWasNotReceived"]',settings.get('13_1_what_was_not_received','S'),'13_1_what_was_not_received',aliases=['select[ng-model="data.WhatWasNotReceived"]'])
        if x:fields.append(x)
        for name,value,field in [
            ('NonFiatCurrencyNotDelivered','N','13_1_non_fiat_not_delivered'),
            ('ThirdPartyGiftCardInd','N','13_1_third_party_gift_card'),
            ('DidMerchantCancelInd','N','13_1_merchant_cancelled'),
            ('MerchantInBankruptcyLiquidationInd','N','13_1_merchant_insolvent'),
            ('DidCardholderCancelPriorExpectedDate','N','13_1_cardholder_cancelled_prior'),
            ('CardholderAttemptToResolve','Y','13_1_attempted_to_resolve'),
        ]:
            fields.append(_check_radio_value(scope,name,value,field))
        text_fields=[
            ('textarea[name="PurchasedInfo"]',settings.get('13_1_purchased_info','The cardholder has filed a dispute for the above-mentioned transaction, claiming that the transaction was not completed successfully and that no related goods/services were received.'),'13_1_purchased_info'),
            ('input[name="ExpectedReceiptDate"]',_expected_receipt_date_from_record(record),'13_1_expected_receipt_date'),
            ('input[name="ExpectedReceiptTime"]',settings.get('13_1_expected_receipt_time',''),'13_1_expected_receipt_time'),
        ]
        for selector,value,field in text_fields:
            if str(value or '').strip():fields.append(_fill_text_value(scope,selector,value,field))
        submit_inspection=_inspect_final_submit(scope,settings)
        LOGGER.info('QUESTIONNAIRE 13.1 HAPPY CASE FILLED | screen=%s | invoice=%s | dispute_amount=%s | fields=%s | submit_found=%s | final_submit_clicked=false',validation['screen_name'],validation['invoice_actual'],validation['amount_actual'],[f['field'] for f in fields],submit_inspection['found'])
    elif code=='13.9':
        validation=_validate_consumer_139_questionnaire(scope,record or {},settings)
        fields.append(_fill_member_case_number(scope,record))
        x=_select_test_value(scope,str(settings.get('13_9_dispute_due_selector','select[name="DisputeDueTo"]')),settings.get('13_9_dispute_due','CL'),'13_9_dispute_due',aliases=['select[name="DisputeDueTo"]','select[ng-model="disputeRequest.relatedInfo.DisputeDueTo"]'])
        if x:fields.append(x)
        x=_select_test_value(scope,'select[name="WhatWasNotReceived"]',settings.get('13_9_what_was_not_received','C'),'13_9_what_was_not_received',aliases=['select[ng-model="data.WhatWasNotReceived"]'])
        if x:fields.append(x)
        submit_inspection=_inspect_final_submit(scope,settings)
        LOGGER.info('QUESTIONNAIRE 13.9 HAPPY CASE FILLED | screen=%s | amount=%s | member_case=%s | dispute_due=CL | what_not_received=C | submit_found=%s | submit_visible=%s | final_submit_clicked=false',validation['screen_name'],validation['amount_actual'],(record or {}).get('qt') or (record or {}).get('member_case'),submit_inspection['found'],submit_inspection['visible'])
    if not fields:raise UnknownScenario('QUESTIONNAIRE_NO_CONFIGURED_FIELDS:'+code)
    LOGGER.info('QUESTIONNAIRE FILLED | code=%s | fields=%s | validation=%s | submit_inspection=%s | final_submit_clicked=false',code,[x['field'] for x in fields],validation,submit_inspection)
    return {'fields':fields,'validation':validation,'submit_inspection':submit_inspection}

def visible(loc,timeout=1500):
    try: loc.first.wait_for(state="visible",timeout=timeout); return True
    except Exception:return False

def screenshot(page,path,settings):
    if not as_bool(settings.get("screenshots_enabled",False)): return ""
    page.screenshot(path=str(path),full_page=True); return path.name

def _list_setting(settings,key_name,default):
    raw=str(settings.get(key_name,default) or default)
    return {x.strip().casefold() for x in raw.split('|') if x.strip()}

def probe_transaction_inquiry_state(page):
    """Return a compact snapshot of the two VROL frames involved in TI navigation."""
    body=page.frame(name='bodyframe')
    buttons=None
    for frame in page.frames:
        if frame.name=='buttons' or '/rolti/web/ti/ti-buttons' in str(frame.url or ''):
            buttons=frame
            break
    snapshot={
        'body_url': str(body.url or '') if body else '',
        'buttons_url': str(buttons.url or '') if buttons else '',
        'pan_visible': False,
        'start_visible': False,
        'submit_visible': False,
        'submit_enabled': False,
    }
    if body:
        try:
            pan=body.locator('#CardNumber').first
            start=body.locator('#StartDate').first
            snapshot['pan_visible']=bool(pan.count() and pan.is_visible())
            snapshot['start_visible']=bool(start.count() and start.is_visible())
        except Exception:
            pass
    if buttons:
        try:
            button_body=buttons.locator('body#buttonBody').first
            submit=buttons.locator('button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]').first
            body_ready=bool(button_body.count() and button_body.is_visible())
            snapshot['submit_visible']=bool(body_ready and submit.count() and submit.is_visible())
            snapshot['submit_enabled']=bool(submit.count() and submit.is_enabled())
        except Exception:
            pass
    return snapshot


def wait_transaction_inquiry_screen_ready(page, settings):
    """Wait for stable TI form; classify rollback only after a persistent split state."""
    timeout=int(settings.get('transaction_inquiry_screen_ready_timeout_ms',45000))
    poll_ms=int(settings.get('transaction_inquiry_screen_ready_poll_ms',250))
    stable_required=int(settings.get('transaction_inquiry_screen_stable_polls',3))
    rollback_required=int(settings.get('transaction_inquiry_rollback_stable_polls',6))
    rollback_grace_ms=int(settings.get('transaction_inquiry_rollback_grace_ms',2500))
    body_fragment=str(settings.get('transaction_inquiry_body_url_fragment','/rolti/web/ti/ti-request')).lower()
    buttons_fragment=str(settings.get('transaction_inquiry_buttons_url_fragment','/rolti/web/ti/ti-buttons')).lower()
    start_time=time.monotonic(); deadline=start_time+timeout/1000
    stable=0; rollback_stable=0; history=[]

    LOGGER.info('STEP WAIT_TRANSACTION_INQUIRY_SCREEN_READY | observing bodyframe and buttons transitions')
    while time.monotonic()<deadline:
        state=probe_transaction_inquiry_state(page)
        signature=(state['body_url'],state['buttons_url'],state['pan_visible'],state['start_visible'],state['submit_visible'],state['submit_enabled'])
        if not history or history[-1]!=signature:
            history.append(signature)
            LOGGER.info('TI FRAME PROBE | body=%s | buttons=%s | pan=%s | start=%s | submit=%s | enabled=%s',state['body_url'],state['buttons_url'],state['pan_visible'],state['start_visible'],state['submit_visible'],state['submit_enabled'])

        body_ok=body_fragment in state['body_url'].lower()
        buttons_ok=buttons_fragment in state['buttons_url'].lower()
        ready=(body_ok and buttons_ok and state['pan_visible'] and state['start_visible'] and state['submit_visible'] and state['submit_enabled'])
        if ready:
            stable+=1; rollback_stable=0
            if stable >= stable_required:
                body=page.frame(name='bodyframe')
                LOGGER.info('PASS WAIT_TRANSACTION_INQUIRY_SCREEN_READY | stable_polls=%s | body=%s | buttons=%s',stable,state['body_url'],state['buttons_url'])
                return body
        else:
            stable=0
            split=(buttons_ok and 'action=invokehomepage' in state['body_url'].lower())
            elapsed_ms=int((time.monotonic()-start_time)*1000)
            if split and elapsed_ms >= rollback_grace_ms:
                rollback_stable+=1
                LOGGER.warning('TI PARTIAL ROLLBACK PROBE | consecutive=%s/%s | elapsed_ms=%s',rollback_stable,rollback_required,elapsed_ms)
                if rollback_stable >= rollback_required:
                    raise UnknownScenario('TRANSACTION_INQUIRY_PARTIAL_ROLLBACK')
            else:
                rollback_stable=0
        page.wait_for_timeout(poll_ms)

    LOGGER.error('TRANSACTION INQUIRY SCREEN NOT READY | history=%s',history[-12:])
    raise UnknownScenario('TRANSACTION_INQUIRY_SCREEN_NOT_READY:'+repr(history[-8:]))



def wait_vrol_landing_frames_stable(page, settings):
    """Wait until both legacy homepage frames are back and stable before reopening Inquiry."""
    timeout=int(settings.get('vrol_landing_frame_settle_timeout_ms',20000))
    poll=int(settings.get('transaction_inquiry_screen_ready_poll_ms',250))
    stable_required=int(settings.get('vrol_landing_frame_stable_polls',4))
    body_fragment=str(settings.get('vrol_home_body_url_fragment','action=InvokeHomePage')).lower()
    buttons_fragment=str(settings.get('vrol_home_buttons_url_fragment','/rolol/jsp/buttons_index.jsp')).lower()
    deadline=time.monotonic()+timeout/1000
    stable=0; previous=None; history=[]
    while time.monotonic()<deadline:
        body=page.frame(name='bodyframe')
        buttons=None
        for frame in page.frames:
            if frame.name=='buttons':
                buttons=frame; break
        body_url=str(body.url or '') if body else ''
        buttons_url=str(buttons.url or '') if buttons else ''
        signature=(body_url,buttons_url)
        if not history or history[-1]!=signature:
            history.append(signature)
            LOGGER.info('LANDING FRAME PROBE | body=%s | buttons=%s',body_url,buttons_url)
        ready=(body_fragment in body_url.lower() and buttons_fragment in buttons_url.lower())
        if ready and signature==previous: stable+=1
        elif ready: stable=1
        else: stable=0
        previous=signature
        if stable >= stable_required:
            LOGGER.info('PASS WAIT_VROL_LANDING_FRAMES_STABLE | bodyframe=%s | buttons=%s | stable_polls=%s',body_url,buttons_url,stable)
            return
        page.wait_for_timeout(poll)
    raise UnknownScenario('VROL_LANDING_FRAMES_NOT_STABLE:'+repr(history[-8:]))



def open_transaction_inquiry(page, settings):
    # Fast reuse after Results > Back. Avoid reopening Inquiry > Transaction Inquiry.
    for frame in page.frames:
        try:
            if frame.locator('#CardNumber').count() and frame.locator('#StartDate').count() and frame.locator('#CardNumber').is_visible():
                LOGGER.info('TRANSACTION INQUIRY FORM REUSED | strategy=RESULTS_BACK | frame=%s | url=%s',frame.name,frame.url)
                return frame
        except Exception:pass
    """Open exact VROL menu path and recover once from partial legacy-frame rollback."""
    wait_vrol_landing_frames_stable(page, settings)
    timeout = int(settings.get('transaction_inquiry_navigation_timeout_ms', 30000))
    poll_ms = int(settings.get('transaction_inquiry_navigation_poll_ms', 250))
    deadline = time.monotonic() + timeout / 1000

    # VROL landing may be reported by URL before its navigation DOM is ready.
    inquiry = None
    inquiry_frame = None
    while time.monotonic() < deadline and inquiry is None:
        for frame in page.frames:
            try:
                candidate = frame.locator('a#inquirymenua[name="inquirymenua"][role="menuitem"]')
                if candidate.count():
                    candidate.first.wait_for(state='attached', timeout=poll_ms)
                    if candidate.first.is_visible():
                        inquiry = candidate.first
                        inquiry_frame = frame
                        break
            except Exception:
                continue
        if inquiry is None:
            page.wait_for_timeout(poll_ms)
    if inquiry is None:
        raise UnknownScenario('INQUIRY_MENU_NOT_FOUND')

    wait_for_manual_step(settings, 'OPEN_INQUIRY_MENU', 'Hover menu Inquiry', 'a#inquirymenua[name="inquirymenua"][role="menuitem"]', inquiry)
    LOGGER.info('STEP OPEN_INQUIRY_MENU | exact selector #inquirymenua | frame=%s', inquiry_frame.url)
    inquiry.scroll_into_view_if_needed()
    inquiry.hover(force=True)
    inquiry.dispatch_event('mouseover')
    LOGGER.info('PASS OPEN_INQUIRY_MENU | Inquiry hovered')

    # The supplied VROL HTML exposes a stable data-js action on the submenu link.
    submenu = inquiry_frame.locator(
        'a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]'
    ).first
    try:
        submenu.wait_for(state='visible', timeout=timeout)
    except Exception:
        # Legacy hover menus can collapse while waiting, so reopen once.
        inquiry.hover(force=True)
        inquiry.dispatch_event('mouseover')
        submenu.wait_for(state='visible', timeout=timeout)
    wait_for_manual_step(settings, 'OPEN_TRANSACTION_INQUIRY', 'Click submenu Transaction Inquiry', 'a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]', submenu)
    LOGGER.info('STEP OPEN_TRANSACTION_INQUIRY | selector data-js=displayTranInquiry()')
    submenu.click()
    LOGGER.info('PASS OPEN_TRANSACTION_INQUIRY | submenu clicked')

    try:
        return wait_transaction_inquiry_screen_ready(page, settings)
    except UnknownScenario as exc:
        if str(exc)!='TRANSACTION_INQUIRY_PARTIAL_ROLLBACK' or not str(settings.get('transaction_inquiry_retry_partial_rollback','YES')).strip().upper() in {'YES','Y','TRUE','1'}:
            raise
        LOGGER.warning('Transaction Inquiry entered a partial rollback state. Reopening menu once after landing settles.')
        wait_vrol_landing_frames_stable(page, settings)
        inquiry=page.locator('a#inquirymenua[name="inquirymenua"][role="menuitem"]').first
        inquiry.wait_for(state='visible',timeout=timeout)
        inquiry.hover(force=True); inquiry.dispatch_event('mouseover')
        submenu=page.locator('a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]').first
        submenu.wait_for(state='visible',timeout=timeout)
        submenu.click()
        LOGGER.info('PASS REOPEN_TRANSACTION_INQUIRY_AFTER_PARTIAL_ROLLBACK')
        return wait_transaction_inquiry_screen_ready(page, settings)

def _find_buttons_frame(page, settings):
    """Find the live buttons_index.jsp frame without depending on its variable title."""
    timeout=int(settings.get('transaction_inquiry_submit_timeout_ms',10000))
    poll=int(settings.get('transaction_inquiry_navigation_poll_ms',250))
    deadline=time.monotonic()+timeout/1000
    observed=[]
    while time.monotonic()<deadline:
        for frame in page.frames:
            frame_name=str(frame.name or '')
            frame_url=str(frame.url or '')
            signature=f'name={frame_name}; url={frame_url}'
            if signature not in observed: observed.append(signature)
            if frame_name!='buttons' and '/rolol/jsp/buttons_index.jsp' not in frame_url:
                continue
            try:
                body=frame.locator('body#buttonBody')
                submit=frame.locator(
                    'button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]'
                ).first
                if body.count() and submit.count() and body.is_visible() and submit.is_visible():
                    return frame,submit
            except Exception:
                continue
        page.wait_for_timeout(poll)
    LOGGER.error('BUTTONS FRAME DISCOVERY FAILED | observed=%s', observed)
    raise UnknownScenario('BUTTONS_FRAME_NOT_FOUND:'+' | '.join(observed[-8:]))


def click_transaction_inquiry_submit(page, settings):
    """Click only #submitButton in the live buttons_index.jsp frame."""
    frame,submit=_find_buttons_frame(page,settings)
    if not submit.is_enabled():
        raise UnknownScenario('TRANSACTION_INQUIRY_SUBMIT_DISABLED')
    selector_text=(
        'frame[name="buttons"] or frame[url*="/rolol/jsp/buttons_index.jsp"] '
        '>> body#buttonBody '
        '>> button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]'
    )
    wait_for_manual_step(
        settings,
        'SUBMIT_TRANSACTION_INQUIRY',
        'Click the Transaction Inquiry Submit button',
        selector_text,
        submit,
    )
    LOGGER.info(
        'STEP CLICK_TRANSACTION_INQUIRY_SUBMIT | frame_name=%s | frame_url=%s | selector=%s',
        frame.name, frame.url, selector_text,
    )
    # Source contract: this button listener calls top.bodyframe.doSubmit().
    submit.click(force=True)
    LOGGER.info('PASS CLICK_TRANSACTION_INQUIRY_SUBMIT')
    return True

def wait_transaction_results(page, settings):
    """After Submit, reacquire bodyframe because VROL may replace/navigate the frame."""
    timeout=int(settings.get('transaction_results_timeout_ms',45000))
    poll=int(settings.get('transaction_results_poll_ms',250))
    deadline=time.monotonic()+timeout/1000
    observed=[]
    while time.monotonic()<deadline:
        frame=page.frame(name='bodyframe')
        if frame:
            try:
                result=frame.locator('table#results').first
                if result.count() and result.is_visible():
                    LOGGER.info('PASS WAIT_TRANSACTION_RESULTS | frame=%s | table#results visible', frame.url)
                    return frame
                # Capture visible body text markers for diagnostics only.
                marker=frame.locator('body').inner_text(timeout=300)[:120].replace('\n',' ')
                if marker and marker not in observed: observed.append(marker)
            except Exception: pass
        page.wait_for_timeout(poll)
    raise UnknownScenario('TRANSACTION_RESULTS_NOT_REACHED:'+ ' | '.join(observed[-3:]))

def _highlight_locator(locator, settings):
    """Apply a reversible red border/outline to the exact next target."""
    enabled = str(settings.get('step_highlight_enabled', 'YES')).strip().upper()
    if enabled not in {'YES','Y','TRUE','1'} or locator is None:
        return False
    try:
        target = locator.first
        target.wait_for(state='visible', timeout=int(settings.get('step_highlight_timeout_ms', 5000)))
        target.scroll_into_view_if_needed()
        target.evaluate("""element => {
            if (!element.dataset.copilotOriginalStyle) {
                element.dataset.copilotOriginalStyle = element.getAttribute('style') || '';
            }
            element.style.setProperty(
                'border',
                '2px solid #ff0000',
                'important'
            );
        }""")
        return True
    except Exception as exc:
        LOGGER.warning('STEP HIGHLIGHT FAILED | %s', exc)
        return False


def _remove_highlight(locator):
    if locator is None:
        return
    try:
        locator.first.evaluate("""element => {
            const original = element.dataset.copilotOriginalStyle;
            if (original !== undefined) {
                if (original) element.setAttribute('style', original);
                else element.removeAttribute('style');
                delete element.dataset.copilotOriginalStyle;
            }
        }""")
    except Exception:
        pass


def wait_for_manual_step(settings, step_code, description, selector_text, locator=None):
    """Show exact selector, highlight target in red, and wait for Enter."""
    enabled = str(settings.get('step_by_step_manual_trigger_enabled', 'YES')).strip().upper()
    if enabled not in {'YES', 'Y', 'TRUE', '1'}:
        LOGGER.info('MANUAL STEP GATE SKIPPED | %s | disabled', step_code)
        return
    configured = str(settings.get('step_by_step_trigger_steps', 'ALL') or 'ALL').strip()
    allowed = {item.strip().upper() for item in configured.split('|') if item.strip()}
    if 'ALL' not in allowed and step_code.upper() not in allowed:
        LOGGER.info('MANUAL STEP GATE SKIPPED | %s | not configured', step_code)
        return
    highlighted = _highlight_locator(locator, settings)
    LOGGER.info('MANUAL STEP READY | %s | %s | selector=%s | highlighted=%s',
                step_code, description, selector_text, highlighted)
    prompt = (
        f'\n[{step_code}] {description}\n'
        f'Exact selector: {selector_text}\n'
        f'Red highlight applied: {"YES" if highlighted else "NO"}\n'
        'Please confirm the highlighted target in Chrome.\n'
        'Press ENTER to execute this step... '
    )
    input(prompt)
    _remove_highlight(locator)
    LOGGER.info('MANUAL STEP TRIGGERED | %s | selector=%s', step_code, selector_text)


def reacquire_transaction_inquiry_form(page, settings, checkpoint):
    """Just-in-time probe and reacquire bodyframe immediately before form actions."""
    timeout=int(settings.get('transaction_inquiry_reacquire_timeout_ms',15000))
    settle_ms=int(settings.get('transaction_inquiry_pre_action_settle_ms',1000))
    poll_ms=int(settings.get('transaction_inquiry_screen_ready_poll_ms',250))
    expected_fragment=str(settings.get('transaction_inquiry_body_url_fragment','/rolti/web/ti/ti-request')).lower()
    page.wait_for_timeout(settle_ms)
    deadline=time.monotonic()+timeout/1000
    observed=[]
    while time.monotonic()<deadline:
        frame=page.frame(name='bodyframe')
        if frame:
            url=str(frame.url or '')
            try:
                pan=frame.locator('#CardNumber').first
                start=frame.locator('#StartDate').first
                valid=(expected_fragment in url.lower() and pan.count() and start.count()
                       and pan.is_visible() and start.is_visible())
                signature=f'checkpoint={checkpoint}; url={url}; pan={pan.count()}; start={start.count()}'
                if signature not in observed: observed.append(signature)
                if valid:
                    LOGGER.info('PASS REACQUIRE_TRANSACTION_INQUIRY_FORM | checkpoint=%s | frame=%s',checkpoint,url)
                    return frame
            except Exception as exc:
                observed.append(f'checkpoint={checkpoint}; {type(exc).__name__}:{str(exc)[:100]}')
        page.wait_for_timeout(poll_ms)
    LOGGER.error('TRANSACTION INQUIRY FORM LOST | checkpoint=%s | page=%s | observed=%s',checkpoint,page.url,observed[-6:])
    raise UnknownScenario('TRANSACTION_INQUIRY_FORM_LOST_BEFORE_'+checkpoint.upper())


def fill_transaction_inquiry_pan(page, pan, settings):
    """Reacquire the live bodyframe and fill PAN without using a stale locator."""
    frame=reacquire_transaction_inquiry_form(page,settings,'ENTER_FULL_PAN')
    field=frame.locator('#CardNumber').first
    wait_for_manual_step(settings,'ENTER_FULL_PAN','Fill the configured full PAN','#CardNumber',field)
    LOGGER.info('STEP ENTER_FULL_PAN | frame=%s | filling masked PAN',frame.url)
    field.fill(str(pan).strip(),timeout=int(settings.get('transaction_inquiry_field_timeout_ms',10000)))
    field.dispatch_event('input'); field.dispatch_event('change')
    LOGGER.info('PASS ENTER_FULL_PAN | frame=%s',frame.url)
    return frame


def fill_transaction_inquiry_start_date(page, start_date, settings):
    """Reacquire again before Start Date because VROL may replace bodyframe."""
    frame=reacquire_transaction_inquiry_form(page,settings,'ENTER_START_DATE')
    value=normalize_start_date(start_date)
    field=frame.locator('#StartDate').first
    wait_for_manual_step(settings,'ENTER_START_DATE',f'Fill Start Date: {value}','#StartDate',field)
    LOGGER.info('STEP ENTER_START_DATE | frame=%s | value=%s',frame.url,value)
    field.fill(value,timeout=int(settings.get('transaction_inquiry_field_timeout_ms',10000)))
    field.dispatch_event('input'); field.dispatch_event('change')
    field.evaluate('(element) => element.blur()')
    LOGGER.info('PASS ENTER_START_DATE | frame=%s | value=%s',frame.url,value)
    return frame,value


def find_transaction_id_filter(frame, settings):
    """Find DataTables header filter from the whole summary frame, not table#results."""
    timeout=int(settings.get('transaction_id_filter_timeout_ms',15000))
    poll=int(settings.get('transaction_results_poll_ms',250))
    deadline=time.monotonic()+timeout/1000
    selectors=[
        '#dtheaderSearch input.search-box[aria-label="Transaction ID / Retrieval Ref #"]',
        '#dtheaderSearch input[aria-label*="Transaction ID / Retrieval"]',
        '.dataTables_scrollHead input.search-box[aria-label*="Transaction ID"]',
    ]
    observed=[]
    while time.monotonic()<deadline:
        # Reacquire bodyframe because the summary frame can be replaced after rendering.
        live=frame.page.frame(name='bodyframe') or frame
        for selector in selectors:
            try:
                loc=live.locator(selector).first
                count=loc.count()
                signature=f'{selector}:count={count}'
                if signature not in observed: observed.append(signature)
                if count and loc.is_visible() and loc.is_enabled():
                    LOGGER.info('TRANSACTION ID FILTER FOUND | selector=%s | frame=%s',selector,live.url)
                    return live,loc,selector
            except Exception as exc:
                observed.append(f'{selector}:{type(exc).__name__}')
        # Accessible-name fallback from the whole frame.
        try:
            loc=live.get_by_role('textbox',name=re.compile(r'Transaction\s*ID\s*/\s*Retrieval',re.I)).first
            if loc.count() and loc.is_visible() and loc.is_enabled():
                selector='role=textbox[name~="Transaction ID / Retrieval"]'
                LOGGER.info('TRANSACTION ID FILTER FOUND | selector=%s | frame=%s',selector,live.url)
                return live,loc,selector
        except Exception:
            pass
        frame.page.wait_for_timeout(poll)
    LOGGER.error('TRANSACTION ID FILTER NOT FOUND | frame=%s | observed=%s',frame.url,observed[-12:])
    raise UnknownScenario('TRANSACTION_ID_FILTER_NOT_FOUND')


def _visible_transaction_ids(frame):
    """Read visible Transaction ID cell values without invoking the full business parser."""
    rows=visible_rows(frame)
    result=[]
    for index in range(rows.count()):
        cells=rows.nth(index).locator(':scope > td')
        if cells.count()<=23:
            continue
        raw=cells.nth(23).inner_text().strip()
        transaction_id,_=split_transaction_ref(raw)
        if transaction_id:
            result.append(transaction_id)
    return result


def _invoice_filter_is_applied(frame, invoice):
    ids=_visible_transaction_ids(frame)
    if not ids:
        return False,ids
    return all(transaction_id_matches_invoice(value,invoice) for value in ids),ids


def _wait_invoice_filter_effect(frame, invoice, timeout_ms, poll_ms=250):
    """Wait until every visible transaction row belongs to the normalized Invoice."""
    deadline=time.monotonic()+timeout_ms/1000
    previous=None; stable=0
    while time.monotonic()<deadline:
        applied,ids=_invoice_filter_is_applied(frame,invoice)
        signature=tuple(ids)
        if applied and signature==previous:
            stable+=1
        elif applied:
            stable=1
        else:
            stable=0
        previous=signature
        if applied and stable>=2:
            return ids
        frame.page.wait_for_timeout(poll_ms)
    return None


def wait_datatables_ready_for_invoice_filter(frame, settings):
    """Wait until DataTables rows and the filter DOM node are stable before typing."""
    timeout=int(settings.get('invoice_filter_ready_timeout_ms',30000))
    poll=int(settings.get('invoice_filter_ready_poll_ms',250))
    stable_required=int(settings.get('invoice_filter_ready_stable_polls',4))
    deadline=time.monotonic()+timeout/1000
    stable=0; previous=None; history=[]
    node_token='copilot-invoice-filter-' + str(int(time.time()*1000))

    LOGGER.info('STEP WAIT_INVOICE_FILTER_READY | waiting for stable table rows and filter input')
    while time.monotonic()<deadline:
        live,search,selector=find_transaction_id_filter(frame,settings)
        rows=visible_rows(live)
        row_ids=tuple(rows.nth(i).get_attribute('id') or str(i) for i in range(rows.count()))
        try:
            processing=live.locator('.dataTables_processing:visible, #results_processing:visible')
            processing_visible=bool(processing.count())
            state=search.evaluate("""(element, token) => {
                if (!element.dataset.copilotStabilityToken) {
                    element.dataset.copilotStabilityToken = token;
                }
                const rect=element.getBoundingClientRect();
                return {
                    token: element.dataset.copilotStabilityToken,
                    connected: element.isConnected,
                    width: Math.round(rect.width),
                    height: Math.round(rect.height),
                    value: element.value
                };
            }""",node_token)
            signature=(str(live.url or ''),row_ids,state['token'],state['connected'],state['width'],state['height'],processing_visible)
            ready=(rows.count()>0 and state['connected'] and state['width']>0 and state['height']>0 and not processing_visible)
            if ready and signature==previous: stable+=1
            elif ready: stable=1
            else: stable=0
            previous=signature
            if not history or history[-1]!=signature:
                history.append(signature)
                LOGGER.info('INVOICE FILTER READY PROBE | rows=%s | token=%s | connected=%s | size=%sx%s | processing=%s | stable=%s/%s',rows.count(),state['token'],state['connected'],state['width'],state['height'],processing_visible,stable,stable_required)
            if ready and stable>=stable_required:
                LOGGER.info('PASS WAIT_INVOICE_FILTER_READY | rows=%s | selector=%s | stable_polls=%s',rows.count(),selector,stable)
                return live,search,selector
        except Exception as exc:
            stable=0
            history.append(('error',type(exc).__name__,str(exc)[:120]))
        frame.page.wait_for_timeout(poll)
    raise UnknownScenario('INVOICE_FILTER_NOT_STABLE_BEFORE_INPUT:'+repr(history[-8:]))


def _reacquire_and_reset_invoice_filter(frame, invoice, settings):
    """Reacquire a possibly replaced DataTables input and reset the full Invoice value."""
    live,search,selector=find_transaction_id_filter(frame,settings)
    search.click(force=True)
    search.press('Control+A')
    search.fill(invoice)
    return live,search,selector


def apply_invoice_filter(frame, invoice, settings):
    """Wait for stable DataTables, type Invoice, verify effect, and recover from node replacement."""
    inv=normalize_invoice_number(invoice)
    live,search,selector=wait_datatables_ready_for_invoice_filter(frame,settings)
    wait_for_manual_step(settings,'FILTER_INVOICE',f'Filter Transaction ID by Invoice: {inv}',selector,search)
    timeout=int(settings.get('invoice_filter_effect_timeout_ms',5000))
    typing_delay=int(settings.get('invoice_filter_typing_delay_ms',60))

    # Attempt 1 uses trusted keyboard events, but only after the header node and rows are stable.
    search.click(force=True)
    search.press('Control+A')
    search.type(inv,delay=typing_delay)
    typed_value=search.input_value()
    if typed_value!=inv:
        LOGGER.warning('INVOICE KEYBOARD INPUT INTERRUPTED | expected=%s | actual=%s | reacquiring filter',inv,typed_value)
    else:
        ids=_wait_invoice_filter_effect(live,inv,timeout)
        if ids is not None:
            rows=wait_stable_visible_rows(live,int(settings.get('single_test_results_timeout_ms',20000)))
            LOGGER.info('PASS FILTER_INVOICE | strategy=STABLE_KEYBOARD_TYPE | invoice_search=%s | visible_ids=%s | visible_rows=%s',inv,ids,rows.count())
            return live,inv,rows

    # The input may have been replaced by a DataTables redraw. Reacquire it and restore the
    # complete Invoice before committing. Never press Enter on a known partial value.
    live,search,selector=_reacquire_and_reset_invoice_filter(live,inv,settings)
    search.press('Enter')
    search.dispatch_event('change')
    search.evaluate('(element) => element.blur()')
    ids=_wait_invoice_filter_effect(live,inv,timeout)
    if ids is not None:
        rows=wait_stable_visible_rows(live,int(settings.get('single_test_results_timeout_ms',20000)))
        LOGGER.info('PASS FILTER_INVOICE | strategy=REACQUIRE_FULL_VALUE_ENTER_CHANGE_BLUR | invoice_search=%s | visible_ids=%s | visible_rows=%s',inv,ids,rows.count())
        return live,inv,rows

    LOGGER.warning('INVOICE FILTER DID NOT APPLY AFTER REACQUIRE/COMMIT | value=%s | visible_ids=%s',search.input_value(),_visible_transaction_ids(live))

    # Final legacy fallback also starts from a freshly reacquired live input.
    live,search,selector=find_transaction_id_filter(live,settings)
    search.evaluate("""(element, value) => {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        setter.call(element, value);
        element.dispatchEvent(new Event('input', {bubbles: true}));
        element.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}));
        element.dispatchEvent(new KeyboardEvent('keyup', {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}));
        element.dispatchEvent(new Event('change', {bubbles: true}));
        element.blur();
    }""",inv)
    ids=_wait_invoice_filter_effect(live,inv,timeout)
    if ids is not None:
        rows=wait_stable_visible_rows(live,int(settings.get('single_test_results_timeout_ms',20000)))
        LOGGER.info('PASS FILTER_INVOICE | strategy=REACQUIRED_NATIVE_EVENT_SEQUENCE | invoice_search=%s | visible_ids=%s | visible_rows=%s',inv,ids,rows.count())
        return live,inv,rows

    raise UnknownScenario('INVOICE_FILTER_NOT_APPLIED:'+f'value={search.input_value()};visible_ids={_visible_transaction_ids(live)}')

def search_transaction(page,pan,invoice,settings):
    """Invoice-first: filter Transaction ID, then always choose the Sale row."""
    b = open_transaction_inquiry(page, settings)
    b=fill_transaction_inquiry_pan(page,pan,settings)
    click_transaction_inquiry_submit(page,settings)
    b=wait_transaction_results(page,settings)
    b,inv,rows=apply_invoice_filter(b,invoice,settings)
    headers=schema_from_dom(b); parsed=[]
    for i in range(rows.count()):
        tx=parse_row_for_code(rows.nth(i),headers,str(settings.get("active_case_code") or "13.1"))
        # Invoice number is matched against Transaction ID only, per business confirmation.
        if transaction_id_matches_invoice(tx.transaction_id,inv):
            LOGGER.info('INVOICE CANDIDATE MATCH | raw_transaction_id=%s | normalized=%s | tran_type=%s',tx.transaction_id,normalize_transaction_id_for_invoice(tx.transaction_id),tx.tran_type)
            parsed.append(tx)
    if not parsed: raise UnknownScenario('TRANSACTION_NOT_FOUND')
    stop_types=_list_setting(settings,'invoice_stop_tran_types','Credit|Sale Rev')
    stop_matches=[x for x in parsed if x.tran_type.casefold() in stop_types]
    if stop_matches:
        types=sorted({x.tran_type for x in stop_matches})
        if types==['Credit']:code='CREDIT_FOUND_BY_INVOICE'
        elif types==['Sale Rev']:code='SALE_REV_FOUND_BY_INVOICE'
        else:code='REFUND_TRANSACTIONS_FOUND_BY_INVOICE'
        import json
        detail={'detail':'Không tiếp tục tra soát do Tran Type có giá trị '+ ' và '.join(types),'tran_types_found':types,'match_method':'INVOICENUM -> Transaction ID / Retrieval','invoice_search':inv}
        _batch_capture(page,settings,'01_invoice_refund_detected.png')
        raise BusinessReview(code,json.dumps(detail,ensure_ascii=False))
    sale=[x for x in parsed if x.tran_type.casefold()=='sale']
    if len(sale)!=1:
        raise UnknownScenario('SALE_ROW_NOT_UNIQUE:'+str(len(sale)))
    tx=sale[0]
    wait_for_manual_step(settings, 'CONFIRM_SALE_ROW', f'Use Sale row with Transaction ID: {tx.transaction_id}', f'tr[data-action="summaryGridRow"]#' + str(tx.locator.get_attribute('id') or '<matched-sale-row>'), tx.locator)
    assoc_stop=_list_setting(settings,'assoc_dispute_stop_values','M|D')
    if tx.assoc_dispute.casefold() in assoc_stop:
        import json
        value=str(tx.assoc_dispute).strip().upper()
        raise BusinessReview('ASSOC_DISPUTE_'+value,json.dumps({'detail':'Không tiếp tục tra soát do Assoc Dispute có giá trị '+value,'match_method':'TRANSACTION_INQUIRY_ASSOC_DISPUTE'},ensure_ascii=False))
    return tx,inv

def normalize_start_date(value):
    """Nguồn Excel cố định YYYYMMDD; chuyển duy nhất sang MM/DD/YY cho VROL."""
    from datetime import datetime
    text=str(value or '').strip()
    try:
        return datetime.strptime(text, '%Y%m%d').strftime('%m/%d/%y')
    except ValueError as exc:
        raise UnknownScenario('SINGLE_TEST_START_DATE_INVALID_YYYYMMDD') from exc


def normalize_invoice_number(value):
    """Invoice dùng để search Transaction ID: trim và bỏ toàn bộ số 0 đầu."""
    raw=str(value or '').strip()
    if not raw: raise UnknownScenario('SINGLE_TEST_INVOICE_MISSING')
    normalized=raw.lstrip('0')
    if not normalized: raise UnknownScenario('SINGLE_TEST_INVOICE_INVALID')
    return normalized


def search_single_test_transaction(page,pan,start_date,invoice,settings):
    """Test full PAN + date + Invoice using the confirmed common table schema."""
    b = open_transaction_inquiry(page, settings)

    b=fill_transaction_inquiry_pan(page,pan,settings)
    b,date_value=fill_transaction_inquiry_start_date(page,start_date,settings)

    LOGGER.info('STEP SUBMIT_TRANSACTION_INQUIRY | exact iframe#buttons #submitButton')
    click_transaction_inquiry_submit(page,settings)
    LOGGER.info('PASS SUBMIT_TRANSACTION_INQUIRY | waiting for transaction results')
    b=wait_transaction_results(page,settings)

    b,inv,rows=apply_invoice_filter(b,invoice,settings)
    if str(settings.get('single_test_target','')).strip().upper()=='COLUMN_MAPPING_PROBE':
        mapping=probe_table_column_mapping(b,settings,LOGGER)
        return None, {'invoice_search':inv,'column_mapping':mapping,'visible_rows':rows.count()}
    headers=schema_from_dom(b); parsed=[]
    for i in range(rows.count()):
        tx=parse_row_for_code(rows.nth(i),headers,str(settings.get("active_case_code") or "13.1"))
        # Business rule: Excel/test Invoice Number matches Transaction ID only.
        if transaction_id_matches_invoice(tx.transaction_id,inv):
            LOGGER.info('INVOICE CANDIDATE MATCH | raw_transaction_id=%s | normalized=%s | tran_type=%s',tx.transaction_id,normalize_transaction_id_for_invoice(tx.transaction_id),tx.tran_type)
            parsed.append(tx)
    if not parsed: raise UnknownScenario('SINGLE_TEST_INVOICE_NOT_FOUND')

    stop_types=_list_setting(settings,'invoice_stop_tran_types','Credit|Sale Rev')
    stop_matches=[x for x in parsed if x.tran_type.casefold() in stop_types]
    if stop_matches:
        types=sorted({x.tran_type for x in stop_matches})
        if types==['Credit']:code='CREDIT_FOUND_BY_INVOICE'
        elif types==['Sale Rev']:code='SALE_REV_FOUND_BY_INVOICE'
        else:code='REFUND_TRANSACTIONS_FOUND_BY_INVOICE'
        import json
        detail={'detail':'Không tiếp tục tra soát do Tran Type có giá trị '+ ' và '.join(types),'tran_types_found':types,'match_method':'INVOICENUM -> Transaction ID / Retrieval','invoice_search':inv}
        _batch_capture(page,settings,'01_invoice_refund_detected.png')
        raise BusinessReview(code,json.dumps(detail,ensure_ascii=False))

    active_code=str(settings.get('active_case_code') or '13.1')
    expected_type='Cash' if active_code=='13.9' else 'Sale'
    eligible=[x for x in parsed if x.tran_type.casefold()==expected_type.casefold()]
    LOGGER.info('INVOICE CANDIDATES | invoice=%s | rows=%s | expected_type=%s | eligible=%s',inv,[{'transaction_id':x.transaction_id,'normalized':normalize_transaction_id_for_invoice(x.transaction_id),'tran_type':x.tran_type} for x in parsed],expected_type,len(eligible))
    if len(eligible)!=1:
        raise UnknownScenario(f'SINGLE_TEST_{expected_type.upper()}_ROW_NOT_UNIQUE:'+str(len(eligible)))
    tx=eligible[0]
    wait_for_manual_step(settings, 'CONFIRM_SALE_ROW', f'Use {expected_type} row with Transaction ID: {tx.transaction_id}', f'tr[data-action="summaryGridRow"]#' + str(tx.locator.get_attribute('id') or '<matched-row>'), tx.locator)
    assoc_stop=_list_setting(settings,'assoc_dispute_stop_values','M|D')
    if tx.assoc_dispute.casefold() in assoc_stop:
        import json
        value=str(tx.assoc_dispute).strip().upper()
        raise BusinessReview('ASSOC_DISPUTE_'+value,json.dumps({'detail':'Không tiếp tục tra soát do Assoc Dispute có giá trị '+value,'match_method':'TRANSACTION_INQUIRY_ASSOC_DISPUTE'},ensure_ascii=False))
    return tx, {
        'start_date':date_value,
        'invoice_raw':str(invoice).strip(),
        'invoice_search':inv,
        'matched_transaction_id':tx.transaction_id,
        'matched_tran_type':tx.tran_type,
        'candidate_count':len(parsed),
    }

def _plain_value(value):
    return str(value).strip() if isinstance(value,(str,int,float)) else ''


def _safe_filename(value):
    text=re.sub(r'[<>:"/\\|?*]+','_',str(value or '').strip())
    text=re.sub(r'\s+',' ',text).strip(' ._')
    return text[:120] or 'UNKNOWN_MERCHANT'

def download_pi_evidence(vrol,context,tx,case,case_dir,settings,logger):
    """Download predispute TransactionDetail.pdf without using Issuer Action."""
    downloads=Path(case_dir)/'documents';downloads.mkdir(parents=True,exist_ok=True)
    last4=str(case.get('pan') or '')[-4:]
    merchant=_safe_filename(case.get('merchant') or 'UNKNOWN_MERCHANT')
    target=downloads/f'{last4}_{merchant}.pdf'
    try:
        tx.locator.click()
        btn=buttons(vrol).get_by_role('button',name=re.compile(r'^View',re.I)).first
        btn.wait_for(state='visible',timeout=int(settings.get('pi_view_timeout_ms',10000)));btn.click()
        item=None
        for frame in vrol.frames:
            loc=frame.get_by_role('menuitem',name=re.compile(r'^Tran Details$',re.I),exact=True).first
            if loc.count() and loc.is_visible():item=loc;break
        if item is None:raise UnknownScenario('PI_TRAN_DETAILS_MENU_NOT_FOUND')
        with context.expect_page(timeout=int(settings.get('pi_popup_timeout_ms',15000))) as pi:item.click()
        detail=pi.value;detail.wait_for_load_state('domcontentloaded')
        save=detail.get_by_role('button',name=re.compile(r'^Save as PDF$',re.I),exact=True).first
        save.wait_for(state='visible',timeout=int(settings.get('pi_save_pdf_timeout_ms',15000)))
        with detail.expect_download(timeout=int(settings.get('pi_download_timeout_ms',30000))) as di:save.click()
        download=di.value;download.save_as(str(target))
        if not target.exists() or target.stat().st_size==0:raise UnknownScenario('PI_EVIDENCE_DOWNLOAD_EMPTY')
        logger.info('PI EVIDENCE DOWNLOADED | qt=%s | code=%s | file=%s | bytes=%s',case.get('qt'),case.get('code'),target,target.stat().st_size)
        try:detail.close()
        except Exception:pass
        return {'required':True,'status':'DOWNLOADED','file_name':target.name,'original_name':download.suggested_filename,'path':str(target),'bytes':target.stat().st_size}
    except Exception as exc:
        logger.exception('PI EVIDENCE DOWNLOAD FAILED | qt=%s | code=%s',case.get('qt'),case.get('code'))
        raise BusinessReview('PI_EVIDENCE_DOWNLOAD_FAILED',str(exc))

def inspect_row(tx):
    return {
        'pi':tx.pi,
        'eci':tx.eci,
        'assoc_dispute':tx.assoc_dispute,
        'tran_type':tx.tran_type,
        'response_code':_plain_value(tx.values.get('response_code')),
        'total_tran_amount':_plain_value(tx.values.get('total_tran_amount')),
        'dr_cr':_plain_value(tx.values.get('dr_cr')),
        'entry_mode':_plain_value(tx.values.get('entry_mode')),
        'tran_desc':_plain_value(tx.values.get('tran_desc')),
        'auth_code':tx.auth_code,
        'transaction_id':tx.transaction_id,
        'retrieval_ref':tx.retrieval_ref,
    }

def evaluate(code,info,amount=None):
    """Apply currently confirmed common and code-specific table rules."""
    hits=[]
    tran_type=str(info.get('tran_type') or '').strip().casefold()
    assoc=str(info.get('assoc_dispute') or '').strip().upper()
    response=str(info.get('response_code') or '').strip()
    if assoc in {'M','D'}: hits.append('ASSOC_DISPUTE_'+assoc)
    if response and response!='00': hits.append('TRANSACTION_NOT_APPROVED')
    if code in {'10.4','13.1'} and tran_type!='sale': hits.append(f'{code}_REQUIRES_SALE')
    if code=='13.9' and tran_type!='cash': hits.append('13.9_REQUIRES_CASH')
    if code=='10.4':
        eci=str(info.get('eci') or '').strip()
        pi=str(info.get('pi') or '').strip()
        if eci=='': hits.append('10_4_ECI_DATA_MISSING')
        elif eci in {'5','6'}: hits.append('10_4_ECI_DATA_ERROR')
        if pi=='': hits.append('10_4_PI_DATA_MISSING')
    return hits


def probe_issuer_menu_hierarchy(page, code, settings):
    """Click Issuer Action, hover Chargeback/Dispute, then hover Fraud/Consumer only."""
    issuer=buttons(page).get_by_role('button',name=re.compile('Issuer Action',re.I)).first
    if not visible(issuer,5000): raise UnknownScenario('ISSUER_ACTION_NOT_FOUND')
    issuer.click()
    LOGGER.info('PASS OPEN_ISSUER_ACTION')

    chargeback=None
    deadline=time.monotonic()+int(settings.get('issuer_menu_probe_timeout_ms',10000))/1000
    while time.monotonic()<deadline and chargeback is None:
        for frame in page.frames:
            for pattern in (r'^Chargeback\s*/\s*Dispute$',r'^Chargeback / Dispute$',r'^Chargeback$'):
                try:
                    loc=frame.get_by_text(re.compile(pattern,re.I),exact=True).first
                    if loc.count() and loc.is_visible():
                        chargeback=(frame,loc,pattern); break
                except Exception: pass
            if chargeback: break
        page.wait_for_timeout(250)
    if not chargeback: raise UnknownScenario('CHARGEBACK_DISPUTE_MENU_NOT_FOUND')
    frame,loc,pattern=chargeback
    loc.hover(force=True); loc.dispatch_event('mouseover')
    LOGGER.info('ISSUER MENU FOUND | level=Chargeback/Dispute | selector=text-regex:%s | frame=%s | url=%s',pattern,frame.name,frame.url)

    expected='Fraud' if code=='10.4' else 'Consumer'
    discovered={}
    deadline=time.monotonic()+int(settings.get('issuer_menu_probe_timeout_ms',10000))/1000
    while time.monotonic()<deadline:
        for action in ('Fraud','Consumer'):
            if action in discovered: continue
            for probe_frame in page.frames:
                try:
                    action_loc=probe_frame.get_by_text(action,exact=True).first
                    if action_loc.count() and action_loc.is_visible():
                        discovered[action]={'frame_name':probe_frame.name,'frame_url':probe_frame.url,'selector':f'text="{action}" exact'}
                        if action==expected:
                            action_loc.hover(force=True); action_loc.dispatch_event('mouseover')
                            LOGGER.info('ISSUER MENU HOVERED | action=%s | selector=text="%s" exact | frame=%s | url=%s',action,action,probe_frame.name,probe_frame.url)
                        else:
                            LOGGER.info('ISSUER MENU FOUND | action=%s | selector=text="%s" exact | frame=%s | url=%s',action,action,probe_frame.name,probe_frame.url)
                        break
                except Exception: pass
        if expected in discovered: break
        page.wait_for_timeout(250)
    if expected not in discovered: raise UnknownScenario('EXPECTED_ISSUER_ACTION_NOT_FOUND:'+expected)
    LOGGER.info('ISSUER HIERARCHY PROBE COMPLETE | expected=%s | discovered=%s | NO Fraud/Consumer CLICK',expected,discovered)
    return {'chargeback_dispute':{'frame_name':frame.name,'frame_url':frame.url},'expected_action':expected,'actions':discovered,'action_clicked':False}


def _find_case_scope(case_page,timeout_ms):
    deadline=time.monotonic()+timeout_ms/1000
    while time.monotonic()<deadline:
        for frame in case_page.frames:
            try:
                if frame.locator('#submitButton').count() and frame.locator('#submitButton').first.is_visible():
                    return frame
            except Exception: pass
        case_page.wait_for_timeout(250)
    raise UnknownScenario('CASE_CREATION_SUBMIT_NOT_FOUND')

def _wait_questionnaire(case_page,timeout_ms):
    deadline=time.monotonic()+timeout_ms/1000
    final_submit_names=re.compile(r'^Submit$',re.I)
    while time.monotonic()<deadline:
        for frame in case_page.frames:
            try:
                text=frame.locator('body').inner_text(timeout=500)
                if re.search(r'ROL-1545\b',text,re.I):
                    detail=' '.join(text.split())
                    LOGGER.warning('ROL-1545 DUPLICATE DETECTED | page=%s | frame=%s | detail=%s',case_page.url,frame.name,detail[:500])
                    raise UnknownScenario('ROL_1545_DUPLICATE_SELECTED_CARD_TRANSACTION_MCSN')
                has_questionnaire=bool(re.search(r'(Fraud|Consumer) Dispute Questionnaire',text,re.I))
                has_case=bool(re.search(r'VROL Case Number\s*\d+',text,re.I)) or frame.locator('#caseNumber').count()>0
                has_submit=frame.get_by_role('button',name=final_submit_names,exact=True).count()>0
                if has_questionnaire and has_case and has_submit: return frame,text
            except UnknownScenario: raise
            except Exception: pass
        case_page.wait_for_timeout(300)
    raise UnknownScenario('READY_FOR_FINAL_SUBMIT_REVIEW_NOT_REACHED')

def inspect_issuer_actions(page, settings):
    """Open Issuer Action and report available Fraud/Consumer selectors without clicking them."""
    issuer=buttons(page).get_by_role('button',name=re.compile('Issuer Action',re.I)).first
    if not visible(issuer,5000):
        raise UnknownScenario('ISSUER_ACTION_NOT_FOUND')
    issuer.click()
    timeout=int(settings.get('issuer_action_probe_timeout_ms',10000))
    deadline=time.monotonic()+timeout/1000
    found={}
    while time.monotonic()<deadline:
        for action in ('Fraud','Consumer'):
            if action in found: continue
            for frame in page.frames:
                try:
                    loc=frame.get_by_text(action,exact=True)
                    if loc.count() and loc.first.is_visible():
                        found[action]={
                            'selector':f'text="{action}" (exact visible)',
                            'frame_name':frame.name,
                            'frame_url':frame.url,
                        }
                        LOGGER.info('ISSUER ACTION FOUND | action=%s | selector=%s | frame=%s | url=%s',action,found[action]['selector'],frame.name,frame.url)
                        break
                except Exception: pass
        if found: break
        page.wait_for_timeout(250)
    if not found:
        raise UnknownScenario('ISSUER_ACTION_SUBMENU_NOT_FOUND')
    LOGGER.info('ISSUER ACTION PROBE COMPLETE | found=%s | no submenu clicked',found)
    return found


def find_case_creation_document(context, origin_page, settings):
    """Find the real VROL Case Creation page/frame using the supplied document contract."""
    timeout=int(settings.get('case_creation_document_timeout_ms',20000))
    poll=int(settings.get('case_creation_document_poll_ms',250))
    deadline=time.monotonic()+timeout/1000
    observed=[]
    while time.monotonic()<deadline:
        pages=list(context.pages)
        # Prefer new popup pages, but also allow same-page/frame rendering.
        pages.sort(key=lambda p: p is origin_page)
        for candidate in pages:
            contract=_case_creation_submit_from_popup(candidate,settings)
            if contract is not None:return contract
            for frame in candidate.frames:
                url=str(frame.url or '')
                signature=f'page={candidate.url}; frame={frame.name}; url={url}'
                if signature not in observed: observed.append(signature)
                try:
                    body=frame.locator('body#mainBody').first
                    form=frame.locator('form#mainForm[action="/rolrfc/web/casefolder/submit-create-case.action"]').first
                    action_code=frame.locator('input#actionCode').first
                    invocation=frame.locator('input#invocationSource[value="TI"]').first
                    submit=frame.locator(
                        'button#submitButton.allbuttons[value="Submit"]'
                        '[data-param-1="SUBMIT"]'
                        '[data-action="returnDoSubmitSubmit"]'
                        '[accesskey="s"]'
                    ).first
                    contract=(
                        body.count() and form.count() and action_code.count()
                        and invocation.count() and submit.count()
                        and body.is_visible() and submit.is_visible() and submit.is_enabled()
                    )
                    if contract:
                        code=action_code.get_attribute('value') or ''
                        case_number=''
                        case_input=frame.locator('input#caseNumber').first
                        if case_input.count(): case_number=case_input.get_attribute('value') or ''
                        LOGGER.info(
                            'CASE CREATION DOCUMENT FOUND | page=%s | frame=%s | url=%s | actionCode=%s | caseNumber=%s',
                            candidate.url,frame.name,url,code,case_number,
                        )
                        return {
                            'page':candidate,'frame':frame,'submit':submit,
                            'action_code':code,'case_number':case_number,'url':url,
                        }
                except Exception:
                    continue
        origin_page.wait_for_timeout(poll)
    LOGGER.info('CASE CREATION DOCUMENT NOT FOUND | optional_probe_complete=true | observed_tail=%s',observed[-3:])
    return None


def _case_creation_submit_from_popup(candidate,settings):
    """Find and click the visible Submit control in one confirmed Case Creation popup."""
    try:maximize_page_window(candidate,LOGGER,int(settings.get('vrol_window_maximize_wait_ms',500)))
    except Exception:pass
    selectors=[
        'button#submitButton','input#submitButton',
        'button[type="submit"]','input[type="submit"][value="Submit"]',
        'button:has-text("Submit")','input[type="button"][value="Submit"]'
    ]
    for frame in candidate.frames:
        try:
            title=frame.locator('span.title').filter(has_text=re.compile(r'^\s*Case Creation\s*$',re.I)).first
            title_ready=bool(title.count() and title.is_visible())
            url_ready='create-case-from-tran-inq' in str(candidate.url) or 'submit-create-case.action' in str(frame.url)
            if not (title_ready or url_ready):continue
            LOGGER.info('CASE CREATION POPUP READY | page_url=%s | frame=%s | signal=%s',candidate.url,frame.name,'span.title' if title_ready else 'create-case-url')
            for selector in selectors:
                submit=frame.locator(selector).first
                if not (submit.count() and submit.is_visible() and submit.is_enabled()):continue
                LOGGER.info('CASE CREATION SUBMIT FOUND | selector=%s | page_url=%s | frame=%s',selector,candidate.url,frame.name)
                wait_for_manual_step(settings,'SUBMIT_CASE_CREATION','Click Submit on PROD - Case Creation',selector,submit)
                try:
                    submit.scroll_into_view_if_needed(timeout=2000);submit.click(timeout=3000,no_wait_after=True)
                    strategy='PLAYWRIGHT_CLICK'
                except Exception as exc:
                    LOGGER.warning('CASE CREATION PLAYWRIGHT CLICK FAILED | selector=%s | fallback=DOM_CLICK | error=%s',selector,str(exc).splitlines()[0])
                    submit.evaluate('el => el.click()');strategy='DOM_CLICK'
                LOGGER.info('PASS CASE CREATION SUBMIT | selector=%s | strategy=%s',selector,strategy)
                return {'page':candidate,'frame':frame,'submit':submit,'url':frame.url,'selector':selector}
            # Title loaded but no known selector. Last-resort exact accessible button in this popup only.
            exact=frame.get_by_role('button',name=re.compile(r'^\s*Submit\s*$',re.I)).first
            if exact.count() and exact.is_visible() and exact.is_enabled():
                exact.evaluate('el => el.click()')
                LOGGER.info('PASS CASE CREATION SUBMIT | selector=role_button_exact_submit | strategy=DOM_CLICK')
                return {'page':candidate,'frame':frame,'submit':exact,'url':frame.url,'selector':'role_button_exact_submit'}
            raise UnknownScenario('CASE_CREATION_SUBMIT_NOT_FOUND_AFTER_TITLE_READY')
        except UnknownScenario:raise
        except Exception:pass
    return None

def submit_case_creation_if_present(context, origin_page, settings):
    """Find and submit Case Creation across all pages/frames before questionnaire.

    Case Creation is commonly a separate popup page. Never treat it as absent merely
    because the original Transaction Inquiry page does not contain the form.
    """
    mode=str(settings.get('case_creation_popup_mode','OPTIONAL')).strip().upper()
    # Fast path: Issuer Action opens Case Creation as the newest popup. Validate the
    # explicit title signal, then search Submit only inside that popup and its frames.
    fast_deadline=time.monotonic()+int(settings.get('case_creation_fast_timeout_ms',6000))/1000
    fast_poll=int(settings.get('case_creation_fast_poll_ms',100))
    while time.monotonic()<fast_deadline:
        live=[p for p in context.pages if not p.is_closed()]
        candidate=live[-1] if live else None
        if candidate is not None and candidate is not origin_page:
            fast_contract=_case_creation_submit_from_popup(candidate,settings)
            if fast_contract is not None:return fast_contract
            for frame in candidate.frames:
                try:
                    title=frame.locator('span.title').filter(has_text=re.compile(r'^\s*Case Creation\s*$',re.I)).first
                    if not (title.count() and title.is_visible()):continue
                    LOGGER.info('CASE CREATION POPUP READY | page_url=%s | frame=%s | signal=span.title | strategy=NEWEST_POPUP_FAST_PATH',candidate.url,frame.name)
                    for selector in ['button#submitButton','button:has-text("Submit")']:
                        submit=frame.locator(selector).first
                        if submit.count() and submit.is_visible() and submit.is_enabled():
                            LOGGER.info('CASE CREATION SUBMIT FOUND | selector=%s | page_url=%s | frame=%s | strategy=NEWEST_POPUP_ONLY',selector,candidate.url,frame.name)
                            wait_for_manual_step(settings,'SUBMIT_CASE_CREATION','Click Submit on PROD - Case Creation',selector,submit)
                            submit.click(no_wait_after=True)
                            LOGGER.info('PASS CASE CREATION SUBMIT | selector=%s | strategy=NEWEST_POPUP_ONLY',selector)
                            return {'page':candidate,'frame':frame,'submit':submit,'url':frame.url,'selector':selector}
                except Exception:pass
        try:origin_page.wait_for_timeout(fast_poll)
        except Exception:time.sleep(fast_poll/1000)
    LOGGER.warning('CASE CREATION FAST PATH MISSED | fallback=LEGACY_FULL_SCAN | timeout_ms=%s',int(settings.get('case_creation_fast_timeout_ms',6000)))
    if mode=='SKIP':
        LOGGER.info('CASE CREATION POPUP CHECK SKIPPED BY CONFIG')
        return None
    timeout=int(settings.get('case_creation_popup_scan_timeout_ms',12000))
    poll=int(settings.get('case_creation_popup_scan_poll_ms',150))
    deadline=time.monotonic()+timeout/1000
    popup_seen=False
    seen=[]
    submit_selectors=[
        'button#submitButton',
        'button:has-text("Submit")',
        'input[type="submit"][value="Submit"]',
        'input[type="button"][value="Submit"]',
    ]
    while time.monotonic()<deadline:
        pages=[p for p in context.pages if not p.is_closed()]
        pages.sort(key=lambda p:p is origin_page)
        for candidate in pages:
            for frame in candidate.frames:
                try:
                    url=str(frame.url or '')
                    body_text=' '.join((frame.locator('body').inner_text(timeout=350) or '').split())
                    url_match='/rolfc/web/casefolder/create-case-from-tran-inq' in url.lower()
                    title_match=bool(re.search(r'\bCase Creation\b',body_text,re.I))
                    dispute=frame.get_by_text('Create Dispute',exact=False).first
                    dispute_present=bool(dispute.count())
                    is_case_creation=url_match or (title_match and dispute_present)
                    if not is_case_creation:
                        continue
                    popup_seen=True
                    signature=f'page={candidate.url}; frame={frame.name}; url={url}'
                    if signature not in seen:
                        seen.append(signature)
                        LOGGER.info('CASE CREATION POPUP FOUND | page_url=%s | frame=%s | url=%s',candidate.url,frame.name,url)
                    create_dispute_checked=False
                    checkbox=None
                    try:
                        label=frame.get_by_text('Create Dispute',exact=False).first
                        if label.count():
                            checkbox=label.locator('xpath=preceding::input[@type="checkbox"][1]')
                            if not checkbox.count():checkbox=label.locator('xpath=ancestor::*[self::label or self::div or self::td][1]//input[@type="checkbox"]').first
                        if checkbox is not None and checkbox.count():
                            if not checkbox.is_checked():checkbox.check()
                            create_dispute_checked=checkbox.is_checked()
                        else:
                            create_dispute_checked=dispute_present
                    except Exception:
                        create_dispute_checked=dispute_present
                    submit=None;selector_used=None
                    for selector in submit_selectors:
                        try:
                            loc=frame.locator(selector).first
                            if loc.count() and loc.is_visible() and loc.is_enabled():
                                submit=loc;selector_used=selector;break
                        except Exception:pass
                    if submit is None:
                        continue
                    LOGGER.info('CASE CREATION SUBMIT FOUND | selector=%s | page_url=%s | frame=%s',selector_used,candidate.url,frame.name)
                    try:_batch_capture(candidate,settings,'02c_case_creation_before_submit.png')
                    except Exception:LOGGER.warning('CASE CREATION BEFORE-SUBMIT EVIDENCE FAILED | page_url=%s',candidate.url)
                    wait_for_manual_step(settings,'SUBMIT_CASE_CREATION','Click Submit on PROD - Case Creation',selector_used,submit)
                    submit.click()
                    LOGGER.info('PASS CASE CREATION SUBMIT | selector=%s | create_dispute_checked=%s',selector_used,create_dispute_checked)
                    try:candidate.wait_for_timeout(int(settings.get('case_creation_post_submit_wait_ms',700)))
                    except Exception:pass
                    try:_batch_capture(candidate,settings,'02d_case_creation_after_submit.png')
                    except Exception:LOGGER.warning('CASE CREATION AFTER-SUBMIT EVIDENCE FAILED | popup_may_have_closed=true')
                    LOGGER.info('QUESTIONNAIRE PAGE DETECTION START | context_pages=%s',len([p for p in context.pages if not p.is_closed()]))
                    return {'page':candidate,'frame':frame,'selector':selector_used,'create_dispute_checked':create_dispute_checked,'url':url}
                except Exception:pass
        origin_page.wait_for_timeout(poll)
    if popup_seen:
        LOGGER.error('CASE CREATION SUBMIT NOT FOUND | observed=%s',seen[-10:])
        raise UnknownScenario('CASE_CREATION_SUBMIT_NOT_FOUND')
    if mode=='REQUIRED':
        raise UnknownScenario('CASE_CREATION_DOCUMENT_REQUIRED_NOT_FOUND')
    LOGGER.info('CASE CREATION POPUP NOT PRESENT AFTER FULL CONTEXT SCAN | mode=OPTIONAL | timeout_ms=%s',timeout)
    return None


def handle_duplicate_case_warning(context, current_page, settings):
    """Acknowledge VROL ROL-749, including buttons whose DOM differs from older #okbutton HTML."""
    timeout_ms=int(settings.get('duplicate_case_warning_timeout_ms',20000))
    deadline=time.monotonic()+timeout_ms/1000
    duplicate_seen=False
    stable_page=current_page
    selectors=[
        'button#okbutton[data-action="disableAndSubmit"]',
        'button#okbutton',
        'input#okbutton',
        'button[data-action="disableAndSubmit"]',
        'input[data-action="disableAndSubmit"]',
        'button[value="OK"]','button[value="Ok"]','input[value="OK"]','input[value="Ok"]',
    ]
    while time.monotonic()<deadline:
        pages=[p for p in context.pages if not p.is_closed()]
        if stable_page not in pages and not stable_page.is_closed():pages.insert(0,stable_page)
        for candidate in reversed(pages):
            for frame in candidate.frames:
                try:
                    body=frame.locator('body')
                    text=body.inner_text(timeout=500) if body.count() else ''
                    duplicate=bool(re.search(r'ROL[-_ ]?749|potential duplicate case|duplicate case',text,re.I))
                    if duplicate:
                        duplicate_seen=True;stable_page=candidate
                        LOGGER.warning('DUPLICATE CASE WARNING DETECTED | code=ROL-749 | frame=%s | url=%s',frame.name,frame.url)
                    if not duplicate:continue
                    candidates=[]
                    for selector in selectors:
                        loc=frame.locator(selector)
                        for i in range(min(loc.count(),10)):candidates.append((selector,loc.nth(i)))
                    # Text/role fallback is essential because current VROL can render OK without #okbutton.
                    for label in (r'^\s*OK\s*$',r'^\s*Ok\s*$'):
                        loc=frame.get_by_role('button',name=re.compile(label,re.I),exact=True)
                        for i in range(min(loc.count(),10)):candidates.append(('role=button name=OK',loc.nth(i)))
                    loc=frame.get_by_text(re.compile(r'^\s*OK\s*$',re.I),exact=True)
                    for i in range(min(loc.count(),10)):candidates.append(('text=OK exact',loc.nth(i)))
                    for selector,ok in candidates:
                        try:
                            if not ok.is_visible():continue
                            LOGGER.info('DUPLICATE OK BUTTON FOUND | selector=%s | tag=%s | id=%s | action=%s',selector,ok.evaluate('(e)=>e.tagName'),ok.get_attribute('id'),ok.get_attribute('data-action'))
                            try:ok.click(timeout=3000)
                            except Exception:ok.click(force=True,timeout=3000)
                            LOGGER.info('PASS ACK_DUPLICATE_CASE | code=ROL-749 | selector=%s | immediate=true | continuing to Case Creation',selector)
                            try:candidate.wait_for_timeout(300)
                            except Exception:pass
                            _batch_capture(candidate,settings,'02f_duplicate_case_warning_after_ok.png')
                            return {'handled':True,'code':'ROL-749','page':candidate,'frame_name':frame.name,'frame_url':frame.url,'selector':selector}
                        except Exception:continue
                    # Emit compact diagnostics only when the warning is present but no clickable OK matched.
                    buttons_inventory=frame.locator('button,input[type="button"],input[type="submit"],a')
                    inventory=[]
                    for i in range(min(buttons_inventory.count(),30)):
                        el=buttons_inventory.nth(i)
                        try:
                            inventory.append({'tag':el.evaluate('(e)=>e.tagName'),'id':el.get_attribute('id'),'name':el.get_attribute('name'),'value':el.get_attribute('value'),'text':(el.inner_text(timeout=200) or '').strip(),'action':el.get_attribute('data-action'),'visible':el.is_visible()})
                        except Exception:pass
                    LOGGER.warning('DUPLICATE OK BUTTON NOT MATCHED YET | frame=%s | controls=%s',frame.name,inventory)
                except Exception:pass
        for candidate in pages:
            for frame in candidate.frames:
                try:
                    text=frame.locator('body').inner_text(timeout=300)
                    if re.search(r'(Fraud|Consumer) Dispute Questionnaire',text,re.I):return {'handled':False,'page':candidate}
                except Exception:pass
        stable_page.wait_for_timeout(250)
    if duplicate_seen:raise UnknownScenario('ROL_749_OK_BUTTON_NOT_FOUND_AFTER_FALLBACKS')
    return {'handled':False,'page':stable_page}

def open_case_and_prepare(page,tx,code,record,settings,downloads):
    """Create/recreate ROL draft, then require questionnaire + VROL number + final Submit."""
    wait_for_manual_step(settings, 'SELECT_SALE_TRANSACTION', 'Select the confirmed Sale transaction row', 'matched Sale row checkbox: input[aria-label="Select transaction"]', tx.locator.get_by_role('checkbox').first if tx.locator.get_by_role('checkbox').count() else tx.locator)
    tx.locator.get_by_role('checkbox').check() if tx.locator.get_by_role('checkbox').count() else tx.locator.click()
    # Proven v8.28 hierarchy, now completed with the final action click:
    # Issuer Action -> hover Chargeback/Dispute -> click Fraud/Consumer.
    issuer_action = buttons(page).get_by_role('button',name=re.compile('Issuer Action',re.I)).first
    wait_for_manual_step(settings, 'OPEN_ISSUER_ACTION', 'Open Issuer Action menu', 'iframe[name="buttons"] >> button:has-text("Issuer Action")', issuer_action)
    if not visible(issuer_action,5000):
        raise UnknownScenario('ISSUER_ACTION_NOT_FOUND')
    issuer_action.click()
    LOGGER.info('PASS OPEN_ISSUER_ACTION')

    # v8.28 required this intermediate hover. Without it Fraud/Consumer is not rendered.
    chargeback=None
    deadline=time.monotonic()+int(settings.get('issuer_menu_probe_timeout_ms',10000))/1000
    while time.monotonic()<deadline and chargeback is None:
        for frame in page.frames:
            for pattern in (r'^Chargeback\s*/\s*Dispute$',r'^Chargeback / Dispute$',r'^Chargeback$'):
                try:
                    loc=frame.get_by_text(re.compile(pattern,re.I),exact=True).first
                    if loc.count() and loc.is_visible():
                        chargeback=(frame,loc,pattern)
                        break
                except Exception:
                    pass
            if chargeback:
                break
        if chargeback is None:
            page.wait_for_timeout(250)
    if chargeback is None:
        raise UnknownScenario('CHARGEBACK_DISPUTE_MENU_NOT_FOUND')
    cb_frame,cb_loc,cb_pattern=chargeback
    cb_loc.hover(force=True)
    cb_loc.dispatch_event('mouseover')
    LOGGER.info('PASS HOVER_CHARGEBACK_DISPUTE | selector=text-regex:%s | frame=%s | url=%s',cb_pattern,cb_frame.name,cb_frame.url)

    action='Fraud' if code=='10.4' else 'Consumer'
    action_loc=None
    action_frame=None
    deadline=time.monotonic()+int(settings.get('issuer_menu_probe_timeout_ms',10000))/1000
    while time.monotonic()<deadline and action_loc is None:
        # Re-hover the parent to keep legacy submenu open while polling.
        try:
            cb_loc.hover(force=True)
            cb_loc.dispatch_event('mouseover')
        except Exception:
            pass
        for frame in page.frames:
            try:
                loc=frame.get_by_text(action,exact=True).first
                if loc.count() and loc.is_visible():
                    action_loc=loc
                    action_frame=frame
                    break
            except Exception:
                pass
        if action_loc is None:
            page.wait_for_timeout(250)
    if action_loc is None:
        raise UnknownScenario('EXPECTED_ISSUER_ACTION_NOT_FOUND:'+action)
    LOGGER.info('ISSUER ACTION FOUND | path=Issuer Action > Chargeback/Dispute > %s | frame=%s | url=%s',action,action_frame.name,action_frame.url)
    _batch_capture(page,settings,'02b_issuer_action_decision_'+action.lower()+'.png')
    wait_for_manual_step(settings, 'SELECT_CASE_ACTION', f'Click Issuer Action submenu: {action}', f'text="{action}" exact after Chargeback/Dispute hover', action_loc)
    action_loc.click()
    LOGGER.info('PASS SELECT_CASE_ACTION | path=Issuer Action > Chargeback/Dispute > %s',action)
    contract=submit_case_creation_if_present(page.context,page,settings)
    if contract is not None:
        case_page=contract['page']
        LOGGER.info('CASE CREATION PATH | popup/document Submit was present and clicked')
    else:
        # OPTIONAL means VROL may navigate directly to the questionnaire without Case Creation.
        candidates=[p for p in page.context.pages if not p.is_closed()]
        case_page=candidates[-1] if candidates else page
        LOGGER.info('CASE CREATION PATH | optional document absent; probing direct questionnaire path | page=%s',case_page.url)
    duplicate_result=handle_duplicate_case_warning(page.context,case_page,settings)
    if duplicate_result.get('page') is not None:
        case_page=duplicate_result['page']
    if duplicate_result.get('handled'):
        # ROL-749 OK returns to Case Creation. Submit the same Case Creation document again
        # before waiting for the questionnaire.
        LOGGER.info('DUPLICATE CASE CONTINUATION | ROL-749 acknowledged; waiting for Case Creation Submit to return')
        second_contract=submit_case_creation_if_present(page.context,case_page,settings)
        if second_contract is None:
            raise UnknownScenario('POST_DUPLICATE_CASE_CREATION_SUBMIT_NOT_FOUND')
        case_page=second_contract['page']
        LOGGER.info('PASS POST_DUPLICATE_CASE_CREATION_SUBMIT | second Case Creation Submit clicked; continuing to questionnaire')
        _batch_capture(case_page,settings,'02g_post_duplicate_case_creation_submit.png')
    q_scope,q_text=_wait_questionnaire(case_page,int(settings.get('questionnaire_timeout_ms',45000)))
    match=re.search(r'VROL Case Number\s*([0-9]{6,15})',q_text,re.I)
    if not match:
        for frame in case_page.frames:
            try:
                value=frame.locator('#caseNumber').get_attribute('value')
                if value and value.isdigit(): match=re.match(r'(\d+)',value); break
            except Exception: pass
    if not match: raise UnknownScenario('VROL_CASE_NUMBER_NOT_FOUND')
    return {'rol':match.group(1),'page':case_page,'scope':q_scope,'ready':True}


# Batch-safety wrapper: one VROL timeout/selector failure must not terminate the full run.
_open_case_and_prepare_impl = open_case_and_prepare
def open_case_and_prepare(page,tx,code,record,settings,downloads):
    try:
        return _open_case_and_prepare_impl(page,tx,code,record,settings,downloads)
    except Exception as exc:
        LOGGER.exception('OPEN CASE WORKFLOW FAILED - RETURNING CASE-LEVEL ERROR | code=%s | invoice=%s',code,(record or {}).get('invoice'))
        # Capture immediately while any surviving Case Creation/questionnaire page is still open.
        # The outer async worker also captures the whole context, but a TargetClosedError can
        # close the failing popup before that later capture runs.
        evidence_dir=Path(str(settings.get('batch_test_case_evidence_dir') or downloads or '.'))
        evidence_dir.mkdir(parents=True,exist_ok=True)
        invoice=re.sub(r'[^A-Za-z0-9._-]+','_',str((record or {}).get('invoice') or 'UNKNOWN_INVOICE')).strip('_')
        captured=[];capture_errors=[]
        try:pages=list(page.context.pages)
        except Exception as context_exc:
            pages=[];capture_errors.append('context_pages:'+str(context_exc))
        for index,candidate in enumerate(pages,1):
            try:
                if candidate.is_closed():
                    capture_errors.append(f'page{index}:already_closed')
                    continue
                target=evidence_dir/f'OPEN_CASE_WORKFLOW_FAILED_{invoice}_page{index:02d}.png'
                candidate.screenshot(path=str(target),full_page=True)
                captured.append(str(target))
            except Exception as shot_exc:
                capture_errors.append(f'page{index}:{type(shot_exc).__name__}:{shot_exc}')
        diagnostic=evidence_dir/f'OPEN_CASE_WORKFLOW_FAILED_{invoice}.txt'
        diagnostic.write_text(
            'code='+str(code)+'\ninvoice='+str((record or {}).get('invoice'))+
            '\nerror_type='+type(exc).__name__+'\nerror='+str(exc)+
            '\ncaptured='+repr(captured)+'\ncapture_errors='+repr(capture_errors)+'\n',
            encoding='utf-8')
        LOGGER.error('OPEN CASE FAILURE EVIDENCE | code=%s | invoice=%s | captured=%s | capture_errors=%s | diagnostic=%s',code,(record or {}).get('invoice'),captured,capture_errors,diagnostic)
        return {'rol':None,'page':page,'scope':None,'ready':False,'workflow_error':str(exc),'workflow_error_type':type(exc).__name__,'workflow_error_screenshots':captured,'workflow_error_capture_errors':capture_errors,'workflow_error_diagnostic':str(diagnostic)}
