from __future__ import annotations
import csv,re,time
from pathlib import Path
from datetime import datetime,timedelta
from shutil import copy2
from openpyxl import load_workbook
from ..workflow import wait_vrol_landing_frames_stable
from src.browser_window import maximize_page_window


def _norm(v):
    digits=re.sub(r'\D','',str(v or ''))
    return digits.lstrip('0') or ('0' if digits else '')

def _visible_scope(page, selectors, timeout_ms=15000):
    end=time.monotonic()+timeout_ms/1000
    while time.monotonic()<end:
        scopes=[page]+[f for f in page.frames if f!=page.main_frame]
        for scope in scopes:
            for sel in selectors:
                try:
                    loc=scope.locator(sel).first
                    if loc.count() and loc.is_visible(): return scope,loc,sel
                except Exception: pass
        page.wait_for_timeout(150)
    raise RuntimeError('ROL500_CONTROL_NOT_FOUND:'+','.join(selectors))

def _wait_report_menu_stable(vrol,settings,logger):
    # Landing URL can be reported as authenticated before legacy frames/menu finish their
    # post-login refresh. Require the landing frame set plus a stable visible Reports menu.
    wait_vrol_landing_frames_stable(vrol,settings)
    stable_required=int(settings.get('rol500_menu_stable_polls',4))
    poll=int(settings.get('rol500_menu_stable_poll_ms',250))
    timeout=int(settings.get('rol500_menu_ready_timeout_ms',20000))
    deadline=time.monotonic()+timeout/1000;stable=0;last=None
    while time.monotonic()<deadline:
        try:
            reports=vrol.locator('a#reportmenua').first
            signature=(vrol.url,reports.is_visible(),reports.get_attribute('aria-expanded'))
            if signature[1] and signature==last:stable+=1
            elif signature[1]:stable=1
            else:stable=0
            last=signature
            if stable>=stable_required:
                logger.info('PASS WAIT_ROL500_MENU_STABLE | url=%s | stable_polls=%s',vrol.url,stable)
                return
        except Exception:stable=0
        vrol.wait_for_timeout(poll)
    raise RuntimeError('ROL500_MENU_NOT_STABLE')

def _safe_menu_hover(locator,label,logger,timeout=5000):
    try:
        locator.hover(timeout=timeout);logger.info('PASS ROL500 MENU HOVER | menu=%s | strategy=NORMAL',label);return
    except Exception as exc:logger.warning('ROL500 MENU NORMAL HOVER INTERCEPTED | menu=%s | error=%s',label,str(exc).splitlines()[0])
    try:
        locator.hover(timeout=timeout,force=True);logger.info('PASS ROL500 MENU HOVER | menu=%s | strategy=FORCE',label);return
    except Exception as exc:logger.warning('ROL500 MENU FORCE HOVER FAILED | menu=%s | error=%s',label,str(exc).splitlines()[0])
    locator.evaluate("""el => { const opts={bubbles:true,cancelable:true,view:window}; el.dispatchEvent(new MouseEvent('mouseover',opts)); el.dispatchEvent(new MouseEvent('mouseenter',opts)); el.focus(); }""")
    logger.info('PASS ROL500 MENU HOVER | menu=%s | strategy=DOM_MOUSE_EVENTS',label)

def _click_report_menu(vrol,settings,logger):
    if str(settings.get('maximize_vrol_popup','YES')).strip().upper() in {'YES','Y','TRUE','1'}:
        maximize_page_window(vrol,logger,int(settings.get('vrol_window_maximize_wait_ms',500)))
    attempts=int(settings.get('rol500_menu_open_attempts',2))
    for attempt in range(1,attempts+1):
        _wait_report_menu_stable(vrol,settings,logger)
        reports=vrol.locator('a#reportmenua').first
        _safe_menu_hover(reports,'Reports',logger,int(settings.get('rol500_menu_hover_timeout_ms',5000)));vrol.wait_for_timeout(int(settings.get('rol500_menu_hover_delay_ms',350)))
        financial=vrol.locator('a[data-menu-id="reportmenu_sub3"]').first
        financial.wait_for(state='visible',timeout=10000);_safe_menu_hover(financial,'Financial Reports',logger,int(settings.get('rol500_menu_hover_timeout_ms',5000)))
        vrol.wait_for_timeout(int(settings.get('rol500_menu_hover_delay_ms',350)))
        target=vrol.locator('a[data-js*="reportSid/33"]').first
        target.wait_for(state='visible',timeout=10000);target.click()
        logger.info('ROL500 MENU CLICKED | attempt=%s/%s | path=Reports > Financial Reports > ROL 500 - Financial Reconciliation Report',attempt,attempts)
        try:
            _visible_scope(vrol,['select[aria-label="Financial Type"]'],int(settings.get('rol500_parameter_transition_timeout_ms',8000)))
            logger.info('PASS ROL500 PARAMETER SCREEN READY | attempt=%s | current_url=%s',attempt,vrol.url)
            return
        except Exception:
            logger.warning('ROL500 PARAMETER SCREEN NOT READY | attempt=%s/%s | current_url=%s | returning_to_stable_landing=true',attempt,attempts,vrol.url)
            if attempt>=attempts:raise RuntimeError('ROL500_PARAMETER_SCREEN_NOT_READY_AFTER_RETRY')
    raise RuntimeError('ROL500_MENU_OPEN_FAILED')

def download_rol500(vrol,context,settings,artifact_dir:Path,logger):
    artifact_dir.mkdir(parents=True,exist_ok=True)
    _click_report_menu(vrol,settings,logger)
    scope,fin,_=_visible_scope(vrol,['select[aria-label="Financial Type"]'],int(settings.get('rol500_parameter_timeout_ms',20000)))
    fin.select_option('O')
    today=datetime.now().date();date_from=today-timedelta(days=int(settings.get('rol500_days_back',3)))
    fmt=str(settings.get('rol500_date_format','%m/%d/%y'))
    _,from_loc,_=_visible_scope(vrol,['input[name="dateFromTxt"]'])
    _,to_loc,_=_visible_scope(vrol,['input[name="dateToTxt"]'])
    from_value=date_from.strftime(fmt);to_date=today;to_value=to_date.strftime(fmt)
    from_loc.fill(from_value);to_loc.fill(to_value)
    logger.info('ROL500 PARAMETERS SET | financial_type=O | from=%s | to=%s',from_value,to_value)
    buttons=vrol.frame(name='buttons')
    if buttons is None: raise RuntimeError('ROL500_BUTTONS_IFRAME_NOT_FOUND')
    submit=buttons.get_by_role('button',name=re.compile('Submit',re.I)).first
    report=None;date_retry_count=0;max_date_retries=int(settings.get('rol500_future_date_retry_count',1))
    response_timeout=int(settings.get('rol500_submit_response_timeout_ms',8000))
    poll_ms=int(settings.get('rol500_submit_response_poll_ms',100))
    while report is None:
        pages_before={id(p) for p in context.pages if not p.is_closed()}
        submit.click(no_wait_after=True)
        logger.info('ROL500 SUBMIT CLICKED | from=%s | to=%s | retry=%s/%s',from_value,to_value,date_retry_count,max_date_retries)
        deadline=time.monotonic()+response_timeout/1000;error_text=''
        while time.monotonic()<deadline:
            new_pages=[p for p in context.pages if not p.is_closed() and id(p) not in pages_before]
            if new_pages:
                report=new_pages[-1]
                report.wait_for_load_state('domcontentloaded')
                logger.info('ROL500 REPORT POPUP DETECTED | elapsed_seconds=%.2f | url=%s',response_timeout/1000-(deadline-time.monotonic()),report.url)
                break
            for error_scope in [vrol]+[f for f in vrol.frames if f!=vrol.main_frame]:
                try:
                    err=error_scope.locator('#errorSummary, span.errorSummary').first
                    if err.count() and err.is_visible():
                        error_text=' '.join((err.inner_text() or '').split())
                        if error_text:break
                except Exception:pass
            if error_text:break
            vrol.wait_for_timeout(poll_ms)
        if report is not None:break
        if re.search(r'ROL-189\b',error_text,re.I) and date_retry_count<max_date_retries:
            previous=to_value;to_date=to_date-timedelta(days=1);to_value=to_date.strftime(fmt)
            _,to_loc,_=_visible_scope(vrol,['input[name="dateToTxt"]'],int(settings.get('rol500_parameter_timeout_ms',20000)))
            # Fast, deterministic overwrite after VROL validation colors/replaces the field.
            to_loc.click();to_loc.press('Control+A');to_loc.type(to_value,delay=0);to_loc.press('Tab')
            date_retry_count+=1
            logger.warning('ROL500 ROL-189 FAST DATE RETRY | previous_to=%s | adjusted_to=%s | retry=%s/%s | elapsed_wait_ms<=%s | error=%s',previous,to_value,date_retry_count,max_date_retries,response_timeout,error_text)
            buttons=vrol.frame(name='buttons')
            if buttons is None:raise RuntimeError('ROL500_BUTTONS_IFRAME_NOT_FOUND_AFTER_ROL189')
            submit=buttons.get_by_role('button',name=re.compile('Submit',re.I)).first
            continue
        if error_text:raise RuntimeError('ROL500_PARAMETER_VALIDATION_ERROR:'+error_text)
        raise RuntimeError('ROL500_SUBMIT_RESPONSE_TIMEOUT')
    logger.info('ROL500 REPORT REQUEST ACCEPTED | from=%s | to=%s | rol189_retries=%s',from_value,to_value,date_retry_count)
    executing='Executing Report, Please wait ...';success='Report executed successfully.'
    timeout_ms=int(settings.get('rol500_execution_timeout_ms',180000));end=time.monotonic()+timeout_ms/1000
    saw_executing=False;download=None
    while time.monotonic()<end:
        try:
            body=report.locator('body').inner_text(timeout=1500)
            if executing in body and not saw_executing:
                saw_executing=True;logger.info('ROL500 EXECUTING | status=%s',executing)
            if success in body:
                logger.info('ROL500 EXECUTION SUCCESS | status=%s',success)
                break
        except Exception: pass
        report.wait_for_timeout(500)
    else: raise RuntimeError('ROL500_EXECUTION_TIMEOUT')
    # VROL normally starts the CSV download automatically at success. Capture a late event,
    # then use the report success URL as a deterministic trigger if the event already passed.
    try:
        with report.expect_download(timeout=int(settings.get('rol500_download_timeout_ms',30000))) as di:
            report.reload(wait_until='domcontentloaded')
        download=di.value
    except Exception:
        raise RuntimeError('ROL500_DOWNLOAD_NOT_CAPTURED')
    target=artifact_dir/'ROL500.csv';download.save_as(str(target))
    if not target.exists() or target.stat().st_size==0: raise RuntimeError('ROL500_DOWNLOAD_EMPTY')
    logger.info('ROL500 DOWNLOADED | path=%s | bytes=%s',target,target.stat().st_size)
    try: report.close()
    except Exception: pass
    return target,{'financial_type':'O','from':from_value,'to':to_value,'original_to':today.strftime(fmt),'rol189_date_retries':date_retry_count,'executing_seen':saw_executing}

def parse_rol500(csv_path:Path):
    rows=[]
    for enc in ('utf-8-sig','cp1252','latin-1'):
        try:
            with csv_path.open('r',encoding=enc,newline='') as f: data=list(csv.reader(f))
            break
        except UnicodeDecodeError: continue
    else: raise RuntimeError('ROL500_CSV_ENCODING_UNSUPPORTED')
    for n,row in enumerate(data[1:],start=2):
        if len(row)<12: continue
        qt=str(row[4] or '').strip();rol=str(row[5] or '').strip();tran=str(row[11] or '').strip()
        if qt or rol or tran: rows.append({'csv_row':n,'qt':qt,'rol_case':rol,'tran_id':tran,'tran_key':_norm(tran)})
    return rows

def enrich_classified(source:Path,rol_rows,output_path:Path,logger):
    copy2(source,output_path);wb=load_workbook(output_path);ws=wb['Sheet1']
    headers={str(ws.cell(2,c).value or '').strip().upper():c for c in range(1,ws.max_column+1)}
    invoice_col=headers.get('INVOICENUM');qt_col=headers.get('BUT TOAN')
    if not invoice_col or not qt_col: raise RuntimeError('ROL500_ENRICH_REQUIRED_HEADERS_MISSING')
    rol_col=37 # AK, per operating file contract
    if not ws.cell(2,rol_col).value: ws.cell(2,rol_col,'ROL CASE')
    status_col=ws.max_column+1;ws.cell(2,status_col,'BOT ROL500 STATUS')
    match_col=status_col+1;ws.cell(2,match_col,'BOT ROL500 MATCH KEY')
    source_col=match_col+1;ws.cell(2,source_col,'BOT ROL500 SOURCE')
    by_tran={};by_qt={}
    for item in rol_rows:
        if item['tran_key']: by_tran.setdefault(item['tran_key'],[]).append(item)
        if item['qt']: by_qt.setdefault(item['qt'].upper(),[]).append(item)
    stats={'rows_checked':0,'matched':0,'unmatched':0,'ambiguous':0}
    for r in range(4,ws.max_row+1):
        invoice=str(ws.cell(r,invoice_col).value or '').strip();qt=str(ws.cell(r,qt_col).value or '').strip()
        if not invoice and not qt: continue
        stats['rows_checked']+=1;key=_norm(invoice);candidates=by_tran.get(key,[])
        match_key='INVOICENUM->ROL500.TRAN_ID'
        if qt:
            exact=[x for x in candidates if x['qt'].upper()==qt.upper()]
            if exact: candidates=exact;match_key+=' + QT'
            elif not candidates:
                candidates=by_qt.get(qt.upper(),[]);match_key='QT_ONLY'
        unique=[];seen=set()
        for x in candidates:
            sig=(x['rol_case'],x['tran_key'],x['qt'])
            if sig not in seen:seen.add(sig);unique.append(x)
        roles=sorted({x['rol_case'] for x in unique if x['rol_case']})
        if len(roles)==1:
            ws.cell(r,rol_col,roles[0]);ws.cell(r,status_col,'ALREADY_CHARGEBACK_IN_ROL500');ws.cell(r,match_col,match_key);stats['matched']+=1
        elif len(roles)>1:
            ws.cell(r,rol_col,' | '.join(roles));ws.cell(r,status_col,'ROL500_AMBIGUOUS_MULTIPLE_CASES');ws.cell(r,match_col,match_key);stats['ambiguous']+=1
        else:
            ws.cell(r,status_col,'NOT_FOUND_IN_ROL500');ws.cell(r,match_col,match_key);stats['unmatched']+=1
        ws.cell(r,source_col,output_path.parent.joinpath('ROL500.csv').name)
    wb.save(output_path);logger.info('ROL500 ENRICH COMPLETE | output=%s | stats=%s',output_path,stats)
    return stats

def run_preflight(vrol,context,settings,classified:Path,batch_dir:Path,logger):
    report_dir=batch_dir/'rol500_preflight';report_dir.mkdir(parents=True,exist_ok=True)
    csv_path,params=download_rol500(vrol,context,settings,report_dir,logger)
    parse_started=time.perf_counter();logger.info('ROL500 CSV PARSE START | path=%s | bytes=%s',csv_path,csv_path.stat().st_size)
    rows=parse_rol500(csv_path);logger.info('ROL500 CSV PARSE COMPLETE | records=%s | elapsed_seconds=%.2f',len(rows),time.perf_counter()-parse_started)
    enriched=batch_dir/f'{classified.stem}_ROL500_ENRICHED.xlsx'
    enrich_started=time.perf_counter();logger.info('ROL500 WORKBOOK ENRICH START | source=%s | output=%s | data_start_row=4',classified,enriched)
    stats=enrich_classified(classified,rows,enriched,logger);logger.info('ROL500 WORKBOOK ENRICH TIMING | elapsed_seconds=%.2f | stats=%s',time.perf_counter()-enrich_started,stats)
    return {'csv_path':str(csv_path),'enriched_workbook':str(enriched),'parameters':params,'report_rows':len(rows),'stats':stats}
