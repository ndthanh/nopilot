def body(page): return page.locator('iframe[name="bodyframe"]').content_frame
def buttons(page): return page.locator('iframe[name="buttons"]').content_frame
def dispute(page): return page.locator('iframe[name="FRAME_ID_Dispute"]').content_frame
