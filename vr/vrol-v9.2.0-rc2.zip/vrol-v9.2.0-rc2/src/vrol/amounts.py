"""Exact amount comparison. Unknown formats stop the case; no rounding/tolerance."""
import re
from decimal import Decimal, InvalidOperation

class AmountDataError(ValueError):
    pass

def parse_amount(value, thousands=',', decimal='.', currency='VND'):
    if value is None or isinstance(value, bool):
        raise AmountDataError('AMOUNT_INVALID')
    if isinstance(value, (int, float, Decimal)):
        result = Decimal(str(value))
    else:
        text = str(value).strip()
        if currency and text.upper().endswith(' ' + currency.upper()):
            text = text[:-(len(currency) + 1)].strip()
        if not decimal or len(decimal) != 1 or (thousands and (len(thousands) != 1 or thousands == decimal)):
            raise AmountDataError('AMOUNT_FORMAT_CONFIG_INVALID')
        integer = r'(?:[0-9]+|[0-9]{1,3}(?:' + re.escape(thousands) + r'[0-9]{3})+)' if thousands else r'[0-9]+'
        if not re.fullmatch(r'[+-]?' + integer + '(?:' + re.escape(decimal) + r'[0-9]+)?', text):
            raise AmountDataError('AMOUNT_INVALID')
        try:
            result = Decimal(text.replace(thousands, '').replace(decimal, '.') if thousands else text.replace(decimal, '.'))
        except InvalidOperation:
            raise AmountDataError('AMOUNT_INVALID') from None
    if not result.is_finite():
        raise AmountDataError('AMOUNT_INVALID')
    return result

def read_vrol_amount(row, settings):
    """Resolve the amount cell by a unique header; never infer from whole-row text."""
    expected = {' '.join(x.lower().split()) for x in str(settings.get('amount_column_headers') or 'Tran Amount|Transaction Amount|Amount').split('|')}
    table = row.locator('xpath=ancestor::table[1]')
    candidates = []
    cells = row.locator('td')
    for header_row in table.locator('thead tr').all():
        headers = header_row.locator('th, td')
        for index, header in enumerate(headers.all()):
            if ' '.join(header.inner_text().lower().split()) in expected:
                # Reject spanning/irregular layouts instead of reading an unrelated cell.
                if headers.count() != cells.count() or any(h.get_attribute('colspan') not in (None, '1') for h in headers.all()):
                    raise AmountDataError('AMOUNT_COLUMN_LAYOUT_UNSUPPORTED')
                candidates.append(index)
    if len(candidates) != 1:
        raise AmountDataError('AMOUNT_COLUMN_NOT_UNIQUE')
    return cells.nth(candidates[0]).inner_text().strip()

def compare_amounts(excel_value, vrol_text, settings):
    values = []
    for source, value in [('excel', excel_value), ('vrol', vrol_text)]:
        values.append(parse_amount(value,
            thousands=str(settings.get(source + '_amount_thousands_separator', ',')),
            decimal=str(settings.get(source + '_amount_decimal_separator', '.')),
            currency=str(settings.get('amount_currency', 'VND'))))
    excel, vrol = values
    return {'excel_amount': str(excel), 'vrol_amount': str(vrol),
            'amount_difference': str(vrol - excel), 'amount_match': excel == vrol}
