from __future__ import annotations
from dataclasses import dataclass
import re, time

class TableContractError(RuntimeError): pass

def norm(value):
    return re.sub(r"\s+", " ", str(value or "").replace("\xa0", " ")).strip()

def key(value): return norm(value).casefold()

ALIASES={
    "assoc_dispute":["Assoc Dispute","Associated Dispute"],
    "transaction_date":["Transaction Date / Time"],
    "tran_type":["Tran Type"],
    "response_code":["Response Code"],
    "pi":["PI","Eligible for Purchase Inquiry"],
    "eci":["MOTO / ECI","MOTO/ECI","ECI"],
    "auth_code":["Auth Code"],
    "transaction_ref":["Transaction ID / Retrieval Ref #"],
}

@dataclass
class TransactionRow:
    locator: object
    values: dict
    transaction_id: str
    retrieval_ref: str

    @property
    def tran_type(self): return norm(self.values.get("tran_type"))
    @property
    def assoc_dispute(self): return norm(self.values.get("assoc_dispute"))
    @property
    def pi(self): return norm(self.values.get("pi"))
    @property
    def eci(self): return norm(self.values.get("eci"))
    @property
    def moto_eci(self): return norm(self.values.get("eci"))
    @property
    def auth_code(self): return norm(self.values.get("auth_code"))


def table(body_frame):
    return body_frame.locator('table#results').first


def schema_from_dom(body_frame):
    t=table(body_frame)
    headers=t.locator('thead > tr').first.locator(':scope > th')
    if headers.count()==0:
        raise TableContractError('TRANSACTION_TABLE_HEADER_NOT_FOUND')
    result=[]
    for i in range(headers.count()):
        result.append(norm(headers.nth(i).inner_text()))
    return result


def resolve_index(headers, logical_name):
    aliases={key(x) for x in ALIASES[logical_name]}
    hits=[i for i,h in enumerate(headers) if key(h) in aliases]
    if len(hits)!=1:
        raise TableContractError(f'{logical_name.upper()}_COLUMN_NOT_UNIQUE:{len(hits)}')
    return hits[0]


def split_transaction_ref(text):
    raw=norm(text)
    parts=re.split(r'\s*/\s*',raw,maxsplit=1)
    return parts[0].replace(' ',''), (parts[1].replace(' ','') if len(parts)>1 else '')


def parse_row(row, headers):
    cells=row.locator(':scope > td')
    if cells.count()!=len(headers):
        raise TableContractError(f'TRANSACTION_TABLE_LAYOUT_UNSUPPORTED:{len(headers)}:{cells.count()}')
    values={}
    for logical in ALIASES:
        idx=resolve_index(headers,logical)
        values[logical]=norm(cells.nth(idx).inner_text())
    transaction_id,retrieval_ref=split_transaction_ref(values['transaction_ref'])
    return TransactionRow(row,values,transaction_id,retrieval_ref)


def visible_rows(body_frame):
    return table(body_frame).locator('tbody > tr[data-action="summaryGridRow"]:visible')


def wait_stable_visible_rows(body_frame,timeout_ms=10000,poll_ms=250):
    deadline=time.monotonic()+timeout_ms/1000
    previous=None; stable=0
    while time.monotonic()<deadline:
        rows=visible_rows(body_frame); signature=[]
        for i in range(rows.count()):
            signature.append(rows.nth(i).get_attribute('id') or str(i))
        signature=tuple(signature)
        if signature==previous: stable+=1
        else: previous=signature; stable=0
        if stable>=2: return rows
        body_frame.page.wait_for_timeout(poll_ms)
    raise TableContractError('TRANSACTION_FILTER_NOT_STABLE')


# Confirmed VROL Transaction Inquiry schema, zero-based. Hidden columns use confirmed DOM positions.
CONFIRMED_SCHEMA={
    'select_transaction':0,
    'assoc_dispute':1,
    'transaction_date':2,
    'processing_date':3,
    'tran_desc':4,
    'tran_class':5,
    'settled_date':6,
    'tran_type':7,
    'response_code':8,
    'total_tran_amount':9,
    'dr_cr':10,
    'merchant_location':11,
    'payment_facilitator':12,
    'pi':13,
    'rdr':14,
    'card_account_number':15,
    'token':16,
    'eci':17,
    'acq_iss_network':18,
    'network_id':19,
    'entry_mode':20,
    'auth_code':21,
    'mcc':22,
    'transaction_ref':23,
    'special_merchant_id':24,
    'arn':25,
    'card_last4':26,
    'token_last4':27,
    'on_us_ind':28,
    'cvv2_result':29,
    'merchant_country':30,
}

EXPECTED_HEADER_BY_INDEX={
    1:'assoc dispute',2:'transaction date/time',4:'tran desc',6:'cpd/settled date',
    7:'tran type',8:'response code',9:'total tran amount',10:'dr/cr',
    11:'merchant/location',13:'pi',14:'rdr',15:'card/account number',
    17:'moto/eci',19:'network id',20:'entry mode',21:'auth code',22:'mcc',
    23:'transaction id/retrieval ref #',24:'special merchant identifier',25:'arn',
    26:'card #',28:'on-us ind',29:'cvv2 result',
}

CODE_REQUIRED_FIELDS={
    '10.4':{'assoc_dispute','transaction_date','settled_date','tran_type','response_code','total_tran_amount','dr_cr','pi','eci','entry_mode','transaction_ref','card_account_number'},
    '13.1':{'assoc_dispute','transaction_date','settled_date','tran_type','response_code','total_tran_amount','dr_cr','transaction_ref','card_account_number'},
    '13.9':{'assoc_dispute','transaction_date','processing_date','tran_desc','settled_date','tran_type','response_code','total_tran_amount','dr_cr','entry_mode','transaction_ref','card_account_number'},
}


def validate_confirmed_schema(headers, code):
    if len(headers)<31:
        raise TableContractError(f'TRANSACTION_TABLE_LAYOUT_UNSUPPORTED:{len(headers)}')
    mismatches=[]
    for index,expected in EXPECTED_HEADER_BY_INDEX.items():
        actual=normalize_header_for_schema(headers[index])
        if actual!=expected:
            mismatches.append((index,expected,actual))
    if mismatches:
        raise TableContractError('CONFIRMED_SCHEMA_HEADER_MISMATCH:'+repr(mismatches))
    if code not in CODE_REQUIRED_FIELDS:
        raise TableContractError('UNSUPPORTED_CODE:'+str(code))
    return CONFIRMED_SCHEMA


def normalize_header_for_schema(value):
    text=norm(value)
    text=re.sub(r'\s*/\s*','/',text)
    return text.casefold()


def parse_row_for_code(row, headers, code):
    schema=validate_confirmed_schema(headers,code)
    cells=row.locator(':scope > td')
    if cells.count()<31:
        raise TableContractError(f'TRANSACTION_TABLE_LAYOUT_UNSUPPORTED:{len(headers)}:{cells.count()}')
    values={name:norm(cells.nth(index).inner_text()) for name,index in schema.items()}
    transaction_id,retrieval_ref=split_transaction_ref(values['transaction_ref'])
    missing=[name for name in CODE_REQUIRED_FIELDS[code] if name not in values]
    if missing: raise TableContractError('REQUIRED_FIELDS_MISSING:'+','.join(sorted(missing)))
    return TransactionRow(row,values,transaction_id,retrieval_ref)


def normalize_transaction_id_for_invoice(value):
    """Normalize VROL Transaction ID for Invoice matching.

    VROL can append a two-digit lifecycle suffix to a settled Sale, e.g.
    Invoice 386290349000020 matches Sale Transaction ID 386290349000020-01.
    """
    text=norm(value).replace(' ','').lstrip('0')
    return re.sub(r'-\d{2}$','',text)


def transaction_id_matches_invoice(transaction_id, invoice):
    return normalize_transaction_id_for_invoice(transaction_id)==norm(invoice).replace(' ','').lstrip('0')
