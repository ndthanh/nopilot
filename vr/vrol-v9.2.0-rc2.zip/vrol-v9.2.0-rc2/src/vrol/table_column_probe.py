from __future__ import annotations
from dataclasses import dataclass, asdict
import re


def normalize_header(value):
    text=str(value or '').replace('\xa0',' ').strip()
    text=re.sub(r'\s*/\s*','/',text)
    text=re.sub(r'\s+',' ',text)
    return text.casefold()


@dataclass(frozen=True)
class ColumnRequirement:
    logical_name: str
    expected_headers: tuple[str, ...]
    codes: tuple[str, ...]
    purpose: str
    preferred_index: int | None = None


# One reusable mapping catalog for 10.4, 13.1 and 13.9.
COLUMN_REQUIREMENTS=(
    ColumnRequirement('select_transaction',('',),('10.4','13.1','13.9'),'Checkbox used to select the matched transaction row',0),
    ColumnRequirement('assoc_dispute',('Assoc Dispute','Associated Dispute'),('10.4','13.1','13.9'),'Stop/review when M or D is present'),
    ColumnRequirement('transaction_date',('Transaction Date / Time',),('10.4','13.1','13.9'),'Transaction timing and audit'),
    ColumnRequirement('processing_date',('Processing Date / Time',),('13.9',),'ATM/cash timing and audit'),
    ColumnRequirement('tran_desc',('Tran Desc',),('13.9',),'Secondary evidence for Cash transaction'),
    ColumnRequirement('tran_class',('Tran Class',),('10.4','13.1','13.9'),'Transaction classification audit'),
    ColumnRequirement('settled_date',('CPD/ Settled Date','CPD / Settled Date'),('10.4','13.1','13.9'),'Settlement confirmation'),
    ColumnRequirement('tran_type',('Tran Type',),('10.4','13.1','13.9'),'Sale for 10.4/13.1; Cash for 13.9; detect Credit/Sale Rev'),
    ColumnRequirement('response_code',('Response Code',),('10.4','13.1','13.9'),'Approved transaction check, normally 00'),
    ColumnRequirement('total_tran_amount',('Total Tran Amount',),('10.4','13.1','13.9'),'Amount and VND audit'),
    ColumnRequirement('dr_cr',('DR / CR','DR/CR'),('10.4','13.1','13.9'),'Debit/credit direction'),
    ColumnRequirement('merchant_location',('Merchant / Location',),('10.4','13.1','13.9'),'Merchant evidence'),
    ColumnRequirement('payment_facilitator',('Payment Facilitator ID /Sub-Merchant ID','Payment Facilitator ID/Sub-Merchant ID'),('10.4','13.1'),'Sub-merchant evidence'),
    ColumnRequirement('pi',('PI','Eligible for Purchase Inquiry'),('10.4',),'Purchase Inquiry evidence requirement'),
    ColumnRequirement('rdr',('RDR',),('10.4','13.1','13.9'),'RDR review indicator'),
    ColumnRequirement('card_account_number',('Card / Account Number','Card/Account Number'),('10.4','13.1','13.9'),'Confirm matched card/account'),
    ColumnRequirement('token',('Token',),('10.4',),'Tokenized transaction evidence',16),
    ColumnRequirement('eci',('MOTO/ ECI','MOTO / ECI','MOTO/ECI','ECI'),('10.4',),'Fraud eligibility/data-quality rule'),
    ColumnRequirement('acq_iss_network',('Acq / Iss Network','Acq/Iss Network'),('10.4','13.1','13.9'),'Network audit'),
    ColumnRequirement('network_id',('Network ID',),('10.4','13.1','13.9'),'Network identifier'),
    ColumnRequirement('entry_mode',('Entry Mode',),('10.4','13.9'),'Fraud/ATM context'),
    ColumnRequirement('auth_code',('Auth Code',),('10.4','13.1','13.9'),'Authorization evidence'),
    ColumnRequirement('mcc',('MCC',),('10.4','13.1','13.9'),'Merchant category/ATM evidence'),
    ColumnRequirement('transaction_ref',('Transaction ID / Retrieval Ref #','Transaction ID/Retrieval Ref #'),('10.4','13.1','13.9'),'Invoice exact match against Transaction ID'),
    ColumnRequirement('special_merchant_id',('Special Merchant Identifier',),('10.4','13.1','13.9'),'Special merchant audit'),
    ColumnRequirement('arn',('ARN',),('10.4','13.1','13.9'),'Reconciliation/audit'),
    ColumnRequirement('card_last4',('Card #',),('10.4','13.1','13.9'),'Masked-card evidence'),
    ColumnRequirement('token_last4',('Token',),('10.4',),'Token last-four evidence',27),
    ColumnRequirement('on_us_ind',('On-Us Ind',),('10.4','13.1','13.9'),'On-us review'),
    ColumnRequirement('cvv2_result',('CVV2 Result',),('10.4',),'Fraud evidence'),
    ColumnRequirement('merchant_country',('Merch Country',),('10.4','13.1','13.9'),'Country/cross-border evidence'),
)


def _find_unique_header(headers, aliases):
    accepted={normalize_header(x) for x in aliases}
    hits=[i for i,value in enumerate(headers) if normalize_header(value) in accepted]
    return hits


def _search_input_for_index(frame, index):
    # Header filter may live in a cloned DataTables header, separate from table#results.
    rows=frame.locator('#dtheaderSearch')
    for row_index in range(rows.count()):
        row=rows.nth(row_index)
        cells=row.locator(':scope > th, :scope > td')
        if cells.count() <= index:
            continue
        cell=cells.nth(index)
        candidate=cell.locator('input.search-box, input[type="text"]').first
        if candidate.count():
            return candidate
    return None


def probe_table_column_mapping(frame, settings, logger):
    """Visually confirm every reusable table-column mapping after Invoice filtering.

    The marker is written to the filter input with DOM assignment only. No input/keyup/change
    event is dispatched, so the active DataTables Invoice filter and visible rows remain intact.
    """
    enabled=str(settings.get('column_mapping_probe_enabled','NO')).strip().upper()
    if enabled not in {'YES','Y','TRUE','1'}:
        return []

    selected_codes={x.strip() for x in str(settings.get('column_mapping_probe_codes','10.4|13.1|13.9')).split('|') if x.strip()}
    table=frame.locator('table#results').first
    header_locators=table.locator('thead > tr').first.locator(':scope > th')
    headers=[header_locators.nth(i).inner_text().strip() for i in range(header_locators.count())]
    results=[]

    logger.info('COLUMN MAPPING PROBE START | headers=%s | codes=%s',len(headers),sorted(selected_codes))
    for requirement in COLUMN_REQUIREMENTS:
        if not selected_codes.intersection(requirement.codes):
            continue
        hits=_find_unique_header(headers,requirement.expected_headers)
        if requirement.preferred_index is not None:
            index=requirement.preferred_index
            hits=[index] if index < len(headers) and normalize_header(headers[index]) in {normalize_header(x) for x in requirement.expected_headers} else []
        record={
            'logical_name':requirement.logical_name,
            'expected_headers':list(requirement.expected_headers),
            'codes':list(requirement.codes),
            'purpose':requirement.purpose,
            'status':'',
        }
        if len(hits)!=1:
            record.update(status='HEADER_NOT_UNIQUE',hit_indexes=hits)
            logger.warning('COLUMN MAP | %s | HEADER_NOT_UNIQUE | hits=%s | aliases=%s',requirement.logical_name,hits,requirement.expected_headers)
            results.append(record)
            continue

        index=hits[0]
        header=headers[index]
        search=_search_input_for_index(frame,index)
        selector=f'#dtheaderSearch > th:nth-child({index+1}) input.search-box'
        if search is None:
            record.update(status='FILTER_INPUT_NOT_FOUND',index=index,header=header,selector=selector)
            logger.warning('COLUMN MAP | %s | FILTER_INPUT_NOT_FOUND | index=%s | header=%s',requirement.logical_name,index,header)
            results.append(record)
            continue

        original=search.input_value()
        marker='*'+header
        search.evaluate('(element, value) => { element.value = value; element.style.setProperty("border", "2px solid #ff0000", "important"); }',marker)
        logger.info('COLUMN MAP READY | logical=%s | code=%s | index=%s | header=%s | selector=%s | marker=%s',requirement.logical_name,'|'.join(requirement.codes),index,header,selector,marker)
        print(
            f'\n[COLUMN_MAPPING] logical={requirement.logical_name}\n'
            f'Codes: {" | ".join(requirement.codes)}\n'
            f'Header index (0-based): {index}\n'
            f'Header text: {header}\n'
            f'Filter selector: {selector}\n'
            f'Marker shown in filter: {marker}\n'
            f'Purpose: {requirement.purpose}\n'
            'Confirm the marked column in Chrome, then press ENTER... ',
            end='',flush=True,
        )
        input()
        search.evaluate('(element, value) => { element.value = value; element.style.removeProperty("border"); }',original)
        record.update(status='CONFIRMED_BY_OPERATOR',index=index,header=header,selector=selector,marker=marker)
        results.append(record)

    logger.info('COLUMN MAPPING PROBE COMPLETE | results=%s',results)
    return results
