from openpyxl import load_workbook
from pathlib import Path

def as_bool(v): return str(v).strip().lower() in {"1","true","yes","y","on"}
def load_all(path:Path):
 wb=load_workbook(path,data_only=True,read_only=True)
 out={}
 for sheet in ["Settings","RunSettings","Selectors"]:
  if sheet not in wb.sheetnames: continue
  rows=wb[sheet].iter_rows(min_row=2,values_only=True)
  for row in rows:
   if row and row[0] not in (None,""): out[str(row[0]).strip()]=row[1]
 answers={}
 if "SecurityQuestions" in wb.sheetnames:
  for q,a,en,*_ in wb["SecurityQuestions"].iter_rows(min_row=2,values_only=True):
   if q and a and as_bool(en): answers[" ".join(str(q).lower().split()).rstrip("?.!")]=str(a)
 return out,answers
