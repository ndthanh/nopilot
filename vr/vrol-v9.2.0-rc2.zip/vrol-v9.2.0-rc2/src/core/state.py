import json,os,uuid
from datetime import datetime
from pathlib import Path
class StateStore:
 def __init__(self,run_dir): self.path=Path(run_dir)/"state.jsonl"
 def event(self,row,status,**extra):
  data={"ts":datetime.now().isoformat(timespec="seconds"),"row":row,"status":status,**extra}
  with self.path.open("a",encoding="utf-8") as f: f.write(json.dumps(data,ensure_ascii=False)+"\n"); f.flush(); os.fsync(f.fileno())
 def latest(self):
  out={}
  if self.path.exists():
   for line in self.path.read_text(encoding="utf-8").splitlines():
    try: d=json.loads(line); out[d["row"]]=d
    except Exception: pass
  return out
