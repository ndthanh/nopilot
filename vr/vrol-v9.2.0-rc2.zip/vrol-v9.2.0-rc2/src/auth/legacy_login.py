import argparse
import html
import json
import logging
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pythoncom
import win32com.client

from openpyxl import load_workbook
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError
from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from src.browser_window import maximize_page_window

CONSOLE = Console()
SENSITIVE_KEYS = {"password", "answer", "security_answer"}


def as_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def normalize_question(value):
    value = re.sub(r"\s+", " ", str(value or "")).strip().lower()
    return re.sub(r"[\s?.!]+$", "", value)


def load_config(path):
    wb = load_workbook(path, data_only=True, read_only=True)
    settings = {}
    for key, value, _description in wb["Settings"].iter_rows(min_row=2, values_only=True):
        if key:
            settings[str(key).strip()] = value

    answers = {}
    for question, answer, enabled, _notes in wb["SecurityQuestions"].iter_rows(min_row=2, values_only=True):
        if question and answer and as_bool(enabled):
            answers[normalize_question(question)] = str(answer)

    required = ["login_url", "username", "password", "welcome_name"]
    missing = [
        key for key in required
        if not str(settings.get(key, "")).strip()
        or str(settings.get(key)).strip() == "CHANGE_ME"
    ]
    if missing:
        raise ValueError("Missing/placeholder settings: " + ", ".join(missing))
    return settings, answers


def level_from_name(value, default):
    return getattr(logging, str(value or default).strip().upper(), getattr(logging, default))


def setup_logging(base, settings):
    now = datetime.now()
    run_dir = base / "logs" / now.strftime("%Y%m%d") / f"run_{now.strftime('%H%M%S')}"
    run_dir.mkdir(parents=True, exist_ok=False)

    logger = logging.getLogger("vrol")
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    file_handler = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    file_handler.setLevel(level_from_name(settings.get("detail_log_level"), "DEBUG"))
    file_handler.setFormatter(logging.Formatter(
        "%(asctime)s.%(msecs)03d | %(levelname)-8s | %(name)s | %(funcName)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(file_handler)

    if as_bool(settings.get("rich_console", True)):
        console_handler = RichHandler(
            console=CONSOLE,
            show_time=True,
            show_level=True,
            show_path=False,
            rich_tracebacks=True,
            tracebacks_show_locals=False,
            markup=True,
        )
    else:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
    console_handler.setLevel(level_from_name(settings.get("console_log_level"), "INFO"))
    logger.addHandler(console_handler)
    return logger, run_dir


def show_run_summary(settings, run_dir):
    table = Table(title="Visa VROL Login Run", show_header=False, border_style="cyan")
    table.add_column("Setting", style="bold cyan")
    table.add_column("Value")
    table.add_row("URL", str(settings["login_url"]))
    table.add_row("Username", str(settings["username"]))
    table.add_row("Chrome channel", str(settings.get("browser_channel", "chrome")))
    table.add_row("Persistent profile", str(settings.get("user_data_dir", "browser_profile")))
    table.add_row("Trust device", str(as_bool(settings.get("trust_device_90_days", True))))
    table.add_row("Run folder", str(run_dir))
    CONSOLE.print(table)


def save_screenshot(page, run_dir, name, logger, settings):
    if not as_bool(settings.get("screenshots_enabled", False)):
        return
    path = run_dir / f"{name}.png"
    try:
        page.screenshot(path=str(path), full_page=True)
        logger.debug("Screenshot saved: %s", path)
    except Exception as exc:
        logger.warning("Could not save screenshot %s: %s", name, exc)


def retry_step(state, description, attempts, logger, action):
    for attempt in range(1, attempts + 1):
        logger.info("[bold cyan]STEP[/] %-30s | %s | attempt %s/%s", state, description, attempt, attempts)
        started = time.monotonic()
        try:
            result = action()
            logger.info("[green]PASS[/] %-30s | %.2fs", state, time.monotonic() - started)
            return result
        except Exception as exc:
            logger.warning("[yellow]RETRY[/] %s | %s", state, exc)
            logger.debug("Step exception", exc_info=True)
            if attempt == attempts:
                raise
            time.sleep(min(2 * attempt, 5))


def normalize_email(value):
    return str(value or "").strip().lower()


def get_outlook_sender_email(message):
    smtp_property = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E"
    try:
        if getattr(message, "SenderEmailType", "") == "EX":
            sender = message.Sender
            if sender:
                exchange_user = sender.GetExchangeUser()
                if exchange_user and exchange_user.PrimarySmtpAddress:
                    return normalize_email(exchange_user.PrimarySmtpAddress)
                exchange_dl = sender.GetExchangeDistributionList()
                if exchange_dl and exchange_dl.PrimarySmtpAddress:
                    return normalize_email(exchange_dl.PrimarySmtpAddress)
            return normalize_email(message.PropertyAccessor.GetProperty(smtp_property))
        return normalize_email(message.SenderEmailAddress)
    except Exception:
        try:
            return normalize_email(message.SenderEmailAddress)
        except Exception:
            return ""


def extract_email_otp(html_body, text_body, min_digits, max_digits):
    html_content = html.unescape(html_body or "")
    html_content = re.sub(
        r"<(style|script)\b[^>]*>.*?</\1>", " ", html_content,
        flags=re.IGNORECASE | re.DOTALL,
    )
    html_content = re.sub(
        r"</?(?:br|p|div|tr|td|li|h1|h2|h3)\b[^>]*>", " ", html_content,
        flags=re.IGNORECASE,
    )
    html_text = re.sub(r"<[^>]+>", " ", html_content)
    searchable = re.sub(r"\s+", " ", f"{html_text} {text_body or ''}").strip()
    pattern = re.compile(
        r"one[\s\-–—]*time\s+password\s*\(\s*OTP\s*\)\s*is\s*:\s*"
        r"(\d{%d,%d})" % (min_digits, max_digits),
        flags=re.IGNORECASE,
    )
    match = pattern.search(searchable)
    return match.group(1) if match else None


def outlook_time_to_local_naive(value):
    """Normalize pywin32 Outlook ReceivedTime to a local naive datetime."""
    if value is None:
        return None
    if getattr(value, "tzinfo", None) is not None:
        return value.astimezone().replace(tzinfo=None)
    return value


def get_matching_otp_message_ids(settings, logger):
    """Snapshot matching OTP messages that already exist before Send OTP."""
    expected_sender = normalize_email(settings.get("otp_sender_email"))
    subject_keyword = str(settings.get("otp_subject_keyword", "")).strip().lower()
    max_items = int(settings.get("otp_max_emails_to_check", 100))
    outlook = win32com.client.Dispatch("Outlook.Application")
    messages = outlook.GetNamespace("MAPI").GetDefaultFolder(6).Items
    messages.Sort("[ReceivedTime]", True)
    existing_ids = set()
    inspected = 0
    for message in messages:
        if inspected >= max_items:
            break
        inspected += 1
        try:
            if getattr(message, "Class", None) != 43:
                continue
            subject = getattr(message, "Subject", "") or ""
            sender = get_outlook_sender_email(message)
            if subject_keyword in subject.lower() and sender == expected_sender:
                entry_id = str(getattr(message, "EntryID", "") or "")
                if entry_id:
                    existing_ids.add(entry_id)
        except Exception:
            logger.debug("Could not snapshot one Outlook item", exc_info=True)
    logger.info("OTP mailbox baseline captured | existing matching messages=%s", len(existing_ids))
    return existing_ids


def find_new_outlook_otp(settings, requested_after, baseline_ids, logger):
    """Return OTP only from a new Outlook item created after Send OTP."""
    expected_sender = normalize_email(settings.get("otp_sender_email"))
    subject_keyword = str(settings.get("otp_subject_keyword", "")).strip().lower()
    max_items = int(settings.get("otp_max_emails_to_check", 100))
    min_digits = int(settings.get("otp_min_digits", 8))
    max_digits = int(settings.get("otp_max_digits", 8))
    tolerance = max(0, int(settings.get("otp_received_time_tolerance_seconds", 2)))
    threshold = requested_after - timedelta(seconds=tolerance)

    outlook = win32com.client.Dispatch("Outlook.Application")
    messages = outlook.GetNamespace("MAPI").GetDefaultFolder(6).Items
    messages.Sort("[ReceivedTime]", True)

    inspected = 0
    for message in messages:
        if inspected >= max_items:
            break
        inspected += 1
        try:
            if getattr(message, "Class", None) != 43:
                continue
            received_time = outlook_time_to_local_naive(getattr(message, "ReceivedTime", None))
            if received_time is None:
                continue
            if received_time < threshold:
                break

            subject = getattr(message, "Subject", "") or ""
            sender = get_outlook_sender_email(message)
            if subject_keyword not in subject.lower() or sender != expected_sender:
                continue

            entry_id = str(getattr(message, "EntryID", "") or "")
            if not entry_id:
                logger.debug("Ignoring OTP candidate without Outlook EntryID")
                continue
            if entry_id in baseline_ids:
                logger.debug(
                    "Ignoring pre-existing OTP email | entry_id_suffix=%s | received=%s",
                    entry_id[-8:], received_time.isoformat(timespec="seconds"),
                )
                continue

            otp = extract_email_otp(
                getattr(message, "HTMLBody", "") or "",
                getattr(message, "Body", "") or "",
                min_digits,
                max_digits,
            )
            if otp:
                logger.info(
                    "New OTP email accepted | received=%s | entry_id_suffix=%s | sender=%s | subject=%s",
                    received_time.isoformat(timespec="seconds"),
                    entry_id[-8:], sender, subject,
                )
                return otp
        except Exception:
            logger.debug("Could not inspect one Outlook item", exc_info=True)
    return None


def capture_outlook_otp_baseline(settings, logger):
    pythoncom.CoInitialize()
    try:
        return get_matching_otp_message_ids(settings, logger)
    finally:
        pythoncom.CoUninitialize()


def wait_for_new_outlook_otp(settings, requested_after, baseline_ids, logger):
    timeout = max(1, int(settings.get("otp_timeout_seconds", 90)))
    interval = max(1, int(settings.get("otp_poll_interval_seconds", 3)))
    deadline = time.monotonic() + timeout
    poll_number = 0
    logger.info(
        "Starting Outlook polling after Send OTP | boundary=%s | baseline_count=%s",
        requested_after.isoformat(timespec="milliseconds"),
        len(baseline_ids),
    )
    pythoncom.CoInitialize()
    try:
        while time.monotonic() < deadline:
            poll_number += 1
            logger.info("Outlook OTP poll #%s", poll_number)
            otp = find_new_outlook_otp(settings, requested_after, baseline_ids, logger)
            if otp:
                logger.info("Fresh OTP retrieved after %s Outlook poll(s)", poll_number)
                return otp
            remaining = max(0, int(deadline - time.monotonic()))
            logger.info(
                "No new OTP email yet | next poll in %ss | remaining timeout=%ss",
                interval, remaining,
            )
            time.sleep(min(interval, max(0, deadline - time.monotonic())))
    finally:
        pythoncom.CoUninitialize()
    raise TimeoutError(
        f"No new matching OTP email arrived after Send OTP within {timeout} seconds"
    )



OTP_POLLING_MODE_OUTLOOK = "OUTLOOK"
OTP_POLLING_MODE_FOLDER_FILENAME = "FOLDER_FILENAME"

def get_otp_polling_mode(settings):
    raw = str(settings.get("otp_polling_mode", OTP_POLLING_MODE_OUTLOOK) or OTP_POLLING_MODE_OUTLOOK)
    mode = raw.strip().upper()
    aliases = {
        "OUTLOOK_DESKTOP": OTP_POLLING_MODE_OUTLOOK,
        "DIRECT": OTP_POLLING_MODE_OUTLOOK,
        "FOLDER": OTP_POLLING_MODE_FOLDER_FILENAME,
        "FILE": OTP_POLLING_MODE_FOLDER_FILENAME,
        "FILE_NAME": OTP_POLLING_MODE_FOLDER_FILENAME,
    }
    mode = aliases.get(mode, mode)
    if mode not in {OTP_POLLING_MODE_OUTLOOK, OTP_POLLING_MODE_FOLDER_FILENAME}:
        raise ValueError("OTP_POLLING_MODE_INVALID:" + mode)
    return mode

def _otp_folder(settings):
    raw = str(settings.get("otp_folder_path", "") or "").strip()
    if not raw:
        raise ValueError("OTP_FOLDER_PATH_MISSING")
    folder = Path(raw)
    if not folder.exists():
        raise FileNotFoundError("OTP_FOLDER_NOT_FOUND:" + str(folder))
    if not folder.is_dir():
        raise NotADirectoryError("OTP_FOLDER_NOT_DIRECTORY:" + str(folder))
    return folder

def _folder_file_signatures(folder, pattern):
    signatures = set()
    for path in folder.glob(pattern):
        try:
            if path.is_file():
                stat = path.stat()
                signatures.add((path.name.casefold(), stat.st_mtime_ns, stat.st_size))
        except OSError:
            continue
    return signatures

def capture_folder_otp_baseline(settings, logger):
    folder = _otp_folder(settings)
    pattern = str(settings.get("otp_folder_file_pattern", "*.txt") or "*.txt").strip()
    signatures = _folder_file_signatures(folder, pattern)
    logger.info("OTP folder baseline captured | folder=%s | pattern=%s | files=%s", folder, pattern, len(signatures))
    return signatures

def extract_otp_from_filename(filename, min_digits, max_digits):
    """Extract OTP from the final numeric filename segment.

    OTP bridge files use names such as YYYYMMDD_HHMMSS_OTP.txt. The older
    implementation rejected these because both YYYYMMDD and OTP are 8 digits.
    The contract is now explicit: prefer the last underscore/hyphen-delimited
    numeric segment, then fall back to a single unambiguous numeric match.
    """
    stem = Path(str(filename or "")).stem
    suffix = re.search(r"(?:^|[_-])(\d{%d,%d})$" % (min_digits, max_digits), stem)
    if suffix:
        return suffix.group(1)
    matches = re.findall(r"(?<!\d)(\d{%d,%d})(?!\d)" % (min_digits, max_digits), stem)
    unique = list(dict.fromkeys(matches))
    return unique[0] if len(unique) == 1 else None

def extract_otp_from_file_content(path, min_digits, max_digits):
    """Fallback for bridges that place the OTP in the txt body instead of its name."""
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            text = path.read_text(encoding=encoding, errors="strict")
            break
        except (UnicodeDecodeError, OSError):
            text = None
    if text is None:
        return None
    labelled = re.search(r"(?:OTP|one[- ]time password)[^0-9]{0,40}(\d{%d,%d})" % (min_digits, max_digits), text, re.I)
    if labelled:
        return labelled.group(1)
    matches = re.findall(r"(?<!\d)(\d{%d,%d})(?!\d)" % (min_digits, max_digits), text)
    unique = list(dict.fromkeys(matches))
    return unique[0] if len(unique) == 1 else None

def find_new_folder_filename_otp(settings, requested_after, baseline_signatures, logger):
    folder = _otp_folder(settings)
    pattern = str(settings.get("otp_folder_file_pattern", "*.txt") or "*.txt").strip()
    min_digits = int(settings.get("otp_min_digits", 8))
    max_digits = int(settings.get("otp_max_digits", 8))
    tolerance = max(0, int(settings.get("otp_received_time_tolerance_seconds", 2)))
    threshold = requested_after.timestamp() - tolerance
    candidates = []
    for path in folder.glob(pattern):
        try:
            if not path.is_file():
                continue
            stat = path.stat()
            signature = (path.name.casefold(), stat.st_mtime_ns, stat.st_size)
            if signature in baseline_signatures or stat.st_mtime < threshold:
                continue
            otp = extract_otp_from_filename(path.name, min_digits, max_digits)
            source = "filename"
            if not otp:
                otp = extract_otp_from_file_content(path, min_digits, max_digits)
                source = "file_content"
            if otp:
                candidates.append((stat.st_mtime_ns, path.name, otp, source))
            else:
                logger.info("OTP folder candidate ignored | file=%s | reason=no_unambiguous_%s_digit_otp", path.name, min_digits)
        except OSError:
            logger.debug("Could not inspect one OTP folder file", exc_info=True)
    if not candidates:
        return None
    candidates.sort(reverse=True)
    newest_time = candidates[0][0]
    newest = [item for item in candidates if item[0] == newest_time]
    if len(newest) != 1:
        logger.warning("Multiple newest OTP filename candidates have the same timestamp; waiting for an unambiguous file")
        return None
    logger.info("New OTP file accepted | file=%s | source=%s | folder=%s", newest[0][1], newest[0][3], folder)
    return newest[0][2]

def wait_for_new_folder_filename_otp(settings, requested_after, baseline_signatures, logger):
    timeout = max(1, int(settings.get("otp_timeout_seconds", 90)))
    interval = max(1, int(settings.get("otp_poll_interval_seconds", 3)))
    deadline = time.monotonic() + timeout
    poll_number = 0
    logger.info("Starting OTP folder polling after Send OTP | folder=%s", _otp_folder(settings))
    while time.monotonic() < deadline:
        poll_number += 1
        logger.info("OTP folder poll #%s", poll_number)
        otp = find_new_folder_filename_otp(settings, requested_after, baseline_signatures, logger)
        if otp:
            logger.info("Fresh OTP retrieved from filename after %s folder poll(s)", poll_number)
            return otp
        time.sleep(min(interval, max(0, deadline - time.monotonic())))
    raise TimeoutError(f"No new OTP filename appeared within {timeout} seconds")

def capture_otp_baseline(settings, logger):
    mode = get_otp_polling_mode(settings)
    logger.info("OTP polling provider selected | mode=%s", mode)
    if mode == OTP_POLLING_MODE_FOLDER_FILENAME:
        return capture_folder_otp_baseline(settings, logger)
    return capture_outlook_otp_baseline(settings, logger)

def wait_for_new_otp(settings, requested_after, baseline, logger):
    mode = get_otp_polling_mode(settings)
    if mode == OTP_POLLING_MODE_FOLDER_FILENAME:
        return wait_for_new_folder_filename_otp(settings, requested_after, baseline, logger)
    return wait_for_new_outlook_otp(settings, requested_after, baseline, logger)

def find_visible_locator_in_page_or_frames(page, selector, text_pattern=None):
    """Return the first visible locator found in the page or any attached frame."""
    for frame in page.frames:
        try:
            locator = frame.locator(selector)
            if text_pattern is not None:
                locator = locator.filter(has_text=text_pattern)
            count = locator.count()
            for index in range(count):
                candidate = locator.nth(index)
                if candidate.is_visible():
                    return candidate, frame
        except Exception:
            continue
    return None, None


def wait_for_vrol_landing(page, settings, logger):
    """Detect successful VROL login by landing URL or authenticated identity."""
    timeout_ms = int(settings.get("vrol_auth_result_timeout_ms", 60000))
    poll_ms = max(100, int(settings.get("vrol_success_poll_interval_ms", 500)))
    expected_email = str(settings.get("vrol_logged_on_email", "")).strip()
    expected_name = str(settings.get("vrol_welcome_name", settings.get("welcome_name", ""))).strip()
    bulletin_text = str(settings.get("vrol_success_bulletin_text", "VROL Bulletin")).strip()
    expected_url_fragment = str(
        settings.get(
            "vrol_success_url_fragment",
            "www.vrol.visaonline.com/rolol/AdminDispatcher",
        )
    ).strip().lower()
    expected_action_fragment = str(
        settings.get("vrol_success_action_fragment", "action=RouteToLandingPage")
    ).strip().lower()
    deadline = time.monotonic() + timeout_ms / 1000
    poll_number = 0

    logger.info(
        "Waiting for VROL success | url_fragment=%s | action_fragment=%s | logged_on_email=%s",
        expected_url_fragment,
        expected_action_fragment,
        expected_email or "<not configured>",
    )
    while time.monotonic() < deadline:
        poll_number += 1
        current_url = page.url or ""
        normalized_url = current_url.lower()

        # Primary marker: the browser reached the authenticated VROL landing route.
        # Query-string parameter order is irrelevant because both fragments are
        # checked independently.
        if (
            expected_url_fragment
            and expected_url_fragment in normalized_url
            and expected_action_fragment in normalized_url
        ):
            logger.info(
                "[bold green]VROL LOGIN SUCCESS[/] | marker=VROL_LANDING_URL | url=%s",
                current_url,
            )
            return {
                "identity": expected_email or "URL-confirmed VROL session",
                "marker": "VROL_LANDING_URL",
                "frame_url": current_url,
            }

        # Secondary marker: authenticated user identity. This is intentionally
        # sufficient by itself because it is only rendered after VROL login.
        logged_on, logged_frame = find_visible_locator_in_page_or_frames(
            page,
            "span.supportText",
            re.compile(r"Currently\s+logged\s+on\s+as:", re.IGNORECASE),
        )
        if logged_on:
            logged_text = re.sub(r"\s+", " ", logged_on.inner_text()).strip()
            if not expected_email or expected_email.lower() in logged_text.lower():
                logger.info(
                    "[bold green]VROL LOGIN SUCCESS[/] | marker=VROL_LOGGED_ON_IDENTITY | %s | frame=%s",
                    logged_text,
                    logged_frame.url if logged_frame else current_url,
                )
                return {
                    "identity": logged_text,
                    "marker": "VROL_LOGGED_ON_IDENTITY",
                    "frame_url": logged_frame.url if logged_frame else current_url,
                }
            logger.warning(
                "VROL identity marker found but account differs from config | actual=%s | expected=%s",
                logged_text,
                expected_email,
            )

        # Tertiary shell signature, useful when identity text is delayed.
        inquiry, _ = find_visible_locator_in_page_or_frames(page, "#inquirymenua")
        quick_search, shell_frame = find_visible_locator_in_page_or_frames(page, "#searchField")
        if inquiry and quick_search:
            logger.info(
                "[bold green]VROL LOGIN SUCCESS[/] | marker=VROL_NAVIGATION_SHELL | Inquiry and Quick Search visible | frame=%s",
                shell_frame.url if shell_frame else current_url,
            )
            return {
                "identity": expected_email or "Authenticated VROL navigation shell",
                "marker": "VROL_NAVIGATION_SHELL",
                "frame_url": shell_frame.url if shell_frame else current_url,
            }

        # Legacy bulletin remains a final fallback.
        bulletin, bulletin_frame = find_visible_locator_in_page_or_frames(
            page,
            "td.title",
            re.compile(re.escape(bulletin_text), re.IGNORECASE),
        )
        if bulletin:
            welcome_pattern = re.compile(
                rf"^\s*Welcome,\s*{re.escape(expected_name)}\s*$",
                re.IGNORECASE,
            )
            welcome, _ = find_visible_locator_in_page_or_frames(page, "td.title", welcome_pattern)
            if welcome:
                welcome_text = re.sub(r"\s+", " ", welcome.inner_text()).strip()
                logger.info(
                    "[bold green]VROL LOGIN SUCCESS[/] | marker=VROL_BULLETIN | %s | frame=%s",
                    welcome_text,
                    bulletin_frame.url if bulletin_frame else current_url,
                )
                return {
                    "identity": welcome_text,
                    "marker": "VROL_BULLETIN",
                    "frame_url": bulletin_frame.url if bulletin_frame else current_url,
                }

        if poll_number == 1 or poll_number % 10 == 0:
            logger.info(
                "VROL landing poll #%s | frames=%s | url=%s",
                poll_number,
                len(page.frames),
                current_url,
            )
        page.wait_for_timeout(poll_ms)

    frame_urls = [frame.url for frame in page.frames]
    raise PlaywrightTimeoutError(
        "VROL authentication completed but no URL, identity, navigation, or bulletin success marker was detected. "
        f"Final URL: {page.url}; frame URLs: {frame_urls}"
    )


def wait_for_vrol_entry_outcome(page, settings, logger):
    """Wait for either an MFA screen or a directly authenticated VROL landing page."""
    timeout=int(settings.get('vrol_entry_outcome_timeout_ms',30000))
    poll=int(settings.get('vrol_entry_outcome_poll_ms',250))
    expected_url=str(settings.get('vrol_success_url_fragment','www.vrol.visaonline.com/rolol/AdminDispatcher')).lower()
    expected_action=str(settings.get('vrol_success_action_fragment','action=RouteToLandingPage')).lower()
    deadline=time.monotonic()+timeout/1000
    while time.monotonic()<deadline:
        url=str(page.url or '')
        lower=url.lower()
        if expected_url in lower and expected_action in lower:
            logger.info('VROL ENTRY OUTCOME | ALREADY_AUTHENTICATED | url=%s',url)
            return 'ALREADY_AUTHENTICATED'
        try:
            heading=page.get_by_role('heading',name=re.compile(r'Multi-Factor Authentication \(MFA\)',re.I))
            if heading.count() and heading.first.is_visible():
                logger.info('VROL ENTRY OUTCOME | MFA_REQUIRED | url=%s',url)
                return 'MFA_REQUIRED'
        except Exception:
            pass
        page.wait_for_timeout(poll)
    raise PlaywrightTimeoutError(f'VROL entry did not reach MFA or authenticated landing within {timeout}ms; url={page.url}')


def open_vrol_and_complete_mfa(portal_page, context, settings, retries, logger):
    """Open Visa Resolve Online in a new tab and complete email OTP MFA."""
    service_link = portal_page.get_by_role("link", name="Visa Resolve Online", exact=True)
    retry_step(
        "OPEN_VROL_SERVICE",
        "Open Visa Resolve Online from My Services",
        retries,
        logger,
        lambda: service_link.wait_for(state="visible"),
    )
    logger.info("Waiting for the Visa Resolve Online tab")
    with portal_page.expect_popup(timeout=int(settings.get("vrol_popup_timeout_ms", 30000))) as popup_info:
        service_link.click()
    vrol_page = popup_info.value
    vrol_page.wait_for_load_state("domcontentloaded")
    if as_bool(settings.get("maximize_vrol_popup", True)):
        maximize_page_window(vrol_page, logger, int(settings.get("vrol_window_maximize_wait_ms", 500)))
    logger.info("VROL tab opened | url=%s", vrol_page.url)

    entry_outcome = wait_for_vrol_entry_outcome(vrol_page, settings, logger)
    if entry_outcome == "ALREADY_AUTHENTICATED":
        landing_result = wait_for_vrol_landing(vrol_page, settings, logger)
        logger.info(
            "VROL MFA SKIPPED | existing authenticated session | marker=%s | identity=%s | frame_url=%s",
            landing_result["marker"], landing_result["identity"], landing_result["frame_url"],
        )
        return vrol_page

    logger.info("VROL MFA is required; continuing with Email OTP flow")
    retry_step(
        "SELECT_EMAIL_MFA",
        "Select Email as the OTP delivery method",
        retries,
        logger,
        lambda: vrol_page.locator("#Email").check(),
    )
    retry_step(
        "SUBMIT_MFA_METHOD",
        "Submit the Email MFA method",
        retries,
        logger,
        lambda: vrol_page.locator("button[name='btnSubmit']").click(),
    )

    send_otp = vrol_page.locator("button[name='btnOTP']")
    send_otp.wait_for(state="visible")

    # Snapshot all matching messages before requesting a new OTP. A candidate
    # must have a new Outlook EntryID and a ReceivedTime after this request.
    otp_mode = get_otp_polling_mode(settings)
    logger.info("Capturing OTP provider baseline before clicking Send OTP | mode=%s", otp_mode)
    otp_baseline_ids = capture_otp_baseline(settings, logger)
    otp_requested_at = datetime.now()
    retry_step(
        "SEND_VROL_OTP",
        "Request the One-Time Password by email",
        retries,
        logger,
        send_otp.click,
    )

    source_message = vrol_page.get_by_text(
        "One-Time Password successfully sent.",
        exact=True,
    )
    retry_step(
        "VERIFY_OTP_SENT",
        "Verify that Visa confirms the OTP email was sent",
        retries,
        logger,
        lambda: source_message.wait_for(
            state="visible",
            timeout=int(settings.get("otp_sent_confirmation_timeout_ms", 20000)),
        ),
    )

    # Do not touch the OTP input until Visa confirms sending and Outlook polling
    # returns a genuinely new email created after the request.
    logger.info("OTP send confirmation detected; starting Outlook polling before entering any OTP value")
    otp = wait_for_new_otp(
        settings,
        otp_requested_at,
        otp_baseline_ids,
        logger,
    )
    logger.info("Fresh OTP is available; proceeding to the One-Time Password field")
    otp_input = vrol_page.locator("input[name='oneTimePassword']")
    retry_step(
        "ENTER_VROL_OTP",
        "Enter the OTP received by email",
        retries,
        logger,
        lambda: (otp_input.wait_for(state="visible"), otp_input.fill(otp)),
    )
    otp_submit = vrol_page.locator("form button[name='btnSubmit']")
    retry_step(
        "SUBMIT_VROL_OTP",
        "Submit the VROL One-Time Password",
        retries,
        logger,
        lambda: (otp_submit.wait_for(state="visible"), otp_submit.click()),
    )

    landing_result = wait_for_vrol_landing(vrol_page, settings, logger)
    logger.info(
        "VROL authenticated landing detected | marker=%s | identity=%s | frame_url=%s",
        landing_result["marker"],
        landing_result["identity"],
        landing_result["frame_url"],
    )
    return vrol_page


def logout_after_success(page, timeout_ms, retries, logger):
    """Open the Visa user menu, verify Log Off is visible, click it, and verify logout."""
    page.bring_to_front()
    profile_button = page.locator("#vol-user-controls-drop")
    login_username = page.locator("#external-login-username")

    # Use several locators because the legacy/Angular menu can expose the item
    # as a menuitem, a button, or a span nested inside a button.
    logoff_candidates = [
        page.get_by_role("menuitem", name="Log Off", exact=True),
        page.get_by_role("button", name="Log Off", exact=True),
        page.locator("button.udp-item", has_text=re.compile(r"^\s*Log Off\s*$", re.I)),
        page.locator("button:has(span.udp-item-label:text-is('Log Off'))"),
    ]

    def first_visible_logoff():
        for locator in logoff_candidates:
            try:
                if locator.count() > 0 and locator.first.is_visible():
                    return locator.first
            except Exception:
                continue
        return None

    def open_profile_menu():
        profile_button.wait_for(state="visible", timeout=timeout_ms)
        profile_button.scroll_into_view_if_needed()
        profile_button.click()
        deadline = time.monotonic() + timeout_ms / 1000
        while time.monotonic() < deadline:
            candidate = first_visible_logoff()
            expanded = profile_button.get_attribute("aria-expanded")
            if candidate is not None:
                logger.info("Profile menu opened | aria-expanded=%s | Log Off is visible", expanded)
                return candidate
            page.wait_for_timeout(200)
        raise PlaywrightTimeoutError(
            "Profile button was clicked but the Log Off menu item did not become visible"
        )

    logoff_button = retry_step(
        "OPEN_PROFILE_MENU",
        "Click profile menu and wait until Log Off becomes visible",
        retries,
        logger,
        open_profile_menu,
    )

    retry_step(
        "CLICK_LOG_OFF",
        "Click the visible Log Off menu item",
        retries,
        logger,
        lambda: logoff_button.click(),
    )
    retry_step(
        "VERIFY_LOGOUT",
        "Verify return to the Visa login page",
        retries,
        logger,
        lambda: login_username.wait_for(state="visible", timeout=timeout_ms),
    )
    logger.info("[bold green]LOGOUT SUCCESS[/] | Returned to the Visa login page")


def start_trace(context, run_dir, settings):
    if not as_bool(settings.get("trace_enabled", False)):
        return None
    context.tracing.start(
        screenshots=as_bool(settings.get("screenshots_enabled", False)),
        snapshots=True, sources=True,
    )
    return run_dir / "trace.zip"


def stop_trace_safely(context, trace_path, logger):
    """Stop and export tracing while the browser context is still alive."""
    if trace_path is None:
        return True
    try:
        context.tracing.stop(path=str(trace_path))
        logger.info("Playwright trace saved: %s", trace_path)
        return True
    except Exception as exc:
        logger.warning("Could not save Playwright trace before context close: %s", exc)
        logger.debug("Trace export exception", exc_info=True)
        return False


def wait_for_post_login_trigger(settings, logger):
    """Pause after successful VROL login until the operator presses the configured key."""
    if not as_bool(settings.get("post_login_manual_trigger_enabled", True)):
        logger.info("Post-login manual trigger is disabled; continuing automatically")
        return
    trigger = str(settings.get("post_login_trigger_key", "ENTER") or "ENTER").strip().upper()
    logger.info("VROL login is complete. Automation is PAUSED before the post-login workflow.")
    logger.info("Inspect the browser now. Trigger key: %s", trigger)
    if trigger in {"ENTER", "RETURN", ""}:
        input("VROL login succeeded. Press ENTER to continue with Inquiry > Transaction Inquiry... ")
        logger.info("POST-LOGIN TRIGGER RECEIVED | ENTER")
        return
    while True:
        typed = input(f"VROL login succeeded. Type {trigger} then press ENTER to continue: ").strip().upper()
        if typed == trigger:
            logger.info("POST-LOGIN TRIGGER RECEIVED | %s", trigger)
            return
        logger.warning("Wrong trigger. Expected %s, received %s", trigger, typed or "<empty>")


def report_trace_path(trace_path, trace_saved, run_dir, logger):
    """Print the exact absolute trace path at the end of every run."""
    if trace_path is None:
        message = "Playwright trace: DISABLED (trace_enabled=NO)"
        logger.info(message)
        CONSOLE.print(Panel.fit(Text(message, style="bold yellow"), title="TRACE", border_style="yellow"))
        (run_dir / "trace_path.txt").write_text(message + "\n", encoding="utf-8")
        return
    absolute = Path(trace_path).resolve()
    if trace_saved and absolute.exists():
        message = f"Playwright trace file: {absolute}"
        logger.info(message)
        CONSOLE.print(Panel.fit(Text(str(absolute), style="bold cyan"), title="TRACE FILE", border_style="cyan"))
    else:
        message = f"Playwright trace was NOT saved. Expected path: {absolute}"
        logger.warning(message)
        CONSOLE.print(Panel.fit(Text(message, style="bold red"), title="TRACE NOT SAVED", border_style="red"))
    (run_dir / "trace_path.txt").write_text(message + "\n", encoding="utf-8")


def wait_for_login_outcome(page, welcome, additional, max_session, timeout_ms, logger):
    logger.info("Waiting for Welcome, Additional Verification, or Max Session Reached")
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if welcome.is_visible():
            logger.info("[green]Detected successful Welcome page[/]")
            return "SUCCESS"
        if additional.is_visible():
            logger.info("[yellow]Detected Additional Verification Required[/]")
            return "ADDITIONAL_VERIFICATION"
        if max_session.is_visible():
            logger.info("[yellow]Detected Max Session Reached[/]")
            return "MAX_SESSION_REACHED"
        time.sleep(0.25)
    return "TIMEOUT"


def resolve_max_session(page, max_session, welcome, additional, timeout_ms, retries, logger):
    """Close the oldest Visa session and return the next observed login outcome."""
    source_state = "CONFIRM_MAX_SESSION_LOGOUT"
    yes_button = page.get_by_role("button", name="Yes", exact=True)
    retry_step(
        source_state,
        "Confirm logout of the oldest Visa session",
        retries,
        logger,
        lambda: (yes_button.wait_for(state="visible"), yes_button.click()),
    )
    logger.info("Oldest Visa session logout was confirmed")
    return wait_for_login_outcome(page, welcome, additional, max_session, timeout_ms, logger)


def run(config_path, after_login=None, settings_override=None):
    settings, answers = load_config(config_path)
    if settings_override:
        settings.update(settings_override)
    base = config_path.resolve().parent
    logger, run_dir = setup_logging(base, settings)
    show_run_summary(settings, run_dir)
    logger.info("Run started. Detailed log: %s", run_dir / "run.log")

    retries = int(settings.get("max_step_retries", 3))
    profile = base / str(settings.get("user_data_dir", "browser_profile"))
    profile.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        logger.info("Launching Google Chrome with persistent profile")
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            channel=str(settings.get("browser_channel", "chrome")),
            headless=as_bool(settings.get("headless", False)),
            slow_mo=int(settings.get("slow_mo_ms", 100)),
            no_viewport=True,
            args=["--start-maximized"],
        )
        context.set_default_timeout(int(settings.get("action_timeout_ms", 20000)))
        context.set_default_navigation_timeout(int(settings.get("navigation_timeout_ms", 60000)))
        trace_path = start_trace(context, run_dir, settings)
        trace_stopped = False
        page = context.pages[0] if context.pages else context.new_page()
        source_state = "INIT"
        try:
            source_state = "OPEN_LOGIN"
            retry_step(source_state, "Open Visa Online login page", retries, logger,
                       lambda: page.goto(str(settings["login_url"]), wait_until="domcontentloaded"))
            username = page.locator("#external-login-username")
            password_method = page.get_by_role("button", name="Password", exact=True)
            source_state = "VERIFY_LOGIN_PAGE"
            retry_step(source_state, "Verify username field and Password button", retries, logger,
                       lambda: (username.wait_for(state="visible"), password_method.wait_for(state="visible")))

            source_state = "ENTER_USERNAME"
            retry_step(source_state, "Enter configured username", retries, logger,
                       lambda: username.fill(str(settings["username"])))

            source_state = "SELECT_PASSWORD_METHOD"
            retry_step(source_state, "Select Password login method", retries, logger, password_method.click)

            source_state = "ENTER_PASSWORD"
            password = page.locator("#external-login-password")
            retry_step(source_state, "Wait for password field and enter password", retries, logger,
                       lambda: (password.wait_for(state="visible"), password.fill(str(settings["password"]))))

            source_state = "SUBMIT_CREDENTIALS"
            retry_step(source_state, "Submit username and password", retries, logger,
                       page.get_by_role("button", name="Continue", exact=True).click)

            welcome = page.locator("p.welcome-message").filter(has_text=re.compile(r"Welcome back,", re.I))
            additional = page.get_by_role("heading", name=re.compile(r"Additional Verification Required", re.I))
            max_session = page.get_by_role("heading", name=re.compile(r"Max Session Reached", re.I))
            outcome_timeout = int(settings.get("login_result_timeout_ms", 45000))
            source_state = "WAIT_LOGIN_OUTCOME"
            outcome = wait_for_login_outcome(
                page, welcome, additional, max_session, outcome_timeout, logger
            )

            # The Max Session notification can appear immediately after credentials.
            # Handle it before deciding whether security-question verification is needed.
            max_session_attempts = 0
            while outcome == "MAX_SESSION_REACHED":
                max_session_attempts += 1
                if max_session_attempts > 2:
                    raise RuntimeError("Max Session Reached appeared repeatedly after confirming Yes")
                source_state = "CONFIRM_MAX_SESSION_LOGOUT"
                outcome = resolve_max_session(
                    page, max_session, welcome, additional,
                    outcome_timeout, retries, logger
                )

            if outcome == "ADDITIONAL_VERIFICATION":
                source_state = "SELECT_SECURITY_QUESTION"
                retry_step(source_state, "Choose Security Question verification", retries, logger,
                           lambda: page.locator("#channel-KBA").check())

                source_state = "SUBMIT_VERIFICATION_CHANNEL"
                retry_step(source_state, "Submit selected verification channel", retries, logger,
                           page.get_by_role("button", name="Submit", exact=True).click)

                source_state = "READ_SECURITY_QUESTION"
                answer_field = page.locator("#answerField")
                answer_field.wait_for(state="visible")
                question_text = page.locator("label[for='default-input']").first.inner_text().strip()
                normalized = normalize_question(question_text)
                logger.info("Security question detected: [bold]%s[/]", question_text)
                if normalized not in answers:
                    raise RuntimeError(f"No enabled answer configured for security question: {question_text}")
                logger.info("Matching enabled answer found in config.xlsx")

                source_state = "ANSWER_SECURITY_QUESTION"
                retry_step(source_state, "Enter mapped security answer", retries, logger,
                           lambda: answer_field.fill(answers[normalized]))

                if as_bool(settings.get("trust_device_90_days", True)):
                    source_state = "TRUST_DEVICE"
                    checkbox = page.locator("#checkboxField")
                    if checkbox.is_visible():
                        retry_step(source_state, "Select Trust this device for 90 days", retries, logger, checkbox.check)
                    else:
                        logger.warning("Trust-device checkbox is not visible; continuing without it")

                source_state = "SUBMIT_SECURITY_ANSWER"
                retry_step(source_state, "Submit security-question answer", retries, logger,
                           page.locator("button[name='btnPrimary']").click)

                source_state = "WAIT_FINAL_OUTCOME"
                final_outcome = wait_for_login_outcome(
                    page, welcome, additional, max_session, outcome_timeout, logger
                )
                final_max_session_attempts = 0
                while final_outcome == "MAX_SESSION_REACHED":
                    final_max_session_attempts += 1
                    if final_max_session_attempts > 2:
                        raise RuntimeError("Max Session Reached appeared repeatedly after security verification")
                    source_state = "CONFIRM_MAX_SESSION_LOGOUT"
                    final_outcome = resolve_max_session(
                        page, max_session, welcome, additional,
                        outcome_timeout, retries, logger
                    )
                if final_outcome != "SUCCESS":
                    raise PlaywrightTimeoutError(
                        f"Expected Welcome after security verification, observed: {final_outcome}"
                    )
            elif outcome != "SUCCESS":
                raise PlaywrightTimeoutError("Neither Welcome nor Additional Verification appeared")

            source_state = "VERIFY_WELCOME_NAME"
            welcome_text = welcome.inner_text().strip()
            expected_name = str(settings["welcome_name"]).strip()
            if expected_name.lower() not in welcome_text.lower():
                raise RuntimeError(f"Welcome appeared but expected name '{expected_name}' was not found: {welcome_text}")

            logger.info("[bold green]LOGIN SUCCESS[/] | %s", welcome_text)
            if as_bool(settings.get("screenshot_on_success", True)):
                save_screenshot(page, run_dir, "login_success", logger, settings)

            vrol_status = "SKIPPED"
            vrol_page = None
            if as_bool(settings.get("open_vrol_after_login", True)):
                source_state = "OPEN_AND_AUTHENTICATE_VROL"
                vrol_page = open_vrol_and_complete_mfa(page, context, settings, retries, logger)
                vrol_status = "SUCCESS"
                save_screenshot(vrol_page, run_dir, "vrol_authenticated", logger, settings)
                if after_login is not None:
                    source_state = "WAIT_POST_LOGIN_TRIGGER"
                    wait_for_post_login_trigger(settings, logger)
                    logger.info("Handing authenticated VROL session to post-login workflow")
                    source_state = "POST_LOGIN_WORKFLOW"
                    after_login(page, vrol_page, context, settings, answers, logger, run_dir)
            else:
                logger.info("Opening VROL after login is disabled by config.xlsx")

            logout_status = "SKIPPED"
            if as_bool(settings.get("logout_after_login", True)):
                source_state = "LOGOUT_AFTER_LOGIN"
                try:
                    if vrol_page and not vrol_page.is_closed():
                        logger.info("Closing the VROL tab before logging off Visa Online")
                        vrol_page.close()
                    page.bring_to_front()
                    page.wait_for_timeout(500)
                    logout_after_success(
                        page,
                        int(settings.get("logout_timeout_ms", 20000)),
                        retries,
                        logger,
                    )
                    logout_status = "SUCCESS"
                    save_screenshot(page, run_dir, "logout_success", logger, settings)
                except Exception as logout_exc:
                    logout_status = "FAILED"
                    logger.exception("LOGOUT FAILED | %s", logout_exc)
                    save_screenshot(page, run_dir, "logout_failed", logger, settings)
                    if as_bool(settings.get("logout_failure_fails_test", True)):
                        raise RuntimeError(f"Login succeeded but logout failed: {logout_exc}") from logout_exc
                    logger.warning("Logout failure is configured as non-fatal; preserving successful login result")
            else:
                logger.info("Logout after login is disabled by config.xlsx")

            result_title = "LOGIN AND LOGOUT SUCCESS" if logout_status == "SUCCESS" else "LOGIN SUCCESS"
            result_text = f"{welcome_text}\nVROL MFA: {vrol_status}\nLogout: {logout_status}\nArtifacts: {run_dir}"
            CONSOLE.print(Panel.fit(
                Text(result_text, style="bold green"),
                title=result_title, border_style="green"
            ))
            print(json.dumps({
                "status": "SUCCESS",
                "welcome": welcome_text,
                "vrol_mfa": vrol_status,
                "logout": logout_status,
                "run_dir": str(run_dir),
            }, ensure_ascii=False))
            time.sleep(max(0, int(settings.get("keep_browser_open_seconds", 5))))
            trace_stopped = stop_trace_safely(context, trace_path, logger)
            return 0
        except Exception as exc:
            authenticated = source_state in {"POST_LOGIN_WORKFLOW", "LOGOUT_AFTER_LOGIN"}
            failure_title = "POST-LOGIN WORKFLOW FAILED" if authenticated else "LOGIN FAILED"
            logger.exception("%s | sourceState=%s | %s", failure_title, source_state, exc)
            save_screenshot(page, run_dir, "failed", logger, settings)
            CONSOLE.print(Panel.fit(
                Text(f"State: {source_state}\nError: {exc}\nArtifacts: {run_dir}", style="bold red"),
                title=failure_title, border_style="red"
            ))
            print(json.dumps({"status": "FAILED", "stage": "POST_LOGIN_WORKFLOW" if authenticated else "LOGIN", "sourceState": source_state, "error": str(exc), "run_dir": str(run_dir)}, ensure_ascii=False))
            trace_stopped = stop_trace_safely(context, trace_path, logger)
            return 1
        finally:
            if not trace_stopped:
                trace_stopped = stop_trace_safely(context, trace_path, logger)
            report_trace_path(trace_path, trace_stopped, run_dir, logger)
            try:
                context.close()
            except Exception as close_exc:
                logger.debug("Browser context was already closed: %s", close_exc)
            logger.info("Run finished | artifacts=%s", run_dir.resolve())


def main():
    parser = argparse.ArgumentParser(description="Visa Online / VROL login automation")
    parser.add_argument("--config", default="config.xlsx")
    args = parser.parse_args()
    return run(Path(args.config))


if __name__ == "__main__":
    raise SystemExit(main())
