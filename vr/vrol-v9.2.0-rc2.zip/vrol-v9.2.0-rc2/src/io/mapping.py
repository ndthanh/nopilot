from pathlib import Path

class MappingError(Exception):
    pass

def mask_pan(p):
    p=str(p or "")
    return p if len(p)<=10 else p[:6]+"*"*max(0,len(p)-10)+p[-4:]

def _decode_mapping_bytes(raw:bytes, preferred="utf-8-sig"):
    candidates=[]
    # BOM-aware priority. 0xFF 0xFE is UTF-16 LE; 0xFE 0xFF is UTF-16 BE.
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        candidates.extend(["utf-16","utf-16-le","utf-16-be"])
    elif raw.startswith(b"\xef\xbb\xbf"):
        candidates.append("utf-8-sig")
    if preferred:
        candidates.append(str(preferred))
    candidates.extend(["utf-8-sig","utf-16","utf-16-le","utf-16-be","cp1258","cp1252"])
    seen=set();errors=[]
    for enc in candidates:
        key=enc.lower()
        if key in seen: continue
        seen.add(key)
        try:
            text=raw.decode(enc)
            # Reject obviously wrong UTF-16 decoding that leaves NULs throughout the file.
            if text.count("\x00") > max(2,len(text)//20):
                raise UnicodeError("decoded text contains excessive NUL characters")
            return text,enc
        except (UnicodeError,LookupError) as exc:
            errors.append(f"{enc}:{exc}")
    raise MappingError("MAPPING_DECODE_FAILED:"+" | ".join(errors))

def load_mapping(path:Path,encoding="utf-8-sig"):
    if not path.exists(): raise MappingError(f"Mapping file not found: {path}")
    text,used_encoding=_decode_mapping_bytes(path.read_bytes(),encoding)
    mapping={};errors=[]
    for n,raw in enumerate(text.splitlines(),1):
        line=raw.strip().lstrip("\ufeff")
        if not line: continue
        parts=line.split("|")
        if len(parts)!=2: errors.append((n,"MAPPING_LINE_INVALID")); continue
        guid,pan=(x.strip() for x in parts)
        guid=guid.upper()
        if not guid: errors.append((n,"MAPPING_GUID_EMPTY")); continue
        if not pan or not pan.isdigit(): errors.append((n,"MAPPING_PAN_INVALID")); continue
        if guid in mapping and mapping[guid]!=pan: errors.append((n,"GUID_MULTIPLE_PAN")); continue
        mapping[guid]=pan
    return mapping,errors,used_encoding
