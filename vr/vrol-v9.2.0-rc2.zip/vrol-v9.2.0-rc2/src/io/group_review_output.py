from pathlib import Path
from shutil import copy2
from datetime import datetime
import json,time
from openpyxl import load_workbook
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
COLUMNS=['BOT GROUP GUID','BOT GROUP SIZE','BOT GROUP DECISION','BOT GROUP REASON CODE','BOT GROUP REASON DETAIL','BOT TRIGGER INVOICE','BOT TRIGGER TRAN TYPE','BOT TRIGGER ASSOC DISPUTE','BOT INVOICE SCAN STATUS','BOT TRAN TYPES FOUND','BOT SALE SELECTED','BOT PI INPUT','BOT PI STATUS','BOT PI FILE','BOT PI PATH','BOT SELECTED SALE COUNT','BOT ISSUER ACTION REQUIRED','BOT ISSUER ACTION CLICKED','BOT ISSUER ACTION PLANNED','BOT ISSUER ACTION EXECUTED','BOT VROL CASE','BOT FINAL SUBMIT CLICKED','BOT REVIEW ACTION','BOT REVIEW STATUS','BOT USER CONFIRMATION','BOT REVIEW NOTE','BOT LOGIC REVIEW REQUIRED','BOT RUN ID','BOT PROCESSED AT']
def create(source:Path,out_dir:Path,run_id:str):
    target=out_dir/f'{source.stem}_CASE_REVIEW_{run_id}.xlsx';copy2(source,target)
    wb=load_workbook(target);ws=wb['Sheet1'];headers={str(ws.cell(2,c).value or '').strip():c for c in range(1,ws.max_column+1)}
    for name in COLUMNS:
        if name not in headers:c=ws.max_column+1;ws.cell(2,c,name);headers[name]=c
    comments={'VROL':'Mã ROL Case: lấy từ ROL500.csv cột F hoặc ghi ngay khi VROL trả case number.','CB date':'Ngày bot thực hiện đẩy tra soát.','CB reject':'Lý do bot loại trừ ở cấp GUID hoặc lý do Visa reject.','CB result':'Chờ xác nhận nguồn báo cáo.','CB rep date':'Chờ xác nhận nguồn báo cáo.','BOT GROUP DECISION':'Quyết định cuối của bot ở cấp GUID.','BOT GROUP REASON DETAIL':'Diễn giải quyết định.','BOT PI PATH':'Đường dẫn PDF chứng từ PI.','BOT VROL CASE':'ROL Case bot đọc trực tiếp sau Case Creation.','BOT REVIEW STATUS':'Trạng thái review development.'}
    for name,text in comments.items():
        if name in headers:ws.cell(2,headers[name]).comment=Comment(text,'Microsoft Copilot')
    for c in range(42,ws.max_column+1):
        ws.column_dimensions[get_column_letter(c)].hidden=True;ws.column_dimensions[get_column_letter(c)].outlineLevel=1
    ws.freeze_panes='A4';ws.sheet_view.showGridLines=False
    wb.save(target);return target,headers
def update_group(path,headers,group,result,run_id):
    wb=load_workbook(path);ws=wb['Sheet1'];headers=_ensure_columns(ws);headers.update(_header_map(ws));by_row={x['row_no']:x for x in result.get('invoice_results',[])}
    reason=result.get('reason_code','');detail=result.get('reason_detail','')
    if reason and not detail and result.get('trigger_invoice'):detail=f"Không tiếp tục toàn bộ cụm GUID do Invoice {result.get('trigger_invoice','')} có Tran Type {result.get('trigger_tran_type','')}"
    for item in group['items']:
        inv=by_row.get(item['row_no'],{})
        values={'BOT REVIEW KEY':review_key(group['guid'],item.get('invoice',''),item.get('qt',''),item.get('code','')),'BOT GROUP GUID':group['guid'],'BOT GROUP SIZE':len(group['items']),'BOT GROUP DECISION':result.get('decision') or result.get('status'),
        'BOT GROUP REASON CODE':reason,'BOT GROUP REASON DETAIL':detail,'CB reject':result.get('cb_reject',''),'BOT TRIGGER INVOICE':result.get('trigger_invoice',''),'BOT TRIGGER TRAN TYPE':result.get('trigger_tran_type',''),'BOT TRIGGER ASSOC DISPUTE':result.get('trigger_assoc_dispute',''),
        'BOT INVOICE SCAN STATUS':inv.get('scan_status',''),'BOT TRAN TYPES FOUND':' | '.join(inv.get('tran_types',[])),'BOT SALE SELECTED':'YES' if inv.get('sale_selected') else 'NO','BOT PI INPUT':inv.get('pi_input',''),'BOT PI STATUS':inv.get('pi_status',''),'BOT PI FILE':inv.get('pi_file',''),'BOT PI PATH':inv.get('pi_path',''),
        'BOT SELECTED SALE COUNT':result.get('selected_count',result.get('selected_count_before_stop',0)),'BOT ISSUER ACTION REQUIRED':'YES' if result.get('issuer_action_required') else 'NO',
        'BOT ISSUER ACTION CLICKED':'YES' if result.get('issuer_action_clicked') else 'NO','BOT ISSUER ACTION PLANNED':result.get('planned_issuer_action',''),'BOT ISSUER ACTION EXECUTED':result.get('executed_issuer_action',''),'BOT VROL CASE':result.get('vrol_case_number',''),'VROL':result.get('vrol_case_number',''),'CB date':datetime.now().date() if result.get('vrol_case_number') else '','BOT FINAL SUBMIT CLICKED':'YES' if result.get('final_submit_clicked') else 'NO',
        'BOT REVIEW ACTION':result.get('review_action',''),'BOT REVIEW STATUS':('REVIEWED_CONFIRMED' if result.get('review_action')=='S' else ('REVIEWED' if result.get('review_action') in {'P','O','T'} else ('LOGIC_REVIEW_REQUIRED' if result.get('review_action')=='F' else ''))),
        'BOT LOGIC REVIEW REQUIRED':'YES' if result.get('review_action')=='F' else 'NO','BOT RUN ID':run_id,'BOT PROCESSED AT':datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        for k,v in values.items():
            if k in headers:ws.cell(item['row_no'],headers[k],v)
    wb.save(path)

def _clean(value): return str(value or '').strip()
def _norm_code(value):
    value=_clean(value)
    return value[:-2] if value.endswith('.0') else value
def review_key(guid,invoice,qt,code):
    inv=_clean(invoice).lstrip('0') or '0'
    return '|'.join((_clean(guid).upper(),inv,_clean(qt),_norm_code(code)))

def _header_map(ws):
    return {_clean(ws.cell(2,c).value):c for c in range(1,ws.max_column+1) if ws.cell(2,c).value is not None}

def _ensure_columns(ws):
    headers=_header_map(ws)
    names=['BOT REVIEW KEY']+COLUMNS
    for name in names:
        if name not in headers:
            c=ws.max_column+1;ws.cell(2,c,name);headers[name]=c
    return headers

def _row_key(ws,row,headers):
    needed=('GUID','INVOICENUM','BUT TOAN','CODE CB')
    if any(x not in headers for x in needed):return ''
    return review_key(ws.cell(row,headers['GUID']).value,ws.cell(row,headers['INVOICENUM']).value,ws.cell(row,headers['BUT TOAN']).value,ws.cell(row,headers['CODE CB']).value)

def prepare_persistent_review_workbook(source:Path,target:Path):
    """Clone the latest classification file and carry forward prior review results by stable case key."""
    previous={}
    if target.exists():
        old=load_workbook(target,data_only=False);ows=old['Sheet1'];oh=_header_map(ows)
        bot_cols=[name for name in ['BOT REVIEW KEY']+COLUMNS if name in oh]
        for row in range(4,ows.max_row+1):
            key=_clean(ows.cell(row,oh.get('BOT REVIEW KEY',0)).value) if oh.get('BOT REVIEW KEY') else _row_key(ows,row,oh)
            if key:previous[key]={name:ows.cell(row,oh[name]).value for name in bot_cols}
    temp=target.with_suffix('.tmp.xlsx');copy2(source,temp)
    wb=load_workbook(temp);ws=wb['Sheet1'];headers=_ensure_columns(ws)
    carried=0
    for row in range(4,ws.max_row+1):
        key=_row_key(ws,row,headers)
        if not key:continue
        ws.cell(row,headers['BOT REVIEW KEY'],key)
        old=previous.get(key)
        if old:
            carried+=1
            for name,value in old.items():
                if name in headers and name!='BOT REVIEW KEY':ws.cell(row,headers[name],value)
    wb.save(temp);temp.replace(target)
    return target,headers,{'previous_records':len(previous),'carried_records':carried}

def completed_review_keys(path:Path,completed_statuses=None):
    completed_statuses=set(completed_statuses or {'REVIEWED_CONFIRMED','REVIEWED','FINAL_SUBMITTED'})
    wb=load_workbook(path,data_only=True,read_only=True);ws=wb['Sheet1'];h=_header_map(ws)
    result={}
    if 'BOT REVIEW STATUS' not in h:return result
    for row in range(4,ws.max_row+1):
        status=_clean(ws.cell(row,h['BOT REVIEW STATUS']).value).upper()
        if status=='RESET' or status not in completed_statuses:continue
        key=_clean(ws.cell(row,h.get('BOT REVIEW KEY',0)).value) if h.get('BOT REVIEW KEY') else _row_key(ws,row,h)
        if key:result[key]=status
    return result


def _source_fingerprint(source:Path):
    stat=source.stat()
    return {'source_path':str(source.resolve()),'source_size':stat.st_size,'source_mtime_ns':stat.st_mtime_ns}

def _metadata_path(target:Path):
    return target.with_name(target.stem+'_metadata.json')

def prepare_persistent_review_workbook_fast(source:Path,target:Path,log=print):
    """Development-only review cache with a fast unchanged-source path.

    If source path/size/mtime is unchanged, do not clone, carry-forward, or save the
    workbook. Only read row-2 headers. A full synchronization is performed only for
    first run or when the classification source changes.
    """
    started=time.perf_counter();meta_path=_metadata_path(target);current=_source_fingerprint(source)
    log(f'REVIEW WORKBOOK CHECK START | target={target}')
    previous_meta={}
    if meta_path.exists():
        try:previous_meta=json.loads(meta_path.read_text(encoding='utf-8'))
        except Exception as exc:log(f'REVIEW WORKBOOK METADATA INVALID | error={exc} | full_sync=true')
    unchanged=target.exists() and all(previous_meta.get(k)==current.get(k) for k in ('source_path','source_size','source_mtime_ns'))
    if unchanged:
        phase=time.perf_counter()
        wb=load_workbook(target,data_only=False,read_only=True);ws=wb['Sheet1'];headers=_header_map(ws);rows=ws.max_row;wb.close()
        log(f'REVIEW WORKBOOK SOURCE UNCHANGED | sync_skipped=true | source={source}')
        log(f'REVIEW WORKBOOK HEADER LOAD COMPLETE | rows={rows} | elapsed_seconds={time.perf_counter()-phase:.2f}')
        log(f'REVIEW WORKBOOK READY | mode=FAST_REUSE | elapsed_seconds={time.perf_counter()-started:.2f}')
        return target,headers,{'mode':'FAST_REUSE','previous_records':0,'carried_records':0,'source_unchanged':True,'elapsed_seconds':round(time.perf_counter()-started,3)}
    reason='TARGET_NOT_FOUND' if not target.exists() else 'SOURCE_CHANGED_OR_METADATA_MISSING'
    log(f'REVIEW WORKBOOK FULL SYNC START | reason={reason} | source={source}')
    phase=time.perf_counter();target,headers,stats=prepare_persistent_review_workbook(source,target)
    log(f'REVIEW WORKBOOK FULL SYNC EXCEL COMPLETE | carried_records={stats.get("carried_records",0)} | elapsed_seconds={time.perf_counter()-phase:.2f}')
    meta={**current,'last_sync_at':datetime.now().isoformat(timespec='seconds')}
    tmp=meta_path.with_suffix('.tmp.json');tmp.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(meta_path)
    stats.update({'mode':'FULL_SYNC','source_unchanged':False,'elapsed_seconds':round(time.perf_counter()-started,3)})
    log(f'REVIEW WORKBOOK READY | mode=FULL_SYNC | elapsed_seconds={time.perf_counter()-started:.2f}')
    return target,headers,stats
