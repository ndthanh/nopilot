from pathlib import Path
from shutil import copy2
from datetime import datetime
from openpyxl import load_workbook

COLUMNS=[
 'BOT DECISION','BOT REASON CODE','BOT REASON DETAIL','BOT TRAN TYPES FOUND',
 'BOT MATCH METHOD','BOT EXISTING ROL CASE','BOT PI STATUS','BOT PI FILE','BOT PI PATH',
 'BOT RULE HITS','BOT RUN ID','BOT PROCESSED AT'
]

def create(source:Path,batch_dir:Path,run_id:str):
    target=batch_dir/f'{source.stem}_DECISION_RESULT.xlsx';copy2(source,target)
    wb=load_workbook(target);ws=wb['Sheet1']
    headers={str(ws.cell(2,c).value or '').strip():c for c in range(1,ws.max_column+1)}
    for name in COLUMNS:
        if name not in headers:
            c=ws.max_column+1;ws.cell(2,c,name);headers[name]=c
    wb.save(target);return target,headers

def update(path:Path,row:int,headers:dict,result:dict,run_id:str):
    wb=load_workbook(path);ws=wb['Sheet1']
    decision=result.get('chargeback_decision') or {}
    pi=result.get('pi_evidence') or {}
    values={
      'BOT DECISION':decision.get('decision') or result.get('status'),
      'BOT REASON CODE':decision.get('reason_code') or result.get('reason',''),
      'BOT REASON DETAIL':decision.get('reason_detail') or result.get('detail',''),
      'BOT TRAN TYPES FOUND':' | '.join(decision.get('tran_types_found') or []),
      'BOT MATCH METHOD':decision.get('match_method',''),
      'BOT EXISTING ROL CASE':decision.get('existing_rol_case',''),
      'BOT PI STATUS':pi.get('status',''),
      'BOT PI FILE':pi.get('file_name',''),
      'BOT PI PATH':pi.get('path',''),
      'BOT RULE HITS':' | '.join(result.get('rule_hits') or []),
      'BOT RUN ID':run_id,
      'BOT PROCESSED AT':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    }
    for name,value in values.items():ws.cell(row,headers[name],value)
    wb.save(path)
