from pathlib import Path
from openpyxl import load_workbook
from shutil import copy2
from datetime import datetime
HEADERS={"member_case":"BUT TOAN","date":"NGAY GD","amount":"SO TIEN","guid":"GUID","tran_id":"TRAN ID","auth":"APPCODE","merchant":"TERMOWNER","invoice":"INVOICENUM","code":"CODE CB","vrol":"VROL","cb_date":"CB date","reject":"CB reject","result":"CB result"}
BOT_HEADERS=["BOT EXCEL AMOUNT","BOT VROL AMOUNT","BOT AMOUNT DIFFERENCE","BOT RUN ID","BOT STATUS","BOT CHECKPOINT","BOT ATTEMPT","BOT UPDATED AT","BOT SCENARIO","BOT ERROR CODE","BOT EVIDENCE ID","BOT CONFIG VERSION","BOT RULESET VERSION"]
def prepare(source:Path,run_dir:Path,run_id:str):
 if not source.exists(): raise FileNotFoundError(source)
 dest=run_dir/f"09_CHARGEBACK_CLASSIFIED_VROL_{run_id}.xlsx"; copy2(source,dest)
 wb=load_workbook(dest); ws=wb["Sheet1"]
 cols={str(ws.cell(2,c).value).strip():c for c in range(1,ws.max_column+1) if ws.cell(2,c).value}
 missing=[h for h in HEADERS.values() if h not in cols]
 if missing: raise ValueError("Missing headers: "+", ".join(missing))
 for h in BOT_HEADERS:
  if h not in cols:
   c=ws.max_column+1; ws.cell(2,c,h); cols[h]=c
 records=[]
 for r in range(4,ws.max_row+1):
  code=str(ws.cell(r,cols[HEADERS["code"]]).value or "").strip()
  if code not in {"13.1","13.9","10.4"}: continue
  rec={k:ws.cell(r,cols[h]).value for k,h in HEADERS.items()}; rec["row"]=r; rec["code"]=code
  for k in ["guid","invoice","member_case","tran_id"]: rec[k]=str(rec[k] or "").strip()
  records.append(rec)
 wb.save(dest); return dest,records,cols
def write_status(path,row,cols,values):
 wb=load_workbook(path); ws=wb["Sheet1"]
 for key,val in values.items():
  if key in cols: ws.cell(row,cols[key],val)
 wb.save(path)
