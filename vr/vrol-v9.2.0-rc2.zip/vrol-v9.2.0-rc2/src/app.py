from pathlib import Path
from datetime import datetime
import uuid,json,shutil
from rich.console import Console
from openpyxl import load_workbook
from .core.config import load_all,as_bool
from .io.mapping import load_mapping,mask_pan
from .io.workbook import prepare,write_status
from .core.state import StateStore
from .vrol.workflow import search_transaction,inspect_row,evaluate,open_case_and_prepare,screenshot,UnknownScenario,BusinessReview
from .auth import legacy_login
C=Console()
def run(config_path:Path,validate_only=False):
 settings,_=load_all(config_path)
 case=Path(str(settings.get("classified_case_file","")).strip())
 mapping_path=Path(str(settings.get("guid_pan_mapping_file","")).strip())
 mapping,errors=load_mapping(mapping_path,str(settings.get("guid_pan_encoding","utf-8-sig")))
 if errors: C.print(f"[yellow]Mapping warnings/errors: {len(errors)}[/yellow]")
 run_id=datetime.now().strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:8]
 run_dir=config_path.parent/"runtime"/"runs"/run_id; run_dir.mkdir(parents=True,exist_ok=False)
 working,records,cols=prepare(case,run_dir,run_id)
 manifest={"run_id":run_id,"case_file":str(case),"mapping_file":str(mapping_path),"mode":settings.get("execution_mode","PRE_SUBMIT_REVIEW"),"records":len(records)}
 (run_dir/"run_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
 if validate_only:
  C.print(f"[green]VALIDATION OK[/green] cases={len(records)} mapping={len(mapping)} working={working}"); return 0
 state=StateStore(run_dir); latest=state.latest()
 # User confirmed ROL case may be recreated: interrupted rows are restarted from transaction search. Completed review rows skip unless rerun_completed=YES.
 def batch(portal,vrol,context,login_settings,answers,logger,login_run_dir):
  for i,rec in enumerate(sorted(records,key=lambda x:(x["guid"],x["row"])),1):
   row=rec["row"]
   if latest.get(row,{}).get("status") in {"READY_FOR_FINAL_SUBMIT_REVIEW","COMPLETED"} and not as_bool(settings.get("rerun_completed",False)): continue
   status_base={"BOT RUN ID":run_id,"BOT ATTEMPT":1,"BOT CONFIG VERSION":settings.get("config_version","1.0"),"BOT RULESET VERSION":settings.get("ruleset_version","1.0")}
   try:
    state.event(row,"IN_PROGRESS",guid=rec["guid"],code=rec["code"]); write_status(working,row,cols,{**status_base,"BOT STATUS":"IN_PROGRESS","BOT CHECKPOINT":"STARTED","BOT UPDATED AT":datetime.now()})
    pan=mapping.get(rec["guid"]);
    if not pan: raise UnknownScenario("PAN_NOT_FOUND")
    tx,inv=search_transaction(vrol,pan,rec["invoice"],settings)
    info=inspect_row(tx); hits=evaluate(rec["code"],info)
    ev=run_dir/f"row_{row}_{rec['code']}_search.png"; evid=screenshot(vrol,ev,settings)
    if info.get("pi")=="Yes": state.event(row,"PI_EVIDENCE_REQUIRED")
    if hits:
     result=hits[0]; state.event(row,"BUSINESS_REVIEW",hits=hits)
     write_status(working,row,cols,{**status_base,"BOT STATUS":"BUSINESS_REVIEW","BOT CHECKPOINT":"RULE_EVALUATED","BOT SCENARIO":result,"BOT ERROR CODE":";".join(hits),"BOT EVIDENCE ID":evid,"BOT UPDATED AT":datetime.now(),"CB reject":result,"CB result":"NOT_SUBMITTED"}); continue
    case_result=open_case_and_prepare(vrol,tx,rec["code"],rec,settings,run_dir/"downloads")
    ev2=run_dir/f"row_{row}_{rec['code']}_ready_for_final_submit.png"; evid2=screenshot(case_result["page"],ev2,settings)
    state.event(row,"READY_FOR_FINAL_SUBMIT_REVIEW",rol=case_result["rol"])
    write_status(working,row,cols,{**status_base,"BOT STATUS":"READY_FOR_FINAL_SUBMIT_REVIEW","BOT CHECKPOINT":"QUESTIONNAIRE_WITH_FINAL_SUBMIT_REACHED","BOT SCENARIO":f"{rec['code']}_READY_FOR_FINAL_SUBMIT_REVIEW","BOT EVIDENCE ID":evid2,"BOT UPDATED AT":datetime.now(),"VROL":case_result["rol"],"CB result":"PRE_SUBMIT_REVIEW"})
   except BusinessReview as e:
    try: ev=run_dir/f"row_{row}_{e.code}.png"; evid=screenshot(vrol,ev,settings)
    except Exception: evid=""
    state.event(row,"BUSINESS_REVIEW",hits=[e.code],detail=e.detail)
    write_status(working,row,cols,{**status_base,"BOT STATUS":"BUSINESS_REVIEW","BOT CHECKPOINT":"TRANSACTION_TABLE_CHECKED","BOT SCENARIO":e.code,"BOT ERROR CODE":e.code,"BOT EVIDENCE ID":evid,"BOT UPDATED AT":datetime.now(),"CB reject":e.code,"CB result":"NOT_SUBMITTED"})
   except Exception as e:
    code=str(e); state.event(row,"UNKNOWN_SCENARIO",error=code);
    try: ev=run_dir/f"row_{row}_unknown.png"; evid=screenshot(vrol,ev,settings)
    except Exception: evid=""
    write_status(working,row,cols,{**status_base,"BOT STATUS":"UNKNOWN_SCENARIO","BOT CHECKPOINT":"STOPPED","BOT ERROR CODE":code,"BOT EVIDENCE ID":evid,"BOT UPDATED AT":datetime.now(),"CB reject":code,"CB result":"USER_REVIEW"})
   C.print(f"[{i}/{len(records)}] row={row} code={rec['code']}")
  C.print(f"[green]Batch finished[/green] {working}")
 # Legacy login owns context lifetime; callback runs batch before logout/close.
 settings["logout_after_login"]=False
 return legacy_login.run(config_path,after_login=batch)
