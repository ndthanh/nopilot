# Worker và marker theo GUID — 20/11/2026

## Cấu hình worker

Đã chạy Visa thật với **3 worker**, trong đó hai luồng PI đã được kiểm tra tải chồng thời gian. Lượt cập nhật này kiểm tra **5 native PI flow đồng thời trên Chrome bằng dữ liệu mô phỏng**, mỗi flow tải hai lần. Chưa chạy Visa thật với 5 worker hoặc benchmark throughput ở mức đó.

Trong config.xlsx, sheet **Settings**:

| Ô | Key | Hiện tại | Cách dùng |
|---|---|---|---|
| B176 | async_worker_count | **3** | Đổi thành 3, 4 hoặc 5 |
| B177 | async_worker_max | **5** | Giới hạn số worker được phép tạo |

`run_async_parallel_case_review.cmd` đã bỏ `--workers 3` cố định. Double-click dùng Excel. Có thể override một lượt bằng CMD:

```bat
run_async_parallel_case_review.cmd --workers 5
```

Số active là `min(số yêu cầu, async_worker_max, số GUID đủ điều kiện)`. Yêu cầu vượt cap có cảnh báo; 0, số âm, số thập phân hoặc giá trị sai bị từ chối. Summary lưu cả configured/requested/cap/effective/active.

Test PI với 5 worker, giới hạn 5 GUID, không đi Issuer Action:

```bat
run_async_native_test.cmd --workers 5 --limit-groups 5
```

PI test mặc định vẫn 3 worker/3 GUID; case test mặc định 1 worker/1 GUID, ép dừng trước Final Submit. Các worker dùng chung persistent context và phiên MFA. Config Final Submit vẫn NO.

## Marker trong groups/GUID

Các file `.txt` nằm trong folder GUID. Cập nhật mới: khi hoàn tất, đổi folder thành
`PI_DOWNLOADED_<GUID>`, `NO_CB_<GUID>`, `FRAUD_<GUID>`, `CONSUMER_<GUID>` hoặc
`REVIEW_REQUIRED_<GUID>`, đồng thời cập nhật đường dẫn PDF/ảnh trong JSON và Excel.
Run lịch sử giữ nguyên. Xem [hướng dẫn dashboard và postflight](OPS_INTEGRATION_2026-11-20.md).

| File | Ý nghĩa |
|---|---|
| `__PI_DOWNLOADED__.txt` | Có PI tải thành công và file chính còn tồn tại |
| `__NO_CHARGEBACK__.txt` | Không chargeback; lý do trong file |
| `__FRAUD__.txt` | Đã đi/thử đi nhánh Fraud |
| `__CONSUMER__.txt` | Đã đi/thử đi nhánh Consumer |
| `__REVIEW_REQUIRED__.txt` | Lỗi, duplicate chưa giải quyết, kết quả chưa xác định hoặc thiếu chứng cứ |
| `__AWAITING_FINAL_SUBMIT__.txt` | Questionnaire đã điền, dừng trước Final Submit |
| `__FINAL_SUBMITTED__.txt` | Có xác nhận Final Submit thành công |
| `__PI_PARTIAL__.txt` | Một phần PI đã tải, phần khác lỗi/pending/thiếu; đi kèm REVIEW_REQUIRED |
| `__IN_PROGRESS__.txt` | Đang xử lý; được thay bằng kết quả khi xong |

FRAUD/CONSUMER là nhánh thao tác, không tự có nghĩa đã gửi dispute thật. Consumer draft có hai marker CONSUMER và AWAITING_FINAL_SUBMIT. Lỗi sau khi dispatch Fraud có thể có FRAUD và REVIEW_REQUIRED. Chỉ dự định đi Fraud nhưng chưa dispatch thì không có FRAUD.

Click Final Submit nhưng chưa xác nhận được kết quả, hoặc bị từ chối, không nhận FINAL_SUBMITTED. Marker ghi riêng `Final submit clicked` và `Final submit confirmed`.

File ghi GUID, status, reason/detail, review reasons, nhánh/stage, ROL case, số PI thành công/lỗi/pending/thiếu và ảnh. Chỉ thay các marker do bot quản lý khi kết quả đổi; tài liệu/file riêng trong GUID folder được giữ nguyên.

## Tổng hợp và mapping sau run

- **guid_outcomes.csv**: mở bằng Excel để filter GUID, category, code, nhánh/stage, ROL, PI counts, reason, folder và ảnh.
- **guid_outcomes.json**: cùng dữ liệu chi tiết và số lượng theo category.

Mỗi GUID có đúng một category chính; REVIEW_REQUIRED ưu tiên khi lỗi/thiếu chứng cứ, kể cả đã đi Fraud/Consumer hoặc tải một phần PI. Số category không đếm trùng GUID. Marker bổ sung ghi phần thao tác đã xảy ra.

Filter **needs_user_review=True** để lấy cả lỗi và draft chờ gửi. `review_required` phản ánh lỗi/chưa xử lý; draft hoàn tất questionnaire có `awaiting_final_submit=True`. Summary có thêm số draft chờ gửi và category counts. Các lượt chạy mới ghi thêm `BOT OUTCOME CATEGORY` và `BOT OUTCOME ACTION STAGE` trong Excel.

Index bao phủ GUID đã giao worker/tạo folder. Các dòng bị loại trước queue có lý do trong Excel và input_exclusions.json. Folder thiếu/hỏng kết quả được nhận diện GUID_NOT_FINALIZED khi dựng index sau run.

## Run cũ

Sau khi run đã dừng:

```bat
run_guid_markers.cmd "C:\path\to\run_id"
```

Lệnh đọc kết quả trên đĩa và bổ sung marker/index; không mở Chrome, hỏi OTP hoặc gửi case. JSON kết quả gốc của run cũ giữ nguyên.

Đã bổ sung cho hai run có sẵn:

- `20261119_233020_e7aab0e5`: **2 GUID PI_DOWNLOADED**, **1 GUID NO_CHARGEBACK**; 9 PDF giữ nguyên đường dẫn.
- `20261119_225958_16e1cdd3`: **1 GUID CONSUMER + AWAITING_FINAL_SUBMIT**, ROL 9000000001; needs_user_review=True.

## Kiểm tra

**101 tests passed, 20.92 giây**: worker 3/4/5, CLI/cap và giá trị sai; marker draft/final/partial/error; thay marker cũ; folder chưa finalize; CSV/JSON; 5 native PI flows đồng thời. Không chạy giao dịch Visa mới trong lượt này.

Config author bằng Artifact Tool và áp patch từng ô để giữ hyperlink sẵn có. Chỉ B177 và mô tả C176/C177 thay giá trị; B176 giữ 3. Giá trị/formula, sheet và package part khác được đối chiếu bảo toàn. Backup: runtime/code_backups/20261120_000618_before_workers_markers/config.xlsx.
