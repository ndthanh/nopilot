# Quy luật đã chốt và kiểm thử lại — 20/11/2026

Code tra soát lấy từ `CODE CB` trong Excel, không suy luận từ merchant, MOTO/ECI
hoặc tên folder. GUID `EXAMPLE_GUID` hiện nằm ở dòng 2516,
code **13.1**, invoice `0000000000000001`. Không áp dụng chặn ECI của 10.4 cho dòng này.

## Quyết định

| Code trong Excel | Điều kiện không submit | Lý do ghi ra |
|---|---|---|
| 10.4 | MOTO/ECI của Sale/Sale-WT là 5, 6 hoặc trống | `lỗi dữ liệu - ECI = 5/6/blank` |
| 10.4, 13.1, 13.9 | Assoc Dispute = D | `Duplicate - assoc dispute = D` |
| 10.4, 13.1 | Tran Type = Credit | `Refund - tran type = Credit` |
| 13.9 | Tran Type = Cash Rev | `Refund - tran type = Cash Rev` |

Chỉ xét các dòng VROL khớp invoice của GUID, không lấy giao dịch không liên quan
của cùng thẻ để chặn. Dừng ở cấp GUID như quy tắc sync. PI=Yes được quét trên tất cả
invoice trước các veto này và trước kiểm tra duy nhất Sale/Cash. Có PI thì tải
chứng từ và không đi Issuer Action cho GUID đó.

Khi nhiều lý do cùng tồn tại và không có PI, giữ thứ tự veto refund, duplicate,
ECI của luồng sync. Lưu ECI thực tế riêng để phân biệt 5, 6 và blank, dù nhãn reject
dùng đúng chuỗi người dùng đã chốt. Các reason code máy giữ nguyên để tương thích báo cáo.

Refund/duplicate được nhận dạng trước lỗi Sale/Cash không duy nhất. Nhờ đó một
invoice chỉ có Credit/Cash Rev, hoặc có D và nhiều Sale, vẫn nhận lý do không-submit
cụ thể. Khi không có veto, vẫn áp dụng đầy đủ các điều kiện chọn Sale/Cash và
questionnaire của sync; ECI 5/6/blank không tự chặn code 13.1 hoặc 13.9.

## Chạy lại

CLI `--recheck-read-only` chỉ bỏ qua registry đối với GUID có kết quả PI/no-CB
đã biết và không có bất kỳ lịch sử thao tác tạo case/ROL nào. Không sửa hay xóa
registry persistent. Case đã tạo, draft và hold vẫn được bảo vệ. `--no-resume`
không được dùng cho lượt kiểm thử lại này.

Lượt `20261120_013046_cb94cc04` được ngắt bằng Ctrl+C theo yêu cầu rà soát lại luật,
sau 133 GUID hoàn tất, 31 PDF. Trạng thái INTERRUPTED không phải kết quả một lượt
full đã hoàn thành. Workbook/registry/checkpoint và các case đã phát sinh được giữ.
Lượt kế tiếp dùng snapshot đầu vào mới, 5 workers, ROL500 đầu/cuối và Final Submit NO.

Kiểm thử tập trung: 53 pass, gồm ma trận veto ba code, ECI riêng 10.4,
PI vượt mọi veto, nhận dạng popup, đổi tên folder và bảo vệ case khi chạy lại.
