# KẾ HOẠCH V6 VÀ PHẠM VI IMPLEMENTATION V1.0.0

## 1. Quyết định nghiệp vụ mới

Business xác nhận ROL case có thể được tạo lại. Vì vậy bot không cần reconciliation theo ROL case để resume một case bị gián đoạn.

Quy tắc mới:

- `PRE_SUBMIT_REVIEW` được phép tạo hoặc tạo lại ROL case.
- Bot dừng trước Final Submit.
- Case bị gián đoạn trước trạng thái hoàn thành review được chạy lại từ Transaction Inquiry.
- Case đã `READY_FOR_FINAL_SUBMIT_REVIEW` được bỏ qua, trừ khi `rerun_completed=YES`.
- ROL number mới nhất được ghi vào cột `VROL` của working workbook.
- Mọi lần chạy lại vẫn tạo evidence và state journal mới.

## 2. Inputs

### File case

Setting `classified_case_file`, mặc định tạm thời:

`C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\fraud-classification-bot-v1.4.1\runs\20261113_193002_a71ac4fb\outputs\09_CHARGEBACK_CLASSIFIED.xlsx`

### File mapping

Setting `guid_pan_mapping_file`, mặc định `T:\input.txt`.

Layout không header:

```text
GUID|full PAN
```

PAN chỉ dùng trong memory, không ghi vào state/report.

## 3. Fraud 10.4

- PI = Yes: ghi `PI_EVIDENCE_REQUIRED`; phase kế tiếp sẽ dùng Transaction Detail/Save as PDF selector để tải predispute evidence.
- ECI = 5, 6 hoặc blank: không tiếp tục, `10_4_ECI_DATA_ERROR`, kết luận “dữ liệu”.
- Assoc Dispute = D: không tiếp tục, `DUPLICATE`.
- Có Tran Type Credit: không tiếp tục, `REFUND`.
- Không hit điều kiện loại trừ: mở Fraud flow, tạo ROL case, điền field đã cấu hình và dừng trước Final Submit.

Thứ tự primary conclusion: Duplicate, Refund, ECI data error. Tất cả rule hit vẫn được ghi vào `BOT ERROR CODE`.

## 4. Resume

State được ghi append-only vào `runtime/runs/<run_id>/state.jsonl` và phản ánh vào các cột `BOT ...` trong working workbook.

Vì được phép tạo lại ROL case:

- Không dùng ROL number làm idempotency key.
- Không cần tìm existing ROL trước khi resume một case dở dang.
- Case dở dang được restart từ search PAN/Invoice.
- Final Submit vẫn không được phép trong v1.0.0.

## 5. Luồng triển khai v1.0.0

1. Tải Settings/SecurityQuestions/RunSettings/Selectors từ `config.xlsx`.
2. Validate và parse `input.txt`.
3. Copy file case thành working workbook.
4. Bổ sung BOT status columns.
5. Login Visa Online bằng module hiện có.
6. Security Question/Max Session/VROL MFA/Outlook OTP.
7. Giữ tab VROL và chuyển cho batch callback.
8. Sort record trong memory theo GUID, không sort workbook vật lý.
9. Map GUID sang PAN.
10. Transaction Inquiry và filter Invoice Number sau khi bỏ số 0 đầu.
11. Chụp evidence.
12. Evaluate common rules và code-specific rules.
13. Nếu eligible, tạo hoặc tạo lại ROL case.
14. Điền các field có selector trong config.
15. Chụp form và ghi `READY_FOR_FINAL_SUBMIT_REVIEW`.
16. Không click Final Submit.

## 6. Cấu trúc

- `src/auth/legacy_login.py`: login implementation đã được nối callback.
- `src/core/config.py`: config sheets.
- `src/core/state.py`: JSONL journal.
- `src/io/mapping.py`: parser `GUID|PAN`.
- `src/io/workbook.py`: working workbook và BOT columns.
- `src/vrol/selectors.py`: frame helpers.
- `src/vrol/workflow.py`: Transaction Inquiry, rule evaluation và ROL preparation.
- `src/app.py`: orchestrator.

## 7. Điều chỉnh selector khi test

Các selector nghiệp vụ trong sheet `Selectors` là candidate selector từ khảo sát. Nếu VROL thực tế khác, cập nhật trực tiếp sheet này, không sửa code trước khi đã xác nhận selector mới.

Case không tìm được selector, nhiều transaction, Invoice rỗng, PAN không mapping hoặc UI khác sẽ được ghi `UNKNOWN_SCENARIO` và chụp ảnh.

## 8. Giới hạn chủ ý của v1.0.0

- Final Submit bị khóa và chưa được implement.
- PI evidence download mới ghi yêu cầu, chưa tự tải nếu selector Transaction Detail/Save as PDF chưa được xác minh trên môi trường test.
- ROL500 chưa chạy trong review mode.
- Selector form chi tiết có thể cần hiệu chỉnh sau lần chạy đầu.

Các giới hạn này bảo đảm bản test không thực hiện Final Submit ngoài ý muốn.
