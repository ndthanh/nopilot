# Native async Playwright — triển khai và kiểm tra

Phiên bản `v9.2.0-rc1`, cập nhật ngày 19/11/2026. Dự án sync v9.0.60 gốc được giữ nguyên để đối chiếu. Backup code và config trước sửa: `runtime/code_backups/20261119_221503_before_native/`.

## Kết quả triển khai

- Backend mặc định `native_async`: Playwright async trực tiếp, không attach sync engine qua cổng CDP. Một persistent context dùng chung phiên đăng nhập; mỗi worker sở hữu trang Inquiry và toàn bộ hậu duệ popup. Đăng ký theo `Page.popup`/`Page.opener()`, giữ quyền sở hữu khi opener trung gian đóng. Không lấy trang mới nhất/toàn context làm trang của worker.
- Không có lock toàn cục cho Inquiry, PI hoặc Issuer Action trong native path. Các tab có thể chờ popup/download độc lập. Login/relogin vẫn phối hợp ở cấp phiên chung; Excel được ghi bằng một writer để bảo toàn workbook. Đây là các tài nguyên chung có chủ đích.
- PI dùng `expect_download()` trên đúng trang Details, kiểm tra trang phát download, transaction ID và PDF trước khi công bố file. Không đổi download directory chung theo invoice. Reacquire row bằng transaction ID và frame sở hữu, tránh locator `nth()` trỏ sang invoice khác sau khi filter.
- File chính: `groups/<GUID>/documents/<invoice>_<last4>_<TERMOWNER>.pdf`; bản copy tổng hợp: `documents/<invoice>_<last4>_<TERMOWNER>.pdf` trong cùng run. Giữ số 0 đầu của invoice, lấy last4 từ full PAN đã mapping, TERMOWNER từ Excel. Kiểm tra hash hai bản; không overwrite nội dung khác khi trùng tên. Manifest, log, JSON và ảnh đặt trong GUID folder ổn định.
- Kiểm tra **transaction ID chính** từ header PDF, không chỉ tìm invoice xuất hiện ở bất kỳ vị trí nào trong bảng associated transactions. Giữ suffix `-NN` khi có để chặn nhầm leg giao dịch.
- Luồng Case Creation kiểm tra Create Dispute, Submit một lần và theo dõi đúng chuỗi popup đến questionnaire. Điền preset 10.4/13.1/13.9 theo sync; maximize cửa sổ **và resize viewport popup** trước khi chụp full page. Lưu checkpoint quanh các bước tạo case để điều tra kết quả chưa rõ.
- ROL-749 được chụp và acknowledge/tiếp tục một lần như sync. ROL-1545, unknown/error và PI lỗi có lý do, ảnh và trạng thái cần review. Không báo PI lỗi là completed. Kết quả không tra soát có reason riêng; input bị loại có `input_exclusions.json` và cột `BOT INPUT EXCLUSION`.
- Rich console hiển thị input/output từng GUID; Python tự tee console ra UTF-8 log. Bộ cài và các lệnh chạy đều là `.cmd`, không cần PowerShell trên production.

## Rule gốc và yêu cầu bổ sung

Không gộp khác biệt được người dùng yêu cầu vào rule sync gốc:

| Phạm vi | Hành vi hiện tại |
|---|---|
| Input | CHECK SALE=SALE, VALID CHARGEBACK=Y, code 10.4/13.1/13.9, mapping PAN đầy đủ; loại prefix 5 |
| ROL500 | Loại toàn GUID có dòng đủ điều kiện đã chargeback, trước khi cắt theo tuổi |
| Tuổi, yêu cầu bổ sung | Chốt ngày Việt Nam khi bắt đầu run; chỉ giữ `age_days > 15`. Giữ cận trên `<120` vốn có ở async; cận này không phải rule sync |
| GUID pha tuổi | Loại dòng chưa đủ tuổi và ghi lý do; xử lý phần đủ tuổi. Inquiry lấy ngày nhỏ nhất còn lại. Chỉ ghi review key của dòng hoàn tất, không đánh dấu cả GUID khi có dòng hoãn |
| **PI, yêu cầu bổ sung mới nhất** | **Quét toàn bộ invoice của GUID trước. VROL PI=Yes ưu tiên hơn Sale/Cash uniqueness, refund/reversal, Assoc Dispute và ECI.** Tải PI đã xác định và không đi Issuer Action cho GUID. Không bỏ sót PI nằm sau invoice có điều kiện group stop |
| Không PI, theo sync | Đúng một Sale/Sale-WT cho 10.4/13.1 hoặc Cash cho 13.9; sau đó Credit/Cash Rev group stop, Assoc D stop, Assoc khác review, 10.4 ECI rỗng/5/6 stop |
| Issuer Action | 10.4 → Fraud; 13.1/13.9 → Consumer; nhóm trộn Fraud/Consumer cần review |
| Questionnaire | Giữ giá trị và kiểm tra nhận diện từ sync; không tự thêm rule Response Code từ entry point `evaluate()` khác |

Nếu Visa gắn PI=Yes cho cả Auth và financial của cùng invoice, ưu tiên các dòng Sale/Sale-WT (10.4/13.1) hoặc Cash (13.9) có PI và gộp theo transaction ID; không đòi hỏi đúng một dòng. Nếu không có financial PI thì vẫn xét các dòng PI khác. Tránh tải lặp Auth và Sale hoặc để một bản ghi PENDING nhưng báo hoàn tất.

PI ưu tiên trong tập đầu vào qua gate ngày/ROL500/card; không dùng PI để đưa lại giao dịch bị loại khỏi queue bởi các gate đầu vào này. Nếu nhiều transaction PI dẫn đến cùng tên file nhưng khác nội dung, báo conflict cần review thay vì mất chứng cứ do overwrite.

## Config và CMD

Trong `config.xlsx`, sheet `Settings`:

| Key | Giá trị hiện tại | Tác dụng |
|---|---|---|
| `allow_final_submit` | **NO** | Dừng sau khi điền/chụp questionnaire. Production đổi YES sẽ kích hoạt gửi thật |
| `questionnaire_maximize_before_capture` | YES | Maximize Chrome và viewport trước ảnh questionnaire |
| `otp_polling_mode` | FOLDER_FILENAME | Poll OTP từ tên file theo provider hiện có |
| `otp_folder_path` | Thư mục OTP đang cấu hình | Console báo đúng thư mục khi VROL thực sự hỏi MFA |

Settings!B47 là nguồn có hiệu lực của allow_final_submit cho native async. Bản cũ có key trùng trong RunSettings; loader đã sửa để giá trị cũ không che mất switch Settings. Giữ nguyên các giá trị config khác, bao gồm thông tin đăng nhập. Có backup config gốc.

Chạy tại CMD trong thư mục dự án:

```bat
install.cmd
run_async_native_test.cmd
run_async_case_test.cmd --guid YOUR_GUID
run_async_parallel_case_review.cmd
run_offline_tests.cmd
```

`run_async_native_test.cmd`: tối đa 3 GUID, PI only, không đi Issuer Action. `run_async_case_test.cmd`: mặc định 1 GUID, luôn ép dừng trước Final Submit kể cả config là YES. Có thể truyền `--workers`, `--limit-groups`, `--guid` nhiều lần và `--console-log`.

Đối soát snapshot: `--skip-rol500 --source-workbook "...ROL500_ENRICHED.xlsx"`. Chỉ dùng cho test với snapshot đã biết. Chạy production bình thường không bỏ ROL500. `--no-resume` là override debug, không dùng để tạo lại case chưa đối soát.

## Final Submit đã chuẩn bị

Chỉ chạy khi config YES và không có `--pre-submit-only`. Reacquire đúng nút questionnaire Angular, ảnh `06_before_final_submit.png`, ghi checkpoint rồi dispatch một lần. Sau đó:

- Xác nhận thành công → `FINAL_SUBMIT_COMPLETED`, ảnh `07_final_submit_result.png`.
- Reject Details → `FINAL_SUBMIT_REJECTED`, ghi nội dung từ chối và ảnh.
- Lỗi form → `FINAL_SUBMIT_FORM_ERROR`, ghi nội dung lỗi và ảnh.
- Không xác nhận được → `FINAL_SUBMIT_RECONCILIATION_REQUIRED`, chụp trang hiện có, không tự resend.

**Chưa bấm Final Submit trên Visa thật.** Các kết quả trên chỉ kiểm tra bằng fixture Chrome cục bộ. Đổi flag chỉ áp dụng khi đi qua luồng mới; không tự gửi lại các draft cũ. Đối chiếu số ROL/checkpoint trước khi xử lý lại.

## Bằng chứng live đã hoàn tất

Các lượt dưới đây chạy Chrome headful qua CMD và dùng snapshot ROL500 của lượt baseline `20261119_214805_3a3fe874`; phiên MFA trong ngày được tái sử dụng.

| Run | Kết quả |
|---|---|
| `20261119_224747_8a85c31a` | GUID `EXAMPLE_GUID`: tải **8/8 PI**, 8 PDF trong GUID/documents và 8 bản tổng hợp, nội dung đúng transaction; 0 lỗi kỹ thuật |
| `20261119_225150_5edfe5cd` | 3 worker/3 GUID: hai GUID tải PI (tổng 9 PDF), một GUID dừng tại checkpoint PI-only trước Issuer Action; 0 review/0 lỗi kỹ thuật. Inquiry chạy chồng thời gian; không dùng lượt này để khẳng định hai download PI thực sự chồng thời gian |
| `20261119_225958_16e1cdd3` | Consumer 13.1 tạo ROL **9000000001**, điền questionnaire, Final Submit=false. Lượt này tìm ra viewport popup vẫn hẹp dù cửa sổ maximize; code đã sửa tiếp |
| `20261119_230157_6c2a043e` | 13.9 dừng đúng Assoc Dispute=D, lưu lý do/ảnh; không tạo case |
| `20261119_230426_283fc414` | Mã PI-first mới, 3 worker: một PI tải đúng hai nơi, hai GUID dừng Assoc D; 0 lỗi kỹ thuật |

Không coi các probe trước đó là test đạt: đã lưu lỗi parser header lấy text ẩn, row locator sai phạm vi frame, login race và menu ẩn trùng tên trong runtime. Chúng đã được sửa và bổ sung regression test. Probe chọn GUID không eligible dừng trước worker, không tạo case.

## Giới hạn đánh giá

- Bộ test có đối chiếu logic với hàm sync thật cho nhánh không PI, và kiểm tra riêng các override PI mới, tuổi, file/hash/collision, popup thuộc worker, download đồng thời, relogin và questionnaire/final-submit fixtures.
- Chưa benchmark tải lớn hay khẳng định mọi popup legacy của Visa luôn độc lập. Ownership/identity checks chặn nhận nhầm trang hoặc file; cần review nếu ứng dụng tái sử dụng named window giữa worker.
- Chưa kiểm thử fresh OTP của nhánh mới vì Visa không hỏi lại trong các phiên hôm nay. Provider polling thư mục được giữ theo cấu hình.
- ROL500 preflight đã chạy ở baseline; các lần debug native dùng enriched snapshot để tránh tải lặp. Chưa chạy lại full batch production hoặc real Final Submit sau migration.

## Các probe bổ sung cần phân biệt

- `20261119_230806_a3f94e13`: hai case dừng đúng refund/Assoc D; một case dừng có ảnh vì parser gặp dòng detail 3 ô trong bảng. Đã sửa chỉ đọc dòng giao dịch `summaryGridRow`, có regression test với bảng detail lồng nhau.
- `20261119_231015_ed8d0761`: dừng chủ động probe PI-first khi phát hiện quét trùng Auth/financial; không coi là run đạt.
- `20261119_231400_853782e6`: test barrier ép hai worker bắt đầu PI cùng lúc, 1 GUID thành công; GUID 8 invoice có 2 lỗi đầu rồi 6 PI thành công. Lỗi popup không khớp ownership được chặn, không gán nhầm file cho invoice. Vì vậy lượt 3 worker trước đó không đủ để kết luận popup PI độc lập hoàn toàn. Các probe tiếp theo đã khoanh vùng delegated click và xác minh cách gọi handler gốc của Visa; xem phần kết quả cuối.

## Questionnaire maximize đã xác minh live

Run `20261119_231818_5442bccc`, 3 worker: GUID `EXAMPLE_GUID` tạo ROL **9000000002**, điền Consumer 13.1, ảnh questionnaire **1438 px rộng**, thấy đủ 3 cột và nút Submit; `final_submit_clicked=false`. Ảnh: `groups/EXAMPLE_GUID/04_questionnaire_filled_final_submit_not_clicked.png`. PI của GUID `1D84...` (chỉ invoice đầu trong probe này) tải đúng; PI của worker còn lại chưa mở được popup. Run có issue nên không coi là concurrency test đạt.

Probe này chỉ dùng invoice đầu của GUID 8 invoice để ép hai PI bắt đầu cùng thời điểm và giảm vòng debug; 7 dòng khác được đánh dấu deferred trong cấu trúc queue thử nghiệm, không đánh dấu toàn GUID completed. Production không cắt nhóm theo cách này. Wrapper chỉ nằm trong runtime/test_sessions, không nằm trong CMD production.

## Kiểm tra độc lập PI đã đạt trên Visa

Run `20261119_232447_9e7a09b3`: **2 worker, 2 PI, 0 review, 0 lỗi kỹ thuật**. Probe ép hai worker bắt đầu PI cùng lúc (mỗi GUID một invoice; GUID 8 invoice chỉ lấy invoice đầu trong probe, các dòng còn lại deferred như đã mô tả). Native handler vẫn thực hiện nguyên luồng View/Tran Details, PDF download và publish.

Bằng chứng trong run.log:

| Worker | Bắt đầu mở Details | Publish PDF | Named target Visa |
|---|---|---|---|
| W02 | 23:25:55.763 | 23:26:05.027 | TIDetails28461087012 |
| W01 | 23:25:55.772 | 23:26:06.065 | TIDetails28461081785 |

Hai popup và hai download chồng thời gian khoảng 9 giây, đúng transaction và đúng owner; PDF có cả bản GUID và bản tổng hợp. Không có JS dialog trong probe. Không dùng mutex PI. Đây là kiểm tra chức năng đồng thời, không phải benchmark throughput.

Contract thực tế: menu là `a[data-js="top.bodyframe.viewDetails()"]` chứa `span#tranTxt`. Trong một số lượt tương tác song song, delegated click không gọi handler (không có window.open). Native đã xác minh đúng chuỗi data-js trên DOM rồi gọi **chỉ** `top.bodyframe.viewDetails()` trong chính frame đó; không eval handler tùy ý. Visa tiếp tục thực hiện kiểm tra selection bên trong hàm gốc. Các UI khác vẫn phải qua ownership/identity checks. Tên popup Visa khác nhau theo transaction record, không phải một tên chung cần khóa toàn session.

Bộ offline hiện tại: **81 passed** (13.25 giây), bao gồm hai native PI flow thật trên Chrome cục bộ chạy asyncio.gather, chọn handler của bodyframe, PDF identity và hai nơi lưu; các nhánh Final Submit mô phỏng; precedence của switch Settings trước key legacy trùng. `pip check` không có dependency hỏng; CLI help hoạt động; không có lệnh PowerShell/pwsh trong các CMD production.

Legacy bridge chỉ giữ để đối chiếu/debug, không tự failover và không bảo đảm các override PI-first/Final Submit mới của native. Production dùng CMD native.

## Hồi quy cuối — đầy đủ nhóm 8 invoice

**Run `20261119_233020_e7aab0e5`: COMPLETED, 3 worker, 3 GUID, 0 review, 0 lỗi kỹ thuật.** Đây là CMD production test bình thường, không dùng wrapper ép barrier hoặc cắt invoice. Hai GUID tải **9/9 PI** (GUID `1D84...` đủ **8/8**); case 13.9 còn lại dừng đúng `GROUP_CONTAINS_ASSOC_DISPUTE_D`. Không đi Issuer Action hoặc Final Submit trong lượt này.

Đã đối soát lại toàn bộ 9 PDF bằng validator hiện tại: ID chính trong PDF đúng transaction; tên đúng invoice nguồn/last4/TERMOWNER; hash bản GUID và bản tổng hợp khớp; cột BOT PI FILE/PATH/CENTRAL PATH trong Excel trỏ đúng file thật; không còn PI PENDING. `artifact_verification.json` trong run ghi **PASS**. Input exclusions ghi nhận 1.353 dòng chưa quá 15 ngày. Flag config có hiệu lực vẫn NO.

Lượt trước `20261119_232654_7e6ab83b` phát hiện menu View còn mở sau khi gọi handler trực tiếp, khiến lần click View tiếp theo đóng menu. Đã sửa mở menu idempotent (tái sử dụng menu đang mở), thêm kiểm thử hai worker, mỗi worker download liên tiếp hai lần. Lượt hồi quy cuối ở trên xác minh fix với chuỗi 8 invoice thật. Các probe `20261119_232224_6ce4e329` và `20261119_231818_5442bccc` có lỗi nên không được tính là test độc lập PI đạt; lượt `20261119_232447_9e7a09b3` mới là bằng chứng download chồng thời gian đạt.

Bộ kiểm thử sau thay đổi cuối: **81 passed, 13.58 giây**. Real Final Submit và fresh OTP vẫn chưa kiểm tra live. Chưa đánh giá throughput trên toàn bộ queue production.

## Cập nhật cửa sổ và thứ tự điền questionnaire

Xem [WINDOW_LAYOUT_2026-11-19.md](WINDOW_LAYOUT_2026-11-19.md): native no_viewport=True, xác nhận cửa sổ maximized, và maximize questionnaire trước fill. Bỏ viewport pixel cố định; popup PI/Case Creation giữ native size. Kiểm tra 3 lượt Chrome headful cục bộ với profile lặp lại; chưa chạy lại case Visa thật trong lượt sửa window layout này. Kết quả live phía trên thuộc bản trước cập nhật cửa sổ.
