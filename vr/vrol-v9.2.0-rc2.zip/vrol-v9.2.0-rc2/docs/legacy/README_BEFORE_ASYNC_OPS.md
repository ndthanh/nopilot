# VROL Automation v9.2.0-rc1

The current async entry point is `run_async_parallel_case_review.cmd`, using native
async Playwright with Rich logging. Read [the async operating guide](ASYNC_RUNTIME_README.txt)
and [implementation/test results](docs/NATIVE_ASYNC_IMPLEMENTATION_2026-11-19.md).
Use `install.cmd`, `run_async_native_test.cmd` (PI only), and
`run_async_case_test.cmd` (questionnaire, forced stop before Final Submit).
`config.xlsx` currently has `allow_final_submit=NO`; production can explicitly set
YES to enable the prepared submit-and-capture path. The older entry points and
notes below describe the sync/legacy workflows.

Window sizing now uses a native viewport and maximizes questionnaire **before**
filling. See [window layout validation](docs/WINDOW_LAYOUT_2026-11-19.md);
`run_window_layout_test.cmd` checks headful sizing locally without a Visa login.

## Change notes

Worker count is now configurable in Settings!B176 (default 3, cap 5 in B177).
GUID folders have outcome/stage marker files and each run has guid_outcomes.csv.
See [worker and marker guide](docs/WORKERS_AND_GUID_MARKERS_2026-11-20.md).

See [Detailed change notes — 2026-11-14](docs/CHANGELOG_2026-11-14.md) for implemented changes, configuration, verification and outstanding work.

## Run
1. Edit `config.xlsx`.
2. Double-click `install.cmd`.
3. Double-click `run_test_config.cmd`.
4. Double-click `run.cmd`.

Default mode is `PRE_SUBMIT_REVIEW`: the bot may create/recreate a ROL case, fills the next form where selectors are configured, captures evidence, writes `READY_FOR_FINAL_SUBMIT_REVIEW`, and does not click final Submit.

## Inputs
- `classified_case_file`: `09_CHARGEBACK_CLASSIFIED.xlsx`.
- `guid_pan_mapping_file`: headerless `input.txt`, one `GUID|full PAN` per line.

## Resume
State is appended to `runtime/runs/<run_id>/state.jsonl` and mirrored to BOT columns in the working workbook. Business confirmed a ROL case can be recreated, so an interrupted non-completed case restarts from transaction search instead of attempting ROL-case reconciliation.

## Important
VROL UI selectors can differ by environment. Review the `Selectors` sheet before testing. Final Submit is intentionally not implemented in v1.0.0.

## Amount gate and capture controls (2026-11-14)

Before any ROL creation, the bot reads the amount from a unique table header and
compares it with `SO TIEN` using Decimal, with no tolerance or rounding. A mismatch
writes `AMOUNT_MISMATCH`, both amounts and the difference (VROL minus Excel) to the
journal and working workbook, then stops that case and proceeds to the next row.
Missing/ambiguous amount columns and invalid amounts stop the case as
`UNKNOWN_SCENARIO`; the bot does not guess an amount.

Optional keys in the **Settings** sheet of `config.xlsx` (Key/Value/Description):

| Key | Default when absent | Meaning |
| --- | --- | --- |
| trace_enabled | NO | Enable Playwright debug trace only when explicitly needed |
| screenshots_enabled | NO | Master switch for all standalone screenshots, including failures, and trace screenshots |
| amount_column_headers | Tran Amount\|Transaction Amount\|Amount | Exact accepted header labels, separated by a pipe |
| amount_currency | VND | Optional currency suffix accepted in amount text |
| excel_amount_thousands_separator | , | Thousands separator for Excel text amounts; numeric cells are unaffected |
| excel_amount_decimal_separator | . | Decimal separator for Excel text amounts |
| vrol_amount_thousands_separator | , | Thousands separator for VROL amount text |
| vrol_amount_decimal_separator | . | Decimal separator for VROL amount text |

The supplied workbook does not need new keys for the safe defaults to apply.
Existing `screenshot_on_success=YES` does not override `screenshots_enabled=NO`.
If trace is explicitly enabled, it still includes DOM/action data even when
screenshots are disabled; use synthetic data for debugging. Existing artifacts
from earlier runs are not deleted by these switches.

The default VROL format is `100,000.00` or `100,000 VND`, following the survey.
For `100.000,00`, configure thousands `.` and decimal `,` explicitly. Verify the
amount header and numeric format in UAT. No browser verification was performed
for this change. Existing resume and other review findings remain outstanding.

Offline verification: `python -m unittest discover -s tests -v`.
The older `review_artifacts/reproduce.py` records pre-fix behavior and is not a
regression test for the patched version.


## V7 table and Case Creation update (2026-11-14)

- Invoice filter matches Excel Invoice Number against the Transaction ID part only.
- If Auth and Sale share the same Transaction ID, the Sale row is selected.
- Credit and Sale Rev stop values are configurable through `invoice_stop_tran_types`.
- Assoc Dispute values `M` and `D` stop the record and trigger screenshot evidence when screenshots are enabled.
- Transaction fields are parsed by table header-to-cell mapping, not regex over the entire row.
- Case Creation is considered a separate page/frame contract with `#submitButton`; the bot clicks only this Submit.
- READY is written only after the next questionnaire page contains questionnaire identity, VROL Case Number and a final Submit button. The final Submit is never clicked.
- Old draft VROL numbers are not used for resume; records may restart from Transaction Inquiry until Final Submit exists in scope.


## Single-card home-office test mode

Use `run_single_test.cmd` when no classified workbook or GUID-to-PAN file is available. Configure only `single_test_full_pan` and `single_test_start_date` in the `Settings` sheet. The default code is 13.1. The test logs in, opens Transaction Inquiry, fills the full PAN and Start Date, submits the search, selects the first visible Sale row, creates/recreates the ROL draft, and stops at `READY_FOR_FINAL_SUBMIT_REVIEW`. It never clicks the questionnaire Final Submit.

Because only PAN and Start Date are supplied, `single_test_sale_strategy=FIRST_VISIBLE` is an explicit test-only assumption. If multiple Sale rows exist, the first visible Sale row is used. Do not use this mode for production cases.


## V8.2 exact Inquiry contract

Navigation now uses only the supplied stable HTML contract: `a#inquirymenua` is hovered, `a[data-js="displayTranInquiry()"]` is clicked, then the bot waits for `#CardNumber` and `#StartDate` in `bodyframe` plus `#submitButton` in `buttons`. The fallback role/text guessing introduced in V8.1 has been removed. The landing URL may be detected before the menu DOM is ready, so the exact menu selector is polled for up to `transaction_inquiry_navigation_timeout_ms`.


## V8.3 single-card Invoice filter

Single-card mode now requires three test inputs in `Settings`: `single_test_full_pan`, `single_test_start_date`, and `single_test_invoice_number`. After Transaction Inquiry returns the table, the bot fills the `Transaction ID / Retrieval Ref #` column filter with the invoice after removing leading zeros. It retains only rows whose Transaction ID exactly matches that normalized invoice. If Auth and Sale have the same Transaction ID, the unique Sale row is selected. Credit and Sale Rev remain configurable stop types.


## V8.4 result-page and development diagnostics fix

A successful Visa/VROL authentication is no longer relabeled as `LOGIN FAILED` when the subsequent automation callback fails. Such failures are reported as `POST-LOGIN WORKFLOW FAILED`. After clicking the exact Transaction Inquiry `#submitButton`, the bot reacquires `bodyframe` and waits for exact `table#results`; it no longer depends on a stale frame locator or the optional `.dataTables_scrollBody` wrapper. In single-card development mode, `single_test_pause_on_error=YES` keeps the browser available for inspection. Close the browser manually and press Enter in CMD when inspection is complete.


## V8.5 exact buttons iframe Submit

Transaction Inquiry Submit is now clicked only through the supplied legacy contract: `iframe#buttons[name="buttons"]`, document body `#buttonBody`, and `button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]`. The code no longer carries a cached `buttons` Frame object from the navigation step. It reacquires the frame immediately before clicking, preventing accidental interaction with Back/Reset/Print buttons or a stale frame document.


## V8.6 step logging and Start Date fix

Every mandatory step now writes explicit STEP/PASS logs: Inquiry hover, Transaction Inquiry click, form readiness, PAN fill, Start Date fill, exact buttons-frame Submit, and result-table readiness. Start Date no longer uses `press("Tab")`; the legacy `checkStartDate` handler can detach/replace the element and make Playwright wait until timeout. The new sequence is fill -> input -> change -> DOM blur. Post-login errors still pause with the browser open for manual inspection.


## V8.7 exact trace path at run end

At the end of every run the console now shows an explicit `TRACE FILE` panel containing the absolute path to `trace.zip`. The same text is saved to `trace_path.txt` inside the login run artifact folder. If tracing is disabled or export fails, the console explicitly says so and shows the expected path. The supplied development config has `trace_enabled=YES`.


## V8.8 manual trigger after login

The development flow now pauses immediately after Visa/VROL authentication succeeds and before any Inquiry automation begins. With `post_login_manual_trigger_enabled=YES` and `post_login_trigger_key=ENTER`, the CMD window displays `VROL login succeeded. Press ENTER to continue with Inquiry > Transaction Inquiry...`. The browser stays open at the authenticated landing page until Enter is pressed. Playwright tracing is enabled and continues across both the login and post-login phases; the exact absolute `trace.zip` path is printed at run end and stored in `trace_path.txt`.


## V8.9 step-by-step Enter gates

After VROL login, the development flow requires Enter before every major post-login action: hover Inquiry, click Transaction Inquiry, fill PAN, fill Start Date, click Transaction Inquiry Submit, filter Invoice, confirm the Sale row, select the transaction, open Issuer Action, click the Consumer/Fraud action, and click Case Creation Submit. Each pause prints a `[STEP_CODE]` prompt. `step_by_step_trigger_steps=ALL` enables all gates; a pipe-separated list can enable only selected gates. Final Submit is not included and is never clicked. Playwright trace remains enabled throughout the pauses and actions.


## V8.10 selector preview and red target highlight

Before every Enter-controlled action, CMD now prints the exact selector the script will use. The exact target in Chrome is scrolled into view and temporarily styled with a 4px red border, white outline, red glow, and pale-red background. The original inline style is preserved and restored immediately after Enter, before the actual action executes. This applies to Inquiry, Transaction Inquiry, PAN, Start Date, the buttons-frame Submit, Invoice filter, matched Sale row, transaction checkbox, Issuer Action, Consumer/Fraud submenu, and Case Creation Submit. If a target cannot be highlighted, the prompt explicitly reports `Red highlight applied: NO` and the operator can stop instead of confirming. Final Submit is still excluded.


## V8.11 live buttons-frame discovery

The Transaction Inquiry Submit iframe title varies by page (`Homepage action buttons` versus `Dispute management action buttons`), so title is no longer part of the selector. The bot scans all live Playwright frames and accepts the frame when `frame.name == "buttons"` or its URL contains `/rolol/jsp/buttons_index.jsp`. Inside that live frame it verifies `body#buttonBody` and the exact `button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]`, highlights that actual button in red, prints the frame name, frame URL and selector, waits for Enter, then clicks it. Failure logs include all observed frame names and URLs.


## V8.12 simple red border

The pre-step target highlight is now intentionally minimal: only `border: 2px solid #ff0000 !important` is applied. White outline, outline offset, red glow, box shadow, and pale-red background have been removed. The original inline style is still restored after Enter and before the action executes.


## V8.13 MM/DD/YY and temporary continuous mode

Transaction Inquiry Start Date is now always normalized to `MM/DD/YY` (for example `20260922` becomes `09/22/26`). The supplied development config temporarily disables both post-login and per-step Enter gates, so the workflow continues automatically. The simple 2px red-border feature remains enabled in config and can be used again by switching `step_by_step_manual_trigger_enabled=YES`. Playwright trace remains enabled.


## V8.14 strict transaction-date format

The transaction date source contract is now intentionally minimal: only `YYYYMMDD` is accepted. The bot converts it directly to VROL `MM/DD/YY`. Alternative date formats are rejected with `SINGLE_TEST_START_DATE_INVALID_YYYYMMDD`, reducing branches and debugging surface.


## V8.15 Transaction Inquiry screen readiness

After clicking `Inquiry > Transaction Inquiry`, the bot now waits before filling PAN or Start Date. Readiness requires all of the following simultaneously: `#CardNumber` visible in `bodyframe`, `#StartDate` visible in `bodyframe`, `body#buttonBody` visible in the live buttons frame, and exact `button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]` both visible and enabled. The complete signature must remain stable for three consecutive polls. Only then can PAN and Start Date be filled. This prevents the form fields being populated while the lower action-button document is still loading.


## V8.16 optional VROL MFA

Opening VROL now waits for one of two outcomes: the MFA method-selection heading, or the authenticated landing URL. If the redirect reaches `AdminDispatcher?action=RouteToLandingPage` directly, the existing authenticated VROL session is accepted immediately and the complete Email/OTP flow is skipped. `VERIFY_VROL_MFA` is no longer retried after a successful redirect. If MFA appears, the existing strict Outlook OTP flow runs unchanged.


## V8.17 just-in-time form probe

The Transaction Inquiry page can briefly satisfy the initial readiness check and then replace `bodyframe` or return to landing before PAN is filled. The bot now waits a configurable settle delay and reacquires the live `bodyframe` immediately before PAN, then reacquires it again immediately before Start Date. Each probe requires the bodyframe URL to contain `/rolti/web/ti/ti-request` and both `#CardNumber` and `#StartDate` to be visible. Stale locators from the earlier readiness check are never reused. If the page has returned to landing, the run stops with an explicit `TRANSACTION_INQUIRY_FORM_LOST_BEFORE_*` error and leaves the browser open for inspection.


## V8.18 legacy-frame transition probe and one-time recovery

The latest trace shows a split state: `buttons` reached `/rolti/web/ti/ti-buttons`, while `bodyframe` returned to `InvokeHomePage`. This is not a missing selector; it is a partial legacy-frame rollback. The bot now waits for the homepage bodyframe to settle before hovering Inquiry, logs every body/buttons transition, requires both TI routes plus visible fields/button, detects the split state immediately, and reopens `Inquiry > Transaction Inquiry` once after landing settles. It no longer waits blindly for 45 seconds when the bodyframe has already rolled back.


## V8.19 table and Issuer Action probe mode

For home-office test data, the intermediate popup Case Creation step is optional. After Transaction Inquiry Submit, the bot probes briefly for a popup containing `#submitButton`; if present it clicks that single button, otherwise it proceeds directly to `table#results`. Single-card mode then normalizes and filters Invoice against Transaction ID, selects the unique Sale row, checks its checkbox, opens Issuer Action, logs any visible `Fraud` and `Consumer` actions with frame name/URL and selector, but does not click either action. The run ends as `TABLE_AND_ISSUER_ACTION_PROBE_COMPLETE`. Production can later switch `single_test_target` back to the full pre-submit flow.


## V8.20 exact Case Creation popup/document contract

The trace-viewer iframe shown during inspection is not used as a production selector. The runtime target is the VROL popup page or its real frame after a Fraud/Consumer action is clicked. The bot now verifies `body#mainBody`, `form#mainForm[action="/rolrfc/web/casefolder/submit-create-case.action"]`, `#actionCode`, `#invocationSource[value="TI"]`, and the exact `button#submitButton.allbuttons[value="Submit"][data-param-1="SUBMIT"][data-action="returnDoSubmitSubmit"][accesskey="s"]`. Only that button is clicked. The old popup probe immediately after Transaction Inquiry search Submit has been removed because Case Creation belongs after selecting the Sale row and clicking Fraud/Consumer. The current home-office `TABLE_AND_ISSUER_ACTION_PROBE` still does not click Fraud or Consumer, so no Case Creation popup is expected in that mode.


## V8.21 DataTables Invoice filter and genuinely optional Case Creation

The Transaction ID filter is now found from the full `bodyframe`/DataTables header, not from `table#results`. Primary selector is `#dtheaderSearch input.search-box[aria-label="Transaction ID / Retrieval Ref #"]`, with scroll-head and accessible-name fallbacks. The bot normalizes Invoice, dispatches input/keyup/change, and waits for stable visible rows. Case Creation mode `OPTIONAL` is now genuine: if the exact Case Creation document appears after Fraud/Consumer, its exact Submit is clicked; if absent, the bot continues by probing the direct questionnaire path instead of raising `CASE_CREATION_DOCUMENT_NOT_FOUND_AFTER_ACTION`.


## V8.22 one-time table-column mapping probe

This diagnostic build retains the working Invoice filter, then pauses before row parsing. For every reusable column needed by 10.4, 13.1 or 13.9, the bot resolves the header index, locates the corresponding `#dtheaderSearch` input, writes a visible marker `*<actual header text>`, adds a simple 2px red border, prints the logical field, codes, index, exact selector and purpose, and waits for Enter. The marker is assigned through DOM only; no input/keyup/change event is dispatched, so the Invoice filter and current visible rows remain active. The original filter value is restored before moving to the next column. The run ends with `COLUMN_MAPPING_PROBE_COMPLETE` and saves the mapping in `result.json`.


## V8.23 stable two-frame recovery

The second Transaction Inquiry attempt was being rejected too early because the old TI buttons frame remained visible while `bodyframe` was still on Home. Recovery now waits for both homepage frames to reset: `bodyframe` must contain `action=InvokeHomePage` and `buttons` must return to `/rolol/jsp/buttons_index.jsp`, stable for consecutive polls. After clicking Transaction Inquiry, a split state is not immediately treated as rollback; it must persist beyond a 2500 ms grace period for six consecutive polls. This allows the normal legacy-frame transition to complete while still detecting a genuine persistent rollback.


## V8.24 confirmed schema, code rules and Issuer hover probe

The one-time mapping has been converted into a fixed zero-based schema for the 31 business columns. Hidden fields such as Processing Date, Tran Class, Acq/Iss Network and Merch Country are read by their confirmed DOM indexes even though they had no visible filter marker. Parser requirements are code-specific: 10.4 requires PI/ECI/Entry Mode, 13.1 does not fail when ECI is unavailable, and 13.9 requires Tran Desc/Processing Date/Entry Mode and Cash. After Invoice filtering, rows are parsed with this schema, common/code rules are evaluated, the matched row is selected, Issuer Action is clicked, Chargeback/Dispute is hovered, and the expected Fraud (10.4) or Consumer (13.1/13.9) item is hovered and logged. Fraud/Consumer is never clicked in this probe build.


## V8.25 Transaction ID lifecycle suffix fix

The filtered sample contains Auth Transaction ID `386290349000020` and Sale Transaction ID `386290349000020-01`. The prior exact comparison retained only Auth, causing `SINGLE_TEST_SALE_ROW_NOT_UNIQUE:0`. Invoice matching now removes only a terminal two-digit lifecycle suffix (`-01`, `-02`, etc.) from VROL Transaction ID before comparison. Both Auth and Sale become candidates; 10.4/13.1 select the unique Sale, while 13.9 selects the unique Cash. Raw and normalized IDs plus transaction types are logged before selection.


## V8.26 reliable DataTables Invoice-filter events

Occasional filtering only after a manual click was caused by treating event dispatch as success without verifying that DataTables changed the rows. The bot now first focuses the exact filter and types Invoice with real Playwright keyboard events (`Control+A`, then per-digit typing). It verifies that every visible Transaction ID matches the normalized Invoice. If no effect is observed, the bot commits with Enter + change + blur. A final legacy fallback uses the native input value setter and bubbling input/keydown/keyup/change events with Enter keyboard metadata. Each strategy is accepted only after the visible Transaction IDs prove the filter was applied; otherwise the run fails with `INVOICE_FILTER_NOT_APPLIED` and logs the current input value and visible IDs.


## V8.27 DataTables stability gate before Invoice input

Before typing Invoice, the bot now waits for at least one visible result row, a connected/non-zero-size filter input, no visible DataTables processing overlay, and an unchanged combination of visible row IDs plus filter DOM-node token for four consecutive polls. If DataTables replaces the input during typing and only a partial value is present, the bot never commits that partial value. It reacquires the live input, restores the complete Invoice, then sends Enter/change/blur and verifies visible Transaction IDs. The native-event fallback also uses a freshly reacquired input.

### V8.28 configurable OTP polling provider

OTP retrieval is selected in the **Settings** sheet of `config.xlsx`:

- `otp_polling_mode=OUTLOOK`: keep the existing Outlook Desktop polling flow.
- `otp_polling_mode=FOLDER_FILENAME`: poll `otp_folder_path` for a newly created file whose **filename** contains one unambiguous OTP.
- `otp_folder_file_pattern` defaults to `*.txt`.

The production folder configured in the supplied workbook is `D:\Techcombank\Thanh OPS. Nguyen Duc - VROL_OTP\inbox`. The folder baseline is captured before **Send OTP**, so pre-existing files are ignored. The OTP value is never written to logs.

#### v8.29.6 exact v8.28 Issuer Action hierarchy restoration
- Restores the missing intermediate step from v8.28: after clicking Issuer Action, locate and hover `Chargeback/Dispute`, dispatch `mouseover`, then locate and click `Fraud` or `Consumer`.
- Re-hovers Chargeback/Dispute while polling so the legacy submenu remains open.
- Adds explicit PASS logs for opening Issuer Action, hovering Chargeback/Dispute and clicking the final action.

#### v8.29.7 duplicate-case continuation
- Detects the VROL `ROL-749` potential duplicate-case warning across every open page and frame.
- Clicks `button#okbutton[data-action="disableAndSubmit"]` and continues to the Fraud/Consumer Dispute Questionnaire.
- Captures screenshots before and after OK and emits explicit `DUPLICATE CASE WARNING DETECTED` / `PASS ACK_DUPLICATE_CASE` logs.
- Normal non-duplicate cases continue directly to the questionnaire.

#### v8.29.8 post-duplicate Case Creation Submit
- After acknowledging `ROL-749` with OK, VROL returns to the Case Creation page.
- The bot reacquires the exact Case Creation document and clicks Submit a second time before waiting for the questionnaire.
- Adds `PASS POST_DUPLICATE_CASE_CREATION_SUBMIT` logging and `02g_post_duplicate_case_creation_submit.png` evidence.

#### v8.29.9 questionnaire inspection pause
- After the questionnaire is positively detected, the batch test captures screenshot, questionnaire HTML and an `input/select/textarea/button` control inventory.
- The browser remains open at a console prompt instead of immediately filling fields or closing.
- Enter/C captures again and continues without filling; R recaptures; F explicitly attempts configured fill; Q stops the batch.
- Default `batch_test_questionnaire_inspection_mode=YES` prevents the unverified questionnaire selectors from causing a failure.

#### v8.30.0 confirmed 13.1 questionnaire contract
- Confirms screen text `Consumer Dispute Questionnaire`.
- Validates displayed Visa Transaction ID against source INVOICENUM after leading-zero normalization.
- Validates `input[name="disputeAmount"]` against source `SO TIEN` after comma/currency normalization.
- Selects `select[name="DisputeDueTo"]` value `NR` (`Merchandise/Services Not Received`).
- No Final Submit is clicked. In inspection mode, use console command `F` only after reviewing the screen to execute these validations and fill.

#### v8.30.1 Angular questionnaire select handling
- The 13.1 DisputeDueTo field is polled while Angular renders it and no longer requires the native select to be visibly styled.
- Supports exact name, lowercase legacy name, ng-model and option-value locators.
- Uses forced native `select_option` and dispatches input/change/blur as a fallback.
- Logs a complete select inventory when the field still cannot be resolved.

#### v8.30.2 immediate ROL-749 acknowledgement
- When both the ROL-749 text and visible `#okbutton` are detected, OK is clicked immediately.
- Removes the redundant manual-step gate and pre-click full-page screenshot from this informational warning path.
- Continues to Case Creation, where the existing second Submit logic proceeds to the questionnaire.
