# Tổng hợp thay đổi code VROL — 14/11/2026

## 1. Phạm vi và trạng thái bàn giao

Bản gốc: `vr-imp.7z`. Bản làm việc: thư mục `visa-review/` trong workspace Git hiện tại.

Đợt này thực hiện ba thay đổi nghiệp vụ/kỹ thuật: chặn case lệch số tiền; cho phép tắt trace và ảnh chụp với mặc định tắt; chuẩn hóa CODE CB dạng số. Đi kèm kiểm thử offline, tài liệu cấu hình và báo cáo review. Chưa triển khai lên VROL, chưa đăng nhập Visa/Outlook, chưa tạo case thật, chưa thực hiện Final Submit.

Không coi đây là bản hoàn tất toàn bộ review. Các mục chưa sửa được liệt kê ở phần 8. Nội dung mô tả hiện trạng trong file này được ưu tiên khi đọc cùng báo cáo review trước khi sửa.

## 2. Các quyết định đã xác nhận

- Amount trong Excel khác amount trên VROL: ghi nhận chênh lệch và **dừng case đó trước bước tạo ROL**. Batch tiếp tục với record kế tiếp; không dừng toàn bộ batch.
- Không có dung sai hoặc tự làm tròn khi đối chiếu tiền.
- READY là trạng thái theo định nghĩa nghiệp vụ, không tự mở rộng phạm vi thành yêu cầu điền đầy đủ mọi field. Đợt này không đổi định nghĩa READY.
- Mapping GUID–PAN là 1:1 theo nguồn dữ liệu. Đợt này không sửa parser mapping.
- Giữ phạm vi V6: có thể tạo/recreate ROL trong PRE_SUBMIT_REVIEW; chưa triển khai Final Submit. PI PDF và ROL500 vẫn ngoài phạm vi đợt này.

## 3. Danh sách file thay đổi

| File | Loại | Thay đổi |
| --- | --- | --- |
| `src/vrol/amounts.py` | Mới | Parse tiền, tìm cột tiền theo header, đối chiếu Decimal |
| `src/app.py` | Sửa | Chèn amount gate trước inspect/rule/form; ghi kết quả; truyền settings khi chụp ảnh |
| `src/io/workbook.py` | Sửa | Thêm ba cột BOT amount; lưu CODE CB đã chuẩn hóa |
| `src/vrol/workflow.py` | Sửa | Screenshot tuân thủ master switch; trả evidence ID rỗng nếu tắt |
| `src/auth/legacy_login.py` | Sửa | Điều khiển trace và toàn bộ ảnh login/error theo settings |
| `tests/test_safety.py` | Mới | Sáu test offline, dùng dữ liệu giả và mock browser/COM |
| `README.md` | Sửa | Cách cấu hình, mặc định, định dạng tiền và chạy test; liên kết tài liệu này |
| `review_artifacts/REVIEW_VI.md` | Mới từ đợt review | Báo cáo đánh giá bản gốc, không phải danh sách lỗi còn nguyên sau sửa |
| `review_artifacts/reproduce.py` | Mới từ đợt review | Script tái hiện hành vi bản gốc; không dùng làm regression test bản mới |
| `.gitignore` | Mới | Loại cache, môi trường, cấu hình cá nhân, mapping và artifact runtime khỏi Git |
| `docs/CHANGELOG_2026-11-14.md` | Mới | Tổng hợp chi tiết thay đổi và giới hạn |

`config.xlsx`, requirements, launcher `.cmd`, state store và tài liệu kế hoạch gốc không bị chỉnh sửa so với archive. Các key mới là tùy chọn; thiếu key sẽ dùng mặc định trong code. File cấu hình cá nhân vẫn có trên máy nhưng được ignore khi đưa source vào Git; cần cung cấp cấu hình triển khai riêng cho một checkout mới.

## 4. Chi tiết amount gate

### 4.1. Luồng xử lý

```text
Tìm giao dịch theo PAN/invoice
  → Đọc amount ở cột có header xác định duy nhất
  → Parse amount Excel và VROL
  → So sánh Decimal
      Khác: ghi AMOUNT_MISMATCH → dừng case → record kế tiếp
      Bằng: tiếp tục inspect/rules/form hiện có
      Không xác định được: UNKNOWN_SCENARIO → dừng case
```

Bước so tiền áp dụng chung cho 10.4, 13.1 và 13.9; diễn ra trước `inspect_row()`, `evaluate()` và `open_case_and_prepare()`.

### 4.2. Đọc và parse

- Đọc cell thông qua header trong `thead`, không dò số trong toàn bộ text của row.
- Chấp nhận một header khớp danh sách cấu hình sau khi chuẩn hóa khoảng trắng và chữ hoa/thường.
- Không có hoặc có nhiều header phù hợp: dừng với `AMOUNT_COLUMN_NOT_UNIQUE`.
- Header có colspan hoặc số cột header khác số cell: dừng với `AMOUNT_COLUMN_LAYOUT_UNSUPPORTED`.
- Dùng Decimal; không so bằng float và không áp dung sai.
- Ô Excel dạng số dùng giá trị số; ô text được parse theo separator đã cấu hình.
- Chấp nhận hậu tố tiền tệ đã cấu hình, ví dụ `100,000 VND`; không tự đổi tiền tệ.
- Giá trị rỗng, boolean, NaN/Infinity, text lạ hoặc nhóm chữ số sai định dạng bị chặn với `AMOUNT_INVALID`.
- Cấu hình separator không hợp lệ được báo `AMOUNT_FORMAT_CONFIG_INVALID`.
- Dấu âm được giữ nguyên, không lấy trị tuyệt đối. Zero/âm có thể parse; tính hợp lệ nghiệp vụ tiếp tục phụ thuộc rule tương ứng.

Đây là so sánh hai số tiền, chưa phải implementation đối chiếu cột currency độc lập. Chưa kiểm chứng header/layout trên VROL thật.

### 4.3. Dữ liệu ghi ra

Working workbook bổ sung:

| Cột | Ý nghĩa |
| --- | --- |
| `BOT EXCEL AMOUNT` | Giá trị Excel sau parse |
| `BOT VROL AMOUNT` | Giá trị VROL sau parse |
| `BOT AMOUNT DIFFERENCE` | VROL trừ Excel, giữ dấu |

Ba giá trị được lưu dạng chuỗi Decimal để giữ biểu diễn chính xác trong kết quả audit, không phải cột phục vụ tính tổng Excel.

Khi lệch tiền:

| Trường | Giá trị |
| --- | --- |
| BOT STATUS | BUSINESS_REVIEW |
| BOT CHECKPOINT | AMOUNT_CHECKED |
| BOT SCENARIO / BOT ERROR CODE | AMOUNT_MISMATCH |
| CB reject | AMOUNT_MISMATCH |
| CB result | NOT_SUBMITTED |
| BOT EVIDENCE ID | Rỗng |

Journal ghi `AMOUNT_CHECKED` với `excel_amount`, `vrol_amount`, `amount_difference`, `amount_match`; nếu lệch ghi thêm `BUSINESS_REVIEW` và `hits=["AMOUNT_MISMATCH"]`.

Ví dụ: Excel `100000`, VROL `200,000 VND` → amount difference `100000`, không gọi bước tạo case. Hai chuỗi `100000` và `100,000.00` được coi là bằng nhau.

Nếu không parse được, nhánh lỗi hiện tại ghi `UNKNOWN_SCENARIO` và mã lỗi; không có bộ số tiền đã chuẩn hóa đầy đủ để ghi. Nhánh mismatch không chụp ảnh kể cả khi bật screenshot; bằng chứng của nhánh này là journal và workbook.

## 5. Trace và screenshot

Hai key mới đặt trong sheet **Settings** của `config.xlsx`, theo layout Key / Value / Description:

| Key | Mặc định nếu không có | Tác dụng |
| --- | --- | --- |
| `trace_enabled` | NO | Cho phép bắt đầu Playwright trace |
| `screenshots_enabled` | NO | Master switch cho ảnh standalone và screenshot trong trace |

- Khi trace tắt, không gọi tracing.start và không xuất trace.zip mới.
- Khi ảnh tắt, ảnh search, ready, unknown, login, VROL authenticated, logout và lỗi đều không được chụp.
- `screenshot_on_success=YES` có sẵn không vượt qua master switch mới.
- Khi không có ảnh, evidence ID để trống; không ghi tên một file chưa được tạo.
- Nếu bật trace nhưng tắt ảnh, trace vẫn chứa DOM snapshots/sources/action data. Đây không phải cơ chế redaction hay bảo đảm trace không chứa thông tin nhạy cảm.
- Không xóa artifact được tạo trong các lần chạy trước.

Phải đặt hai key trên ở **Settings** để login và batch dùng chung giá trị. Legacy login chỉ đọc Settings; không đặt các key này riêng trong RunSettings/Selectors hoặc khai báo trùng giá trị khác nhau giữa các sheet.

## 6. Cấu hình amount

Các key tùy chọn cũng nên đặt trong Settings:

| Key | Mặc định |
| --- | --- |
| `amount_column_headers` | `Tran Amount` hoặc `Transaction Amount` hoặc `Amount`, ngăn cách bằng ký tự pipe |
| `amount_currency` | VND |
| `excel_amount_thousands_separator` | dấu phẩy `,` |
| `excel_amount_decimal_separator` | dấu chấm `.` |
| `vrol_amount_thousands_separator` | dấu phẩy `,` |
| `vrol_amount_decimal_separator` | dấu chấm `.` |

Mặc định phù hợp `100,000.00`. Nếu UI hiển thị `100.000,00`, đặt separator hàng nghìn là `.` và thập phân là `,`. Không tự suy luận locale. Cần xác nhận cấu hình này trước UAT để tránh diễn giải sai chuỗi có dấu phân cách.

## 7. Chuẩn hóa CODE CB và kiểm thử

Trước sửa: `prepare()` chuyển code thành chuỗi để lọc, nhưng record lại giữ ô số gốc. Do đó so sánh với `'10.4'`, `'13.1'`, `'13.9'` có thể sai.

Sau sửa: lưu `rec['code'] = code` sau bước chuẩn hóa. Các nhánh hiện có nhận chuỗi nhất quán; numeric 10.4 không còn rơi vào Consumer chỉ vì sai kiểu dữ liệu. Đợt này không thay nội dung rule ECI/Cash/form.

Chạy từ thư mục project sau khi đã cài dependencies:

```bash
python -m unittest discover -s tests -v
python -m compileall -q src main.py
```

Kết quả kiểm thử offline ngày 14/11/2026: **6 test PASS**, kiểm tra cú pháp PASS.

| Test | Phạm vi |
| --- | --- |
| test_exact_comparison | Bằng/khác amount, nhóm nghìn, hậu tố VND, chênh lệch nhỏ |
| test_explicit_locale | Format dấu chấm/phẩy được chỉ định, số 0 và số âm |
| test_invalid_amounts_stop | None, boolean, rỗng, nhóm nghìn sai, NaN/Infinity và chuỗi không hợp lệ |
| test_column_lookup | Đọc đúng cell theo header; từ chối header thiếu/trùng |
| test_capture_controls | Mặc định không start/stop trace hoặc chụp ảnh; bật tường minh có tác dụng |
| test_batch_mismatch_stops_before_inspect_and_create | Workbook giả, login/search mock; lệch tiền không gọi inspect/create; ghi journal và workbook đúng; không tạo ảnh; numeric 13.1 thành chuỗi |

Test dùng mock cho Windows COM và browser, không truy cập tài khoản thật. Chưa có end-to-end test Windows/Outlook/VROL; chưa kiểm tra toàn bộ hành vi UI hoặc mọi rule nghiệp vụ. Không chạy script `review_artifacts/reproduce.py` như regression suite vì script đó cố tình assert lỗi trước khi sửa.

## 8. Các việc còn tồn đọng

1. **Resume xuyên run:** đề xuất job theo input và kho trạng thái chung mới ở mức thiết kế; chưa implement. Journal vẫn theo run mới.
2. **PI/ECI/Assoc Dispute:** parser cũ vẫn đọc toàn row; cần chuyển sang header/cell. Chỉ amount đã có parser riêng.
3. **Xác nhận tạo case/READY:** chưa thêm postcondition tạo case; vẫn có placeholder `CREATED_NOT_PARSED` và các field optional bị bỏ qua.
4. **Sale Rev/Sale/currency:** chưa bổ sung common checks tương ứng. Amount gate không thay thế các check này.
5. **Mapping:** giữ parser hiện có theo giả định nguồn 1:1; chưa thêm chặn cứng nếu nguồn vi phạm giả định.
6. **Selector/page transition:** chưa kiểm chứng popup/frame và selector form trên môi trường thật.
7. **Cờ tạo case/submit:** chưa bổ sung enforcement độc lập cho `allow_rol_case_creation` hay action classifier.
8. **Bảo vệ artifact:** đã thêm công tắc tắt, chưa thêm mask/redact, phân quyền, thời hạn lưu hoặc lọc exception nguyên văn.
9. **Vận hành:** chưa sửa exit code batch, workbook save atomic, duplicate headers hay wait/filter transaction.

Ưu tiên tiếp theo: kiểm chứng amount column/format bằng dữ liệu test; sửa parser các trường còn lại và xác nhận kết quả create-case; triển khai resume theo input; sau đó mới UAT batch nhỏ có giám sát.

## 9. Tổ chức source và Git

Code, tests và docs đã nằm cùng project. README liên kết đến tài liệu này. `.gitignore` loại các file phát sinh và cấu hình cá nhân khỏi source control nhưng không xóa các file local.

Tại thời điểm tổng hợp, project nằm trong workspace Git cha; chưa có Git remote hay commit ban đầu. Không tạo repo GitHub, commit hoặc push trong đợt này. Không thay đổi các project khác trong workspace.
