# Business rules trích từ dự án sync: 13.9, 13.1 và 10.4

> Tài liệu này trích rule **sync gốc**. Native async đã triển khai yêu cầu mới
> của người dùng: lọc tuổi >15 ngày tại runtime; PI=Yes được quét toàn GUID
> trước uniqueness và group-stop. Xem
> [báo cáo triển khai](NATIVE_ASYNC_IMPLEMENTATION_2026-11-19.md) để phân biệt
> override mới với rule sync trong phần trích dẫn bên dưới.

Ngày trích xuất: 19/11/2026. Nguồn: `visa-review-v9.0.60/visa-review-v9.0.60`.

Tài liệu mô tả hành vi hiện có trong mã nguồn, phục vụ chuyển sang async. Luồng chính được lấy làm chuẩn là `run_case_review.py → precheck_guid_group() → open_case_and_prepare() → fill_test_questionnaire()`. Các giá trị questionnaire dưới đây là preset/mặc định trong code; chưa đọc cấu hình workbook để xác nhận giá trị cấu hình thực tế. Chưa chạy VROL hoặc test cần OTP.

## 1. Điều kiện đầu vào chung

| ID | Điều kiện / hành động | Phạm vi |
|---|---|---|
| IN-01 | Đọc Sheet1, header dòng 2, dữ liệu từ dòng 4. Chỉ chọn CHECK SALE = SALE và VALID CHARGEBACK = Y. | Dòng nguồn |
| IN-02 | Phải có GUID, BUT TOAN và INVOICENUM; CODE CB thuộc 13.9, 13.1, 10.4. Dòng thiếu các trường này hoặc code ngoài phạm vi không được đưa vào nhóm. | Dòng nguồn |
| IN-03 | Gom các dòng đủ điều kiện theo GUID; giữ thứ tự dòng nguồn trong nhóm. | GUID |
| IN-04 | PAN lấy từ mapping GUID → full PAN; thiếu mapping thì UNDEFINED_CASE / GUID_PAN_MAPPING_NOT_FOUND, không Issuer Action. | GUID |
| IN-05 | Start Date là ngày nhỏ nhất trong các ngày nguồn có dạng YYYYMMDD của nhóm; đổi sang MM/DD/YY khi điền Inquiry. Nhóm không có ngày phù hợp → GROUP_START_DATE_MISSING. Ngày không tồn tại có thể lỗi khi chuyển đổi. | GUID |
| IN-06 | Bỏ GUID đã có trong reviewed_guids registry. | GUID |
| IN-07 | Khi ROL500 preflight bật, bất kỳ dòng eligible nào của GUID có ALREADY_CHARGEBACK_IN_ROL500 thì bỏ toàn bộ GUID. | GUID |
| IN-08 | PAN bắt đầu bằng 5 → NO_CHARGEBACK_REQUIRED / NON_VISA_PAN_PREFIX_5, bỏ trước Inquiry. Code không có gate tổng quát yêu cầu mọi PAN còn lại phải bắt đầu bằng 4. | GUID |

Nguồn: `src/review/guid_group.py:18`, `:160`; `run_case_review.py:399`, đặc biệt đoạn dựng lại queue sau ROL500 và kiểm tra PAN đầu 5.

Sync loader không có điều kiện tuổi giao dịch < 120 ngày. Không đưa gate tuổi đang có ở async vào tập rule sync này.

## 2. Xác định giao dịch của invoice

| ID | Rule |
|---|---|
| MATCH-01 | Invoice dùng để tìm kiếm được trim và bỏ số 0 đầu; invoice rỗng hoặc chỉ có số 0 là lỗi. |
| MATCH-02 | Match chính xác Transaction ID với invoice sau chuẩn hóa; Transaction ID được bỏ khoảng trắng, số 0 đầu và hậu tố lifecycle -NN, ví dụ -01. Không match substring; không dùng Retrieval Ref làm lựa chọn thay thế trong precheck. |
| MATCH-03 | 13.1 và 10.4: phải có đúng một dòng Sale hoặc Sale - WT. Sale Dispute Financial - WT không phải dòng Sale gốc. |
| MATCH-04 | 13.9: phải có đúng một dòng Cash. |
| MATCH-05 | Không có hoặc nhiều hơn một dòng eligible → UNDEFINED_CASE / ELIGIBLE_ROW_NOT_UNIQUE; không đi tiếp PI/Issuer. |
| MATCH-06 | Bảng được validate theo schema tối thiểu 31 cột và header đã xác nhận. Tuy nhiên precheck đang bỏ qua exception parse từng hàng; lỗi schema/hàng có thể biểu hiện cuối cùng thành không tìm được eligible row. |

Nếu gặp `ROL-897: No matching transactions found`, precheck trả `MANUAL_REVIEW_REQUIRED / ROL_897_NO_MATCHING_TRANSACTIONS`, không chọn giao dịch hoặc Issuer Action. Runner có auto-action S để tiếp tục nhóm sau khi auto progress bật; việc tự chuyển nhóm không đồng nghĩa đã chứng minh không cần chargeback.

Nguồn: `src/vrol/workflow.py:908`; `src/vrol/transaction_table.py:155`, `:188`; `src/review/guid_group.py:73`, `:160`.

## 3. Ma trận quyết định theo code

Các gate PI/refund/Assoc/ECI dưới đây chỉ được xét sau khi đã đạt MATCH-03 hoặc MATCH-04.

| Nội dung | 13.9 | 13.1 | 10.4 |
|---|---|---|---|
| Dòng eligible | Cash | Sale hoặc Sale - WT | Sale hoặc Sale - WT |
| Nguồn PI | Cột PI trên dòng eligible của bảng VROL | Như 13.9 | Như 13.9 |
| PI = Yes | Đưa vào nhánh tải PDF; bỏ các gate còn lại của invoice này | Như 13.9 | Như 13.9 |
| Nếu không PI, loại giao dịch làm dừng GUID | Cash Rev | Credit | Credit |
| Nếu không PI, Assoc Dispute = D trên dòng eligible | Dừng GUID: Duplicate | Dừng GUID: Duplicate | Dừng GUID: Duplicate |
| Nếu không PI, Assoc Dispute rỗng | Qua gate này | Qua gate này | Qua gate này |
| Nếu không PI, Assoc Dispute có giá trị khác rỗng/D | UNDEFINED_CASE, yêu cầu review | Như 13.9 | Như 13.9 |
| Nếu không PI, MOTO/ECI rỗng, 5 hoặc 6 | Không có gate này | Không có gate này | Dừng GUID: lỗi dữ liệu |
| MOTO/ECI khác rỗng/5/6 | Không được kiểm tra ở gate này | Không được kiểm tra ở gate này | Qua gate ECI; code chưa có whitelist giá trị khác |
| Nhánh Issuer nếu nhóm đủ điều kiện và không PI pending | Consumer | Consumer | Fraud |

**Thứ tự thực thi trong một invoice:**

1. Match invoice và yêu cầu đúng một eligible row.
2. PI = Yes → ghi pending evidence và chuyển sang invoice tiếp theo.
3. Có Credit hoặc Cash Rev theo code → dừng nhóm.
4. Assoc Dispute = D → dừng nhóm; giá trị khác rỗng/D → undefined.
5. Riêng 10.4: ECI rỗng/5/6 → dừng nhóm.
6. Check checkbox giao dịch; yêu cầu checkbox vừa chọn thực sự checked; lưu Transaction ID vào danh sách tích lũy.

Nguồn chính: `src/review/guid_group.py:184`, `:214`, `:228`, `:241`, `:248`, `:257`, `:264`.

### 3.1. Các giới hạn cần giữ đúng khi diễn giải

- PI chỉ nhận diện Yes sau trim và không phân biệt hoa/thường. Mọi giá trị khác, kể cả rỗng hoặc giá trị lạ, đều vào nhánh không PI; precheck chưa có gate PI thiếu/sai giá trị.
- Rule refund/reversal tìm trong tất cả hàng match cùng invoice, không chỉ hàng eligible, nhưng chỉ chạy sau uniqueness và khi PI của eligible row không phải Yes.
- Tran Type được so không phân biệt hoa/thường. Credit và Cash Rev là các giá trị chính xác trong tập loại trừ; không tự mở rộng thành mọi tên có chữ Credit/Rev. Sale Rev chưa có gate loại trừ riêng trong precheck.
- Assoc Dispute được quyết định từ dòng eligible, không phải mọi dòng phụ match invoice.
- Comment nói Assoc D phải kiểm tra trước uniqueness; code hiện kiểm tra uniqueness trước. Tài liệu giữ thứ tự của code.
- PI không miễn gate cho cả GUID. Ví dụ invoice đầu PI Yes, invoice sau không PI có Credit vẫn làm dừng GUID.

## 4. Kết quả ở cấp GUID

| ID | Điều kiện | Kết quả |
|---|---|---|
| GROUP-01 | Gặp Credit cho 13.1/10.4 hoặc Cash Rev cho 13.9 ở gate loại trừ | NO_CHARGEBACK_REQUIRED; reason GROUP_REJECT_TRAN_TYPE; CB reject = Refund - Tran Type = <loại giao dịch>. |
| GROUP-02 | Assoc Dispute = D | NO_CHARGEBACK_REQUIRED; reason GROUP_CONTAINS_ASSOC_DISPUTE_D; CB reject = Duplicate - Assoc Dispute = D. |
| GROUP-03 | ECI rỗng/5/6 đối với 10.4 | NO_CHARGEBACK_REQUIRED; reason GROUP_REJECT_MOTO_ECI; CB reject = Lỗi dữ liệu - MOTO/ECI rỗng hoặc = 5/6. Đây là cách code phân loại hiện tại dù nguyên nhân là lỗi dữ liệu. |
| GROUP-04 | Nhóm dừng bởi các gate trên | Không Issuer Action; các invoice chưa xét nhận NOT_SCANNED_AFTER_GROUP_STOP. Checkbox trước đó có thể đã được chọn nhưng nhóm không được phép đi tiếp. |
| GROUP-05 | Scan xong không dừng và có ít nhất một PI pending | READY_FOR_PI_EVIDENCE_REVIEW; chỉ tải chứng từ PI pending; không Issuer Action cho GUID đó. Điều này cũng áp dụng nhóm có cả invoice PI và không PI. |
| GROUP-06 | Scan xong không dừng, không PI pending, có một giao dịch selected | READY_FOR_ISSUER_ACTION_REVIEW. |
| GROUP-07 | Như trên nhưng nhiều giao dịch selected | READY_FOR_MULTI_ISSUER_ACTION_REVIEW; dùng multi-selection của nhóm. |
| GROUP-08 | Nhóm chỉ gồm 10.4 | Planned Issuer Action: Chargeback/Dispute → Fraud. |
| GROUP-09 | Các code của nhóm thuộc tập 13.1/13.9 | Planned Issuer Action: Chargeback/Dispute → Consumer. Code cho phép nhóm trộn 13.1 và 13.9. |
| GROUP-10 | Nhóm trộn 10.4 với 13.1 hoặc 13.9, tới nhánh Issuer | Planned action undefined; runner chuyển LOGIC_REVIEW_REQUIRED / UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES, không mở Issuer. |

Nhánh PI thực hiện View → Tran Details → Save as PDF. Tải đủ → `PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION`; tải lỗi → `PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED`, giữ thông tin invoice lỗi. Việc “không Issuer Action” không đồng nghĩa bot không cần tải chứng từ.

Nguồn: `src/review/guid_group.py:277`; `run_case_review.py:522`.

## 5. Preset questionnaire theo từng code

### 5.1. Code 13.9

Màn hình yêu cầu: **Consumer Dispute Questionnaire**.

| Trường | Giá trị từ code |
|---|---|
| Member Case Number | BUT TOAN của record đại diện; fallback member_case nếu hàm được gọi với record kiểu khác |
| DisputeDueTo | Mặc định CL; có thể đổi bằng setting 13_9_dispute_due |
| WhatWasNotReceived | Mặc định C; có thể đổi bằng setting 13_9_what_was_not_received |
| Amount comparison | Bị runner Case Review tắt; không sửa amount trên form trong hàm fill |
| Final Submit | Hàm fill chỉ kiểm tra nút, không click |

Code không xác nhận label hiển thị của CL/C bằng một bảng nghĩa cố định; lưu chính xác option value khi chuyển async.

Nguồn: `src/vrol/workflow.py:116`, `:253`.

### 5.2. Code 13.1

Màn hình yêu cầu: **Consumer Dispute Questionnaire**. Visa Transaction ID hiển thị phải khớp invoice của record đại diện sau khi chỉ giữ chữ số và bỏ số 0 đầu.

| Trường | Giá trị từ code |
|---|---|
| Member Case Number | BUT TOAN của record đại diện |
| DisputeDueTo | Mặc định NR; setting 13_1_dispute_due |
| WhatWasNotReceived | Mặc định S, comment mô tả Services; setting 13_1_what_was_not_received |
| NonFiatCurrencyNotDelivered | N, cố định trong hàm fill |
| ThirdPartyGiftCardInd | N, cố định |
| DidMerchantCancelInd | N, cố định |
| MerchantInBankruptcyLiquidationInd | N, cố định |
| DidCardholderCancelPriorExpectedDate | N, cố định |
| CardholderAttemptToResolve | Y, cố định |
| PurchasedInfo | Mô tả mặc định bên dưới; setting 13_1_purchased_info |
| ExpectedReceiptDate | NGAY GD của record đại diện, YYYYMMDD → MM/DD/YYYY; không phải tự tính ngày nhỏ nhất của GUID ở bước này |
| ExpectedReceiptTime | Setting 13_1_expected_receipt_time; mặc định rỗng, bỏ qua khi rỗng |
| Amount comparison | Runner Case Review tắt; code vẫn tìm và đọc dispute amount ở nhánh 13.1 |
| Final Submit | Chỉ kiểm tra nút, không click trong hàm fill |

PurchasedInfo mặc định:

> The cardholder has filed a dispute for the above-mentioned transaction, claiming that the transaction was not completed successfully and that no related goods/services were received.

Đây là các câu trả lời happy case đã được lập trình sẵn, không được suy ra từ bằng chứng giao dịch hoặc phản hồi thực tế của khách hàng trong hàm này.

Nguồn: `src/vrol/workflow.py:87`, `:168`, `:226`.

### 5.3. Code 10.4

Màn hình yêu cầu: **Fraud Dispute Questionnaire**, có điều kiện hiển thị **10.4 Fraud - Card Absent Environment**.

| Trường | Giá trị từ code |
|---|---|
| Member Case Number | BUT TOAN của record đại diện |
| CardholderDeniesAuthorizingInd | Checked = True, cố định |
| FraudTypeCode | Mặc định FT6; setting 10_4_fraud_type |
| Amount comparison | Runner Case Review tắt; không sửa amount trên form trong hàm fill |
| Final Submit | Chỉ kiểm tra nút, không click trong hàm fill |

Không suy diễn ý nghĩa chi tiết của FT6 từ log; hàm select thực tế cho phép setting thay đổi giá trị, dù log happy case đang ghi cứng FT6.

Nguồn: `src/vrol/workflow.py:134`, `:218`.

### 5.4. Điều kiện và giới hạn chung khi tạo case

- Nếu auto progress bật (mặc định YES trong code), trạng thái ready PI/Issuer được tự chọn action P; nếu tắt thì runner hỏi người dùng.
- Issuer → Chargeback/Dispute → Fraud/Consumer. Case Creation Submit được click nếu có màn hình này; VROL cũng có thể vào questionnaire trực tiếp.
- Gặp cảnh báo potential duplicate ROL-749: code tự bấm OK, rồi Submit lại Case Creation để tiếp tục. Hành vi này khác gate Assoc Dispute = D vốn dừng nhóm.
- Phải đọc được VROL Case Number và đúng questionnaire để trả ready.
- Với multi-selection, code hiện dùng item/transaction đầu tiên làm record đại diện để mở menu và điền một questionnaire; chưa có rule xác nhận các invoice cùng BUT TOAN/ngày hoặc cùng preset. Nhóm trộn 13.1/13.9 dùng code của item đại diện để chọn bộ câu trả lời.
- Runner đặt validate_dispute_amount = NO. Nếu gọi helper với YES thì yêu cầu amount kỳ vọng, amount hiển thị parse được và bằng nhau; đây không phải gate đang bật trong luồng Case Review.
- Runner đặt allow_final_submit = NO trước bước tạo hồ sơ. Checkpoint tự động mặc định là QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT.
- Sync còn nhánh review thủ công: nếu người dùng chọn T và gõ đúng SUBMIT thì runner có thể gọi final submit thật. Vì vậy “không Final Submit” là checkpoint tự động hiện tại; không phải toàn bộ chương trình không có khả năng gửi thật.
- Lỗi tạo case/questionnaire → LOGIC_REVIEW_REQUIRED và chụp bằng chứng. Không được hiểu là kết luận nghiệp vụ không cần chargeback.

Nguồn: `src/vrol/workflow.py:1369`, `:1438`; `run_case_review.py:141`, `:401`, `:563`.

## 6. Bộ rule khác trong cùng dự án: evaluate()

`src/vrol/workflow.py:1031` có hàm `evaluate()`, được gọi từ `src/app.py`, `single_test.py` và `batch_test.py`. Luồng GUID `run_case_review.py` không gọi hàm này.

| Nội dung | Luồng GUID precheck | Helper evaluate |
|---|---|---|
| Response Code khác 00, có giá trị | Không có gate loại trừ | Thêm hit TRANSACTION_NOT_APPROVED |
| Assoc Dispute M | UNDEFINED_ASSOC_DISPUTE_VALUE nếu không PI | Hit ASSOC_DISPUTE_M |
| Assoc Dispute D | Dừng nhóm nếu không PI, sau uniqueness/refund | Hit ASSOC_DISPUTE_D |
| Sale - WT | Được chấp nhận cho 13.1/10.4 | Không bằng sale nên bị hit REQUIRES_SALE |
| PI rỗng đối với 10.4 | Nhánh không PI, tiếp tục xét các gate khác | Hit 10_4_PI_DATA_MISSING |
| PI Yes vượt qua ECI/Assoc/refund | Có, sau uniqueness | Không có nhánh ưu tiên tương đương |
| Credit/Cash Rev cùng invoice làm dừng nhóm | Có | Không có logic cấp nhóm tương đương |

Khi chuyển async theo luồng GUID, không tự gộp thêm rule từ evaluate vào precheck; đó sẽ là thay đổi nghiệp vụ.

## 7. Ví dụ chốt hành vi

| Tình huống | Hành vi hiện tại của luồng GUID |
|---|---|
| 13.9: một Cash, không PI, có Cash Rev cùng invoice | Dừng GUID: GROUP_REJECT_TRAN_TYPE |
| 13.1: một Sale - WT, không PI, Assoc rỗng, không Credit | Chọn giao dịch; nếu cả nhóm đạt và không PI pending thì Consumer |
| 10.4: một Sale, PI Yes, ECI 5, Assoc D, có Credit | Invoice này vào nhánh PI; bỏ qua ba gate ECI/Assoc/Credit |
| 10.4: hai Sale, PI Yes | ELIGIBLE_ROW_NOT_UNIQUE trước khi xét PI |
| 10.4: một Sale, PI không phải Yes, Assoc rỗng, ECI 6 | Dừng GUID: GROUP_REJECT_MOTO_ECI |
| 13.1: invoice A PI Yes; invoice B không PI có Credit | B làm dừng GUID; nhóm không đi tới trạng thái ready PI |
| 13.1: invoice A PI Yes; invoice B không PI nhưng đủ điều kiện | Scan xong → tải PI của A; không Issuer cho GUID này |
| Một Sale, không PI, Response Code 05, các gate khác đều qua | Precheck chưa chặn bởi Response Code; evaluate sẽ có hit TRANSACTION_NOT_APPROVED |
| Cùng GUID có 13.1 và 10.4, không PI, tất cả invoice qua gate | UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES ở runner |

Các ví dụ là diễn giải mã, chưa phải kết quả chạy test. Các điểm cần xác nhận nghiệp vụ trước khi thay đổi gồm: ưu tiên uniqueness/Assoc, PI trộn trong GUID, mixed 13.1/13.9, Response Code, PI rỗng, preset questionnaire và gate tuổi giao dịch.

## 8. Yêu cầu người dùng bổ sung sau test ngày 19/11/2026

- Chỉ xử lý giao dịch có tuổi **> 15 ngày** so với ngày bot chạy, tức ít nhất 16 ngày. Người dùng xác nhận upstream đã chịu trách nhiệm loại giao dịch chưa đủ tuổi; runtime này tiếp tục nguyên nhóm GUID, không lọc tuổi lần hai. Đây là hợp đồng đầu vào bổ sung, không phải gate đã có trong sync loader.
- PI cuối cùng phải nằm tại **run/documents**, tên **invoice nguồn_last4_TERMOWNER.pdf**; giữ số 0 đầu của invoice nguồn.
- Visa hỏi OTP một lần trong ngày theo vận hành đã xác nhận. Tái sử dụng phiên đã xác thực; khi giao diện yêu cầu mới lấy mã mới qua polling thư mục cấu hình trong config.xlsx.
- Không tách hoặc hoãn GUID theo tuổi ở runtime này. Trước khi test lại cần đối soát đúng file đầu ra upstream vì dữ liệu hiện có còn các ngày chưa quá 15 ngày; không tự sửa dòng/nhóm để làm khớp giả định.

Chi tiết triển khai và tiêu chí kiểm thử nằm trong [ASYNC_REPAIR_AND_MIGRATION_PLAN_2026-11-19.md](ASYNC_REPAIR_AND_MIGRATION_PLAN_2026-11-19.md). Các rule được trích nguyên trạng từ sync ở mục 1–7 vẫn là tham chiếu cho phần nghiệp vụ còn lại.
