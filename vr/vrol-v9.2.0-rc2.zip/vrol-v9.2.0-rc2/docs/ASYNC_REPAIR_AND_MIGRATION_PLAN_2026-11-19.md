# Phương án sửa sau test và chuyển sang Playwright async

> **Đã được thay thế bởi yêu cầu và triển khai mới:** xem
> [NATIVE_ASYNC_IMPLEMENTATION_2026-11-19.md](NATIVE_ASYNC_IMPLEMENTATION_2026-11-19.md).
> Nội dung dưới đây là bản phương án lịch sử. Yêu cầu cuối cùng là PI lưu chính
> trong `groups/<GUID>/documents` và copy vào `documents` của run; lọc tuổi >15
> ngày thêm một lần tại bot; PI=Yes được ưu tiên trước mọi quyết định tra soát
> trong GUID. Native async, CMD, Rich và nhánh Final Submit theo config đã triển khai.

Ngày cập nhật: 19/11/2026. Căn cứ: luồng sync v9.0.60, test headful `20261119_214805_3a3fe874`, và yêu cầu bổ sung của người dùng sau test.

Trạng thái: phương án triển khai; lượt này chỉ cập nhật tài liệu, chưa sửa runtime, config hoặc chạy lại giao dịch.

## 1. Yêu cầu đã chốt và nguyên tắc đối chiếu

1. File PI cuối cùng nằm trong **`<run_dir>/documents/`**, dùng đúng tên **`<invoice nguồn>_<4 số cuối full PAN>_<TERMOWNER>.pdf`**.
2. Ngày giao dịch phải cũ hơn ngày bot chạy **hơn 15 ngày**: `age_days > 15`, tức ít nhất 16 ngày theo lịch. Người dùng đã xác nhận **upstream chịu trách nhiệm loại giao dịch chưa đủ tuổi**. Bản này tiếp tục với nguyên nhóm GUID nhận từ upstream, không bổ sung cơ chế tách/hoãn dòng theo tuổi.
3. Theo vận hành người dùng xác nhận, Visa hỏi OTP một lần trong ngày. Tái sử dụng phiên/profile đã xác thực; chỉ chạy provider polling thư mục khi màn hình VROL thực sự yêu cầu OTP. Không chủ động yêu cầu OTP cho từng tab hoặc từng GUID.
4. Các rule lựa chọn giao dịch, PI, refund/reversal, Assoc Dispute, ECI, group stop, nhánh Fraud/Consumer và preset questionnaire phải bám luồng sync theo GUID.
5. Hai thay đổi được người dùng bổ sung là tuổi giao dịch và nơi lưu/tên file. Không diễn giải chúng thành rule đã có trong bản sync gốc. Bản sync và bộ tài liệu trích rule gốc được giữ làm tham chiếu.
6. Mục tiêu cuối: browser automation trong native path dùng Playwright async trực tiếp, mỗi worker quản lý trang và chuỗi popup của mình. Bridge sync/CDP hiện tại chỉ là backend chuyển tiếp để đối chiếu/quay lui giữa các lượt chạy.

## 2. Bằng chứng và vấn đề cần sửa

| Phát hiện | Điều đã biết | Hướng sửa |
|---|---|---|
| PI chưa được lưu cuối cùng | Cả 8 invoice W03 báo `name 'shutil' is not defined`; code dùng os.replace cũng chưa import os | Sửa lỗi import ở backend hiện tại, kiểm tra persistence trước khi đóng popup |
| Sai phạm vi documents | Hàm PI đang chọn `group_dir / 'documents'` | Một nơi lưu chính thức là `run_dir / 'documents'`; folder GUID chỉ lưu manifest/log/ảnh |
| Tên file chưa hoàn tất | Công thức tên ở backend đã có invoice/last4/merchant nhưng nhánh publish chưa chạy thành công | Định nghĩa một hàm dựng tên dùng chung, xác thực input, dùng invoice nguồn và TERMOWNER |
| Fraud timeout | Diagnostic READY_FOR_FINAL_SUBMIT_REVIEW_NOT_REACHED; ảnh page07 vẫn ở Case Creation có Create Dispute checked và nút Submit | Gắn đúng popup/frame, ghi nhận Submit thực sự và chờ transition cụ thể; chưa kết luận nguyên nhân gốc là thiếu thời gian |
| Nhận diện popup còn toàn context | PI quét context.pages; Case Creation dùng trang mới nhất/full scan | Thay bằng registry quyền sở hữu trang, sự kiện theo Page và xác minh transaction/case |
| Download thay cấu hình chung | Mỗi invoice đổi Browser.setDownloadBehavior | Native ưu tiên download event/save_as của client sở hữu browser, không đổi đường dẫn chung theo invoice |
| Kết quả PI retry bị ghi completed | W03 review_required=false và folder __COMPLETED__; summary chỉ đếm một nhóm cần review | Chuẩn hóa bảng trạng thái, báo lỗi/retry riêng; batch kết thúc không đồng nghĩa test đạt |
| Ngày và queue | Async lấy dates[0], lọc ROL500 theo dòng; sync dùng min ngày và loại cả GUID có dòng đã chargeback | Sửa parity này trước khi đánh giá tốc độ |
| Artifact path sau rename | Screenshot path còn trỏ folder GUID trước rename | Tránh di chuyển file chính thức; cập nhật đường dẫn/manifest sau finalize |

Không sử dụng riêng việc file có kích thước > 0, `%PDF-` hoặc tên đúng để kết luận nội dung thuộc đúng invoice.

## 3. Contract ngày giao dịch

### 3.1. Cách tính

- Nguồn ngày: NGAY GD của dòng Excel, parse YYYYMMDD và kiểm tra ngày tồn tại.
- Chốt `run_business_date` một lần khi bắt đầu run theo múi giờ Việt Nam, lưu trong summary. Run đi qua nửa đêm không tự đổi tiêu chí giữa các worker.
- `age_days = run_business_date - transaction_date`, tính bằng số ngày lịch.
- Điều kiện mới: chỉ xử lý nếu `age_days > 15`; không dùng `>= 15` và không tính theo số giờ chờ của phiên browser.
- Upstream sở hữu quyết định loại dòng chưa đủ tuổi. Bản này chỉ đối soát hợp đồng đầu vào, không gán NO_CHARGEBACK_REQUIRED, deferred hoặc tự cắt bớt dòng của GUID theo ngày.

Ví dụ nếu ngày chạy là **19/11/2026**:

| NGAY GD | Tuổi | Điều kiện > 15 ngày |
|---|---|---|
| 05/11/2026 | 14 | Chưa xử lý |
| 04/11/2026 | 15 | Chưa xử lý |
| 03/11/2026 | 16 | Đủ tuổi |

### 3.2. GUID có nhiều ngày

**Đã chốt theo trả lời người dùng:** upstream loại giao dịch chưa đủ tuổi; xử lý nguyên nhóm GUID nhận được. Không thêm bộ lọc > 15 ngày lần hai, không chia nhóm hoặc hoãn cả nhóm tại runtime này. Start Date của Inquiry là ngày nhỏ nhất của nhóm nhận từ upstream, đúng cách sync đang làm.

- Giữ nguyên group stop PI/refund/Assoc/ECI; không tự tạo một group mới cho từng invoice để né group stop.
- ROL500 vẫn loại ở cấp GUID theo sync, không loại từng dòng để tạo một nhóm thiếu giao dịch.
- Giữ registry ở cấp GUID theo hợp đồng hiện tại; không cần thiết kế trạng thái partial/deferred chỉ vì policy tuổi thuộc upstream. Khi upstream có thể phát sinh invoice mới cho GUID đã xử lý, đối chiếu review_key/fingerprint để tránh registry cũ che mất dữ liệu mới; đây là vấn đề resume riêng.

**Đối soát dữ liệu trước lượt test tiếp:** dùng ngày 19/11/2026 và NGAY GD, kiểm tra đọc-only bằng loader hiện tại cho thấy:

| Nguồn | GUID qua bộ lọc runtime hiện tại | Dòng tuổi 0–15 ngày trong tập đó | GUID pha trộn tuổi |
|---|---|---|---|
| File đang cấu hình 09_CHARGEBACK_CLASSIFIED.xlsx | 2.003 | 2.097 | 62 |
| Snapshot sau ROL500 của test 20261119_214805_3a3fe874 | 1.729 | 1.355 | 53 |

Các số này không phải toàn bộ workbook, mà là tập còn lại sau các bộ lọc sẵn có của loader. Chưa kết luận upstream sai: cần xác minh đúng phiên bản đầu ra upstream, cột ngày và cờ eligible trước khi chạy lại. Không tự lọc sửa dữ liệu hoặc thay đổi nhóm để che sự khác biệt giữa nguồn hiện có và hợp đồng người dùng mô tả. Lượt lập phương án không đổi file đầu vào.

### 3.3. Cận 120 ngày đang có ở async

Async hiện loại tuổi >= 120 ngày; sync loader không có gate này. Cần rà soát xem cận trên này có nằm trong hợp đồng upstream không; chưa có xác nhận để tự xóa hoặc mở rộng. Không gộp nó với rule > 15 ngày và không mô tả là rule sync. Nếu được giữ, phải xử lý minh bạch để không âm thầm cắt bớt dòng của nhóm. Đây là khác biệt cũ cần tách khỏi việc port async.

## 4. Contract file PI

### 4.1. Đường dẫn và tên

```text
runtime/async_parallel/<run_id>/
  documents/
    <invoice_nguon>_<last4>_<TERMOWNER>.pdf
  groups/<GUID hoặc folder finalized>/
    guid_case.log
    pi_manifest.json
    group_precheck.json
  _tmp/pi/<GUID>/<invoice>/<attempt>/
    <file đang tải hoặc file .part>
```

- Invoice nguồn: trim nhưng giữ số 0 đầu; không lấy invoice_search đã chuẩn hóa để đặt tên.
- Last4: lấy 4 chữ số cuối full PAN đã được kiểm tra/mapping đúng, giữ dạng chuỗi để không mất số 0.
- TERMOWNER: lấy đúng cột TERMOWNER của invoice; không thay bằng merchant đang hiển thị trên một popup khác. Chuẩn hóa ký tự tên file không hợp lệ trên Windows và khoảng trắng dư; không tự bỏ dấu hoặc đổi chữ không cần thiết.
- Thiếu invoice/PAN/TERMOWNER: báo lỗi dữ liệu có chỉ rõ dòng; không âm thầm xuất file UNKNOWN_MERCHANT rồi coi là đạt naming contract.
- Một hàm dựng đường dẫn dùng chung cho bridge và native; kết quả không phụ thuộc current working directory hoặc tên folder GUID sau finalize.
- Nếu trùng tên trong run: chỉ dùng lại khi identity và nội dung được xác nhận trùng; nếu khác giao dịch/nội dung thì báo conflict, không ghi đè và không tự thêm hậu tố làm sai cú pháp tên đã chốt.

### 4.2. Lưu và xác nhận

1. Tìm lại giao dịch theo Transaction ID đầy đủ và identity ổn định của hàng; không dùng lại locator nth(i) đã được lấy lúc filter invoice cũ.
2. Chọn đúng transaction để View/Tran Details; không để selection tồn từ invoice khác làm thay đổi đối tượng mở PI.
3. Xác nhận popup có identity khớp giao dịch yêu cầu, không chỉ nhận vì title là Transaction Details.
4. Chờ spinner PI kết thúc, đăng ký download listener trước click Save as PDF.
5. Native: dùng đối tượng Download của trang sở hữu thao tác và save_as vào file .part riêng, có deadline. Giữ file đến khi tải xong và kiểm tra được PDF.
6. Kiểm tra tối thiểu size/signature, đọc lại file; đối chiếu identity trên popup và nội dung PDF khi có thể trích xuất. File không đủ bằng chứng đúng invoice phải được giữ để review, không báo thành công.
7. Publish atomically vào run/documents với tên chuẩn, cập nhật pi_file/pi_path/bytes/identity/attempt/status vào manifest và kết quả invoice.
8. Chỉ sau khi xác nhận file chính thức tồn tại và được ghi nhận mới đóng popup thuộc worker và dọn tệp tạm của attempt đó.

Backend cũ có thể được sửa import + output contract trước để có đường đối chiếu. Các PDF tạm của lượt test trước không được tự đổi tên hàng loạt để biến thành chứng từ thành công: chưa xác minh chúng khớp từng invoice.

## 5. Giữ business rules sync khi port

Nguồn chuẩn: `src/review/guid_group.py` và luồng gọi trong `run_case_review.py` của v9.0.60; không tự cộng thêm rule của helper evaluate.

| Rule cần bảo toàn | Hành vi |
|---|---|
| Eligible row | 13.9: đúng một Cash; 13.1/10.4: đúng một Sale hoặc Sale - WT |
| Thứ tự | Uniqueness → PI → refund/reversal → Assoc Dispute → ECI riêng 10.4 → checkbox |
| PI | Lấy từ VROL cho cả 3 code; Yes bỏ các gate tiếp theo của invoice đó, không miễn gate cho invoice khác |
| Refund/reversal | Credit cho 13.1/10.4; Cash Rev cho 13.9; dừng cả nhóm theo code hiện tại |
| Assoc | D dừng nhóm; rỗng qua gate; giá trị khác rỗng/D cần review khi không PI |
| ECI | Chỉ 10.4: rỗng/5/6 dừng nhóm khi không PI; không thêm whitelist mới |
| Nhóm PI + không PI | Nếu scan xong không dừng và có PI pending thì tải PI, không Issuer cho nhóm |
| Nhánh Issuer | 10.4 → Fraud; 13.1/13.9 → Consumer; Fraud trộn Consumer cần review |
| Questionnaire | Giữ preset và giá trị cấu hình đã trích; không suy ra câu trả lời mới khi refactor |
| Amount / Response Code | Không tự bật amount comparison hoặc gate Response Code từ evaluate vào precheck |
| Checkpoint | Có thể Case Creation Submit/điền questionnaire theo luồng sync; không Final Submit trong test tự động |

Tạo rule engine nhận dữ liệu thuần, cùng fixtures và expected outcomes cho hai adapter. So sánh quyết định/reason/invoice outcomes; ngoại lệ có chủ đích chỉ gồm policy ngày và contract output đã nêu. Không chạy hai backend tạo case trên cùng GUID để lấy benchmark.

## 6. Kiến trúc async đích

- Một async_playwright, một persistent BrowserContext cho phiên đăng nhập dùng chung; một worker xử lý một GUID trên trang riêng tại một thời điểm.
- Inquiry → live frame → form → Submit → results → filter/snapshot → rules đều dùng async API. Không gọi run_full_group sau precheck async vì hàm bridge sẽ truy vấn lại từ đầu.
- DTO chỉ chứa dữ liệu/identity; Locator/Page không đi qua thread hoặc được lưu làm bằng chứng cố định của invoice.
- Worker có settings/context trạng thái riêng; filter các invoice trong cùng tab xử lý tuần tự. Nhiều worker có thể chờ kết quả đồng thời.
- Đọc snapshot bảng ít round trip hơn; vẫn giữ hai chiến lược small-table DIRECT_DOM và UI filter theo sync, không dùng DataTables API nội bộ để đổi nghiệp vụ.
- Excel và file I/O nặng có thể dùng thread; browser native không dùng sync_api hay secondary CDP client cho toàn engine.

### 6.1. Popup chain và bỏ lock chung

Registry gắn mỗi Page với worker/GUID/transaction/attempt/stage; đăng ký trước thao tác có thể mở trang. Ưu tiên popup event theo Page; dùng opener khi có để nhận quan hệ cha-con, lưu ownership ngay để không phụ thuộc cha còn sống. Một router context-level chỉ làm fallback có kiểm chứng, không trao cùng page cho hai worker.

- Bắt cả popup mới, navigation/frame transition cùng trang và reuse popup đã sở hữu.
- Case Creation → warning → questionnaire có thể đổi trang/frame; chờ trạng thái trên toàn chain thuộc worker, không chỉ một case_page cũ.
- Xác minh Transaction ID hoặc Case Number trước Submit, điền questionnaire, tải PDF và cleanup. Không chọn trang mới nhất toàn context hoặc dựa vào title giống nhau.
- Nếu VROL thực sự reuse một page giữa hai worker, phải khóa tài nguyên page đó hoặc đánh giá context riêng. Event tracking không tạo isolation cho một page bị dùng chung.
- Native ưu tiên Playwright Download/save_as. Nếu vẫn cần Chrome CDP để tải, dùng một download manager cấu hình một lần, tương quan download GUID/frame/worker; không để mỗi invoice đổi downloadPath dùng chung.
- Chỉ gỡ global popup lock sau test chứng minh hai chuỗi PI chạy đồng thời không lẫn identity/file và cleanup không đóng trang của nhau. Giữ riêng khóa xác thực/session recovery.

### 6.2. OTP một lần trong ngày và console

- Giữ persistent profile và logout_after_login=False; thử dùng trạng thái đã xác thực trước, không reset profile hoặc tạo login mới cho từng GUID.
- Trạng thái UI/server quyết định có cần MFA: không bỏ qua yêu cầu chỉ vì đã lưu ngày OTP hôm nay, cũng không gửi lại OTP khi landing đã authenticated.
- Nếu bị yêu cầu: coordinator duy nhất thực hiện baseline → Send OTP → thông báo console có thư mục/poll interval/timeout → polling FOLDER_FILENAME theo config.xlsx → submit → authenticated.
- Không cache hoặc dùng lại chuỗi OTP cũ trong ngày. Tái sử dụng phiên đã xác thực, không tái sử dụng mã.
- Log hiển thị kịp thời trong console headful, có stage và worker; không in mã OTP hoặc tên file chứa mã vào log mới.
- Lượt test vừa rồi MFA được skip do session đã xác thực, phù hợp quan sát của người dùng; vẫn cần test provider khi VROL thực sự hỏi OTP vào lần sau.

## 7. Các đợt sửa và điều kiện hoàn tất

| Đợt | Phạm vi | Tiêu chí xong |
|---|---|---|
| A | Đối soát đúng đầu ra upstream; sửa import, canonical documents/naming, phân loại retry/review và path sau finalize | File PI không còn nằm nhầm phạm vi; lỗi PI không bị coi completed; tuổi > 15 được upstream bảo đảm, runtime không tự chia/hoãn nhóm |
| B | Tách rules/DTO, sửa parity queue với sync, thêm run_business_date và result schema từng invoice | So sánh fixture sync/native đúng; khác biệt policy được ghi rõ |
| C | Port Inquiry/precheck async, chế độ Inquiry-only, backend legacy_bridge/native_async chọn trước run | Native không gọi lại Inquiry sync, hai worker không lẫn input/filter/selection |
| D | Port PI async với ownership/download; sửa Case Creation transition và questionnaire async | Nhiều PI đúng identity/nội dung/tên/path; Fraud/Consumer đạt đúng checkpoint trên chain sở hữu |
| E | Test 1 → 2 → 3 worker; từng loại 13.9/13.1/10.4, sau đó benchmark | Không đổi quyết định nghiệp vụ; có số đo throughput và thời gian chờ khóa; chỉ bỏ khóa nơi đã chứng minh isolation |

Đợt A là sửa tối thiểu cho backend hiện tại, không phải kết luận chuyển async đã xong. Đợt C/D mới thay đổi cơ chế điều khiển browser. Bridge chỉ giữ làm fallback cho lượt chạy mới, không tự đổi backend giữa một thao tác tạo case đang dang dở.

## 8. Kiểm thử cụ thể

1. Offline input contract: đối soát tuổi 14/15/16 với cờ eligible của upstream; ngày sai/tương lai; ngày chạy qua nửa đêm; bảo đảm runtime không tự chia/hoãn GUID; ROL500 bảo toàn gate cả nhóm. Không bổ sung gate tuổi mới ở runtime.
2. Offline PI filesystem: invoice có 0 đầu, last4 có 0 đầu, TERMOWNER có ký tự không hợp lệ/dấu tiếng Việt; thiếu dữ liệu; collision; .part chưa xong; PDF rỗng/sai signature; không đánh dấu downloaded trước publish.
3. HTML local với async Playwright: nhiều trang/iframe; popup mới và reuse; popup cha đóng sớm; download cùng tên nguồn từ hai worker; delayed event từ attempt cũ; sai identity phải dừng trước thao tác tiếp.
4. Live PI: một GUID nhiều invoice, kiểm từng file trong run/documents đúng identity/nội dung; sau đó hai GUID PI chạy chồng lấp. Không chỉ dựa trên filename để chấm đạt.
5. Live case: xác nhận Case Creation page/frame và action, ghi checkpoint trước/sau Submit, warning ROL-749/ROL-1545 đúng rule; chờ questionnaire trên đúng chain, không tự gửi lại case không rõ kết quả.
6. Live business: cả 3 code, PI Yes, Credit/Cash Rev, Assoc D, ECI gate, mixed-code và ROL-897. Giữ giới hạn GUID; không mở full batch khi còn lỗi chức năng.
7. Report: summary có số completed/retry/review và sai lệch input contract; phân biệt COMPLETED_WITH_ISSUES hoặc FAILED phù hợp; exit code phản ánh technical failure, trong khi kết luận nghiệp vụ hợp lệ như Assoc D không bị coi lỗi kỹ thuật.

## 9. Thứ tự ưu tiên đề xuất

**Output PI + age policy + report trước → native Inquiry/rules → native PI → Case Creation/questionnaire → chứng minh popup độc lập → tăng concurrency.**

Chưa chạy lại nhánh tạo case trong lượt lập phương án này. Cần đối soát checkpoint/trạng thái GUID bị timeout trước khi chọn lại cho test, tránh tạo lại hồ sơ chỉ để thử timeout hoặc benchmark.
