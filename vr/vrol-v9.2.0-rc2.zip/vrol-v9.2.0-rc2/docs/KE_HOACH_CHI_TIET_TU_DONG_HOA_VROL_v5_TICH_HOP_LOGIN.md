# KẾ HOẠCH CHI TIẾT TỰ ĐỘNG HÓA VROL
## Phạm vi Code 13.1, Code 13.9 và Code 10.4

**Phiên bản hợp nhất:** Bao gồm luồng nghiệp vụ, kiến trúc dùng chung, data contract của `09_CHARGEBACK_CLASSIFIED.xlsx`, chế độ Pre-submit Review, evidence, report và xử lý unknown case.

# 1. Mục tiêu

Xây dựng hệ thống tự động hóa Playwright để:

1. Đọc giao dịch từ `09_CHARGEBACK_CLASSIFIED.xlsx`.
2. Sắp xếp và nhóm theo GUID.
3. Map GUID với output CMS GUID2PAN để lấy full PAN.
4. Đăng nhập Visa Online và VROL.
5. Tra cứu theo PAN và Invoice Number.
6. Áp dụng common pre-check và rule riêng cho Code 13.1, 13.9, 10.4.
7. Ghi nhận Refund, Sale Rev, đã chargeback, existing VROL case, Visa reject và ngoại lệ dữ liệu.
8. Hỗ trợ chạy đến trước Submit cuối để business review.
9. Chỉ tạo dispute khi cấu hình và approval hợp lệ.
10. Ghi kết quả về Excel, sinh report, screenshot, trace và evidence.
11. Reconcile multi-case bằng báo cáo ROL500.
12. Dừng an toàn và ghi nhận mọi trường hợp chưa có rule.

# 2. Nguyên tắc thiết kế

Không xây ba bot riêng. Hệ thống gồm:

- **Common VROL Engine**: login, navigation, Transaction Inquiry, table parsing, checkpoint và retry.
- **Rule Engine**: rule nghiệp vụ cấu hình theo từng code.
- **Code-specific Form Handler**: form 13.1, 13.9 và 10.4.
- **Scenario Registry**: danh sách case đã biết.
- **Unknown Scenario Handler**: case ngoài kịch bản.
- **Final Submission Guard**: kiểm soát Submit cuối.
- **Evidence and Report Framework**: ảnh, trace, HTML snapshot và báo cáo.
- **ROL500 Reconciliation**: map transaction với ROL case cho multi-case.

Luồng tổng quát:

```text
Excel Input
→ Input Validation
→ GUID Grouping
→ GUID-to-PAN Mapping
→ VROL Transaction Inquiry
→ Invoice Search
→ Common Pre-check
→ Code-specific Rule Evaluation
→ Form Population
→ Final Submission Guard
→ PRE_SUBMIT_REVIEW hoặc FULL_SUBMIT
→ Result/Evidence/Report
→ ROL500 Reconciliation nếu cần
```

Rule phải tách khỏi locator Playwright và có `rule_version`, `effective_date`, `approved_by`, `source_document`, `last_updated_at`.

# 3. Data contract của file nghiệp vụ

## 3.1. Cấu trúc workbook

File chính: `09_CHARGEBACK_CLASSIFIED.xlsx`.

- Sheet: `Sheet1`.
- 42 cột từ A đến AP.
- Dòng 1: nhóm dữ liệu/chức năng.
- Dòng 2: header kỹ thuật bot sử dụng.
- Dòng 3: diễn giải nghiệp vụ.
- Dữ liệu bắt đầu từ dòng 4.

## 3.2. Mapping cột

| Cột | Header dòng 2 | Mục đích |
|---|---|---|
| A | `BUT TOAN` | Member Case Number/QT tra soát |
| D | `NGAY GD` | Ngày giao dịch |
| E | `SO TIEN` | Số tiền giao dịch nguồn T24 |
| M | `GUID` | Nhóm và map sang full PAN |
| Q | `TRAN ID` | Transaction ID nguồn |
| R | `APPCODE` | Auth Code/App Code |
| U | `CHECK SALE` | Trạng thái thanh quyết toán |
| V | `TERMOWNER` | Merchant/Term Owner |
| W | `AMOUNTORIG` | Số tiền gốc từ card report |
| X | `CURRENCYORIG` | Loại tiền gốc |
| Y | `AMOUNT` | Số tiền card report |
| AD | `INVOICENUM` | Invoice Number dùng search VROL |
| AG | `Loai GD` | Loại giao dịch theo BRD |
| AH | `VALID CHARGEBACK` | Kết quả phân loại Y/N |
| AI | `REASON` | Lý do không đủ điều kiện |
| AJ | `CODE CB` | 10.4, 13.1 hoặc 13.9 |
| AK | `VROL` | VROL/ROL Case Number |
| AL | `CB date` | Ngày đẩy chargeback |
| AM | `CB reject` | Reject/refund/đã CB/ngoại lệ |
| AN | `CB result` | Kết quả xử lý |
| AO | `CB rep date` | Ngày representment nếu có |
| AP | `SOATM` | Số ATM, liên quan 13.9 khi áp dụng |

Bot nhận diện theo header dòng 2 và kiểm tra chéo vị trí. Thiếu/trùng header bắt buộc thì dừng với `INPUT_SCHEMA_INVALID`.

Các trường GUID, Invoice Number, Transaction ID và Member Case Number phải đọc dạng chuỗi để không mất số `0` đầu hoặc bị chuyển thành scientific notation.

## 3.3. Ghi kết quả

- AK: VROL/ROL case number.
- AL: ngày chargeback.
- AM: lý do reject/không tiếp tục/ngoại lệ.
- AN: trạng thái tổng hợp.
- AO: representment date nếu có.

Không ghi trực tiếp lên file gốc. Tạo:

`09_CHARGEBACK_CLASSIFIED_RESULT_YYYYMMDD_HHMMSS.xlsx`

Giữ nguyên sheet, thứ tự dòng, định dạng, công thức và merged cells. Ghi file tạm trước rồi đổi tên để tránh file hỏng. Nếu file bị khóa, ghi `OUTPUT_FILE_LOCKED` và checkpoint, không submit lại case.

# 4. GUID-to-PAN và nhóm xử lý

1. Sắp xếp dữ liệu theo GUID.
2. Nhóm các dòng cùng GUID.
3. Map GUID với output CMS GUID2PAN.
4. Một GUID không có PAN: `PAN_NOT_FOUND`.
5. Một GUID có nhiều PAN: `GUID_MULTIPLE_PAN`.
6. PAN không hợp lệ: `INVALID_PAN`.
7. Full PAN không ghi vào log/report; chỉ dùng trong memory và nguồn được kiểm soát.
8. Mở Transaction Inquiry một lần cho mỗi PAN nếu phạm vi ngày cho phép, sau đó xử lý từng Invoice Number.

# 5. Login, session, OTP và browser

Bot nhận biết các trạng thái username, password, Security Question, MFA, OTP, Visa Home, VROL, session timeout và authentication failure.

OTP tách thành adapter:

```text
OtpProvider
├── OutlookDesktopProvider
├── ManualOtpProvider
└── FutureMailboxApiProvider
```

Với Outlook Desktop: kiểm tra Outlook đang chạy, mở nếu cần, chờ sẵn sàng, gửi OTP, chỉ đọc email mới sau thời điểm gửi, trích xuất OTP và retry theo policy.

Playwright chạy Google Chrome bằng `channel="chrome"` và duy trì một browser context cho batch.

# 6. Transaction Inquiry và Invoice Number

## 6.1. Điều hướng

Visa Online Home → Visa Resolve Online → Inquiry → Transaction Inquiry → nhập full PAN → thiết lập Start Date nếu cần → Submit search → chờ bảng load.

Các iframe đã ghi nhận gồm `bodyframe`, `buttons`, `FRAME_ID_Dispute`; cần helper riêng và không lặp selector trong workflow.

## 6.2. Rule Invoice Number đã chốt

1. Đọc `INVOICENUM` cột AD dạng chuỗi.
2. Trim khoảng trắng.
3. Nếu có một hoặc nhiều số `0` đầu, bỏ toàn bộ số `0` đầu.
4. Nhập giá trị chuẩn hóa vào `Transaction ID / Retrieval`.
5. Sau chuẩn hóa, Invoice Number phải tương ứng Transaction ID trên VROL.

Ví dụ:

```text
Invoice Excel: 0346296420541394
Search VROL:   346296420541394
```

Nếu Invoice Number rỗng:

- Không fallback sang Auth Code.
- Không tạo dispute.
- Chụp ảnh.
- Ghi `INVOICE_NUMBER_MISSING` vào report và output Excel.

Nếu search trả về nhiều dòng:

- Không tự chọn theo amount, date, Auth Code hoặc merchant.
- Chụp bảng kết quả.
- Ghi `MULTIPLE_ROWS_FOR_INVOICE`.
- Đưa user review.

Không áp dụng date tolerance để chọn giao dịch. Ngày giao dịch chỉ dùng để bảo đảm Start Date của VROL bao phủ dữ liệu cần tìm.

# 7. Common pre-check

Trước form dispute, chạy:

- Không tìm thấy: `TRANSACTION_NOT_FOUND`.
- Nhiều dòng: `MULTIPLE_ROWS_FOR_INVOICE`.
- Có Credit/Sale Rev theo rule: `MERCHANT_REFUNDED`.
- Assoc Dispute = D: `ALREADY_CHARGEDBACK`.
- Existing case: `EXISTING_VROL_CASE`, ghi case number nếu đọc được.
- Amount mismatch: `AMOUNT_MISMATCH`.
- Currency mismatch: `CURRENCY_MISMATCH`.
- Visa reject trong full mode: mở Reject Details, lấy Error Code/Edit Description và ghi `VISA_REJECTED`.

Lỗi nghiệp vụ không retry. Chỉ retry timeout, frame/popup chưa load, network tạm thời, OTP hết hạn, download/report chưa xong.

# 8. Rule Code 13.1

- Loại action: Consumer.
- Điều kiện số tiền: `50.000 VND ≤ X < 10.000.000 VND`.
- Search theo Invoice Number đã chuẩn hóa.
- Chọn dòng Sale khi chỉ có một kết quả hợp lệ.
- Không có Credit/Sale Rev, Assoc Dispute D hoặc existing case.
- `DisputeDueTo = NR`.
- `WhatWasNotReceived = S`.
- Các câu hỏi đã khảo sát chọn No/Yes theo rule được duyệt.
- Expected Receipt Date lấy ngày giao dịch, format theo trường VROL.
- Member Case Number lấy giá trị QT từ Excel.
- Narrative đặt trong config/template.
- Review mode: `13_1_READY_TO_SUBMIT`, dừng trước Submit.
- Ngoài khoảng tiền: `13_1_AMOUNT_OUT_OF_SCOPE`.

# 9. Rule Code 13.9

- Tran Type phải là Cash.
- Issuer Action → Consumer.
- `DisputeDueTo = CL`.
- Lý do `Non Receipt of Cash`.
- So sánh Dispute Amount với Excel.
- Điền Member Case Number.
- Review mode: `13_9_READY_TO_SUBMIT`.
- Tran Type không phải Cash: `13_9_INVALID_TRANSACTION_TYPE`.
- Field bắt buộc mới/chưa có rule: `UNKNOWN_SCENARIO` hoặc `FORM_FIELD_RULE_MISSING`, không Submit.

Các rule amount, partial cash, adjustment/refund và chứng từ chưa được business chốt phải giữ configurable/manual review.

# 10. Rule Code 10.4

- Issuer Action → Fraud.
- Search từng Invoice Number, không áp dụng kết quả một invoice cho cả nhóm.
- Rule eligibility phải lấy từ BRD 2.2.1; thiếu rule version thì `10_4_RULESET_NOT_AVAILABLE`.
- Fraud Type thường được khảo sát là FT6 nhưng không mặc định tuyệt đối nếu rule chưa xác định.
- Check Certification và điền Member Case Number.
- Hỗ trợ single-case và multi-case.
- Nếu PI = Yes, tải Transaction Detail PDF và đặt tên ưu tiên `{last4PAN}_{invoiceNumber}_{termOwner}.pdf`.
- Nếu một giao dịch trong nhóm có Credit/Sale Rev, policy `STOP_WHOLE_GROUP`, `STOP_MATCHED_TRANSACTION_ONLY` hoặc `REQUIRE_BUSINESS_REVIEW` phải lấy từ config đã duyệt.
- Review mode: `10_4_READY_TO_SUBMIT`.

# 11. ROL500 reconciliation

Trong full mode, khi tạo nhiều case:

1. Ghi pending record vào JSONL.
2. Chạy `ROL 500 - Financial`.
3. Chọn Financial Type theo cấu hình đã xác nhận.
4. Chọn khoảng ngày dựa trên thời gian submit sớm nhất/muộn nhất.
5. Tải `ROL500.csv`.
6. Map Tran ID với ROL Case.
7. Không tìm thấy: `ROL500_CASE_NOT_FOUND`.
8. Nhiều case cho một Tran ID: `ROL500_MULTIPLE_CASES`.
9. Không ghi cùng một case number cho mọi dòng khi chưa map chắc chắn.

# 12. State machine, checkpoint và retry

```text
NEW
→ INPUT_VALIDATED
→ PAN_RESOLVED
→ VROL_SEARCHED
→ TRANSACTION_MATCHED
→ PRECHECK_PASSED
→ RULE_EVALUATED
→ READY_TO_SUBMIT
→ READY_TO_SUBMIT_REVIEWED       (PRE_SUBMIT_REVIEW)
hoặc
→ SUBMITTED → CASE_CONFIRMED     (FULL_SUBMIT)
→ EXCEL_UPDATED
→ COMPLETED
```

Mỗi transition ghi `sourceState`, `targetState`, `timestamp`, `attempt`, `runId`, `rowId`, `reason`.

Checkpoint sau PAN resolve, search, match, pre-check, trước submit, sau submit, lấy case number, cập nhật Excel và pending ROL500.

Nếu crash sau Submit nhưng trước ghi Excel, retry không được Submit lại; phải tìm existing case hoặc reconcile.

# 13. Chuẩn hóa trạng thái

| Status | Ý nghĩa |
|---|---|
| `READY_TO_SUBMIT_REVIEWED` | Form hoàn thành, chưa Submit |
| `SUCCESS` | Tạo case thành công trong full mode |
| `PENDING_RECONCILIATION` | Đã tạo multi-case, chờ ROL500 |
| `EXISTING_VROL_CASE` | Đã có case |
| `MERCHANT_REFUNDED` | Credit/Sale Rev theo rule |
| `ALREADY_CHARGEDBACK` | Assoc Dispute = D |
| `TRANSACTION_NOT_FOUND` | Không tìm thấy invoice |
| `MULTIPLE_ROWS_FOR_INVOICE` | Nhiều dòng, cần user review |
| `AMOUNT_MISMATCH` | Số tiền không khớp |
| `RULE_NOT_MATCHED` | Không thỏa rule |
| `UNKNOWN_SCENARIO` | Ngoài kịch bản đã biết |
| `VISA_REJECTED` | Visa reject |
| `TECHNICAL_ERROR` | Lỗi kỹ thuật |
| `RETRY_PENDING` | Chờ retry |
| `CONTROL_BREACH` | Vi phạm khóa Submit trong review mode |

# 14. Cấu trúc source đề xuất

```text
vrol-automation/
├── run.cmd
├── setup.cmd
├── package.json
├── playwright.config.js
├── config/
│   ├── config.xlsx
│   ├── column-mapping.yaml
│   ├── narratives.yaml
│   └── rules/
│       ├── code-13.1.yaml
│       ├── code-13.9.yaml
│       └── code-10.4.yaml
├── src/
│   ├── orchestration/
│   ├── input/
│   ├── browser/
│   ├── authentication/
│   ├── pages/
│   ├── matching/
│   ├── rules/
│   ├── forms/
│   ├── config/
│   ├── controls/
│   ├── scenarios/
│   ├── evidence/
│   ├── reports/
│   ├── output/
│   ├── retry/
│   └── logging/
├── runtime/
│   ├── checkpoints/
│   ├── logs/
│   ├── traces/
│   ├── screenshots/
│   ├── downloads/
│   └── evidence/
└── tests/
    ├── unit/
    ├── rule-tests/
    ├── fixtures/
    └── integration/
```

Selector ưu tiên role/name, label, stable name/id, text có ngữ cảnh; tránh `nth-child`, ID động, timestamp, case number và số tiền cụ thể. Parse bảng theo header, không dựa vị trí cột tuyệt đối.

# 15. Kế hoạch triển khai

## Giai đoạn 1: Data contract và controls

- Khóa schema Excel và mapping GUID2PAN.
- Tạo `config.xlsx`.
- Xây config validation/checksum.
- Xây Final Submission Guard.
- Xây state machine, report và evidence framework.

## Giai đoạn 2: Common engine

- Login/session/MFA/OTP.
- VROL navigation, popup, iframe.
- Transaction Inquiry.
- Invoice normalization/search.
- Common pre-check.
- Checkpoint/retry/resume.

## Giai đoạn 3: Code 13.1

- Happy case.
- Amount out of scope.
- Refund/Sale Rev.
- Existing dispute/case.
- Reject handling trong full mode.

## Giai đoạn 4: Code 13.9

- Cash detection.
- Non Receipt of Cash.
- Amount validation.
- Required-field guard.
- Unknown field handling.

## Giai đoạn 5: Code 10.4

- BRD 2.2.1 rule evaluator.
- Single/multi-case.
- PI evidence.
- Related Cases.
- ROL500 reconciliation.

## Giai đoạn 6: Business review và hardening

- Chạy Pre-submit Review.
- Review report/screenshot.
- Bổ sung unknown scenarios.
- Regression.
- Session expiry, OTP refresh, popup/frame race.
- Crash-after-submit recovery.
- Approval để bật full flow.

# 16. Các điểm vẫn cần business chốt

1. Phạm vi group nghiệp vụ ngoài GUID nếu có.
2. Policy Credit/Sale Rev cho nhóm Code 10.4.
3. Nội dung đầy đủ BRD 2.2.1 và logic Fraud Type.
4. Rule còn thiếu của 13.9: amount, partial cash, adjustment/refund, PI và chứng từ.
5. Quy tắc CB Date, timezone và existing/rejected case.
6. Tham số ROL500, Financial Type, date range và duplicate mapping.
7. Quyền truy cập evidence có full PAN và phương án tạo bản masked.

---

# 17. KIỂM SOÁT PRE-SUBMIT, EVIDENCE VÀ UNKNOWN CASE

## 17.1. Quyết định thiết kế

Hệ thống phải hỗ trợ hai chế độ chạy:

1. `PRE_SUBMIT_REVIEW`: chạy toàn bộ luồng đến ngay trước Submit cuối cùng, thu thập kết quả và bằng chứng, nhưng không tạo dispute.
2. `FULL_SUBMIT`: cho phép tạo dispute sau khi business hoàn tất xác nhận và cấu hình được phê duyệt.

Chế độ mặc định bắt buộc là `PRE_SUBMIT_REVIEW`.

## 17.2. Cấu hình trong config.xlsx

Tạo sheet `RUN_SETTINGS`:

| Setting Key | Giá trị mặc định | Quy tắc |
|---|---|---|
| `EXECUTION_MODE` | `PRE_SUBMIT_REVIEW` | Chỉ nhận `PRE_SUBMIT_REVIEW` hoặc `FULL_SUBMIT` |
| `ALLOW_FINAL_SUBMIT` | `NO` | Khóa độc lập thao tác Submit cuối |
| `CAPTURE_SCREENSHOT` | `YES` | Chụp ảnh theo checkpoint |
| `CAPTURE_HTML_ON_EXCEPTION` | `YES` | Lưu HTML khi lỗi/case lạ nếu chính sách cho phép |
| `ENABLE_TRACE_ON_EXCEPTION` | `YES` | Lưu Playwright trace cho case lỗi |
| `STOP_ON_UNKNOWN_CASE` | `YES` | Dừng transaction hiện tại khi chưa có rule |
| `CONTINUE_NEXT_TRANSACTION` | `YES` | Tiếp tục dòng kế tiếp nếu session an toàn |
| `WRITE_RESULT_TO_EXCEL` | `YES` | Ghi output/report trong cả hai mode |
| `GENERATE_CASE_REPORT` | `YES` | Sinh báo cáo cho mọi transaction |
| `REQUIRE_CONFIG_APPROVAL` | `YES` | Bắt buộc approval khi chạy full |
| `APPROVED_BY` | trống | Người phê duyệt |
| `APPROVED_AT` | trống | Thời điểm phê duyệt |
| `APPROVAL_REFERENCE` | trống | Ticket/biên bản/email phê duyệt |
| `CONFIG_VERSION` | `1.0` | Phiên bản cấu hình |
| `RULESET_VERSION` | `1.0` | Phiên bản rule nghiệp vụ |

### 17.2.1. Điều kiện bật FULL_SUBMIT

Bot chỉ được bấm Submit cuối khi đồng thời thỏa mãn:

```text
EXECUTION_MODE = FULL_SUBMIT
ALLOW_FINAL_SUBMIT = YES
REQUIRE_CONFIG_APPROVAL = YES
APPROVED_BY không rỗng
APPROVED_AT hợp lệ
APPROVAL_REFERENCE không rỗng
CONFIG_VERSION được hỗ trợ
RULESET_VERSION đã được phê duyệt
```

Nếu thiếu bất kỳ điều kiện nào:

- Tự hạ về `PRE_SUBMIT_REVIEW`.
- Ghi `FINAL_SUBMIT_NOT_AUTHORIZED`.
- Không bấm Submit cuối.
- Vẫn sinh report và screenshot.

Không dùng một Boolean duy nhất để bật full flow, nhằm tránh user sửa nhầm một ô.

## 17.3. Điểm dừng trong PRE_SUBMIT_REVIEW

Bot vẫn thực hiện:

1. Đọc `09_CHARGEBACK_CLASSIFIED.xlsx`.
2. Sắp xếp và nhóm theo GUID.
3. Map GUID sang full PAN.
4. Login Visa/VROL.
5. Search theo Invoice Number đã bỏ toàn bộ số `0` đầu.
6. Thực hiện common pre-check.
7. Đánh giá rule 13.1, 13.9 hoặc 10.4.
8. Mở Consumer/Fraud flow tương ứng.
9. Điền toàn bộ field đã có rule.
10. Kiểm tra Dispute Amount, Member Case Number và câu trả lời.
11. Chụp màn hình form hoàn chỉnh.
12. Ghi kết luận dự kiến vào báo cáo.
13. Dừng ngay trước Submit cuối.
14. Thoát bằng Cancel/Close/Back theo cách không tạo case.

State cuối của review mode:

```text
READY_TO_SUBMIT_REVIEWED
```

State này không đồng nghĩa với `SUBMITTED` hoặc `CASE_CONFIRMED`.

## 17.4. Final Submission Guard

Mọi thao tác tạo dispute phải đi qua một guard dùng chung:

```text
FinalSubmissionGuard.assertAuthorized(runContext, config)
```

Các form handler 13.1, 13.9 và 10.4 không được gọi trực tiếp locator Submit cuối.

Guard kiểm tra:

- Execution mode.
- Cờ cho phép submit.
- Approval metadata.
- Config/rule version.
- State transaction hiện tại.
- Không có checkpoint `SUBMITTED` hoặc `CASE_CONFIRMED` trước đó.
- Không có unknown/unresolved condition.

Nếu code gọi Submit khi đang review mode:

- Chặn click.
- Ghi `SUBMIT_BLOCKED_BY_CONFIGURATION`.
- Chụp ảnh `06_SUBMIT_BLOCKED`.

## 17.5. Phân loại các nút Submit

| Action type | Ý nghĩa | Review mode |
|---|---|---|
| `SEARCH_SUBMIT` | Chạy tra cứu | Được phép |
| `NAVIGATION_SUBMIT` | Sang bước kế tiếp, chưa tạo case | Chỉ cho phép sau khi xác minh |
| `FINAL_CASE_SUBMIT` | Tạo dispute/case | Bị chặn |
| `REPORT_SUBMIT` | Chạy báo cáo như ROL500 | Được phép nếu không tạo dispute |

Nếu không xác định được loại nút, mặc định coi là `FINAL_CASE_SUBMIT` và chặn.

## 17.6. Báo cáo bắt buộc cho mọi case

Mọi transaction đều có một record, bao gồm:

- Happy case.
- Case bị loại theo rule.
- Existing case.
- Refund/đã chargeback.
- Case kỹ thuật lỗi.
- Case chưa từng được định nghĩa.

Không chỉ ghi report cho lỗi.

File đề xuất:

`VROL_AUTOMATION_CASE_REPORT_YYYYMMDD_HHMMSS.xlsx`

Các cột:

- Run ID.
- Execution Mode.
- Source File/Sheet/Row.
- Member Case Number.
- GUID.
- Masked PAN.
- Invoice Number gốc.
- Invoice Number dùng search.
- Code CB.
- Scenario Code.
- Scenario Type: `KNOWN`/`UNKNOWN`.
- Rule Version.
- Config Version.
- Final State.
- Eligible For Submit: Y/N.
- Expected Action.
- Actual Action.
- Bot Conclusion.
- Exception Code/Detail.
- Business Question.
- Screenshot Paths.
- Trace Path.
- HTML Snapshot Path.
- Processed At.
- Retry Count.
- Business Decision/Comment.
- Reviewed By/At.

## 17.7. Ma trận case đã biết

| Nhóm | Scenario Code | Xử lý |
|---|---|---|
| Chung | `KNOWN_READY_TO_SUBMIT` | Điền form và dừng trước Submit trong review mode |
| Chung | `INVOICE_NUMBER_MISSING` | Không fallback Auth Code; screenshot, report, user review |
| Chung | `TRANSACTION_NOT_FOUND` | Screenshot bảng kết quả và report |
| Chung | `MULTIPLE_ROWS_FOR_INVOICE` | Không tự chọn; screenshot và report |
| Chung | `MERCHANT_REFUNDED` | Không tạo dispute |
| Chung | `ALREADY_CHARGEDBACK` | Không tạo case mới |
| Chung | `EXISTING_VROL_CASE` | Ghi case number hiện hữu nếu đọc được |
| Chung | `AMOUNT_MISMATCH` | Không Submit |
| Chung | `FINAL_SUBMIT_NOT_AUTHORIZED` | Chặn do config/approval |
| Chung | `TECHNICAL_ERROR` | Evidence và retry theo policy |
| 13.1 | `13_1_READY_TO_SUBMIT` | Form Consumer 13.1 hoàn tất |
| 13.1 | `13_1_AMOUNT_OUT_OF_SCOPE` | Ngoài khoảng 50.000 đến dưới 10.000.000 VND |
| 13.9 | `13_9_READY_TO_SUBMIT` | Cash/Non Receipt of Cash hoàn tất |
| 13.9 | `13_9_INVALID_TRANSACTION_TYPE` | Tran Type không phải Cash |
| 10.4 | `10_4_READY_TO_SUBMIT` | Fraud form hoàn tất |
| 10.4 | `10_4_PI_EVIDENCE_REQUIRED` | Tải chứng từ theo rule |
| 10.4 | `10_4_PENDING_RECONCILIATION` | Full mode multi-case chờ ROL500 |
| Full mode | `VISA_REJECTED` | Lấy Reject Details và report |

## 17.8. Case chưa biết

Case chưa biết là trường hợp không match duy nhất với một scenario/rule đã được duyệt, ví dụ:

- Field bắt buộc mới xuất hiện.
- Dropdown có giá trị chưa có rule.
- VROL trả trạng thái mới.
- Tran Type mới.
- Không xác định được mối liên hệ giữa Credit/Sale Rev và Sale.
- Related Cases không map được transaction.
- Fraud Type không xác định được.
- Iframe/giao diện thay đổi.
- Tổ hợp dữ liệu chưa từng khảo sát.

Bot phải:

1. Không Submit.
2. Dừng riêng transaction hiện tại.
3. Ghi `UNKNOWN_SCENARIO`.
4. Sinh `unknown_case_id` duy nhất.
5. Chụp toàn màn hình và vùng liên quan.
6. Lưu HTML snapshot/trace theo config.
7. Ghi field label/value và trạng thái trang đọc được.
8. Ghi bước cuối đã hoàn thành.
9. Ghi hành động đã bị chặn.
10. Tạo câu hỏi cụ thể cho business.
11. Tiếp tục transaction tiếp theo nếu session an toàn.

Không ghi chung chung “case lạ”. Report phải nêu điều kiện nào không match và rule nào còn thiếu.

## 17.9. Screenshot checkpoints

Tên file:

```text
{runId}_{sourceRow}_{codeCB}_{scenarioCode}_{checkpoint}_{timestamp}.png
```

Checkpoint tối thiểu:

- `01_INPUT_ROW`.
- `02_TRANSACTION_SEARCH`.
- `03_PRECHECK_RESULT`.
- `04_ACTION_SELECTION`.
- `05_FORM_COMPLETED`.
- `06_SUBMIT_BLOCKED`.
- `07_SUBMIT_RESULT`, chỉ full mode.
- `08_REJECT_DETAILS`, nếu reject.
- `09_UNKNOWN_CASE`.

Full PAN không được ghi trong tên file, log hoặc report. Evidence chứa full PAN phải nằm trong thư mục hạn chế quyền; bản dùng cho business review nên được mask.

## 17.10. Báo cáo tổng hợp theo run

Summary phải có:

- Tổng dòng input.
- Số dòng theo từng code.
- Known/unknown scenario.
- Eligible/not eligible.
- Ready to submit.
- Refund.
- Already chargeback.
- Existing VROL case.
- Transaction not found.
- Invoice missing.
- Multiple rows.
- Amount mismatch.
- Technical error.
- Số case thực sự submitted.

Trong `PRE_SUBMIT_REVIEW`, submitted count bắt buộc bằng 0. Nếu lớn hơn 0:

- Đánh dấu toàn run `CONTROL_BREACH`.
- Dừng batch.
- Lưu toàn bộ trace/evidence.
- Không tiếp tục transaction mới.

## 17.11. Kiểm soát config trong khi chạy

Đầu mỗi run:

1. Đọc `config.xlsx`.
2. Validate schema và allowed values.
3. Tính checksum file.
4. Ghi checksum, config version và rule version vào run report.
5. Lưu snapshot cấu hình dùng cho run.

Trước mỗi transaction hoặc trước Submit cuối, kiểm tra checksum. Nếu config thay đổi giữa run:

- Ghi `CONFIG_CHANGED_DURING_RUN`.
- Không Submit.
- Dừng trước transaction tiếp theo.

## 17.12. Quy trình xác nhận với business

1. Chạy `PRE_SUBMIT_REVIEW` trên bộ case đại diện.
2. Business xem case report, screenshot và form hoàn chỉnh.
3. Ghi Business Decision/Comment theo từng scenario.
4. Unknown case được bổ sung rule hoặc giữ manual review.
5. Chạy regression lại toàn bộ scenario đã cập nhật.
6. Xác nhận không có Submit trong review mode.
7. Khóa config/rule version.
8. Ghi approval metadata.
9. Chuyển sang `FULL_SUBMIT`.

## 17.13. Tiêu chí nghiệm thu bổ sung

- Review mode không thể tạo case, kể cả form handler gọi nhầm Submit.
- Mọi transaction có record trong report.
- Mọi known case có evidence phù hợp.
- Unknown case dừng an toàn và có câu hỏi cụ thể cho business.
- Screenshot map đúng source row và scenario.
- Full PAN không xuất hiện trong log/report thông thường.
- Việc đổi mode có approval metadata và audit trail.
- Config thay đổi giữa run được phát hiện.
- Retry không tạo duplicate case.
- Crash sau Submit có thể phục hồi mà không Submit lại.

## 17.14. Cập nhật kiến trúc source

Bổ sung các thành phần:

```text
config/
└── config.xlsx

src/config/
├── config-reader.js
├── config-validator.js
└── config-checksum.js

src/controls/
├── final-submission-guard.js
├── action-classifier.js
└── control-breach-handler.js

src/scenarios/
├── scenario-registry.js
├── known-scenario-handler.js
└── unknown-scenario-handler.js

src/evidence/
├── screenshot-service.js
├── html-snapshot-service.js
├── trace-service.js
└── evidence-manifest.js

src/output/
├── case-report-writer.js
├── run-summary-writer.js
└── business-review-writer.js
```

## 17.15. Kết luận

Phần cập nhật này là cần thiết trước khi phát triển production. `PRE_SUBMIT_REVIEW` không chỉ là một tùy chọn giao diện mà phải là kiểm soát kỹ thuật ở cấp orchestration, state machine và source code. Mọi case đã biết và chưa biết đều phải tạo report/evidence. Bot chỉ được chuyển sang `FULL_SUBMIT` khi cấu hình, rule version và approval metadata đều hợp lệ.

# 18. Tiêu chí nghiệm thu tổng thể

- Review mode không tạo dispute trong mọi tình huống.
- Mọi transaction có report record và evidence phù hợp.
- Known case có expected result rõ ràng.
- Unknown case dừng an toàn, không suy đoán và có câu hỏi cho business.
- Bot không tạo duplicate sau retry/crash.
- Case number được map đúng source row.
- Full PAN không xuất hiện trong log/report thông thường.
- Config/rule version và approval có audit trail.
- Full flow chỉ bật sau regression và business sign-off.

# 19. Kết luận

Thiết kế chính thức là:

```text
Common VROL Engine
+ Configurable Rule Engine
+ Code-specific Form Handlers
+ Scenario Registry
+ Unknown Scenario Queue
+ Final Submission Guard
+ Evidence and Reporting Framework
```

Trong giai đoạn đầu, hệ thống vận hành mặc định ở `PRE_SUBMIT_REVIEW`. Bot chỉ chuyển sang `FULL_SUBMIT` khi toàn bộ điều kiện cấu hình, rule version và approval metadata hợp lệ. Nếu dữ liệu không match duy nhất với rule đã duyệt, bot không suy đoán, không Submit, mà lưu bằng chứng và đưa vào danh sách business review.


# 20. Bổ sung bắt buộc cho batch vài nghìn case: trạng thái bền vững và Resume

## 20.1. Không chỉ dùng một cột trạng thái

Với batch vài nghìn case, một cột trạng thái đơn lẻ không đủ để resume an toàn. File kết quả phải bổ sung các cột từ AQ trở đi, không ghi đè AK:AO đang dùng cho nghiệp vụ:

| Cột | Header đề xuất | Mục đích |
|---|---|---|
| AQ | `BOT RUN ID` | ID duy nhất của lần chạy |
| AR | `BOT STATUS` | Trạng thái hiện tại của dòng |
| AS | `BOT SOURCE STATE` | State trước transition gần nhất |
| AT | `BOT TARGET STATE` | State sau transition gần nhất |
| AU | `BOT CHECKPOINT` | Checkpoint cuối đã commit |
| AV | `BOT ATTEMPT` | Số lần thử |
| AW | `BOT UPDATED AT` | Thời điểm cập nhật gần nhất |
| AX | `BOT WORKER ID` | Worker/process đang giữ case |
| AY | `BOT LEASE UNTIL` | Thời điểm hết lease xử lý |
| AZ | `BOT SCENARIO` | Scenario code đã match |
| BA | `BOT ERROR CODE` | Mã lỗi gần nhất |
| BB | `BOT EVIDENCE ID` | ID liên kết evidence manifest |
| BC | `BOT CONFIG VERSION` | Phiên bản config của case |
| BD | `BOT RULESET VERSION` | Phiên bản rule của case |
| BE | `BOT RESUME TOKEN` | Token/idempotency key phục vụ resume |

`BOT STATUS` tối thiểu hỗ trợ: `PENDING`, `IN_PROGRESS`, `READY_TO_SUBMIT_REVIEWED`, `SUBMITTING`, `SUBMITTED`, `CASE_CONFIRMED`, `COMPLETED`, `RETRY_PENDING`, `BUSINESS_REVIEW`, `TECHNICAL_ERROR`, `UNKNOWN_SCENARIO`.

## 20.2. Nguồn trạng thái chính

Excel phục vụ business nhìn nhanh, nhưng không nên là transaction store duy nhất. Bot đồng thời duy trì:

- `runtime/state/case_state.jsonl`: append-only event journal.
- `runtime/state/case_snapshot.json`: snapshot mới nhất của từng source row.
- `runtime/state/run_manifest.json`: thông tin run, checksum input/config, worker và tổng số case.
- `runtime/checkpoints/{runId}/{rowId}.json`: checkpoint chi tiết từng case.

Mỗi transition phải ghi JSONL và flush xuống ổ đĩa trước, sau đó cập nhật snapshot và Excel theo batch nhỏ. Nếu mất điện giữa lúc ghi Excel, journal vẫn xác định được state cuối đã commit.

## 20.3. Atomic checkpoint

Thứ tự commit:

1. Thực hiện bước read-only hoặc thao tác UI.
2. Thu thập kết quả/evidence.
3. Ghi event JSONL với `sourceState`, `targetState`, `timestamp`, `attempt`, `idempotencyKey`.
4. `flush` và `fsync` file journal.
5. Ghi checkpoint tạm `{rowId}.json.tmp`.
6. Đổi tên nguyên tử thành `{rowId}.json`.
7. Cập nhật snapshot.
8. Cập nhật các cột AQ:BE trong Excel theo chu kỳ cấu hình, ví dụ 10-25 case/lần hoặc ngay tại state có hệ quả.

Các state `READY_TO_SUBMIT`, `SUBMITTING`, `SUBMITTED`, `CASE_CONFIRMED` phải flush ngay, không đợi batch.

## 20.4. Resume khi mất điện hoặc bot bị kill

Khi khởi động lại:

1. Đọc `run_manifest.json` và kiểm tra checksum input/config.
2. Rebuild snapshot từ JSONL nếu snapshot thiếu/hỏng.
3. Reconcile snapshot với Excel bằng `BOT RUN ID`, source row và `BOT RESUME TOKEN`.
4. Case `COMPLETED`, `BUSINESS_REVIEW`, `READY_TO_SUBMIT_REVIEWED` được bỏ qua trừ khi chạy lại có chủ đích.
5. Case `PENDING`, `RETRY_PENDING`, `TECHNICAL_ERROR` retry theo policy.
6. Case `IN_PROGRESS` có lease hết hạn được chuyển `RECOVERY_REQUIRED` rồi chạy lại từ checkpoint an toàn.
7. Case `SUBMITTING` tuyệt đối không bấm Submit lại. Bot phải tra existing VROL case/Related Cases hoặc ROL500 để xác định kết quả.
8. Case `SUBMITTED` nhưng chưa `CASE_CONFIRMED` đi vào reconciliation, không resubmit.
9. Case có config/ruleset khác phiên bản hiện tại phải ghi `CONFIG_VERSION_MISMATCH` và yêu cầu quyết định resume bằng version cũ hay re-evaluate.

## 20.5. Idempotency và chống hai worker xử lý cùng case

- Khóa logic theo `source_file_checksum + sheet + source_row + normalized_invoice + code_cb`.
- Mỗi case có `BOT RESUME TOKEN` ổn định.
- Worker claim case bằng `WORKER ID` và lease time.
- Chỉ worker giữ lease hợp lệ mới được thao tác VROL.
- Khi submit, tạo `submission_intent` trước click và `submission_result` sau kết quả.
- Nếu không biết click đã tới server hay chưa, case phải sang `SUBMISSION_OUTCOME_UNKNOWN`, không được click lại.

## 20.6. Hiệu năng cho vài nghìn case

- Không save toàn workbook sau mỗi thao tác nhỏ. Ghi state journal ngay, còn Excel cập nhật theo batch nhỏ.
- Giữ một browser context; tái sử dụng Transaction Inquiry theo GUID/PAN khi an toàn.
- Screenshot happy case theo checkpoint tối thiểu; lỗi/unknown/reject chụp đầy đủ.
- Giới hạn dung lượng trace: chỉ bật khi exception hoặc theo sampling cấu hình.
- Báo cáo tiến độ theo `processed/total`, trạng thái và tốc độ, nhưng không ghi full PAN.


# 21. Selector Catalog chi tiết từ tài liệu khảo sát

## 21.1. Nguyên tắc sử dụng

Các selector dưới đây được giữ lại từ summary 13.1, 13.9 và 10.4 ở mức khảo sát. Chúng là **candidate selectors**, chưa được coi là production selector cho đến khi chạy xác minh trên môi trường thật.

Mỗi Page Object phải lưu:

- Selector chính.
- Selector fallback.
- Frame/tab chứa control.
- Action type: search, navigation, final submit, report.
- Expected visible state trước và sau action.
- Timeout riêng.
- Screenshot checkpoint khi fail.

Không đưa username, password, OTP, full PAN, Invoice Number thật hoặc URL chứa state/token vào source/config/report. Các giá trị `.fill(...)` trong catalog được thay bằng `runtimeValue`.

## 21.2. Các frame và selector lõi đã ghi nhận

| Khu vực | Candidate selector |
|---|---|
| VROL body | `page1.locator('iframe[name="bodyframe"]').contentFrame()` |
| Button frame | `page1.locator('iframe[name="buttons"]').contentFrame()` |
| Dispute frame | `page1.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame()` |
| Transaction table | `bodyFrame.locator('.vr-table')` |
| Header search container | `bodyFrame.locator('#dtheaderSearch')` |
| Invoice search | `bodyFrame.locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' })` |
| Search/operation Submit | `buttonsFrame.getByRole('button', { name: 'Submit' })` |

Nút Submit trong `buttons` frame phải được action classifier xác định theo page/state. Không được mặc định coi mọi `Submit` là an toàn.

## 21.3. Catalog trích từ từng file khảo sát

### 13.1 - case bị visa reject.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 4: click — page1 | `internal:role=textbox[name="Username"i]` | `await page.getByRole('textbox', { name: 'Username' }).click();` |
| Event 32: fill — page1 | `internal:role=textbox[name="Username"i]` | `await page.getByRole('textbox', { name: 'Username' }).fill(runtimeValue);` |
| Event 33: press — page1 | `internal:role=textbox[name="Username"i]` | `await page.getByRole('textbox', { name: 'Username' }).press('Enter');` |
| Event 34: click — page1 | `internal:role=button[name="Continue"i]` | `await page.getByRole('button', { name: 'Continue' }).click();` |
| Event 35: press — page1 | `internal:role=textbox[name="Username"i]` | `await page.getByRole('textbox', { name: 'Username' }).press('Tab');` |
| Event 36: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press('Enter');` |
| Event 37: click — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).click();` |
| Event 38: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press('Tab');` |
| Event 39: press — page1 | `internal:role=button[name="Back"i]` | `await page.getByRole('button', { name: 'Back' }).press('Tab');` |
| Event 40: click — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).click();` |
| Event 46: fill — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).fill(runtimeValue);` |
| Event 59: press — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).press('Enter');` |
| Event 61: click — page1 | `internal:text="Answer your security question."i` | `await page.getByText('Answer your security question.').click();` |
| Event 62: check — page1 | `internal:role=radio[name="Security Question Answer your"i]` | `await page.getByRole('radio', { name: 'Security Question Answer your' }).check();` |
| Event 63: click — page1 | `internal:role=button[name="Submit"i]` | `await page.getByRole('button', { name: 'Submit' }).click();` |
| Event 64: click — page1 | `internal:role=textbox[name="default-input"i]` | `await page.getByRole('textbox', { name: 'default-input' }).click();` |
| Event 69: fill — page1 | `internal:role=textbox[name="default-input"i]` | `await page.getByRole('textbox', { name: 'default-input' }).fill(runtimeValue);` |
| Event 70: press — page1 | `internal:role=textbox[name="default-input"i]` | `await page.getByRole('textbox', { name: 'default-input' }).press('Enter');` |
| Event 73: click — page1 | `internal:role=link[name="Visa Resolve Online"i]` | `await page.getByRole('link', { name: 'Visa Resolve Online' }).click();` |
| Event 78: click — page2 | `internal:role=button[name="Submit"i]` | `await page1.getByRole('button', { name: 'Submit' }).click();` |
| Event 79: click — page2 | `internal:role=button[name="Send OTP"i]` | `await page1.getByRole('button', { name: 'Send OTP' }).click();` |
| Event 80: click — page2 | `internal:role=textbox[name="otpPassword"i]` | `await page1.getByRole('textbox', { name: 'otpPassword' }).click();` |
| Event 84: fill — page2 | `internal:role=textbox[name="otpPassword"i]` | `await page1.getByRole('textbox', { name: 'otpPassword' }).fill(runtimeValue);` |
| Event 89: press — page2 | `internal:role=textbox[name="otpPassword"i]` | `await page1.getByRole('textbox', { name: 'otpPassword' }).press('Enter');` |
| Event 101: click — page2 | `internal:role=menuitem[name="Inquiry"s]` | `await page1.getByRole('menuitem', { name: 'Inquiry', exact: true }).click();` |
| Event 102: click — page2 | `internal:role=menuitem[name="Transaction Inquiry"i]` | `await page1.getByRole('menuitem', { name: 'Transaction Inquiry' }).click();` |
| Event 103: click — page2 | `internal:role=textbox[name="Quick Search:"i]` | `await page1.getByRole('textbox', { name: 'Quick Search:' }).click();` |
| Event 104: fill — page2 | `internal:role=textbox[name="Quick Search:"i]` | `await page1.getByRole('textbox', { name: 'Quick Search:' }).fill(runtimeValue);` |
| Event 106: click — page2 | `internal:role=button[name="Search"i]` | `await page1.getByRole('button', { name: 'Search' }).click();` |
| Event 107: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="2695653245"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('2695653245').click();` |
| Event 108: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="10/27/26 23:25 GMT  System,"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: '10/27/26 23:25 GMT  System,' }).click();` |
| Event 109: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Consumer Dispute - Delivered"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Consumer Dispute - Delivered' }).click();` |
| Event 110: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="Date/Time User Name Event CPD/Settled Date Details 10/29/26 10:23 GMT Do Thi"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('Date/Time User Name Event CPD/Settled Date Details 10/29/26 10:23 GMT Do Thi').click();` |
| Event 111: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Consumer Dispute - Rejected"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Consumer Dispute - Rejected' }).click();` |
| Event 112: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="/27/26 03:31 GMT  Nguyen Phuong, Thao  Consumer Dispute - Rejected     Dispute"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: '/27/26 03:31 GMT  Nguyen Phuong, Thao  Consumer Dispute - Rejected     Dispute' }).click();` |
| Event 114: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="Reject Details"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'Reject Details' }).click();` |
| Event 118: click — page3 | `internal:role=cell[name="ROL-"i]` | `await page2.getByRole('cell', { name: 'ROL-' }).click();` |
| Event 119: click — page3 | `internal:text="ROL-"i` | `await page2.getByText('ROL-').click();` |
| Event 120: click — page3 | `internal:role=cell[name="Dispute is invalid under"i]` | `await page2.getByRole('cell', { name: 'Dispute is invalid under' }).click();` |
| Event 122: click — page3 | `internal:role=cell[name="Error Code"i]` | `await page2.getByRole('cell', { name: 'Error Code' }).click();` |
| Event 124: click — page3 | `internal:role=cell[name="Edit Description"i]` | `await page2.getByRole('cell', { name: 'Edit Description' }).click();` |
| Event 126: click — page3 | `internal:role=row[name="ROL-1805 Dispute is invalid"i]` | `await page2.getByRole('row', { name: 'ROL-1805 Dispute is invalid' }).click();` |

### 13.1 - case đã có vrol number.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 4: click — page1 | `.v-input-container >> nth=0` | `await page.locator('.v-input-container').first().click();` |
| Event 74: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="VROL Bulletin Welcome, Thanh"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'VROL Bulletin Welcome, Thanh' }).click();` |
| Event 76: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Card/Account Number:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Card/Account Number:' }).fill(runtimeValue);` |
| Event 77: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Card/Account Number:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Card/Account Number:' }).click();` |
| Event 79: click — page2 | `iframe[name="buttons"] >> internal:control=enter-frame >> internal:role=button[name="Submit"i]` | `await page1.locator('iframe[name="buttons"]').contentFrame().getByRole('button', { name: 'Submit' }).click();` |
| Event 80: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="/ 631407556400"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '/ 631407556400' }).dblclick();` |
| Event 81: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('ControlOrMeta+c');` |
| Event 82: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="586313643674309"s]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '586313643674309', exact: true }).dblclick();` |
| Event 91: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77729207250-Sale-46"] >> internal:role=cell[name="780173"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77729207250-Sale-46"]').getByRole('cell', { name: '780173' }).dblclick();` |
| Event 94: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).click();` |
| Event 95: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).fill(runtimeValue);` |
| Event 96: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).press('ControlOrMeta+a');` |
| Event 103: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="346314172199943"s]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '346314172199943', exact: true }).click();` |
| Event 107: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="00"i][description="Approved and completed successfully"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '00', description: 'Approved and completed successfully' }).click();` |
| Event 112: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77729207251-Auth-24"] >> internal:role=cell[name="00"i][description="Approved and completed successfully"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77729207251-Auth-24"]').getByRole('cell', { name: '00', description: 'Approved and completed successfully' }).click();` |
| Event 114: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Tran Type"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Tran Type' }).click();` |
| Event 116: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Tran Type"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Tran Type' }).fill(runtimeValue);` |
| Event 118: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="346314147562440"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '346314147562440' }).dblclick();` |
| Event 122: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=link[name="Clear Transaction ID /"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('link', { name: 'Clear Transaction ID /' }).click();` |
| Event 124: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select transaction 11/10/26   11/11/26  Sale  00  56,569 VND  DR  FACEBK *URAKNEAWY4 DUBLIN IE  No   No   7  0002  10  320186  7311  346` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select transaction 11/10/26   11/11/26  Sale  00  56,569 VND  DR  FACEBK *URAKNEAWY4 DUBLIN IE  No   No   7  0002  10  320186  7311  346314178771627    449539  0771', exact: true }).locator('#responseCode').clic` |
| Event 127: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select transaction 11/10/26   11/11/26  Sale  00  56,569 VND  DR  FACEBK *HY473CNWY4 DUBLIN IE  No   No   7  0002  10  890183  7311  346` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select transaction 11/10/26   11/11/26  Sale  00  56,569 VND  DR  FACEBK *HY473CNWY4 DUBLIN IE  No   No   7  0002  10  890183  7311  346314155971576    446790  0771', exact: true }).locator('#responseCode').clic` |
| Event 129: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="346314147562440"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '346314147562440' }).click();` |
| Event 134: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="00"s]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: '00', exact: true }).click();` |
| Event 135: click — page2 | `iframe[name="buttons"] >> internal:control=enter-frame >> internal:role=button[name="Issuer Action ▲"i]` | `await page1.locator('iframe[name="buttons"]').contentFrame().getByRole('button', { name: 'Issuer Action ▲' }).click();` |
| Event 136: click — page2 | `internal:role=menuitem[name="Fraud"s]` | `await page1.getByRole('menuitem', { name: 'Fraud', exact: true }).click();` |
| Event 140: click — page3 | `tr:nth-child(7) > td` | `await page2.locator('tr:nth-child(7) > td').click();` |
| Event 141: press — page3 | `#duplicateBody` | `await page2.locator('#duplicateBody').press('ControlOrMeta+=');` |
| Event 142: click — page3 | `internal:role=link[name="5610828731"i]` | `await page2.getByRole('link', { name: '5610828731' }).click();` |
| Event 144: click — page3 | `internal:role=cell[name="Select \"Cancel\" to cancel the request and return to the previous screen."s]` | `await page2.getByRole('cell', { name: 'Select "Cancel" to cancel the request and return to the previous screen.', exact: true }).click();` |
| Event 147: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> tr:nth-child(8) > .info` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('tr:nth-child(8) > .info').click();` |
| Event 148: click — page2 | `iframe[name="buttons"] >> internal:control=enter-frame >> internal:role=button[name="Issuer Action"i]` | `await page1.locator('iframe[name="buttons"]').contentFrame().getByRole('button', { name: 'Issuer Action' }).click();` |
| Event 160: click — page2 | `iframe[name="buttons"] >> internal:control=enter-frame >> internal:role=button[name="Issuer Action"i]` | `await page1.locator('iframe[name="buttons"]').contentFrame().getByRole('button', { name: 'Issuer Action' }).dblclick();` |
| Event 162: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #mainBody` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#mainBody').click();` |
| Event 163: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="TI Response"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'TI Response' }).click();` |
| Event 166: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="Related Cases"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'Related Cases' }).click();` |
| Event 167: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828731_77729105127_1130311127_414361_0__414361_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828731_77729105127_1130311127_414361_0__414361_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click();` |
| Event 168: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828716_77729105152_1130311127_498750_0__498750_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828716_77729105152_1130311127_498750_0__498750_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click();` |
| Event 169: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828730_77729105118_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828730_77729105118_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click();` |
| Event 170: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828729_77729105132_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828729_77729105132_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click();` |
| Event 171: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828717_77729105136_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828717_77729105136_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click();` |
| Event 172: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828718_77729105141_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828718_77729105141_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click();` |
| Event 173: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828717_77729105136_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828717_77729105136_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 177: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828719_77729105144_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828719_77729105144_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click();` |
| Event 178: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828720_77729105138_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828720_77729105138_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click();` |
| Event 180: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828731_77729105127_1130311127_414361_0__414361_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828731_77729105127_1130311127_414361_0__414361_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 183: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828718_77729105141_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828718_77729105141_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 184: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828719_77729105144_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828719_77729105144_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 185: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828720_77729105138_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828720_77729105138_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 186: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828721_77729105126_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828721_77729105126_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 187: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828722_77729105129_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] >> internal:role=cell[name="Tran Inquiry - Fulfilled"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828722_77729105129_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"]').getByRole('cell', { name: 'Tran Inquiry - Fulfilled' }).click({` |
| Event 188: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828723_77729105133_1130311127_498750_0__498750_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828723_77729105133_1130311127_498750_0__498750_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 189: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828724_77729105123_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828724_77729105123_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 190: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828725_77729105124_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828725_77729105124_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 191: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828726_77729105130_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828726_77729105130_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 192: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828727_77729105131_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828727_77729105131_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 193: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828728_77729105125_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828728_77729105125_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 194: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828729_77729105132_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828729_77729105132_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 195: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828730_77729105118_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828730_77729105118_1130311127_414361_0__414361_UNASGN_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 196: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="_5610828716_77729105152_1130311127_498750_0__498750_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="_5610828716_77729105152_1130311127_498750_0__498750_INPROC_null___null_vcrenabledtxn_atravailable"] > td:nth-child(3)').click({` |
| Event 207: click — page7 | `internal:role=heading[name="Dispute Information"i]` | `await page6.getByRole('heading', { name: 'Dispute Information' }).click();` |
| Event 209: click — page7 | `internal:text="Dispute Information"i` | `await page6.getByText('Dispute Information').click({` |
| Event 212: click — page7 | `internal:text="Dispute Information"i` | `await page6.getByText('Dispute Information').click();` |
| Event 221: click — page7 | `.card-header.pb-10` | `await page6.locator('.card-header.pb-10').click();` |
| Event 222: click — page7 | `internal:text="Dispute Information"i` | `await page6.getByText('Dispute Information').dblclick();` |

### 13.1 - happy case 01.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 44: press — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).press('Shift+Enter');` |
| Event 45: click — page1 | `internal:role=button[name="Continue"i]` | `await page.getByRole('button', { name: 'Continue' }).click({` |
| Event 103: check — page1 | `internal:role=checkbox[name="checkbox"i]` | `await page.getByRole('checkbox', { name: 'checkbox' }).check();` |
| Event 112: uncheck — page1 | `internal:role=checkbox[name="checkbox"i]` | `await page.getByRole('checkbox', { name: 'checkbox' }).uncheck();` |
| Event 115: click — page1 | `div >> internal:has-text="Welcome back, Thanh"i >> nth=3` | `await page.locator('div').filter({ hasText: 'Welcome back, Thanh' }).nth(3).click();` |
| Event 116: click — page1 | `internal:text="Welcome back, Thanh"i` | `await page.getByText('Welcome back, Thanh').click();` |
| Event 140: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> div >> internal:has-text="*Please enter one of the"i >> nth=3` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('div').filter({ hasText: '*Please enter one of the' }).nth(3).click();` |
| Event 149: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select all rows : activate to"i] >> internal:label="Auth Code"s` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select all rows : activate to' }).getByLabel('Auth Code', { exact: true }).click();` |
| Event 150: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select all rows : activate to"i] >> internal:label="Auth Code"s` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select all rows : activate to' }).getByLabel('Auth Code', { exact: true }).fill(runtimeValue);` |
| Event 152: check — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select transaction 10/26/26   10/27/26  Sale  00  499,000 VND  DR  .OP*Green SM"i] >> internal:label="Select transaction"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select transaction 10/26/26   10/27/26  Sale  00  499,000 VND  DR  .OP*Green SM' }).getByLabel('Select transaction').check();` |
| Event 153: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Sale"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Sale' }).click();` |
| Event 157: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').click();` |
| Event 160: click — page2 | `internal:role=menuitem[name="Consumer"i]` | `await page1.getByRole('menuitem', { name: 'Consumer' }).click();` |
| Event 164: click — page3 | `internal:role=button[name="Submit"i]` | `await page2.getByRole('button', { name: 'Submit' }).click();` |
| Event 166: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=heading[name="VROL Case Number"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('heading', { name: 'VROL Case Number' }).click();` |
| Event 168: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Yes No OK Cancel Bundled Case"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Yes No OK Cancel Bundled Case').click();` |
| Event 169: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=heading[name="Dispute Information"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('heading', { name: 'Dispute Information' }).click();` |
| Event 171: select — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> select[name="DisputeDueTo"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('select[name="DisputeDueTo"]').selectOption('NR');` |
| Event 174: select — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> select[name="WhatWasNotReceived"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('select[name="WhatWasNotReceived"]').selectOption('S');` |
| Event 175: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-NonFiatCurrencyNotDelivered-N` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-NonFiatCurrencyNotDelivered-N').check();` |
| Event 176: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-ThirdPartyGiftCardInd-N` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-ThirdPartyGiftCardInd-N').check();` |
| Event 177: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-DidMerchantCancelInd-N` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-DidMerchantCancelInd-N').check();` |
| Event 178: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo').click();` |
| Event 203: fill — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo').fill(runtimeValue);` |
| Event 397: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> .card > div:nth-child(2) >> nth=0` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('.card > div:nth-child(2)').first().click();` |
| Event 441: press — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-PurchasedInfo').press('ControlOrMeta+a');` |
| Event 445: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-MerchantInBankruptcyLiquidationInd-N` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-MerchantInBankruptcyLiquidationInd-N').check();` |
| Event 446: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> input[name="ExpectedReceiptDate"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('input[name="ExpectedReceiptDate"]').click();` |
| Event 447: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=button >> internal:has-text=/^$/` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('button').filter({ hasText: /^$/ }).click();` |
| Event 448: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=button[name="previous"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('button', { name: 'previous' }).click();` |
| Event 449: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=button[name="26"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('button', { name: '26' }).click();` |
| Event 450: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Yes No"i >> nth=5` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Yes No').nth(5).click();` |
| Event 453: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-DidCardholderCancelPriorExpectedDate-N` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-DidCardholderCancelPriorExpectedDate-N').check();` |
| Event 454: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> #Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-CardholderAttemptToResolve-Y` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('#Form_Dispute-Consumer-ElaborationSection-NonReceiptGroup-CardholderAttemptToResolve-Y').check();` |
| Event 455: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> input[name="memberCaseNumber"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('input[name="memberCaseNumber"]').click();` |
| Event 456: fill — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> input[name="memberCaseNumber"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('input[name="memberCaseNumber"]').fill(runtimeValue);` |
| Event 458: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=button[name="Submit"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('button', { name: 'Submit' }).click();` |

### 13.1 - đơn vị đã hoàn trả 01.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 34: click — page1 | `.pwd-slot > .field > .v-input-container` | `await page.locator('.pwd-slot > .field > .v-input-container').click();` |
| Event 63: press — page2 | `body` | `await page1.locator('body').press('1');` |
| Event 64: press — page2 | `body` | `await page1.locator('body').press('9');` |
| Event 65: press — page2 | `body` | `await page1.locator('body').press('6');` |
| Event 67: press — page2 | `body` | `await page1.locator('body').press('3');` |
| Event 68: press — page2 | `body` | `await page1.locator('body').press('2');` |
| Event 88: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> .row.vr-table > div:nth-child(2) >> nth=0` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('.row.vr-table > div:nth-child(2)').first().click();` |
| Event 92: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Auth Code"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Auth Code' }).click();` |
| Event 93: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Auth Code"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Auth Code' }).fill(runtimeValue);` |

### 13.1 -đơn vị đã hoàn trả 02, check theo invoice.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 4: press — page1 | `body` | `await page.locator('body').press('t');` |
| Event 5: press — page1 | `body` | `await page.locator('body').press('h');` |
| Event 6: press — page1 | `body` | `await page.locator('body').press('a');` |
| Event 75: press — page2 | `internal:role=textbox[name="otpPassword"i]` | `await page1.getByRole('textbox', { name: 'otpPassword' }).press('Insert');` |
| Event 94: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> div >> internal:has-text="Card/Account Number:"i >> nth=5` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('div').filter({ hasText: 'Card/Account Number:' }).nth(5).click();` |
| Event 97: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="This date/time range is the"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('This date/time range is the').click();` |
| Event 102: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=link[name="Clear Auth Code filter"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('link', { name: 'Clear Auth Code filter' }).click();` |
| Event 103: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Auth Code"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Auth Code' }).press('Tab');` |
| Event 104: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch > th:nth-child(23)` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch > th:nth-child(23)').press('ArrowRight');` |
| Event 107: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).press('ArrowLeft');` |
| Event 130: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).press('ArrowRight');` |

### 10.4 13.1, case PI = yes, download chứng từ, đổi tên lưu file.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 56: click — page2 | `internal:text="<< Dashboard"i` | `await page1.getByText('<< Dashboard').click();` |
| Event 58: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #ti-request-form` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#ti-request-form').click();` |
| Event 64: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).press('ControlOrMeta+ArrowLeft');` |
| Event 67: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77750269763-Sale-1"] >> internal:role=cell[name="VND"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77750269763-Sale-1"]').getByRole('cell', { name: 'VND' }).click();` |
| Event 69: click — page2 | `iframe[name="buttons"] >> internal:control=enter-frame >> internal:role=button[name="View ▲"i]` | `await page1.locator('iframe[name="buttons"]').contentFrame().getByRole('button', { name: 'View ▲' }).click();` |
| Event 71: click — page2 | `internal:role=menuitem[name="Tran Summary"i]` | `await page1.getByRole('menuitem', { name: 'Tran Summary' }).click();` |
| Event 75: click — page3 | `internal:role=button[name="View ▲"i]` | `await page2.getByRole('button', { name: 'View ▲' }).click();` |
| Event 78: click — page2 | `internal:role=menuitem[name="Tran Details"i]` | `await page1.getByRole('menuitem', { name: 'Tran Details' }).click();` |
| Event 83: click — page4 | `internal:role=button[name="Save as PDF"i]` | `await page3.getByRole('button', { name: 'Save as PDF' }).click();` |

### 10.4 Code fraud nhiều case, kèm theo xuất report để tra cứu rol case.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 14: press — page1 | `internal:role=textbox[name="Username"i]` | `await page.getByRole('textbox', { name: 'Username' }).press('CapsLock');` |
| Event 47: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press(' ');` |
| Event 49: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press('Shift+T');` |
| Event 50: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press('h');` |
| Event 51: press — page1 | `internal:role=button[name="Password"i]` | `await page.getByRole('button', { name: 'Password' }).press('CapsLock');` |
| Event 58: press — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).press('CapsLock');` |
| Event 59: press — page1 | `internal:role=textbox[name="Password"i]` | `await page.getByRole('textbox', { name: 'Password' }).press('ControlOrMeta+a');` |
| Event 79: click — page2 | `internal:role=menuitem[name="<< Dashboard"i]` | `await page1.getByRole('menuitem', { name: '<< Dashboard' }).click();` |
| Event 90: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> .dataTables_scrollBody` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('.dataTables_scrollBody').click();` |
| Event 92: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> #dtheaderSearch >> internal:role=textbox[name="Transaction ID / Retrieval"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('#dtheaderSearch').getByRole('textbox', { name: 'Transaction ID / Retrieval' }).dblclick();` |
| Event 97: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77750063757-Sale-10"] >> internal:role=cell[name="0002"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77750063757-Sale-10"]').getByRole('cell', { name: '0002' }).click();` |
| Event 103: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77750063755-Sale-7"] >> internal:role=cell[name="0002"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77750063755-Sale-7"]').getByRole('cell', { name: '0002' }).click();` |
| Event 113: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> [id="77750063753-Sale-9"] >> internal:role=cell[name="0002"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('[id="77750063753-Sale-9"]').getByRole('cell', { name: '0002' }).click();` |
| Event 124: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="5611462197"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('5611462197').click();` |
| Event 125: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="5611462197"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('5611462197').dblclick();` |
| Event 126: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="VROL Case Number"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('VROL Case Number').click();` |
| Event 128: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=heading[name="Fraud Dispute Questionnaire"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('heading', { name: 'Fraud Dispute Questionnaire' }).click();` |
| Event 129: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="<< 1 of 4 >>"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('<< 1 of 4 >>').click();` |
| Event 130: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text=">>"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('>>').click();` |
| Event 133: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="<<"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('<<').click();` |
| Event 136: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="356314350589664"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('356314350589664').dblclick();` |
| Event 139: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=definition >> internal:has-text="VND"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('definition').filter({ hasText: 'VND' }).click();` |
| Event 141: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Card/Account Number: 4220-75xx-xxxx-9100 Cardholder Name: Network: VISA Tran ID"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Card/Account Number: 4220-75xx-xxxx-9100 Cardholder Name: Network: VISA Tran ID').click();` |
| Event 142: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="631570000065"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('631570000065').click();` |
| Event 144: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Vietnam Technological And"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Vietnam Technological And').click({` |
| Event 145: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Vietnam Technological And"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Vietnam Technological And').click();` |
| Event 146: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Issuer: Vietnam Technological"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Issuer: Vietnam Technological').click();` |
| Event 150: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="INTER-REGIONAL"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('INTER-REGIONAL').click({` |
| Event 151: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Tran Amount: 56569 VND"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Tran Amount: 56569 VND').click({` |
| Event 152: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Processing Date: 11/11/"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Processing Date: 11/11/').click({` |
| Event 153: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Processing Date: 11/11/"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Processing Date: 11/11/').click();` |
| Event 154: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="631574000068"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('631574000068').dblclick();` |
| Event 155: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Sale"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Sale').click();` |
| Event 159: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text=">>"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('>>').click({` |
| Event 160: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="356314412041172"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('356314412041172').click();` |
| Event 161: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Tran ID: 356314412041172"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Tran ID: 356314412041172').click();` |
| Event 162: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="356314412041172"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('356314412041172').dblclick();` |
| Event 163: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="74143616315000068235684"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('74143616315000068235684').click();` |
| Event 168: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="<< 2 of 4 >>"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('<< 2 of 4 >>').click();` |
| Event 170: select — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=combobox` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('combobox').selectOption('FT6');` |
| Event 171: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="Certification that the"i >> nth=0` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('Certification that the').first().click();` |
| Event 172: check — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:role=checkbox[name="Certification that the"i]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByRole('checkbox', { name: 'Certification that the' }).check();` |
| Event 180: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="ROL Case Number"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('ROL Case Number').dblclick();` |
| Event 181: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="/13/26 07:28 GMT  Nguyen Phuong, Thao  Multiple cases created at same time"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: '/13/26 07:28 GMT  Nguyen Phuong, Thao  Multiple cases created at same time' }).click();` |
| Event 182: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Related case 5611462198,"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Related case 5611462198,' }).click();` |
| Event 186: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="Related case 5611462198"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'Related case 5611462198' }).click();` |
| Event 187: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="Related case 5611462199"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'Related case 5611462199' }).click();` |
| Event 188: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=link[name="Related case 5611462200"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('link', { name: 'Related case 5611462200' }).click();` |
| Event 189: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="-414361-6315-00006823568-4"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('-414361-6315-00006823568-4').dblclick();` |
| Event 190: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="-414361-6315-00006823568-4"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('-414361-6315-00006823568-4').click();` |
| Event 193: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="Name: FACEBK *LELMXES4E4"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('Name: FACEBK *LELMXES4E4').click();` |
| Event 196: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="ARN:"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('ARN:').click();` |
| Event 197: click — page2 | `internal:role=menuitem[name="ROL 500 - Financial"i]` | `await page1.getByRole('menuitem', { name: 'ROL 500 - Financial' }).click();` |
| Event 198: select — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:label="Financial Type"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByLabel('Financial Type').selectOption('O');` |
| Event 199: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> div >> nth=5` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('div').nth(5).click();` |
| Event 201: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range From:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range From:' }).click();` |
| Event 202: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range From:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range From:' }).press('Shift+ArrowLeft');` |
| Event 203: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range From:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range From:' }).fill(runtimeValue);` |
| Event 204: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range To:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range To:' }).click();` |
| Event 205: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range To:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range To:' }).press('Shift+ArrowLeft');` |
| Event 206: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range To:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range To:' }).fill(runtimeValue);` |
| Event 208: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> div >> internal:has-text="Work Access Work Access Non-"i >> nth=3` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('div').filter({ hasText: 'Work Access Work Access Non-' }).nth(3).click();` |
| Event 213: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range From:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range From:' }).press('Tab');` |
| Event 214: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range To:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range To:' }).press('ArrowRight');` |
| Event 215: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Date Range To:"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Date Range To:' }).press('ArrowLeft');` |
| Event 220: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Is VCR?"s]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Is VCR?', exact: true }).click();` |
| Event 234: click — page5 | `internal:role=button[name="Show in folder"i]` | `await page4.getByRole('button', { name: 'Show in folder' }).click();` |
| Event 236: click — page5 | `internal:role=button[name="Copy download link"i]` | `await page4.getByRole('button', { name: 'Copy download link' }).click();` |
| Event 237: click — page5 | `#downloadsList` | `await page4.locator('#downloadsList').click();` |

### 10.4 standard code fraud.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 50: click — page1 | `internal:text="PasswordPlease enter your"i` | `await page.getByText('PasswordPlease enter your').click();` |
| Event 67: click — page1 | `.skeleton-item >> nth=0` | `await page.locator('.skeleton-item').first().click({` |
| Event 68: click — page1 | `section >> nth=1` | `await page.locator('section').nth(1).click();` |
| Event 76: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=textbox[name="Start Date"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('textbox', { name: 'Start Date' }).click();` |
| Event 78: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select all rows : activate to"i] >> internal:label="Transaction ID / Retrieval Ref #"s` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select all rows : activate to' }).getByLabel('Transaction ID / Retrieval Ref #', { exact: true }).click();` |
| Event 79: fill — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=row[name="Select all rows : activate to"i] >> internal:label="Transaction ID / Retrieval Ref #"s` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('row', { name: 'Select all rows : activate to' }).getByLabel('Transaction ID / Retrieval Ref #', { exact: true }).fill(runtimeValue);` |
| Event 93: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="* Certification that the"i >> nth=0` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('* Certification that the').first().click();` |
| Event 95: select — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> select[name="FraudTypeCode"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('select[name="FraudTypeCode"]').selectOption('FT6');` |
| Event 96: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> .fields.FraudTypeCode > .input-group` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('.fields.FraudTypeCode > .input-group').click();` |

### 13.9 Non receipt of Cash happy case.md

| Event/Action | Locator khảo sát | Playwright candidate |
|---|---|---|
| Event 63: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:text="Transaction Search PeriodThis"i` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByText('Transaction Search PeriodThis').click();` |
| Event 64: check — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=checkbox[name="Include subsequent Credits /"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('checkbox', { name: 'Include subsequent Credits /' }).check();` |
| Event 65: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=checkbox[name="Include subsequent Credits /"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('checkbox', { name: 'Include subsequent Credits /' }).dblclick();` |
| Event 67: uncheck — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=checkbox[name="Include subsequent Credits /"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('checkbox', { name: 'Include subsequent Credits /' }).uncheck();` |
| Event 70: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('Shift+C');` |
| Event 71: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('a');` |
| Event 72: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('·');` |
| Event 73: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('á');` |
| Event 76: press — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> body` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('body').press('s');` |
| Event 77: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> .vr-table` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().locator('.vr-table').click();` |
| Event 107: click — page2 | `iframe[name="bodyframe"] >> internal:control=enter-frame >> internal:role=cell[name="Cash"i]` | `await page1.locator('iframe[name="bodyframe"]').contentFrame().getByRole('cell', { name: 'Cash' }).click();` |
| Event 113: select — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> select[name="DisputeDueTo"]` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('select[name="DisputeDueTo"]').selectOption('CL');` |
| Event 114: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> .card.card-default.mt-0 > .card-body` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('.card.card-default.mt-0 > .card-body').click();` |
| Event 116: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="* Required Field"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('* Required Field').click();` |
| Event 117: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> .fields.WhatWasNotReceived > .input-group` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('.fields.WhatWasNotReceived > .input-group').click();` |
| Event 119: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> internal:text="5611442299"i` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().getByText('5611442299').dblclick();` |
| Event 121: click — page3 | `iframe[name="FRAME_ID_Dispute"] >> internal:control=enter-frame >> .col-md-12.float-end` | `await page2.locator('iframe[name="FRAME_ID_Dispute"]').contentFrame().locator('.col-md-12.float-end').click();` |

## 21.4. Quy tắc chuyển candidate selector thành production selector

1. Loại bỏ selector phụ thuộc dữ liệu động, SID, case number, username, timestamp, số tiền và `nth-child`.
2. Ưu tiên `getByRole`, `getByLabel`, stable `name`/`id` và text có ngữ cảnh.
3. Với table row, parse header và cell thành object; match theo Invoice Number chuẩn hóa, không ghép toàn bộ row text thành locator.
4. Mỗi selector có test `visible`, `enabled`, `unique count = 1` trước action.
5. Khi selector chính fail nhưng fallback thành công, ghi `SELECTOR_FALLBACK_USED` để theo dõi drift.
6. Nếu cả primary/fallback fail, chụp screenshot + HTML snapshot và ghi `SELECTOR_NOT_FOUND` hoặc `UI_CHANGED`.
7. Final Submit selector chỉ nằm trong `FinalSubmissionGuard`, không xuất hiện trong form handler.
8. Catalog phải được version hóa theo `selector_catalog_version` và gắn với evidence của run.

# 22. Điều chỉnh kế hoạch triển khai

Trước khi làm handler nghiệp vụ, cần hoàn thành theo thứ tự:

1. State journal, checkpoint, lease và resume engine.
2. Các cột AQ:BE hoặc companion state workbook nếu business không cho phép thêm cột vào file chính.
3. Config guard và Pre-submit Review.
4. Selector Catalog, Page Objects, frame helpers và selector drift reporting.
5. Common search/pre-check.
6. Handler 13.1, 13.9 và 10.4.
7. ROL500 reconciliation.
8. Kiểm thử mất điện/kill process tại các checkpoint, đặc biệt trước và sau Submit.

# 23. Tiêu chí nghiệm thu bổ sung

- Kill bot tại bất kỳ checkpoint nào và resume không mất case, không xử lý trùng.
- Kill tại `SUBMITTING` không gây submit lần hai.
- Excel cho business thấy trạng thái từng dòng và thời điểm cập nhật cuối.
- JSONL có thể rebuild snapshot sau khi xóa/hỏng snapshot.
- Hai worker không claim cùng một case.
- Selector catalog có primary/fallback, frame, action type và expected state.
- UI drift tạo evidence và unknown/technical report, không click nhầm.
- Không mất selector chi tiết từ summary khảo sát; mọi candidate đều được lưu trong phụ lục và được phân loại trước production.

# 24. Tích hợp module đăng nhập hiện có `vrol_login2`

## 24.1. Kết quả đánh giá hiện trạng

Gói login hiện có 7 file: `vrol_login.py`, `config.sample.xlsx`, `requirements.txt`, `README.md`, `run_login.bat`, `run_test.cmd`, `setup_venv.bat`. File Python compile hợp lệ và đã triển khai login Visa Online, Security Question, Max Session Reached, mở VROL bằng popup, Email MFA, đọc OTP từ Outlook Desktop Legacy, xác nhận landing VROL, logout, Rich logging, screenshot và Playwright trace.

Module hiện tại là một chương trình test login độc lập. Sau khi thành công, nó có thể đóng VROL, logout Visa Online và đóng browser context. Vì automation nghiệp vụ cần tiếp tục sử dụng chính VROL page/context để xử lý vài nghìn case, không nối bằng cách gọi `vrol_login.py` như một subprocess rồi mở browser mới. Cần refactor module thành service trả về authenticated session.

## 24.2. Những thành phần phải tái sử dụng

Giữ và chuyển thành module dùng chung:

- `as_bool`, `normalize_question`, `load_config`.
- Rich console và file logging.
- `retry_step` nhưng bổ sung error classification và checkpoint callback.
- Outlook sender resolution.
- OTP HTML/text parser.
- OTP baseline bằng Outlook EntryID.
- Freshness boundary bằng `ReceivedTime`.
- Outlook polling có timeout.
- Tìm locator trong top page và mọi frame.
- VROL landing validation theo URL, identity, navigation shell và bulletin.
- Max Session Reached handler.
- Safe trace export trước khi đóng context.

Không ghi password, security answer hoặc OTP vào log. Username và email cũng cần masking trong log/run summary production.

## 24.3. Kiến trúc sau refactor

```text
src/authentication/
├── auth-session.py
├── visa-online-login.py
├── security-question-handler.py
├── max-session-handler.py
├── vrol-service-launcher.py
├── vrol-mfa-handler.py
├── vrol-landing-validator.py
├── logout-handler.py
└── otp/
    ├── outlook-provider.py
    ├── otp-parser.py
    └── otp-freshness-policy.py

src/browser/
├── browser-session-manager.py
└── authenticated-session.py
```

Contract trả về:

```text
AuthenticatedVrolSession
├── context
├── portal_page
├── vrol_page
├── authenticated_at
├── success_marker
├── identity_masked
├── profile_path
├── auth_attempt
└── close(logout_policy)
```

Orchestrator gọi login một lần đầu batch, nhận `vrol_page`, sau đó chuyển cho Transaction Inquiry và các handler nghiệp vụ. Logout chỉ chạy khi batch kết thúc, người vận hành yêu cầu dừng, hoặc session không thể phục hồi.

## 24.4. Thay đổi entry point

Tách hai entry point:

1. `run_login_test.bat`: giữ hành vi test độc lập, có thể logout sau login.
2. `run_automation.bat`: login rồi tiếp tục batch, không logout ngay.

`run_login.bat` hiện tại có thể giữ để kiểm thử module login, nhưng production orchestration phải gọi Python API trực tiếp, không gọi `.bat` lồng nhau.

## 24.5. Settings cần ghép vào `config.xlsx`

Giữ hai sheet hiện có `Settings`, `SecurityQuestions`; bổ sung `RUN_SETTINGS`, `RULES`, `COLUMN_MAPPING`, `SELECTOR_OVERRIDES` hoặc tách config nghiệp vụ thành workbook riêng rồi load qua một Config Service.

Các settings login cần giữ:

- `login_url`.
- `username`.
- `welcome_name`.
- `browser_channel=chrome`.
- `headless`.
- `slow_mo_ms`.
- `navigation_timeout_ms`.
- `action_timeout_ms`.
- `login_result_timeout_ms`.
- `trust_device_90_days`.
- `user_data_dir`.
- `max_step_retries`.
- `open_vrol_after_login`.
- `vrol_popup_timeout_ms`.
- `vrol_auth_result_timeout_ms`.
- `otp_subject_keyword`.
- `otp_sender_email`.
- `otp_timeout_seconds`.
- `otp_poll_interval_seconds`.
- `otp_max_emails_to_check`.
- `otp_min_digits`, `otp_max_digits`.
- `otp_received_time_tolerance_seconds`.

Bổ sung:

- `logout_policy=END_OF_BATCH|ON_FAILURE|NEVER`.
- `session_healthcheck_interval_cases`.
- `session_healthcheck_interval_minutes`.
- `reauth_on_session_expired`.
- `max_reauth_attempts_per_run`.
- `outlook_process_check_enabled`.
- `outlook_start_command`.
- `otp_mailbox_folder`.
- `mask_identity_in_logs=YES`.
- `trace_mode=EXCEPTION|ALWAYS|OFF`.

Password và security answers hiện nằm trong `config.xlsx`. Đây là rủi ro cần xử lý trước production. Thiết kế mục tiêu là lưu secret trong Windows Credential Manager/OS keyring và để `config.xlsx` chỉ chứa credential alias. Nếu giai đoạn đầu vẫn dùng Excel, phải hạn chế ACL, không commit, không copy vào evidence và kiểm tra file permission khi startup.

## 24.6. State machine đăng nhập tích hợp

```text
AUTH_INIT
→ BROWSER_PROFILE_READY
→ VISA_LOGIN_PAGE_OPENED
→ CREDENTIALS_SUBMITTED
→ LOGIN_OUTCOME_DETECTED
→ MAX_SESSION_RESOLVED            (nếu có)
→ SECURITY_QUESTION_COMPLETED     (nếu có)
→ VISA_PORTAL_AUTHENTICATED
→ VROL_POPUP_OPENED
→ MFA_METHOD_SELECTED
→ OTP_BASELINE_CAPTURED
→ OTP_REQUESTED
→ OTP_SEND_CONFIRMED
→ FRESH_OTP_RECEIVED
→ OTP_SUBMITTED
→ VROL_AUTHENTICATED
→ AUTH_SESSION_READY
```

Mỗi transition ghi vào run journal. Không ghi password, answer hoặc OTP. Login checkpoint không được dùng để “resume giữa chừng” sau khi process chết; khi restart phải khởi tạo browser/session mới và login lại, sau đó resume giao dịch từ case checkpoint.

## 24.7. Selector Catalog login đã xác minh từ code hiện tại

| Bước | Selector/cách xác định | Expected state |
|---|---|---|
| Username | `page.locator('#external-login-username')` | visible |
| Password method | `page.get_by_role('button', name='Password', exact=True)` | visible/enabled |
| Password | `page.locator('#external-login-password')` | visible sau chọn Password |
| Continue | `page.get_by_role('button', name='Continue', exact=True)` | credentials submitted |
| Welcome | `page.locator('p.welcome-message').filter(has_text=/Welcome back,/i)` | Visa portal authenticated |
| Additional Verification | heading `/Additional Verification Required/i` | chọn Security Question |
| Security Question channel | `page.locator('#channel-KBA')` | checked |
| Channel Submit | button role `Submit`, exact | question page appears |
| Answer field | `page.locator('#answerField')` | visible |
| Question label | `page.locator("label[for='default-input']").first` | text mapped in config |
| Trust Device | `page.locator('#checkboxField')` | optional visible |
| Answer Submit | `page.locator("button[name='btnPrimary']")` | outcome detected |
| Max Session | heading `/Max Session Reached/i` | Yes button available |
| Max Session Yes | button role `Yes`, exact | oldest session closed |
| VROL service | link role `Visa Resolve Online`, exact | popup opens |
| MFA heading | heading `/Multi-Factor Authentication \(MFA\)/i` | visible |
| Email MFA | `vrol_page.locator('#Email')` | checked |
| MFA method Submit | `button[name='btnSubmit']` | Send OTP screen |
| Send OTP | `button[name='btnOTP']` | success message appears |
| OTP sent confirmation | exact text `One-Time Password successfully sent.` | start Outlook polling |
| OTP input | `input[name='oneTimePassword']` | fill only after fresh OTP |
| OTP Submit | `form button[name='btnSubmit']` | landing validation begins |
| VROL landing URL | contains `www.vrol.visaonline.com/rolol/AdminDispatcher` and `action=RouteToLandingPage` | primary success |
| Logged-on identity | `span.supportText` containing `Currently logged on as:` | secondary success |
| Inquiry menu | `#inquirymenua` | navigation shell |
| Quick Search | `#searchField` | navigation shell |
| Bulletin | `td.title` containing configured bulletin text | fallback success |
| Profile menu | `#vol-user-controls-drop` | logout menu visible |
| Return-to-login | `#external-login-username` | logout confirmed |

Các selector này được đưa vào Page Object/Selector Registry, kèm primary, fallback, timeout, expected state và selector catalog version.

## 24.8. Điểm nối chính xác với batch automation

Điểm nối là sau `wait_for_vrol_landing()` trả về thành công. Thay vì tiếp tục nhánh đóng VROL/logout, hàm `authenticate()` trả `AuthenticatedVrolSession` cho `BatchRunner`:

```text
session = auth_service.authenticate(config, run_context)
batch_runner.run(session.vrol_page, input_workbook, resume_store)
shutdown_service.close(session, logout_policy)
```

`BatchRunner` phải kiểm tra marker `AUTH_SESSION_READY` trước khi claim case đầu tiên.

## 24.9. Session health check trong batch

Trước khi xử lý GUID mới, và định kỳ theo config:

1. Kiểm tra VROL page chưa đóng.
2. Kiểm tra landing URL hoặc navigation shell.
3. Kiểm tra không xuất hiện login/MFA/session-expired page.
4. Kiểm tra `#inquirymenua` hoặc control xác thực tương đương còn visible.
5. Nếu session expired, ghi checkpoint cho case hiện tại trước khi re-auth.
6. Re-auth trong browser context mới nếu cần.
7. Quay lại case từ checkpoint read-only gần nhất; không replay Final Submit.

Trạng thái bổ sung:

- `AUTH_SESSION_HEALTHY`.
- `AUTH_SESSION_EXPIRED`.
- `REAUTH_IN_PROGRESS`.
- `REAUTH_SUCCESS`.
- `REAUTH_FAILED`.

## 24.10. Outlook readiness

Code hiện tại gọi COM Outlook trực tiếp nhưng chưa có bước chủ động xác nhận Outlook process/application sẵn sàng trước khi gửi OTP. Trước production cần bổ sung:

1. Thử `win32com.client.Dispatch('Outlook.Application')` và truy cập Inbox.
2. Nếu thất bại và policy cho phép, chạy Outlook bằng command cấu hình.
3. Poll đến khi MAPI Inbox đọc được.
4. Chỉ sau đó mới click Send OTP.
5. Nếu Outlook không sẵn sàng, dừng tại `OUTLOOK_NOT_READY`; không gửi nhiều OTP liên tiếp.

## 24.11. Retry policy riêng cho login

Có thể retry:

- Navigation timeout trước credential submit.
- Locator chưa visible.
- Popup chưa mở.
- Outlook tạm chưa đọc được.
- OTP email chưa tới trong timeout, với giới hạn resend cấu hình.
- VROL landing marker chậm.

Không retry mù:

- Sai password.
- Security question không có mapping.
- Account locked.
- Identity sau login khác expected account.
- OTP đã submit nhưng outcome không xác định.
- Max Session lặp quá giới hạn.

`retry_step` hiện bắt mọi exception. Khi tích hợp phải phân loại `RetryableAuthError`, `BusinessAuthError`, `SecurityAuthError`, `UnknownAuthOutcome`; chỉ retry nhóm đầu.

## 24.12. Vấn đề cần chỉnh trước khi nối production

1. `show_run_summary()` đang hiển thị username đầy đủ; phải mask.
2. Config sample chứa username và security answer mẫu; bản production không được lưu secret thật trong source package.
3. `SENSITIVE_KEYS` đã khai báo nhưng chưa được áp dụng như một redaction filter chung cho logger.
4. `retry_step` retry mọi exception, có nguy cơ lặp thao tác không an toàn.
5. `logout_after_login=True` phù hợp test nhưng không phù hợp batch.
6. Trace đang bật toàn run; batch hàng nghìn case cần trace theo exception hoặc segment để tránh file quá lớn.
7. Run directory chỉ dùng timestamp đến giây và `exist_ok=False`; cần thêm run UUID để tránh collision.
8. Persistent profile cần lock file để ngăn hai process dùng cùng profile.
9. Khi `SUBMIT_VROL_OTP` outcome không rõ, không được resend/submit lại tự động trước khi phân loại page state.
10. `config.sample.xlsx` có `headless=True` trong file thực tế trong khi description khuyến nghị False; production bắt đầu với headed Chrome để business review và khảo sát ổn định.

## 24.13. Kế hoạch tích hợp theo thứ tự

### Bước A: Baseline và regression login

- Giữ nguyên package login làm baseline.
- Chạy `run_test.cmd` nhiều vòng trên máy dev để lấy tỷ lệ pass/fail và failure taxonomy.
- Lưu result theo run ID, không dùng credential trong evidence.

### Bước B: Refactor không thay đổi hành vi

- Tách các module nhưng giữ cùng selector/state.
- Viết unit test cho normalize question, OTP parser, freshness boundary và config validation.
- Viết fake page/fixture test cho outcome classification.

### Bước C: Trả authenticated session

- Tạo `authenticate()` trả context, portal page và VROL page.
- Bỏ logout khỏi happy path của production.
- Gắn `AUTH_SESSION_READY` vào orchestrator journal.

### Bước D: Nối state/resume engine

- Login là run-level state; transaction là case-level state.
- Mất điện yêu cầu login lại nhưng case resume từ journal.
- Session expired giữa batch yêu cầu checkpoint rồi re-auth.

### Bước E: Nối VROL navigation

- Từ VROL landing, gọi Page Object Transaction Inquiry.
- Dùng chính `vrol_page`, không tạo Chrome/PAN session mới.
- Sau khi xác minh navigation, chạy Pre-submit Review cho case đầu tiên.

### Bước F: Hardening

- Outlook readiness.
- Credential redaction/secret storage.
- Profile lock.
- Error classification.
- Re-auth policy.
- Trace segmentation.
- Test kill process tại login, sau VROL landing và giữa batch.

## 24.14. Tiêu chí nghiệm thu tích hợp login

- Login module trả authenticated VROL page cho batch runner.
- Không logout trước khi batch hoàn thành.
- Có thể login lại sau mất điện rồi resume đúng case.
- Session expiry không làm mất checkpoint.
- OTP cũ không được tái sử dụng.
- Không gửi OTP khi Outlook chưa sẵn sàng.
- Không lộ password, answer, OTP hoặc full username trong log/report.
- Hai process không dùng cùng persistent Chrome profile.
- Sai identity làm run fail an toàn.
- Login test runner vẫn hoạt động độc lập.
- VROL Transaction Inquiry mở được từ session do module login tạo ra.

# 25. Điều chỉnh kiến trúc tổng thể sau khi nhận module login

Module `vrol_login2` trở thành implementation nền của `AuthenticationSubsystem`, không bị viết lại từ đầu. Kế hoạch phát triển cập nhật:

1. Đóng băng baseline login và regression test.
2. Refactor thành authenticated-session service.
3. Hoàn thiện state journal/resume và config guard.
4. Nối VROL landing với Transaction Inquiry Page Object.
5. Chạy Pre-submit Review Code 13.1.
6. Mở rộng 13.9 và 10.4.
7. Hardening session/OTP/Outlook và ROL500.
8. Chỉ bật Full Submit sau business sign-off.
