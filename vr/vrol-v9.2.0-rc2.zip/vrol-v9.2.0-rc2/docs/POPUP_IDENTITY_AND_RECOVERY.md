# Questionnaire ownership and recovery

Excel `CODE CB` selects the workflow: 10.4 uses Fraud; 13.1 uses Consumer with
`DisputeDueTo=NR`; 13.9 uses Consumer with `DisputeDueTo=CL`. A conflicting
Consumer preset is rejected. A page heading alone cannot distinguish 13.1/13.9.

The popup registry is installed before actions and follows each opener chain.
Legacy named `window.open` and form targets are scoped to their worker; existing
iframe targets are preserved. Five simultaneous workers using identical window
and nested form target names are covered by a real Chrome regression test.

Before filling, after filling and before Final Submit, validate the questionnaire
against the selected transaction: Tran ID/invoice, code/category and ROL number.
Production inputs additionally require masked card BIN/last4 and transaction date.
The expected date comes from the selected VROL financial row, since upstream Excel
can carry an authorization date. Unexpected/missing identity fields stop the case.
The checkpoint records the verified masked identity without full PAN.

Reacquire the live questionnaire frame after navigation/maximization and require
stable identity. Do not infer the code from whichever popup appears first. ROL-749
is acknowledged once, then its old warning must leave before continuing. ROL-1537
requires individual disputes and remains a review case under GUID-wide rules.

Chrome restarts after 100 leased GUIDs: block new leases, drain active workers,
close the bot context, relogin once and recreate worker tabs. Preflight ROL500 is
outside this lifecycle and is not repeated. Tabs are recycled after 25 GUIDs per
worker. Per-GUID deadlines and bounded popup cleanup prevent indefinite waits.
Only read-only failures before any case side effect may retry on a fresh tab.
PI has two bounded attempts with exact transaction/PDF identity validation.
An uncertain case creation/final submit remains held for reconciliation.

These mechanisms follow the opener/event and record-identity guidance in
[the article supplied by the user](https://app.thetestingacademy.com/blog/playwright-multiple-tabs-popup-race-condition),
the official [Playwright pages guide](https://playwright.dev/python/docs/pages),
and [Page popup/crash events](https://playwright.dev/python/docs/api/class-page#page-event-popup).
Named targets can reuse existing windows as described by
[MDN Window.open](https://developer.mozilla.org/en-US/docs/Web/API/Window/open#reuse_existing_windows_and_avoid_target_blank).
