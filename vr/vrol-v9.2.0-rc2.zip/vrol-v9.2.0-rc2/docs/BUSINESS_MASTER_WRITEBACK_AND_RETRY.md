# Ghi trạng thái vào file 09 và xử lý các case cần review

Áp dụng cho bản native async, cập nhật ngày 20/11/2026. Quy ước đã thống nhất: user nhập `SKIP` ở AM; bot ghi ngược vào **file 09 gốc**, không sửa snapshot contract.

## 1. Quy ước dữ liệu

Sheet `Sheet1`, header dòng 2, dữ liệu bắt đầu từ dòng 4. Dùng vị trí cột vật lý, không chèn ba cột mới vào giữa workbook.

| Cột | Nội dung |
| --- | --- |
| AK | Số VROL nếu đã quan sát được; giữ dạng text |
| AL | Ngày bot xử lý theo múi giờ Việt Nam, hiển thị `dd/mm/yyyy` |
| AM | Kết quả nghiệp vụ hoặc lý do cần user kiểm tra |

| Kết quả | AM |
| --- | --- |
| Có ít nhất một chứng từ PI tải thành công | `PI` |
| Questionnaire Fraud đã điền xong hoặc Final Submit thành công | `FRAUD` |
| Questionnaire Consumer đã điền xong hoặc Final Submit thành công | `consumer` |
| Không đẩy theo rule nghiệp vụ | `NO_CB` |
| Không đẩy do Assoc Dispute D | `Assoc D` |
| VROL trả 300+ giao dịch | `Trả user: VROL trả 300+ giao dịch; cần kiểm tra thủ công (backlog)` |
| Nhiều Sale/Cash cho một invoice | `Trả user: nhiều Sale/Cash cho một invoice; cần kiểm tra thủ công` |
| Retry vẫn không giải quyết được | `Review: ...` hoặc lý do ROL-1537 cần xử lý từng giao dịch |

Bot ghi cùng kết quả lên **mọi dòng của GUID**, kể cả dòng không đủ điều kiện vào queue. Chỉ cần một dòng AM có `SKIP`, kết quả đã ghi hoặc nội dung khác ngoài `FORCE` thì bỏ qua toàn bộ GUID ở lần chạy tiếp theo. Không phân biệt chữ hoa/thường của marker; khoảng trắng đơn thuần được xem là trống. Bộ lọc này áp dụng cả chế độ user nhập danh sách GUID và `--no-resume`.

Ví dụ: GUID có hai dòng SALE đủ điều kiện, user nhập `SKIP` ở AM của một dòng → cả GUID bị bỏ qua. Dòng HOLD có AM trống chỉ bị loại theo rule SALE, không tự làm các dòng SALE khác của GUID bị bỏ qua.

### Chủ động chạy bằng FORCE ở AM

User nhập `FORCE` vào AM của một dòng thuộc GUID để yêu cầu xử lý cả nhóm theo cùng phạm vi như chọn GUID trên dashboard. Bot lấy nguyên code, invoice, QT, ngày và merchant từ file 09, PAN từ input.txt. Chỉ vượt điều kiện upstream `VALID CHARGEBACK = Y`, ví dụ upstream loại do hơn 35 giao dịch. Không đổi code và không bỏ qua SALE, tuổi giao dịch, Visa PAN, ROL đã có, registry/hold, PI-first hoặc các rule Assoc D/refund/ECI trên VROL.

Các dòng khác trong nhóm có thể để AM trống hoặc FORCE. Nếu có cả SKIP/kết quả đã ghi và FORCE trong cùng GUID, SKIP/kết quả đã ghi được ưu tiên; cần kiểm tra và xóa các kết quả cũ có chủ đích trước khi đặt yêu cầu mới. FORCE không tự bỏ registry/hold hoặc tạo lại một case ROL đã có.

Sau khi xử lý, bot thay FORCE bằng kết quả thực tế PI/FRAUD/consumer/NO_CB/Assoc D hoặc lý do review, đồng thời ghi AL/AK. Nếu nhóm bị loại trước khi vào xử lý, giữ marker và báo lý do trong `input_exclusions.json` và `am_force_report.csv/json`. Report FORCE tách riêng phần yêu cầu chủ động, ghi code từ input, trạng thái, override upstream, số PI, ROL và folder. Nếu file master bị khóa, ý định ghi kết quả thay FORCE được giữ bền vững và có thể sync lại sau khi đóng Excel; kết quả cũ không tự tiêu thụ một yêu cầu FORCE mới.

Có thể nhập FORCE sau lúc publish contract nhưng trước lúc bot khởi động; xóa FORCE khỏi master trước khi chạy cũng hủy yêu cầu FORCE đã nằm trong snapshot. Nếu code/invoice/QT của master khác snapshot, cần publish contract mới; không dùng FORCE để chạy theo code cũ.

PI ưu tiên hơn điều kiện loại trừ. Nếu chỉ một số PI tải thành công thì AM vẫn là `PI` theo quy ước trên, nhưng trạng thái kỹ thuật vẫn là cần review; xem `BOT PI STATUS`, `guid_outcomes.csv` và ảnh để biết các file còn thiếu. `FRAUD`/`consumer` ở AM là tuyến xử lý, **không xác nhận Final Submit**: cột `BOT FINAL SUBMIT CLICKED`, checkpoint và kết quả xác nhận submit mới thể hiện việc gửi cuối cùng.

## 2. Luồng input, carry-forward và writeback

1. Dashboard ghép đúng cặp FC + GUID2PAN, tạo snapshot bất biến của `09_chargeback_classified.xlsx` và `input.txt`. Manifest mới bổ sung `files.workbook.source_path` trỏ về file 09 gốc.
2. VROL xác minh hash snapshot, format mapping và lineage. Trước khi xây queue, tạo bản làm việc `<run>/09_BUSINESS_INPUT.xlsx`.
3. Ghép AM mới nhất từ file 09 gốc vào bản làm việc theo GUID. User có thể thêm SKIP sau lúc publish contract nhưng trước lúc bot khởi động; marker vẫn chặn GUID nếu các thông tin khác đã đổi. Với GUID chưa có marker, nếu tập `(invoice, BUT TOAN, CODE CB)` giữa master và snapshot khác nhau hoặc GUID đã bị xóa khỏi master, dừng trước login và báo `MASTER_INPUT_IDENTITY_CHANGED`; cần publish contract mới để tránh chạy theo code cũ.
4. Khôi phục kết quả từ ledger vào bản làm việc nếu fingerprint tập định danh trùng và AM đang trống. Đồng thời ghi bù các kết quả này vào master mới từ upstream. File mới phải còn đúng các GUID và bộ định danh tương ứng; không suy luận từ số dòng.
5. Lọc AM, SALE, tuổi giao dịch và các điều kiện hiện có; chạy preflight ROL500 và bot. Không đổi code tra soát từ Excel.
6. CentralWriter tuần tự nhận kết quả của các worker. Mỗi CASE_RESULT ghi journal và ledger, cập nhật workbook kết quả. Khi flush (mặc định 20 GUID) và khi kết thúc run, merge ngược AK/AL/AM vào master.
7. Sau postflight ROL500, lấy số case theo invoice từ workbook đối chiếu rồi cập nhật AK của những GUID có outcome được quản lý. Không biến việc tìm thấy số ROL thành xác nhận Final Submit.

Ledger ở `<VROL>/runtime/business_state.sqlite3`, không chứa PAN hoặc mật khẩu. Giữ ledger qua các ngày chạy để đưa kết quả vào các bản file 09 mới. Backup master đầu tiên tại `<run>/master_backups/`; file này không bị ghi đè bởi lệnh sync chạy lại.

Ghi master bằng cách đọc streaming rồi chỉ sửa XML các dòng có cell cần đổi, giữ nguyên các dòng khác, ZIP part khác, công thức và cache công thức không liên quan. Không dựng DOM toàn worksheet hoặc save/rebuild toàn bộ master bằng openpyxl. Trước khi replace, so sánh hash master để phát hiện file bị sửa trong lúc merge. Nếu file bị khóa hoặc thay đổi, ghi `PENDING`; nếu AM đã có giá trị khác hoặc AK chứa số case khác, giữ nguyên dữ liệu user và báo `CONFLICT`. Không ghi đè SKIP; chỉ thay FORCE bằng kết quả mới có writeback intent tương ứng.

File Excel nên đóng trong lúc chạy để master được cập nhật ngay. Kết quả vẫn còn trong ledger và output nếu master đang mở. Không mở đồng thời hai bản bot dùng chung master/ledger; process lock bảo vệ các lệnh của cùng một cài đặt.

## 3. Config và các lệnh CMD

Các khóa trong sheet `Settings`:

| Key | Default | Cách dùng |
| --- | --- | --- |
| `async_master_writeback_enabled` | `YES` | Bật ghi file 09 gốc |
| `async_master_workbook` | trống | Có thể đặt đường dẫn tuyệt đối tới master dùng chung |
| `business_state_retention_days` | `180` | Số ngày giữ kết quả trong ledger |
| `pi_spinner_hidden_timeout_ms` | `45000` | Hạn chờ spinner PI |
| `pi_spinner_hidden_poll_ms` | `200` | Khoảng cách kiểm tra spinner |
| `pi_spinner_hidden_stable_polls` | `3` | Số lần liên tục thấy display none |
| `pi_documents_export_dir` | trống | Thư mục đích có sẵn để copy PI sau postflight thành công |

Ưu tiên đường dẫn master: CLI `--master-workbook` → `async_master_workbook` → `source_path` trong contract → input thủ công / đường dẫn file 09 trong config. Với contract cũ chưa có source_path, đặt `async_master_workbook` rõ ràng. Không đặt master vào thư mục snapshot `ops_inputs`.

Cài đặt độc lập bằng `install.cmd`, thiết lập đường dẫn bằng `configure_paths.cmd`. Khi nâng cấp cài đặt đã có config, có thể thêm ba key master/retention ở bảng trên; nếu không thêm, default trong code vẫn áp dụng. Không thay config production bằng sample vì sample không có credentials.

Task Scheduler vẫn chạy `run_scheduled.cmd`, dự kiến 19:40 sau cặp upstream 19:30. Hai project được cài độc lập, chia sẻ đường dẫn contract và quyền truy cập master. Tài khoản chạy Task Scheduler cần quyền ghi cả thư mục chứa master để tạo temp và atomic replace.

Sau khi đóng Excel, ghi bù mà không login/OTP:

```bat
sync_master_status.cmd --run-dir "runtime\async_parallel\<run_id>"
```

Có thể chỉ rõ `--master-workbook "D:\Data\09_chargeback_classified.xlsx"`. Lệnh giữ nguyên snapshot, đọc ledger và ROL từ output của run; return code 2 nếu còn PENDING/CONFLICT.

Dọn ledger/registry và thử ghi bù:

```bat
cleanup_business_state.cmd --master-workbook "D:\Data\09_chargeback_classified.xlsx"
```

Lệnh giữ các marker AM; không xóa input, PI, run cũ hay review holds. Mỗi run cũng tự cleanup: xóa ledger quá hạn, loại registry entry trùng/GUID không còn trong input và entry đã được ledger quản lý. Registry legacy chưa có ledger được giữ nếu GUID còn trong input, vì không đủ thông tin để tự khôi phục chính xác outcome của lịch sử. Có backup registry trước thay đổi. Marker AM vẫn hiệu lực sau khi ledger hết hạn.

Xóa AM đơn thuần không đảm bảo chạy lại: ledger có thể khôi phục kết quả; registry và review hold còn có thể chặn. Để replay có chủ đích, dùng file gốc có AM trống và `--no-resume` trong lệnh chạy thủ công; không dùng lại snapshot đã ghi marker. Các hold sau Issuer Action/Final Submit chưa rõ kết quả vẫn phải đối chiếu riêng. Tính năng này không tự xóa hold để tạo lại case.

## 4. Sửa rule và các lỗi cần review

### Bảng giao dịch chưa render đủ

Các case Assoc D trong feedback có lỗi đọc hàng 32 cột khi mới có 8/11/12/17 TD. `native_table.parse_row_for_code()` chờ TD thứ 31 được gắn vào DOM trước khi lấy snapshot. Sau đó vẫn xác minh schema và identity; không đoán cột khi dữ liệu còn thiếu.

### Rule toàn GUID

`native_precheck.py` khám phá PI ở mọi invoice trước. Nếu không có PI, đánh giá veto cho toàn GUID trước khi kiểm tra tính duy nhất của Sale/Cash. Vì vậy nhiều Sale ở invoice đầu không che mất Assoc D/Credit/Cash Rev ở invoice sau. Moto/ECI 5/6/blank vẫn chỉ loại code 10.4.

VROL báo rõ `300+ Transactions Found` hoặc chỉ trả first 300: trả user kiểm tra thủ công; tính năng xử lý vượt giới hạn để backlog. Không tự kết luận không có Sale/refund chỉ vì invoice nằm ngoài tập kết quả bị cắt. Nhiều Sale/Cash cùng invoice cũng trả user; không tự chọn dòng đầu. Associated Transactions thật vẫn dừng và chụp hình; bảng Associated Transactions nhúng trong trang summary không bị xem là popup cần dừng.

### Spinner PI

`native_pi.wait_for_pi_spinner()` áp dụng hướng dẫn đã kiểm chứng trên production: phải tìm thấy `img#piSpinner`; tất cả spinner trong popup đúng owner có computed `display == none` liên tục 3 lần. `visibility:hidden`, opacity 0 hoặc spinner chưa xuất hiện không đủ điều kiện. Chỉ sau đó mới xác minh lại transaction và bấm Save as PDF. PI vẫn có kiểm tra transaction ID trong nội dung PDF.

### Retry questionnaire / ROL-1537

`case_retry.py` cho phép **một lần** khởi động lại chain trên tab worker mới đối với ROL-1537, timeout chuyển từ Case Creation sang questionnaire hoặc không tìm thấy popup/questionnaire ổn định. Có thể đã tạo case nháp ở attempt đầu; chấp nhận theo yêu cầu business, nhưng lưu checkpoint/ROL nếu quan sát được và ảnh tại `case_attempt_01/` + `case_retry_history.json`.

Chỉ cleanup popup thuộc worker hiện tại. Không động tới các worker khác. Retry vẫn đi qua đầy đủ rule và xác minh questionnaire theo code Excel + Tran ID/invoice + ngày + thẻ masked + ROL ổn định. Không retry khi code/invoice/card/date/owner mismatch, hoặc khi checkpoint đã bước vào `FINAL_SUBMIT_*`/final_submit_clicked. Timeout mất phản hồi sau Final Submit phải đối chiếu ROL500, không tự gửi lại.

Nếu retry tiếp tục gặp ROL-1537, trả user xử lý từng giao dịch và ghi rõ đã retry một lần. Không tự tách nhóm để submit từng giao dịch trong bản sửa này. Retry read-only trước Issuer Action hiện có vẫn giới hạn một lần riêng; không có vòng lặp retry vô hạn.

## 5. Báo cáo và dashboard

- Workbook output trong run giữ các cột BOT chi tiết, AK/AL/AM.
- `guid_outcomes.csv/json` bổ sung business_result và case_retry_count; reason_code/reason_detail giữ nguyên để audit.
- `master_writeback.json` nêu trạng thái merge, các GUID xung đột và lỗi ghi; `master_backups/` giữ bản trước lần sửa đầu.
- Dashboard VROL mặc định mở bảng kết quả, có nút mở Excel output, documents và file log; không poll live log. Bảng có lọc PI/FRAUD/consumer/NO_CB/Assoc D/Review/đang chạy, số lượng, tìm GUID, mở folder GUID và ảnh. Báo cáo writeback chỉ hiện thêm khi PENDING/CONFLICT.
- PI theo từng GUID ở `groups/<prefix>_<GUID>/documents/`; tổng hợp trong run. Khi export không được cấu hình, giữ `<run>/documents/`.

### Xuất thư mục PI theo ngày

Đặt `Settings.pi_documents_export_dir` bằng thư mục đích đã tồn tại, ví dụ `Z:\Visa_PI`. Key thiếu/trống hoặc đường dẫn không tồn tại → bỏ qua, không tạo thư mục đích gốc. Cấu hình trống sẵn trong sample.

Sau khi mọi worker kết thúc và postflight ROL500 SUCCESS, bot copy toàn bộ folder PI tổng hợp sang `<đích>/YYYYMMDD_documents`, rồi đổi `<run>/documents` thành `<run>/YYYYMMDD_documents`. Ngày lấy theo run_business_date tại Việt Nam. Các link PI trong JSON và workbook output được cập nhật; folder documents riêng của từng GUID giữ nguyên. Không export nếu postflight thất bại/bị bỏ qua hoặc folder PI rỗng.

Nhiều run cùng ngày có thể bổ sung file vào cùng folder đích: file giống hash được giữ một bản; cùng tên khác nội dung thì báo `PI_EXPORT_FILENAME_CONFLICT`, không ghi đè. Xem `pi_documents_export.json` để biết số file copy, file đã có, local_path/export_path và lỗi. Dashboard có nút mở folder đích khi đã được tạo. Thư mục đích không được nằm trong run hiện tại.

### Trạng thái kết thúc

- `SUCCESS`: luồng kết thúc bình thường, không còn mục cần review.
- `SUCCESS_WITH_REVIEWS`: luồng đã hoàn tất, có case cần review/chờ Final Submit, ROL500 cần đối chiếu, writeback pending/conflict hoặc lỗi copy PI. Vẫn tính là run thành công; CMD return code 0.
- `FAILED`: lỗi toàn luồng/gián đoạn hoặc postflight ROL500 thất bại. CMD return code khác 0.

Lỗi từng GUID được ghi thành kết quả Review, không tự biến run đã hoàn tất thành FAILED. Dashboard vẫn đọc được trạng thái `COMPLETED_WITH_ISSUES` của các run cũ và trình bày như success with reviews.

## 6. Kế hoạch kiểm thử và giới hạn

1. Test fixture: AM trên dòng HOLD vẫn chặn toàn GUID; SKIP hiệu lực sau publish; exact labels/date/ROL cho toàn GUID; snapshot không đổi.
2. Test carry-forward: cùng identity được khôi phục, đổi invoice/code không dùng nhầm lịch sử; SKIP user được giữ; --no-resume không khôi phục ledger.
3. Test writeback: Excel khóa file, hash thay đổi, AK/AM conflict, postflight ROL, backup, ngày Việt Nam, style/công thức/cache/ZIP part được giữ.
4. Test browser cục bộ: spinner chưa tồn tại/visibility hidden/nhiều frame, TD append chậm; test popup/download 5 worker hiện có.
5. Test retry: timeout và ROL-1537 thành công/thất bại, đúng một retry, lưu ảnh/checkpoint; identity mismatch và Final Submit không retry.
6. Dashboard: provenance master, bỏ nhóm AM khi kiểm tra mapping, hiển thị writeback deferred.
7. Kiểm tra thực tế Visa chỉ chạy subset khi cần và đủ input/phiên đăng nhập; không dùng mẫu giả để khẳng định đã test được dịch vụ Visa. Không test Final Submit thật trong môi trường hiện tại.

Các artifact feedback của business là dữ liệu riêng, không đưa vào Git/ZIP public. Số liệu của lượt chạy trên máy khác không thể được thay đổi hoặc kết luận là đã được chạy lại từ các test cục bộ này.

Kết quả kiểm chứng bản sửa tại máy phát triển ngày 20/11/2026: **239 test bot, 28 test dashboard đều qua**. Test bổ sung FORCE/ưu tiên SKIP/kết quả cũ, không vượt age/SALE/ROL/registry, marker được thay bằng outcome mới, ghi bù sau restart, hủy FORCE đã publish, code snapshot bị thay đổi, XML có namespace, các dòng thưa và extension payload không liên quan. JavaScript dashboard kiểm tra cú pháp thành công. Bộ test có Chrome cục bộ cho popup/download 2 và 5 worker, spinner/render chậm, các nút mở file/folder qua API mock và lọc bảng kết quả.

Đã chạy subset 15 GUID trên Visa thật với 5 workers, dừng trước Final Submit. Kết quả: 9 đối chiếu case hiện có, 3 nhiều Sale, 2 giới hạn 300+, 1 lỗi ổn định filter; cả 15 cần review. Đã đối chiếu 20 dòng master: 44 cell thay đổi, chỉ trong AK/AL/AM, các cell và ZIP part không liên quan được giữ nguyên. Tiến trình pilot bị gián đoạn sau khi đã lưu đủ kết quả, đã khôi phục ghi file từ artifact và tải postflight ROL500 thành công, không replay hành động case. Trạng thái cuối SUCCESS_WITH_REVIEWS. Nhánh PI/FRAUD/consumer không phát sinh trong subset này; không test Final Submit thật.

Lượt pilot dùng flush mỗi GUID để quan sát; production giữ mặc định batch 20. Sau khi phát hiện ghi file chậm, merge master chuyển sang streaming/vá XML theo dòng. Bản mới được xác minh trên bản sao file tổng thật, đồng thời có test giữ cache công thức, style, namespace và ZIP part không liên quan. Sample vẫn tắt trace/Final Submit và để trống đường dẫn export. Artifact feedback/run thực tế không nằm trong Git/ZIP sạch.
