# Cửa sổ maximized và viewport native — 19/11/2026

Đã cập nhật bản async theo yêu cầu: trang chính render theo vùng nội dung thực của cửa sổ maximized; popup thông thường giữ kích thước native; questionnaire maximize **trước khi điền**, rồi chụp sau khi điền xong.

## Nguyên nhân và cách sửa

`viewport=None` trong API Python không tương đương `no_viewport=True`: None bị bỏ khỏi options và Playwright vẫn có thể dùng viewport mặc định. Ngoài ra, cách cũ tự đặt kích thước viewport bằng bounds cửa sổ trừ 16/100 px và áp tối thiểu 1280 px không phù hợp mọi DPI, màn hình hoặc loại cửa sổ Chrome. Luồng cũ còn điền questionnaire trước rồi mới maximize lúc chụp.

- Factory `launch_browser_context()` dùng **no_viewport=True** cùng `--start-maximized`.
- `window_layout.maximize_window()` điều khiển đúng windowId của Page, bỏ device-metrics override, xác minh trạng thái maximized và chờ geometry ổn định. Khôi phục cửa sổ minimized/fullscreen trước khi maximize. Nếu không xác nhận được trong thời gian giới hạn, báo lỗi thay vì tiếp tục với kích thước không rõ.
- Không tính vùng nội dung từ kích thước ngoài cửa sổ bằng số pixel cố định. Chrome tự xử lý viền, toolbar, monitor và Windows DPI. Native metrics được ghi để debug.
- Xác nhận cửa sổ chính ở Visa Access, VROL entry và worker. Không đăng ký event maximize toàn bộ page/popup trong context.
- Questionnaire: nhận diện đúng popup/frame thuộc worker → maximize → chờ reflow/frame-width ổn định → ghi geometry vào checkpoint → điền → kiểm tra layout/chụp full page. Iframe được mở chiều cao cho ảnh đầy đủ; không ép min-width theo viewport giả.
- Questionnaire luôn maximize trước fill. Key cũ `questionnaire_maximize_before_capture` chỉ điều khiển lần xác nhận bổ sung trước ảnh; giá trị NO không bỏ bước bắt buộc trước fill. Không đổi config.xlsx trong lượt này.

## Kiểm tra headful cục bộ

Chạy **run_window_layout_test.cmd**. Có thể thêm `--cycles 3` hoặc số lượt khác. Script dùng profile test riêng và HTML mô phỏng; không kết nối Visa, không dùng thông tin đăng nhập và không tạo case thật.

Lượt đạt: `runtime/window_layout/20261119_234850/result.json`, **3/3 cycles PASS**, cùng profile đóng/mở lại ba lần:

| Kiểm tra | Kết quả |
|---|---|
| Trang chính sau maximize | Native viewport; innerWidth = 1440 CSS px ở cả 3 lượt |
| Đổi hai kích thước cửa sổ native | Viewport thay đổi cùng chiều rộng cửa sổ, không mắc ở 1280 px |
| Questionnaire trước nhập đầu tiên | Window state maximized, frame innerWidth = 1440 CSS px |
| Popup PI và Case Creation | Giữ nguyên width/height/state, không bị maximize theo questionnaire |
| Ảnh full page | 2850 × 2708 device px ở DPI 200%; đủ 3 cột và nút Submit |
| Final Submit | Không click trên trang mô phỏng |

Screenshot dùng device pixel theo DPI; CSS pixel và kích thước ngoài native window là các số khác nhau. Native scrollbar cũng ảnh hưởng bề rộng document. Bộ probe so sánh ảnh với **geometry tại thời điểm trước capture**, không suy luận bị cắt từ phép so sánh ảnh với outerWidth hoặc geometry sau capture. Các probe đầu có assertion sai đơn vị đã được sửa; không tính những lượt đó là PASS.

Ảnh kiểm tra: `runtime/window_layout/20261119_234850/cycle_01/02_questionnaire_filled_maximized.png` (các cycle 02/03 có ảnh tương tự). Log: `runtime/test_sessions/window_layout_probe.log`.

## Hồi quy và phạm vi

Unit/integration tests xác nhận factory native viewport, bounded failure khi window manager không maximize, khôi phục minimized window, và trạng thái maximized ngay lúc hàm fill được gọi. Luồng Case Creation → popup con questionnaire → fill/capture vẫn giữ guard Final Submit, kể cả `allow_final_submit=YES` khi test ép pre-submit-only. Có cả case config xác nhận-before-capture là YES và NO.

Lượt cập nhật này kiểm tra bằng Chrome headful cục bộ và bộ test; chưa chạy lại một case Visa thật với cơ chế window layout mới. Các kết quả live 9 PI và questionnaire ở báo cáo triển khai trước đó thuộc phiên bản trước cập nhật này. Business rule, OTP provider và Final Submit flag không thay đổi.

Backup trước sửa: `runtime/code_backups/20261119_234056_before_native_window_layout/`.

Kết quả bộ kiểm thử: **83 passed (18.47 giây)**; kiểm tra riêng window recovery/factory sau cùng: **3 passed**.
