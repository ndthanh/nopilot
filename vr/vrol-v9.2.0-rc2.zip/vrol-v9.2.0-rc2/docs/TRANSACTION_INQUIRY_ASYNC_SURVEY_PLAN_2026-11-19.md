# Khảo sát Transaction Inquiry và kế hoạch chuyển sang async

Ngày khảo sát: 19/11/2026. Trạng thái: đã đọc và đối chiếu mã; chưa triển khai thay đổi runtime, chưa chạy test, chưa mở trình duyệt hoặc đăng nhập cần OTP.

**Cập nhật sau khảo sát:** test headful 3 GUID đã chạy trong run `20261119_214805_3a3fe874`. Phương án sửa sau test và yêu cầu mới về `run/documents`, tên PI, tuổi giao dịch > 15 ngày, OTP một lần trong ngày được ghi trong [ASYNC_REPAIR_AND_MIGRATION_PLAN_2026-11-19.md](ASYNC_REPAIR_AND_MIGRATION_PLAN_2026-11-19.md). Dùng bản phương án sau test cho thứ tự triển khai tiếp theo; trạng thái và kết luận khảo sát gốc bên dưới được giữ để tham chiếu.

## 1. Kết luận và phạm vi

- Dự án sync tham chiếu: `visa-review-v9.0.60/visa-review-v9.0.60`.
- Dự án cần phát triển: `vr9.1.13.16`.
- Bản async hiện là mô hình lai: scheduler, login, ROL500 và writer dùng async; toàn bộ precheck/Inquiry, PI và tạo hồ sơ vẫn chạy bằng Playwright sync trong thread, kết nối lại vào Chrome qua CDP cho mỗi GUID.
- Các thread hiện tại **đã có thể chạy Inquiry đồng thời**. Chuyển sang async thuần giúp thống nhất quyền sở hữu trình duyệt, giảm kết nối/CDP client và tối ưu số lần đọc DOM; chưa có benchmark để khẳng định hệ số tăng tốc.
- Ưu tiên: sửa chênh lệch dữ liệu đầu vào → đóng băng quy tắc nghiệp vụ → chuyển Inquiry/precheck sang async → tích hợp PI và tạo hồ sơ → đo rồi mới tăng worker.
- Giữ checkpoint hiện tại: có thể tạo case và điền questionnaire nhưng không bấm Final Submit. Chuyển async không đồng nghĩa mở Final Submit.

Phạm vi chính là luồng thực tế `run_case_review.py → precheck_guid_group()`, không lấy riêng `search_transaction()` hoặc `search_single_test_transaction()` làm chuẩn, vì luồng theo GUID có thêm ưu tiên PI và các quy tắc dừng cả nhóm.

## 2. Bản đồ mã nguồn đã đối chiếu

Các đường dẫn bên dưới tính từ thư mục workspace `vrol`.

| Vai trò | File / vị trí bắt đầu |
|---|---|
| Sync: điều phối, ROL500 theo GUID, reviewed registry, tái sử dụng form | `visa-review-v9.0.60/visa-review-v9.0.60/run_case_review.py:399` |
| Sync: gom nhóm, chọn ngày nhỏ nhất | `visa-review-v9.0.60/visa-review-v9.0.60/src/review/guid_group.py:18` |
| Sync: chọn cách scan và toàn bộ precheck | `visa-review-v9.0.60/visa-review-v9.0.60/src/review/guid_group.py:148`, `:160` |
| Sync: điều hướng, frame, Submit, kết quả | `visa-review-v9.0.60/visa-review-v9.0.60/src/vrol/workflow.py:278`, `:395`, `:496`, `:522` |
| Sync: điền form, lọc invoice và xác nhận lọc | `visa-review-v9.0.60/visa-review-v9.0.60/src/vrol/workflow.py:610`, `:805` |
| Schema 31 cột và chuẩn hóa Transaction ID | `visa-review-v9.0.60/visa-review-v9.0.60/src/vrol/transaction_table.py:104`, `:155`, `:188` |
| Sync: kết quả từng invoice ghi vào workbook | `visa-review-v9.0.60/visa-review-v9.0.60/src/io/group_review_output.py:27` |
| Async: login → ROL500 → queue → worker → writer | `vr9.1.13.16/run_async_parallel_case_review.py:97` |
| Async: đầu vào và central writer | `vr9.1.13.16/async_runtime/excel_store.py:12`, `:92` |
| Async: hàm Inquiry có sẵn, hiện chưa được gọi từ luồng chính | `vr9.1.13.16/async_runtime/worker.py:119` |
| Async: luồng chính gọi bridge | `vr9.1.13.16/async_runtime/worker.py:217` |
| Bridge: engine sync, khóa popup chung | `vr9.1.13.16/async_runtime/sync_parity_engine.py:46` |
| Async: mở Inquiry và phát hiện rollback | `vr9.1.13.16/async_runtime/browser.py:317` |
| Async: session manager, chưa được nối vào worker để phục hồi | `vr9.1.13.16/async_runtime/session.py:14` |

Đã kiểm tra thêm:

- `vr9.1.13.16/sync_reference_run_case_review.py` giống nội dung `run_case_review.py` bên sync.
- Hai bản `src/vrol/transaction_table.py` giống nhau.
- Phần precheck trong hai bản `src/review/guid_group.py` giống nhau; bản trong dự án async đã bổ sung nhiều sửa lỗi cho PI PDF.
- `src/vrol/workflow.py` trong dự án async bổ sung bằng chứng khi mở case lỗi; phần Inquiry tương ứng vẫn giống bản sync.
- README Phase 1 không phản ánh đủ runtime hiện tại. Cần dựa vào call path thực tế và cập nhật tài liệu sau khi chuyển đổi.

## 3. Logic Transaction Inquiry thực tế ở bản sync

### 3.1. Chuẩn bị nhóm

1. Đọc `Sheet1`, header dòng 2, dữ liệu từ dòng 4.
2. Chọn `CHECK SALE = SALE`, `VALID CHARGEBACK = Y`, có GUID, BUT TOAN và INVOICENUM; chỉ nhận code `10.4`, `13.1`, `13.9`.
3. Gom theo GUID, giữ thứ tự dòng trong mỗi nhóm; lấy PAN từ mapping và Start Date là **ngày nhỏ nhất** trong nhóm.
4. Bỏ GUID đã có trong reviewed registry. Sau ROL500 preflight, nếu **bất kỳ dòng nào của nhóm** đã có chargeback trong ROL500 thì bỏ cả GUID.
5. PAN bắt đầu bằng `5` được ghi kết quả bỏ qua trước khi Inquiry, không đi tiếp sang Issuer Action.

### 3.2. Điều hướng và gửi truy vấn

1. Tái sử dụng form nếu đang có `#CardNumber` và `#StartDate`; nếu cần thì mở `Inquiry → Transaction Inquiry`.
2. Chờ cả bodyframe và buttons ổn định, đủ trường nhập và Submit. Nếu màn hình rollback một phần thì chờ landing ổn định và mở lại tối đa một lần.
3. Lấy lại bodyframe ngay trước từng lần điền để tránh frame bị thay thế.
4. Điền PAN, phát `input/change`; đổi ngày `YYYYMMDD → MM/DD/YY`, phát `input/change` rồi blur.
5. Tìm Submit đúng frame có `body#buttonBody` và `button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]`; yêu cầu enabled rồi click.
6. Lấy lại bodyframe khi chờ `table#results` hiển thị. Precheck nhận diện `ROL-897: No matching transactions found` thành `MANUAL_REVIEW_REQUIRED`, không Issuer Action.

Giới hạn cần kiểm chứng: hàm chờ kết quả sync chỉ trả về khi có bảng kết quả. Nếu ROL-897 xuất hiện mà không có bảng, code có thể timeout trước khi tới nhánh nhận diện thông báo. Async mới nên nhận diện cả bảng và lỗi nghiệp vụ ngay trong vòng chờ; kiểm thử bằng fixture trước khi xác minh trên VROL.

### 3.3. Scan bảng và match invoice

- Đọc số `Transactions Found` trên UI.
- Dùng `DIRECT_DOM` khi biết số kết quả, không vượt `transaction_direct_scan_max_rows` (mặc định 25) và DOM đã có đủ hàng.
- Nếu số lượng không rõ, quá ngưỡng hoặc DOM chưa đủ thì dùng `INVOICE_FILTER` trên UI. Không gọi DataTables API nội bộ.
- Filter cần chờ input/hàng/spinner ổn định; nhập bằng keyboard; nếu không áp dụng thì lấy lại input, điền đủ giá trị, Enter/change/blur; cuối cùng dùng chuỗi native events dự phòng.
- Chỉ chấp nhận hiệu ứng lọc khi mọi Transaction ID đang hiển thị đều match invoice và ổn định qua các poll.
- Invoice được trim, bỏ số 0 đầu; Transaction ID còn được bỏ hậu tố lifecycle `-NN`. Không dùng substring để kết luận match.
- Xác thực schema bảng theo vị trí/header đã xác nhận, tối thiểu 31 cột; có trường bắt buộc theo từng code.

### 3.4. Thứ tự quyết định phải giữ nguyên

Đây là thứ tự **mã đang chạy**, kể cả khi comment gần đó mô tả khác:

1. Tìm đúng **một** dòng hợp lệ: `Sale` hoặc `Sale - WT` cho 10.4/13.1; `Cash` cho 13.9. `Sale Dispute Financial - WT` không thuộc sale-family. Không có hoặc nhiều hơn một dòng → `ELIGIBLE_ROW_NOT_UNIQUE`.
2. Đọc PI từ **bảng VROL**, không dùng PI trong Excel để quyết định. Nếu PI = Yes: đánh dấu tải chứng từ, bỏ qua các gate Credit/Cash Rev, Assoc Dispute và MOTO/ECI của invoice đó.
3. Nếu không PI: Credit cho 10.4/13.1 hoặc Cash Rev cho 13.9 → dừng cả GUID, `GROUP_REJECT_TRAN_TYPE`.
4. Assoc Dispute = D trên dòng eligible → dừng cả GUID, `GROUP_CONTAINS_ASSOC_DISPUTE_D`; giá trị không rỗng khác D → `UNDEFINED_ASSOC_DISPUTE_VALUE`.
5. Với 10.4, MOTO/ECI rỗng, 5 hoặc 6 → dừng cả GUID, `GROUP_REJECT_MOTO_ECI`.
6. Đánh dấu checkbox, xác nhận checkbox vừa chọn và tích lũy danh sách Transaction ID. Không đếm checkbox chỉ trong DOM đã lọc để suy ra tổng đã chọn.
7. Khi nhóm dừng, các invoice còn lại nhận `NOT_SCANNED_AFTER_GROUP_STOP`; không mở Issuer Action.
8. Nếu scan xong và có PI pending → `READY_FOR_PI_EVIDENCE_REVIEW`, tải PDF rồi không Issuer Action cho nhóm. Nếu không có PI → chuẩn bị single/multi Issuer Action.
9. Nhóm chỉ 10.4 chọn Fraud; nhóm có các code thuộc 13.1/13.9 chọn Consumer; hỗn hợp Fraud/Consumer → review logic.

Hai tình huống không được diễn giải rộng hơn code:

- PI ưu tiên ở từng invoice sau khi đã đạt uniqueness. Một invoice không PI xuất hiện sau đó vẫn có thể làm dừng toàn nhóm. Không mặc định “có một PI thì bỏ mọi gate cho tất cả invoice”.
- Comment nói kiểm tra Assoc D trước uniqueness, nhưng code kiểm tra uniqueness trước. Kế hoạch giữ hành vi thực tế và ghi rõ tình huống cần xác nhận nghiệp vụ sau này.

### 3.5. Ranh giới sau Inquiry

- PI: View → Tran Details → Save as PDF.
- Issuer: mở Fraud/Consumer → Case Creation Submit → questionnaire → dừng trước Final Submit.
- Sau kết quả không Issuer Action, sync có thể bấm Back đúng `button#editButton[data-action="editQuery"]` bằng DOM click, chờ form ổn định rồi dùng cho GUID tiếp theo.
- Khi đã đi vào tạo case hoặc không Back được, sync tái tạo luồng VROL. Không mặc định mọi trạng thái cuối đều Back được.
- Amount validation hiện bị tắt trong runner/bridge. Không tự bật hoặc bổ sung điều kiện amount trong đợt chuyển async.

## 4. Chênh lệch và điểm nghẽn của bản async hiện tại

| Ưu tiên | Phát hiện từ mã | Hệ quả / hướng xử lý |
|---|---|---|
| P0 | `load_groups()` giữ ngày theo thứ tự dòng; `_group_dict()` lấy `dates[0]` | Có thể truy vấn từ ngày muộn hơn và bỏ sót giao dịch. Dùng trường `start_date` rõ ràng = min ngày hợp lệ của nhóm. |
| P0 | ROL500 đang loại từng dòng trước khi gom GUID | Nhóm có thể còn một phần và tiếp tục tạo case dù sync bỏ cả nhóm. Gom/đánh dấu exclusion ở cấp GUID trước khi enqueue. |
| P0 | Async chưa lọc code hợp lệ, thiếu invoice hoặc BUT TOAN như sync | Đầu vào không tương đương; có thể lỗi sâu trong parser thay vì bị loại sớm. Chuẩn hóa và kiểm tra trước login. |
| P0 | Reviewed registry chỉ được ghi vào thư mục run hiện tại, không đọc để dựng queue | Chạy lại có thể xử lý GUID đã làm. Dùng registry bền vững và tách trạng thái đã thử / cần retry / checkpoint hoàn tất. |
| P0 | Session manager có API relogin nhưng worker không sử dụng | Hết phiên có thể bị ghi hàng loạt thành lỗi từng GUID. Nối detection/generation và phục hồi worker. |
| P1 | `process_group()` gọi `to_thread(run_full_group)`; `inquiry()` async không được gọi | Sửa hàm `inquiry()` riêng sẽ không thay đổi hành vi chính. Cần đổi call path sau khi port đầy đủ precheck. |
| P1 | Mỗi GUID khởi tạo Playwright sync/CDP client | Có overhead cần đo; bỏ khỏi đường chạy native sau khi đủ chức năng. |
| P1 | `popup_sem` được truyền nhưng không dùng; khóa thật là `threading.Lock` trong bridge | Cấu hình `async_popup_concurrency` hiện không điều khiển các thao tác đó. Dùng một coordinator thống nhất khi chuyển đổi. |
| P1 | PI và Issuer dùng cùng một khóa chung; PI đổi `Browser.setDownloadBehavior` | Đây là trạng thái chia sẻ của browser/context, không độc lập theo popup. Chưa được tăng download/popup concurrency hoặc bỏ khóa. |
| P1 | `open_transaction_inquiry()` async bắt đầu bằng chờ landing; READY trả ngay một poll | Cần tách reuse/Back/landing và kiểm tra ổn định; hiện helper không thay thế trực tiếp hợp đồng sync được. |
| P1 | Vòng rollback async có thể đặt lại deadline nhiều lần dù log ghi “once” | Thêm bộ đếm retry và deadline toàn thao tác để bảo đảm kết thúc. |
| P1 | CentralWriter mới ghi 4 trường tổng hợp, không ghi đủ kết quả invoice/PI/ROL | Cần projection dữ liệu từng dòng tương đương sync, vẫn một writer duy nhất. |
| P1 | Báo cáo review chỉ đánh dấu vài status và reason nhất định | `MANUAL_REVIEW_REQUIRED` do ROL-897 hoặc `PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED` có thể vào thư mục COMPLETED. Dùng bảng phân loại trạng thái thống nhất. |
| P2 | Quét lại từng cell và parse lại toàn bảng cho mỗi invoice | Với nhánh DIRECT_DOM, đọc snapshot bảng một lần, lập chỉ mục invoice trong Python; giảm round trip Playwright. |

Các khác biệt đầu vào khác cần thể hiện rõ trong cấu hình/kết quả:

- Async đang loại dòng có ngày invalid, tương lai hoặc tuổi >= 120 ngày. Sync loader không có gate tuổi này. Giữ thành policy có tên và log lý do; không âm thầm coi đây là quy tắc parity của sync. Cần quyết định mức áp dụng theo dòng hay cả GUID khi triển khai.
- Async ưu tiên `FULL PAN` trong workbook rồi mới mapping; sync lấy mapping. Mapping async còn có fallback `input.txt`. Cần chọn nguồn dữ liệu chính và phát hiện xung đột, tránh PAN sai nhưng có vẻ hợp lệ.
- Async bỏ PAN đầu 5 khỏi queue nhưng chưa ghi kết quả từng dòng như sync. Cần event loại trừ có reason để mọi dòng đều có thể đối soát.
- `case_review_input_sheet` được đọc nhưng loader/writer vẫn cố định `Sheet1`. Đợt đầu nên kiểm tra/ghi rõ contract Sheet1; không để cấu hình tạo kỳ vọng sai.
- Bản async chưa gọi ROL500 postflight trong runner. Phạm vi này tách khỏi tăng tốc Inquiry; chỉ tích hợp sau worker hoàn tất, không chạy song song với popup đang hoạt động.

## 5. Thiết kế đề xuất

```text
Kiểm tra input/config → login + OTP một lần → ROL500 preflight
  → queue GUID hợp lệ
      → W01: page riêng → Inquiry async → scan/decision → PI hoặc Issuer
      → W02: page riêng → Inquiry async → scan/decision → PI hoặc Issuer
      → W03: page riêng → Inquiry async → scan/decision → PI hoặc Issuer
           Inquiry/precheck được chạy đồng thời giữa các GUID
           PI/Issuer dùng chung một coordinator, ban đầu chỉ một lượt
  → result queue → một central writer → báo cáo/checkpoint
```

### Phân tách trách nhiệm

- **Một GUID / worker / page tại một thời điểm.** Không dùng `gather()` cho các invoice trên cùng trang vì filter, checkbox và menu là trạng thái có thể thay đổi.
- **Session dùng chung:** một async Playwright, một persistent BrowserContext, generation chung; login/OTP và mở tab từ portal được điều phối tập trung.
- **Worker state riêng:** copy settings cho từng worker/GUID; không chia sẻ các trường mutable như active code, selected count, folder bằng cùng dict.
- **Dữ liệu thuần:** snapshot hàng bảng và quyết định không chứa Page/Frame/Locator. Mã chuẩn hóa, schema và rules có thể dùng chung với sync; DOM adapter của sync và async tách riêng.
- **Hàng được chọn:** lưu Transaction ID đầy đủ và row identity đã xác nhận. Sau redraw/filter phải lấy lại locator đúng dòng, không giữ locator `nth(i)` từ danh sách cũ để dùng cho invoice khác.
- **Kết quả:** giữ `status`, `decision`, `reason_code`, `reason_detail`, `invoice_results`, selected IDs và các cờ Issuer/Final Submit; writer nhận dữ liệu thuần, không nhận đối tượng Playwright.
- **Popup:** lưu quyền sở hữu theo worker/page/opener và danh tính giao dịch; nhận cả popup mới và popup được reuse. Không lấy tùy ý trang mới nhất trong `context.pages`.
- **Download:** giữ khóa từ trước khi đổi download behavior đến khi PDF được lưu/xác thực và dọn xong; khôi phục chính sách download chung trong `finally`. Chỉ thu hẹp khóa sau khi chứng minh được quyền sở hữu download độc lập.
- **I/O:** Excel và việc file nặng dùng thread khi cần; browser trong native path chỉ dùng async API. Không chuyển đối tượng sync/async Playwright qua ranh giới thread.

### OTP lấy bằng polling thư mục cấu hình trong config.xlsx

Yêu cầu đã xác nhận: dùng OTP provider `FOLDER_FILENAME`, đường dẫn thư mục do `config.xlsx` thiết lập; không thiết kế luồng mặc định yêu cầu người dùng gõ OTP vào terminal/trình duyệt.

Cơ chế này đã có trong `src/auth/legacy_login.py:328` và được async gọi tại `async_runtime/browser.py:181`. Loader async đọc các cặp key/value từ sheet Settings và RunSettings của workbook. Các key cần giữ tương thích:

| Setting | Ý nghĩa / mặc định trong code |
|---|---|
| `otp_polling_mode` | Đặt rõ `FOLDER_FILENAME`; nếu bỏ trống, provider hiện mặc định OUTLOOK |
| `otp_folder_path` | Thư mục chứa file OTP; bắt buộc tồn tại. Nên cấu hình đường dẫn tuyệt đối vì helper hiện giải quyết đường dẫn tương đối theo working directory |
| `otp_folder_file_pattern` | Mặc định `*.txt` |
| `otp_timeout_seconds` | Mặc định 90 giây |
| `otp_poll_interval_seconds` | Mặc định 3 giây |
| `otp_min_digits`, `otp_max_digits` | Mặc định đều 8 |
| `otp_received_time_tolerance_seconds` | Mặc định 2 giây |

Luồng phải giữ: chụp baseline file trước Send OTP → ghi nhận thời điểm yêu cầu → click Send OTP → chờ thông báo gửi thành công → poll file mới hoặc file thay đổi đủ mới so với baseline → trích OTP → điền và xác nhận trên đúng trang MFA. Helper ưu tiên nhóm số cuối tên file dạng `YYYYMMDD_HHMMSS_<OTP>.txt`, có fallback đọc nội dung; không lấy ngày trong tên file làm OTP. Nhiều candidate mới nhất cùng timestamp thì tiếp tục chờ thay vì đoán.

Hiện vòng poll file đồng bộ chạy bằng `asyncio.to_thread()`, không chặn event loop. Khi tách provider có thể chuyển vòng chờ sang `asyncio.sleep()` để hỗ trợ hủy tác vụ rõ ràng hơn; thao tác trình duyệt vẫn dùng async API. Không cần đổi provider chỉ để đạt async browser.

Chỉ coordinator đăng nhập/session được yêu cầu và nhận OTP, tuần tự hóa chu kỳ Send → poll → xác nhận để các worker không cùng nhận một mã. Khóa xác thực này tách khỏi popup/PI và không buộc xử lý giao dịch tuần tự. Tích hợp thật cần có nguồn tạo file OTP mới trong thư mục đã cấu hình; chưa tự mở phiên đăng nhập chỉ vì provider đã sẵn có.

### Xử lý lỗi và session

- Local timeout/DOM không đúng: bằng chứng gắn đúng GUID, kết quả cần review, thử phục hồi form/tab của worker rồi xử lý nhóm kế tiếp.
- Session hết hạn: pause cấp phát, một tác vụ thực hiện relogin cho generation hiện tại, dựng lại page cho các worker; nếu VROL yêu cầu OTP thì coordinator lấy qua polling thư mục cấu hình như trên.
- Sửa vòng đời `_ready`: `start()` hiện chưa set event; relogin lỗi phải đánh thức/cho lỗi tới các bên chờ. Không để worker chờ vô hạn.
- Persistent profile có thể không mở được context mới trong khi context cũ còn giữ profile. Thiết kế phục hồi phải quiesce worker và đóng phiên cũ hoặc tái xác thực cùng context, thay vì mặc định mở chồng lên.
- Chỉ tự retry khi biết chưa tạo case. Sau Case Creation/nhận ROL mà mất phản hồi, ghi checkpoint và đối soát; không tự gửi lại mù.
- Supervise worker và writer task: task lỗi phải được truyền tới controller; tránh `queue.join()` treo khi worker/writer đã chết. Drain/flush/cancel có thứ tự trước khi đóng context.

## 6. Kế hoạch triển khai theo đợt

### Đợt 1 — Hợp đồng dữ liệu và queue, chưa cần OTP

File: `async_runtime/models.py`, `excel_store.py`, runner và module policy/result dùng chung nếu cần.

- Thêm `start_date` rõ ràng, chuẩn hóa code/invoice/ngày, kiểm tra schema workbook và mapping.
- Sửa loại ROL500 ở cấp GUID, đọc reviewed registry bền vững, ghi event cho các exclusion.
- Chốt policy tuổi giao dịch và nguồn PAN bằng cấu hình có giá trị mặc định rõ ràng; không đổi ngầm khi refactor.
- Xác định schema kết quả và phân loại completed/manual review/retry/checkpoint. Một lượt chạy kết thúc không đồng nghĩa tất cả GUID thành công.
- Bổ sung ghi workbook từng invoice và ROL/PI; event bền vững trước, workbook lưu theo batch và có thể dựng lại từ event nếu ngắt.

Hoàn tất khi fixture nhóm nhiều ngày, nhóm ROL500 hỗn hợp và chạy lại cho queue đúng; mỗi dòng bị loại có lý do; writer ghi đúng dòng theo `row_no`.

### Đợt 2 — Rules và parser không phụ thuộc trình duyệt, chưa cần OTP

File đề xuất: `async_runtime/transaction_rules.py`, DTO trong `models.py`; tận dụng hằng số/schema hiện có.

- Tách normalize/schema/matching/decision khỏi thao tác locator.
- Tạo fixtures tổng hợp từ contract, không đưa PAN hoặc dữ liệu khách hàng thật vào test.
- Giữ nguyên thứ tự uniqueness → PI → refund/reversal → Assoc → ECI; giữ group stop và mixed-code behavior.
- Đối chiếu quyết định với sync trên cùng dữ liệu giả lập, đồng thời kiểm tra expected outcome độc lập để tránh hai bản cùng sai.
- Schema lỗi phải báo rõ lỗi cấu trúc, không bị nuốt rồi suy ra “không có eligible transaction”. Đây là sửa chẩn đoán có chủ đích, cần ghi trong thay đổi.

Hoàn tất khi rules có đầu vào/đầu ra thuần và bao phủ các nhánh nghiệp vụ trong mục 7.

### Đợt 3 — Port Inquiry/precheck async, kiểm thử bằng HTML cục bộ

File đề xuất: `async_runtime/transaction_inquiry.py`, `transaction_table.py`, `precheck.py`; chỉnh `browser.py`, `worker.py`.

- Tách helper điều hướng khỏi `worker.py`, cài lại hợp đồng reuse/Back/landing/rollback, field events, live Submit, result/error waits.
- Port DIRECT_DOM và UI filter với xác nhận hiệu ứng, hỗ trợ frame bị thay và input bị redraw.
- DIRECT_DOM đọc các cell cần thiết trong một snapshot DOM; validate schema trước khi parse, lập chỉ mục để tránh scan lại toàn bảng cho mỗi invoice.
- Có chặn chế độ **Inquiry-only**: kết quả dừng trước View/Issuer, phục vụ so sánh nghiệp vụ không tạo hồ sơ.
- Giữ lựa chọn backend `legacy_bridge` / `native_async` trong giai đoạn chuyển; chưa đủ PI/Issuer thì backend native chạy Inquiry-only, không tự gọi lại bridge toàn nhóm.

Không được gọi `run_full_group()` sau Inquiry async để “tiếp tục”, vì hàm đó hiện tự Submit và precheck lại từ đầu. Nếu cần cầu nối tạm, phải tách continuation nhận ID/dữ liệu thuần, tự tìm lại hàng trên tab mà không gửi lại Inquiry; không truyền locator async sang sync. Mặc định ưu tiên hoàn thiện native path và dùng bridge hiện tại làm đường quay lui giữa các lần chạy.

Hoàn tất khi hai worker chạy đồng thời trên hai trang fixture, không lẫn PAN/date/filter/selection, mọi wait có giới hạn và native Inquiry không gọi Playwright sync/CDP bridge.

### Đợt 4 — PI/Issuer async và vận hành đầy đủ

File đề xuất: `async_runtime/pi_evidence.py`, `case_workflow.py`, coordinator; chỉnh worker/session/runner.

- Port PI từ **bản đã sửa trong vr9.1.13.16**, giữ spinner gate, popup reuse, thư mục tạm theo invoice, file `%PDF-`, kích thước tối thiểu/ổn định, copy `.part` rồi replace và chỉ đóng popup sau khi xác thực file.
- Port Issuer Action, Case Creation, duplicate handling và questionnaire; giữ Final Submit bị chặn.
- Áp dụng coordinator chung với concurrency = 1, ownership popup, phục hồi tab sau case và session generation.
- Tích hợp result/writer/checkpoint/report xuyên suốt. Cập nhật test cũ đang bắt buộc chuỗi `asyncio.to_thread(run_full_group...)`; kiểm tra hành vi thay vì ép kiến trúc cũ.
- Gỡ dependency sync/CDP attach khỏi native path khi đủ chức năng; không cần gỡ CDP dùng riêng cho cấu hình download nếu Chrome vẫn yêu cầu.

Hoàn tất khi native có đủ các nhánh và test offline bên dưới; bridge còn hoạt động để quay lui theo cấu hình trước khi chạy batch mới.

### Đợt 5 — Xác minh VROL và đo tốc độ, cần nguồn file OTP hoạt động

- Sau khi lấy và xác nhận OTP từ thư mục cấu hình, bắt đầu 1 worker / Inquiry-only trên tập đại diện; so kết quả với sync ở mức rules/precheck, không tạo case hai lần để benchmark.
- Tăng 2 rồi 3 worker trên cùng loại workload, giữ popup = 1. Không tăng cap trước khi có số đo và xác nhận session/tab độc lập.
- Kiểm thử PI/Case Creation trên các GUID riêng, theo checkpoint hiện tại và dừng trước Final Submit.
- Xác nhận đủ: nhỏ/lớn table, PI popup reuse, ROL-897, Back liên tiếp, hết phiên, lỗi một worker và tiếp tục nhóm sau.
- Đo thời gian tách biệt login/OTP, ROL500, Inquiry, scan/filter, chờ khóa, PI, case, Excel; lưu tổng GUID/phút, p50/p95, tỷ lệ lỗi và event-loop lag.
- Chỉ chốt worker mặc định khi tăng throughput mà không đổi quyết định, không tải nhầm PDF hoặc lẫn popup. Không cam kết tốc độ tuyến tính theo số worker.

## 7. Kiểm thử có thể chuẩn bị trước OTP

Hiện các test đã đọc trong `vr9.1.13.16/tests` chủ yếu kiểm tra chuỗi trong mã nguồn (ví dụ test full-engine bridge và Back contract). Chúng hữu ích để giữ dấu hiệu cũ nhưng chưa chứng minh concurrency hoặc parity nghiệp vụ. Chưa chạy các test này trong lượt khảo sát.

| Nhóm test dự kiến | Tình huống tối thiểu |
|---|---|
| Queue/policy | Ngày không theo thứ tự; ROL500 một dòng trong GUID nhiều dòng; reviewed registry; thiếu mapping/invoice/QT; code ngoài phạm vi; PAN đầu 5; PAN workbook khác mapping; mốc tuổi 119/120 và ngày tương lai |
| OTP folder | Baseline loại file cũ; tên có ngày/giờ và OTP ở cuối; fallback nội dung; file thay đổi sau yêu cầu; candidate mới nhất mơ hồ; timeout/hủy; nhiều worker chỉ có một chu kỳ yêu cầu OTP |
| Matching/schema | Invoice có 0 đầu; Transaction ID có `-01`; ID gần giống nhưng không bằng; thiếu/đổi cột; Sale - WT và Sale Dispute Financial - WT; eligible 0/2 hàng |
| Rules | PI Yes cùng Credit/Assoc D/ECI 5; không PI có Credit/Cash Rev; Assoc D/giá trị lạ; ECI rỗng/5/6/hợp lệ; nhiều invoice dừng giữa nhóm; nhóm PI + không PI; Fraud/Consumer trộn |
| Điều hướng HTML local | Frame đổi sau fill; Submit disabled; form reuse; Back; rollback lặp; bảng nhỏ/lớn; filter node bị thay; ROL-897 có/không có bảng |
| Concurrency | Hai page giao nhau ở barrier có kiểm soát; worker A đang chờ kết quả thì B vẫn tiến; lỗi A không đóng page B; worker settings không lẫn; popup coordinator có tối đa một chủ sở hữu |
| PI và output | PDF chưa đủ/0 byte/sai signature; popup reuse đúng giao dịch; path còn đúng sau rename folder; workbook từng invoice; PI retry/ROL-897 được đưa vào review report |
| Phục hồi | Hai worker phát hiện expired chỉ một lần login; relogin lỗi không treo; worker/writer chết không kẹt join; ngắt khi đang chờ popup; không tự tạo lại case sau checkpoint không chắc chắn |

Playwright với trang HTML cục bộ là kiểm thử có trình duyệt nhưng không cần VROL/OTP; phải tách khỏi test tích hợp thật. Dùng event/barrier để kiểm tra sự chồng lấp tác vụ, không kiểm tra bằng thời gian sleep dễ dao động.

## 8. Tiêu chí chấp nhận và bước tiếp theo

- Queue và quyết định tương đương sync trên fixtures đã định nghĩa; mọi khác biệt policy/chẩn đoán có tên và ghi rõ.
- Native Inquiry/precheck dùng async API, không gọi lại precheck sync; mỗi worker sở hữu một trang và state riêng.
- Có kết quả từng invoice, đường dẫn bằng chứng sử dụng được sau khi finalize, registry phân biệt retry/review/hoàn tất.
- Tất cả retry/wait có giới hạn, lỗi task không làm treo batch, session recovery không tạo case trùng do retry mù.
- PI/Issuer giữ serialized cho đến khi kiểm chứng được phạm vi state chung; Final Submit không được click.
- Chỉ nghiệm thu tăng tốc sau benchmark có OTP; test offline không được mô tả là đã xác nhận hoạt động trên VROL thật.

**Bước triển khai nên làm tiếp:** đợt 1 và 2 trước, rồi đợt 3 với chế độ Inquiry-only. Đợt 4 hoàn thiện đường native; đợt 5 cần xác nhận nguồn file OTP và cấu hình thư mục hoạt động. Lượt khảo sát này chỉ bổ sung tài liệu kế hoạch, chưa sửa runtime hoặc cấu hình.
