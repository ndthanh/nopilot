# Implementation scope

- PRE_SUBMIT_REVIEW creates or recreates the ROL case.
- It stops before the final dispute Submit.
- Interrupted cases can restart and recreate ROL case per business confirmation.
- Fraud 10.4: PI=Yes flags evidence download; ECI 5/6/blank => data error; Assoc Dispute D => Duplicate; Credit => Refund.
- Headerless mapping format: GUID|full PAN.
