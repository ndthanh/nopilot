# Visa async + RPA Ops

## Run on Windows CMD

- Install Visa dependencies: `install.cmd`.
- Manual Visa run: `run_async_parallel_case_review.cmd`.
- Dashboard launch: choose the FC + GUID2PAN bundle in **VROL Visa**, then Run.
- Direct handoff: `run_vrol_from_ops.cmd "C:\...\manifest.json"`.
- Offline checks: `run_offline_tests.cmd` (Visa); the dashboard has its own command of the same name.

The dashboard uses `run_vrol_from_ops.cmd` without PowerShell. Its `install.cmd`
calls `setup.cmd`; Task Scheduler uses native Windows COM through pywin32.
Chrome must run in a logged-on interactive Windows session.

## Inputs and configuration

FC and GUID2PAN are one upstream pair. The dashboard accepts an explicit
`source_fc_run_id` from conversion logs, or a unique conversion in the FC coupled
window with the same declared input path. An ambiguous pair waits for review.
It never combines two independent latest files. The current-day policy uses UTC+7.

Snapshots are published atomically under `runtime/ops_inputs/<bundle_id>/`:
`09_chargeback_classified.xlsx`, converted `input.txt` (`GUID|PAN`), `manifest.json`.
SHA-256, source IDs, mapping format and GUID coverage are checked again before login.
A newer incomplete FC run leaves VROL waiting for its matching conversion.

Settings in config.xlsx remain authoritative: workers default 3 / cap 5,
`allow_final_submit=NO` by default, and the existing OTP folder polling settings.
The runner polls OTP only when Visa asks for it. A process lock prevents overlapping
Visa processes; worker popup chains remain independent inside the process.

## GUID folders and Associated Transactions

Work begins in `groups/<GUID>`; completion renames it to:

- `PI_DOWNLOADED_<GUID>`
- `NO_CB_<GUID>`
- `FRAUD_<GUID>` or `CONSUMER_<GUID>` (check awaiting/final marker)
- `REVIEW_REQUIRED_<GUID>`

Embedded JSON/JSONL paths, screenshots, PI manifests and subsequent Excel updates
use the renamed folder. Run-wide PI copies remain in `documents/`.
Existing historical runs are preserved; this policy applies to newly processed GUIDs.

The association-selection form (`submit_ti_atr_selection` or its action) is a known
review stop. Its questionnaire sidebar namesake does not match. Save ROL + screenshot,
do not change radio buttons or submit, then close only the worker popup chain.
An in-place association screen closes the worker tab; the next GUID gets a fresh tab.

`runtime/review_holds/<GUID>.json` prevents automatic recreation of unresolved cases,
including historical failures after issuer-action dispatch. It is separate from the
completion registry. After an operator reconciles the existing ROL, they may change
the hold's disposition from `HOLD_REVIEW` to `RELEASED` if replay is appropriate.
`--no-resume` does not bypass case-side-effect holds.

## Final ROL500 reconciliation

After all workers finish and CentralWriter closes, open a fresh VROL report tab and
download `postflight/ROL500.csv`. Match using the sync rules: normalized invoice to
transaction ID, refine by QT, and QT-only fallback when invoice has no candidates.
`BOT ROL500 POST MATCH KEY` explicitly identifies the fallback.

The run's `09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx` is atomically updated with
reported ROL (AK / VROL), postflight status, match method, source and timestamp.
Ambiguous and absent matches preserve directly observed case numbers and all bot
decisions. Presence in the report never means Final Submit was confirmed.
Missing recently submitted cases may reflect report latency/date coverage; review
the CSV and report parameters before deciding to resend anything.

Artifacts: `rol500_postflight_result.json`, `postflight/rol500_reconciliation.csv`
and `.json`. Failure keeps GUID results/Excel and marks the run with issues.
Postflight defaults to YES (`rol500_postflight_enabled`); `--skip-postflight` is an
explicit diagnostic override, independent of `--skip-rol500` preflight.

## Dashboard and review

The Output tab shows every queued/running/completed GUID, with a review filter,
checkpoint stage, ROL, postflight observation and folder/screenshot buttons.
GUID search and pagination allow access beyond the first 200 displayed rows.
`VROL_GUID_POLL_SECONDS` in dashboard settings defaults to 5 (range 2–300).
Live polling reads only Visa artifacts, without starting bots or collecting all upstream logs.
`WAITING_OTP` is distinct from RUNNING; stopped processes do not remain RUNNING.

- PI aggregate: `<run>/documents/`.
- PI per GUID: `<run>/groups/<OUTCOME>_<GUID>/documents/<invoice>_<last4>_<termowner>.pdf`.
- Complete GUID index: `guid_outcomes.csv/json`.
- Review includes errors, Associated Transactions, unresolved holds and questionnaires awaiting Final Submit.
- Error-only report: `review_required_cases.csv`; do not use this alone as the review queue.

When static reporting is enabled, the newest completed Visa run gets a portable pack
at `<STATIC_REPORT_OUTPUT_DIR>/vrol/<run_id>/index.html` with PI, review CSV and screenshots.
The shared pack omits mapping input, config, browser profile and OTP files.

## Validation boundary

Offline tests use synthetic workbooks, reports, HTML and mocked process launch.
They do not create live Visa cases or exercise real Final Submit. Production upstream
paths must be configured in dashboard Settings; missing paths produce WAITING_INPUT.

Validation on this change: Visa suite 108 passed; dashboard integration 17 passed.
After the final search/pagination change, its browser check and postflight checks
passed again (3 tests). Windows COM scheduler enumeration also ran successfully
on this host (no configured tasks in the custom folder). No live Visa run or
Final Submit was performed for these changes.
