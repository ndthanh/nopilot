@echo off
setlocal
cd /d "%~dp0"
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
title VROL - Local Browser Window Test - No Visa Connection
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  pause
  exit /b 1
)
echo LOCAL WINDOW TEST - CHROME HEADFUL - NO VISA - NO OTP - NO REAL CASE
".venv\Scripts\python.exe" -u diagnostics\check_browser_windows.py %*
set RC=%ERRORLEVEL%
echo Window test exit code: %RC%
pause
exit /b %RC%
