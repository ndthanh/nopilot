from pathlib import Path
from datetime import datetime
import argparse,json,uuid,time,csv,shutil
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box
from openpyxl import load_workbook
C=Console()
from src.core.config import load_all
from src.io.mapping import load_mapping
from src.review.guid_group import load_guid_groups,precheck_guid_group,download_pi_document
from src.io.group_review_output import create,update_group
from batch_test import recycle_vrol_tabs_to_portal
from src.vrol.reports.rol500 import run_preflight
from src.vrol.workflow import open_case_and_prepare,fill_test_questionnaire
from src.browser_window import maximize_page_window

def _yn(value): return '[green]YES[/]' if value else '[red]NO[/]'
def _decision_style(value):
    value=str(value or '')
    if value=='NO_CHARGEBACK_REQUIRED':return 'bold green'
    if value.startswith('READY_FOR'):return 'bold cyan'
    if value in {'UNDEFINED_CASE','MANUAL_REVIEW_REQUIRED'}:return 'bold yellow'
    if value=='USER_SKIPPED':return 'dim'
    return 'bold white'
def render_review_table(group,result,folder):
    decision=result.get('decision') or result.get('status') or ''
    inputs=Table(title='INPUT / GUID GROUP',box=box.ROUNDED,header_style='bold white on blue',show_lines=True,expand=True)
    inputs.add_column('Field',style='bold cyan',width=22);inputs.add_column('Value',overflow='fold')
    inputs.add_row('GUID',group.get('guid',''));inputs.add_row('PAN (BIN6 + Last4)',group.get('masked_pan',''))
    inputs.add_row('Excel rows',', '.join(map(str,[x.get('row_no') for x in group.get('items',[])])))
    inputs.add_row('Invoice count',str(len(group.get('items',[]))));inputs.add_row('Start date',str(group.get('start_date','')))
    inputs.add_row('Invoices','\n'.join(f"{i}. {x.get('invoice','')} | QT {x.get('qt','')} | Code {x.get('code','')}" for i,x in enumerate(group.get('items',[]),1)))
    C.print(inputs)
    inv=Table(title='INVOICE PRECHECK RESULTS',box=box.ROUNDED,header_style='bold white on dark_green',show_lines=True,expand=True)
    for col in ('#','Excel row','QT','Code','Invoice','PI','PI chứng từ','Scan status','Tran Types','Assoc Dispute','Selected'):
        inv.add_column(col,overflow='fold')
    for i,item in enumerate(result.get('invoice_results') or [],1):
        assoc=item.get('assoc_dispute') or ' | '.join(item.get('assoc_disputes') or [])
        inv.add_row(str(i),str(item.get('row_no','')),str(item.get('qt','')),str(item.get('code','')),str(item.get('invoice_raw','')),str(item.get('pi_input','')),str(item.get('pi_status','')),str(item.get('scan_status','')),' | '.join(item.get('tran_types') or []),str(assoc or ''),_yn(bool(item.get('sale_selected'))))
    if not result.get('invoice_results'):inv.add_row('-','-','-','-','-','-','-','No invoice result','-','-','-')
    C.print(inv)
    output=Table(title='BOT DECISION',box=box.HEAVY_EDGE,header_style='bold white on purple',show_lines=True,expand=True)
    output.add_column('Decision item',style='bold magenta',width=28);output.add_column('Result',overflow='fold')
    output.add_row('Status',f"[{_decision_style(result.get('status'))}]{result.get('status','')}[/]")
    output.add_row('Decision',f"[{_decision_style(decision)}]{decision}[/]")
    output.add_row('Reason code',str(result.get('reason_code','')));output.add_row('Reason',str(result.get('reason_detail','')))
    output.add_row('Thao tác cần review trước',str(result.get('planned_review_action','Không áp dụng')))
    output.add_row('Issuer Action dự kiến',str(result.get('planned_issuer_action','Không áp dụng')))
    output.add_row('Issuer Action required',_yn(bool(result.get('issuer_action_required'))));output.add_row('Issuer Action clicked',_yn(bool(result.get('issuer_action_clicked'))))
    output.add_row('Selected transaction count',str(result.get('selected_count',result.get('selected_count_before_stop',0))))
    output.add_row('Trigger invoice',str(result.get('trigger_invoice','')));output.add_row('Trigger Tran Type',str(result.get('trigger_tran_type','')))
    output.add_row('Trigger Assoc Dispute',str(result.get('trigger_assoc_dispute','')));output.add_row('Artifacts',str(folder))
    C.print(output)

def _case_dates(group):
    return sorted({str(x.get('date') or x.get('start_date') or group.get('start_date') or '') for x in group.get('items',[]) if x.get('date') or x.get('start_date') or group.get('start_date')})

def _log_bot_decision(logger,group,result,action,reason):
    dates=', '.join(_case_dates(group)) or '(blank)'
    table=Table(show_header=False,box=box.ROUNDED,padding=(0,1),expand=True)
    table.add_column('Field',style='bold cyan',width=20)
    table.add_column('Value',style='bold white')
    table.add_row('GUID',str(group.get('guid') or ''))
    table.add_row('Masked PAN',str(group.get('masked_pan') or ''))
    table.add_row('Transaction dates',dates)
    table.add_row('Status',str(result.get('status') or ''))
    table.add_row('Decision',str(result.get('decision') or result.get('status') or ''))
    table.add_row('Bot action',str(action or ''))
    table.add_row('Reason',str(reason or ''))
    C.print(Panel(table,title='[bold yellow]BOT DECISION[/]',border_style='bright_yellow',expand=True))
    logger.warning('========== BOT DECISION | guid=%s | pan=%s | transaction_dates=%s | status=%s | decision=%s | action=%s | reason=%s ==========',group.get('guid'),group.get('masked_pan'),_case_dates(group),result.get('status'),result.get('decision'),action,reason)

def _back_to_transaction_inquiry(page,settings,logger):
    """Click the exact Back button in iframe#buttons, then wait for TI request form."""
    selector='button#editButton[data-action="editQuery"]'
    frames=[]
    try:
        exact=page.frame(name='buttons')
        if exact is not None:frames.append(exact)
    except Exception:pass
    for frame in page.frames:
        if frame not in frames and ('buttons_index.jsp' in frame.url or 'ti-buttons' in frame.url):frames.append(frame)
    for frame in page.frames:
        if frame not in frames:frames.append(frame)
    observed=[]
    for frame in frames:
        try:
            back=frame.locator(selector).first
            count=back.count();visible=bool(count and back.is_visible());enabled=bool(count and back.is_enabled())
            observed.append({'name':frame.name,'url':frame.url,'count':count,'visible':visible,'enabled':enabled})
            if not (count and visible and enabled):continue
            logger.info('RESULTS BACK EXACT BUTTON FOUND | selector=%s | iframe_id=buttons | frame_name=%s | frame_url=%s',selector,frame.name,frame.url)
            # Legacy VROL action is JS-bound. Native DOM click is the most deterministic path.
            back.evaluate("el => { el.focus(); el.click(); }")
            logger.info('RESULTS BACK CLICK DISPATCHED | selector=%s | strategy=DOM_CLICK | frame_url=%s',selector,frame.url)
            deadline=time.monotonic()+int(settings.get('transaction_results_back_timeout_ms',7000))/1000
            stable=0
            while time.monotonic()<deadline:
                request_frame=None
                for live in page.frames:
                    try:
                        pan=live.locator('#CardNumber').first;date=live.locator('#StartDate').first
                        if pan.count() and date.count() and pan.is_visible() and date.is_visible():request_frame=live;break
                    except Exception:pass
                if request_frame is not None:
                    stable+=1
                    if stable>=2:
                        logger.info('PASS RESULTS BACK TO TRANSACTION INQUIRY | selector=%s | strategy=DOM_CLICK | request_frame=%s | pan_preserved=%s | date_preserved=%s',selector,request_frame.url,request_frame.locator('#CardNumber').input_value(),request_frame.locator('#StartDate').input_value())
                        return True
                else:stable=0
                page.wait_for_timeout(100)
            logger.warning('RESULTS BACK TRANSITION TIMEOUT | selector=%s | observed=%s',selector,observed)
            return False
        except Exception as exc:
            observed.append({'name':getattr(frame,'name',''),'url':getattr(frame,'url',''),'error':str(exc)})
    logger.warning('RESULTS BACK EXACT BUTTON NOT FOUND | selector=%s | observed=%s',selector,observed)
    return False


def _write_activity_event(out_dir,event):
 event=dict(event);event.setdefault('timestamp',time.strftime('%Y-%m-%d %H:%M:%S'))
 with (Path(out_dir)/'activity_report.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(event,ensure_ascii=False)+'\n')
 path=Path(out_dir)/'activity_report.csv';fields=['timestamp','event','guid','masked_pan','status','reason_code','detail','screenshot','html','action'];exists=path.exists()
 with path.open('a',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
  if not exists:w.writeheader()
  w.writerow(event)

def _session_expired(context):
 for page in context.pages:
  if page.is_closed():continue
  try:
   if 'visaonline.com/login' in (page.url or '').lower():return True,page,'LOGIN_URL'
   u=page.locator('#external-login-username').first
   if u.count() and u.is_visible():return True,page,'USERNAME_FIELD'
  except Exception:pass
 return False,None,''

def _auto_review_action(result,settings,logger,guid):
    if str(settings.get('case_review_auto_progress_enabled','YES')).strip().upper() not in {'YES','Y','TRUE','1'}:
        return None
    status=str(result.get('status') or '')
    decision=str(result.get('decision') or '')
    reason=str(result.get('reason_code') or '')
    if status=='READY_FOR_PI_EVIDENCE_REVIEW':
        logger.warning('========== AUTO REVIEW ACTION | guid=%s | status=%s | action=P | reason=PI_EVIDENCE_REQUIRED ==========',guid,status)
        return 'P'
    if status in {'READY_FOR_ISSUER_ACTION_REVIEW','READY_FOR_MULTI_ISSUER_ACTION_REVIEW'}:
        logger.info('AUTO REVIEW ACTION | guid=%s | status=%s | action=P | reason=AUTO_CREATE_CASE_TO_QUESTIONNAIRE',guid,status)
        return 'P'
    if status=='ROL_897_NO_MATCHING_TRANSACTIONS' or reason=='ROL_897_NO_MATCHING_TRANSACTIONS':
        logger.info('AUTO REVIEW ACTION | guid=%s | status=%s | reason_code=%s | action=S | reason=TERMINAL_NO_MATCH',guid,status,reason)
        return 'S'
    if status=='NO_CHARGEBACK_REQUIRED' or decision=='NO_CHARGEBACK_REQUIRED':
        logger.info('AUTO REVIEW ACTION | guid=%s | status=%s | decision=%s | action=S | reason=TERMINAL_NO_CHARGEBACK',guid,status,decision)
        return 'S'
    return None

def prompt(group,result,folder):
    print('\n'+'='*96);print('GUID GROUP PRECHECK - REVIEW BEFORE NEXT GROUP')
    print(json.dumps({'guid':group['guid'],'pan_bin6_last4':group['masked_pan'],'rows':[x['row_no'] for x in group['items']],
      'invoices':[x['invoice'] for x in group['items']],'result':{k:v for k,v in result.items() if not k.startswith('_')},'artifacts':str(folder)},ensure_ascii=False,indent=2))
    print('='*96)
    render_review_table(group,result,folder)
    state=str(result.get('decision') or result.get('status') or '')
    ready=state.startswith('READY_FOR_') or state=='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED'
    actions=[]
    if ready:actions.append('[bold green]P[/] Xác nhận chuyển sang hàng chờ Issuer Action')
    actions.extend(['[bold yellow]R[/] Kiểm tra lại precheck','[bold cyan]S[/] Xác nhận quyết định của bot phù hợp, lưu và sang nhóm tiếp theo','[bold magenta]F[/] Phản hồi: cần xem lại logic xử lý','[bold red]Q[/] Dừng và lưu kết quả'])
    C.print(Panel.fit('\n'.join(actions),title='THAO TÁC REVIEW',border_style='bright_blue'))
    while True:
        try:c=input('P thực hiện Issuer Action; R kiểm tra lại; S xác nhận bot đúng; F xem lại logic; Q dừng > ').strip().upper()
        except EOFError:c='Q'
        allowed={'P','R','S','F','Q'} if ready else {'R','S','F','Q'}
        if c in allowed:return c

def _questionnaire_frame_candidates(page):
    """Return live VCR dispute frames only; never use landing/menu frames."""
    found=[]
    for frame in page.frames:
        name=str(frame.name or '')
        url=str(frame.url or '')
        if name=='FRAME_ID_Dispute' or '/vcr-ui/app/dispute/dispute.html' in url:
            found.append(frame)
    return found

def _safe_browser_wait(context,milliseconds):
    """Wait without depending on the questionnaire page, which VROL may close after Submit."""
    deadline=time.monotonic()+max(0,milliseconds)/1000
    while time.monotonic()<deadline:
        live=next((p for p in context.pages if not p.is_closed()),None)
        remaining=max(0,deadline-time.monotonic())
        step=min(0.2,remaining)
        if step<=0:break
        if live is not None:
            try:
                live.wait_for_timeout(int(step*1000));continue
            except Exception:
                pass
        time.sleep(step)

def _final_submit_review_pause(context,settings,logger,folder,outcome):
    """Development review pause after VROL transitions to the post-submit screen."""
    pause_ms=int(settings.get('final_submit_review_pause_ms',5000))
    logger.info('FINAL SUBMIT POST-TRANSITION REVIEW PAUSE | outcome=%s | milliseconds=%s',outcome,pause_ms)
    _safe_browser_wait(context,pause_ms)
    live=next((p for p in reversed(context.pages) if not p.is_closed()),None)
    if live is not None:
        try:
            live.screenshot(path=str(Path(folder)/'08_after_final_submit_review_pause.png'),full_page=True)
        except Exception:
            pass

def _click_final_submit(questionnaire_page,settings,logger,folder):
    """Click the exact Angular Submit in FRAME_ID_Dispute, then wait for a real outcome."""
    timeout=int(settings.get('final_submit_reacquire_timeout_ms',15000))
    poll=int(settings.get('final_submit_poll_ms',200))
    outcome_timeout=int(settings.get('final_submit_outcome_timeout_ms',30000))
    exact_selector='button[ng-click="trigger(Buttons.SUBMIT,true)"][ng-show="isBtnVisible(Buttons.SUBMIT)"]'
    deadline=time.monotonic()+timeout/1000
    chosen=None;observed=[]
    while time.monotonic()<deadline and chosen is None:
        for page in reversed([p for p in questionnaire_page.context.pages if not p.is_closed()]):
            for frame in _questionnaire_frame_candidates(page):
                try:
                    loc=frame.locator(exact_selector).first
                    count=loc.count();visible=loc.is_visible() if count else False;enabled=loc.is_enabled() if count else False
                    observed.append((page.url,frame.name,frame.url,exact_selector,count,visible,enabled))
                    if count and visible and enabled:
                        # Playwright trial performs actionability checks without dispatching a click.
                        loc.scroll_into_view_if_needed(timeout=timeout)
                        loc.click(timeout=timeout,trial=True)
                        chosen=(page,frame,loc);break
                except Exception as exc:
                    observed.append(('probe_error',type(exc).__name__,str(exc)[:160]))
            if chosen:break
        if not chosen:questionnaire__safe_browser_wait(page.context,poll)
    if not chosen:
        raise RuntimeError('FINAL_SUBMIT_BUTTON_NOT_ACTIONABLE_IN_LIVE_DISPUTE_FRAME:'+repr(observed[-12:]))
    page,frame,loc=chosen
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    try:page.screenshot(path=str(folder/'06_before_final_submit.png'),full_page=True)
    except Exception:pass
    logger.info('FINAL SUBMIT EXACT ANGULAR BUTTON ACTIONABLE | page=%s | frame_name=%s | frame_url=%s | selector=%s',page.url,frame.name,frame.url,exact_selector)
    # Reacquire once more immediately before the real click so Angular replacement cannot stale the locator.
    live_frame=next((f for f in _questionnaire_frame_candidates(page) if f.name=='FRAME_ID_Dispute' or f.url==frame.url),None)
    if live_frame is None:raise RuntimeError('FINAL_SUBMIT_DISPUTE_FRAME_LOST_BEFORE_CLICK')
    live=live_frame.locator(exact_selector).first
    live.wait_for(state='visible',timeout=timeout)
    if not live.is_enabled():raise RuntimeError('FINAL_SUBMIT_BUTTON_DISABLED_BEFORE_CLICK')
    live.click(timeout=timeout,no_wait_after=True)
    logger.info('PASS FINAL SUBMIT CLICK DISPATCHED | selector=%s | frame_name=%s',exact_selector,live_frame.name)
    outcome_deadline=time.monotonic()+outcome_timeout/1000
    while time.monotonic()<outcome_deadline:
        pages=[p for p in page.context.pages if not p.is_closed()]
        for pg in pages:
            for scope in [pg]+list(pg.frames):
                try:
                    reject=scope.locator('h3:has-text("Reject Details"), h4:has-text("Edits - Dispute Rejected")').first
                    if reject.count() and reject.is_visible():
                        logger.info('FINAL SUBMIT OUTCOME | outcome=VISA_REJECT_DETAILS | page=%s',pg.url)
                        try:pg.screenshot(path=str(folder/'07_final_submit_rejected.png'),full_page=True)
                        except Exception:pass
                        _final_submit_review_pause(page.context,settings,logger,folder,'VISA_REJECT_DETAILS')
                        return {'selector':exact_selector,'clicked':True,'outcome':'VISA_REJECT_DETAILS','page_url':pg.url}
                except Exception:pass
        live_frames=[]
        for pg in pages:live_frames.extend((pg,f) for f in _questionnaire_frame_candidates(pg))
        for pg,f in live_frames:
            try:
                current_error=f.locator('[vcr-display-error] [ng-bind-html="currentError.message"], [role="alert"] .ng-binding').first
                if current_error.count() and current_error.is_visible():
                    detail=' '.join(current_error.inner_text().split())
                    if detail:
                        logger.warning('FINAL SUBMIT OUTCOME | outcome=VROL_FORM_ERROR | detail=%s',detail[:500])
                        try:pg.screenshot(path=str(folder/'07_final_submit_form_error.png'),full_page=True)
                        except Exception:pass
                        _final_submit_review_pause(page.context,settings,logger,folder,'VROL_FORM_ERROR')
                        return {'selector':exact_selector,'clicked':True,'outcome':'VROL_FORM_ERROR','detail':detail,'page_url':pg.url}
                success=f.locator('text=/Case Confirmation|Dispute Submitted|submitted successfully/i').first
                if success.count() and success.is_visible():
                    detail=' '.join(success.inner_text().split())
                    logger.info('FINAL SUBMIT OUTCOME | outcome=CONFIRMATION | detail=%s',detail)
                    _final_submit_review_pause(page.context,settings,logger,folder,'CONFIRMATION')
                    return {'selector':exact_selector,'clicked':True,'outcome':'CONFIRMATION','detail':detail,'page_url':pg.url}
            except Exception:pass
        if not live_frames:
            landing=next((p for p in pages if 'vrol.visaonline.com' in p.url.lower()),page)
            logger.info('FINAL SUBMIT OUTCOME | outcome=DISPUTE_FRAME_CLOSED_OR_LANDING_RETURNED | page=%s | reconciliation=ROL500_REQUIRED',landing.url)
            try:landing.screenshot(path=str(folder/'07_final_submit_landing_return.png'),full_page=True)
            except Exception:pass
            _final_submit_review_pause(page.context,settings,logger,folder,'DISPUTE_FRAME_CLOSED_OR_LANDING_RETURNED')
            return {'selector':exact_selector,'clicked':True,'outcome':'DISPUTE_FRAME_CLOSED_OR_LANDING_RETURNED','page_url':landing.url,'rol500_reconciliation_required':True}
        _safe_browser_wait(page.context,poll)
    raise RuntimeError('FINAL_SUBMIT_OUTCOME_NOT_DETECTED')

def _evidence_stem(group):
    masked=''.join(ch if ch.isalnum() else 'X' for ch in str(group.get('masked_pan') or 'UNKNOWNPAN'))
    guid=''.join(ch for ch in str(group.get('guid') or 'UNKNOWNGUID') if ch.isalnum())
    return f'{masked}_{guid}'

def _clear_transaction_table_filter_before_evidence(page,logger):
    for scope in list(page.frames):
        try:
            search=scope.locator('thead input.search-box, input[aria-label*="Transaction ID" i], input[type="search"]').first
            if not (search.count() and search.is_visible()):continue
            current=search.input_value()
            if not current:return True
            js="el => { const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set; setter.call(el,''); el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.blur(); }"
            search.evaluate(js)
            page.wait_for_timeout(300)
            logger.info('TRANSACTION FILTER CLEARED BEFORE EVIDENCE | previous=%s',current)
            return True
        except Exception:pass
    logger.info('TRANSACTION FILTER CLEAR BEFORE EVIDENCE | action=NOT_REQUIRED_OR_NOT_FOUND')
    return False

def _copy_pi_to_central_folder(source_path,invoice,out_dir,logger):
    source=Path(source_path);central=Path(out_dir)/'PI_EVIDENCE_PDFS';central.mkdir(parents=True,exist_ok=True)
    prefix=f'{invoice}_';name=source.name if source.name.casefold().startswith(prefix.casefold()) else prefix+source.name
    destination=central/name;counter=2
    while destination.exists():destination=central/f'{Path(name).stem}_{counter}{source.suffix}';counter+=1
    shutil.copy2(source,destination);logger.info('PI EVIDENCE CENTRAL COPY | invoice=%s | source=%s | destination=%s',invoice,source,destination)
    return str(destination)

def _capture_chargeback_table_evidence(page,group,folder,logger):
    _clear_transaction_table_filter_before_evidence(page,logger)
    stem=_evidence_stem(group);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    png=folder/f'{stem}_transaction_table.png'
    try:page.screenshot(path=str(png),full_page=True);logger.info('CHARGEBACK TABLE SCREENSHOT SAVED | guid=%s | screenshot=%s | html_saved=false',group.get('guid'),png)
    except Exception as exc:logger.warning('CHARGEBACK TABLE SCREENSHOT FAILED | guid=%s | error=%s',group.get('guid'),exc)
    return {'transaction_table_screenshot':str(png)}


def _capture_questionnaire_full_page(page,scope,path,logger):
    maximize_page_window(page,logger,500)
    iframe=page.locator('iframe#FRAME_ID_Dispute, iframe[name="FRAME_ID_Dispute"]').first
    original_style=''
    try:
        if iframe.count():
            original_style=iframe.get_attribute('style') or ''
            height=scope.evaluate('Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)')
            iframe.evaluate("(el,h)=>{el.style.height=h+'px';el.style.minHeight=h+'px';}",height)
            page.wait_for_timeout(300)
        page.screenshot(path=str(path),full_page=True)
        logger.info('QUESTIONNAIRE FULL PAGE EVIDENCE SAVED | path=%s',path)
    finally:
        if iframe.count():
            try:iframe.set_attribute('style',original_style)
            except Exception:pass

def _capture_tagged_failure_evidence(page,group,folder,tag,logger,context=None):
    stem=_evidence_stem(group);safe_tag=''.join(ch if ch.isalnum() or ch in {'_','-'} else '_' for ch in str(tag).upper())
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);context=context or page.context;captures=[]
    for page_index,candidate in enumerate([p for p in context.pages if not p.is_closed()],1):
        page_path=folder/f'{stem}_{safe_tag}_page{page_index:02d}.png'
        try:candidate.screenshot(path=str(page_path),full_page=True);captures.append(str(page_path));logger.info('FAILURE PAGE SCREENSHOT SAVED | guid=%s | tag=%s | page=%s | url=%s | path=%s',group.get('guid'),safe_tag,page_index,candidate.url,page_path)
        except Exception as exc:logger.warning('FAILURE PAGE SCREENSHOT FAILED | guid=%s | tag=%s | page=%s | error=%s',group.get('guid'),safe_tag,page_index,exc)
        for frame_index,frame in enumerate(candidate.frames,1):
            if frame==candidate.main_frame:continue
            frame_path=folder/f'{stem}_{safe_tag}_page{page_index:02d}_frame{frame_index:02d}.png'
            try:frame.frame_element().screenshot(path=str(frame_path));captures.append(str(frame_path));logger.info('FAILURE FRAME SCREENSHOT SAVED | guid=%s | tag=%s | page=%s | frame=%s | frame_name=%s | frame_url=%s | path=%s',group.get('guid'),safe_tag,page_index,frame_index,frame.name,frame.url,frame_path)
            except Exception as exc:logger.warning('FAILURE FRAME SCREENSHOT FAILED | guid=%s | tag=%s | page=%s | frame=%s | frame_name=%s | frame_url=%s | error=%s',group.get('guid'),safe_tag,page_index,frame_index,frame.name,frame.url,exc)
    logger.info('TAGGED FAILURE EVIDENCE SAVED | guid=%s | tag=%s | screenshots=%s | html_saved=false',group.get('guid'),safe_tag,len(captures))
    return {'failure_evidence_tag':safe_tag,'failure_evidence_screenshot':captures[0] if captures else '','failure_evidence_screenshots':captures}


def post_issuer_review(group,result,folder):
    print('\n'+'='*96);C.print('[bold cyan]REVIEW SAU KHI THỰC HIỆN ISSUER ACTION[/]')
    render_review_table(group,result,folder)
    C.print(Panel.fit('[bold green]O[/] Xác nhận đúng, chưa Submit và sang nhóm tiếp theo\n[bold red]T[/] Submit case ngay (yêu cầu xác nhận SUBMIT)\n[bold magenta]F[/] Phản hồi cần xem lại logic\n[bold yellow]R[/] Chạy lại toàn bộ group\n[bold red]Q[/] Dừng và lưu kết quả',title='THAO TÁC SAU ISSUER ACTION',border_style='cyan'))
    while True:
        try:c=input('O đúng; T submit; F xem lại logic; R chạy lại; Q dừng > ').strip().upper()
        except EOFError:c='O'
        if c in {'O','T','F','R','Q'}:return c
def load_reviewed_guids(path):
    if not path.exists():return set()
    values=set()
    for raw in path.read_text(encoding='utf-8-sig',errors='replace').splitlines():
        value=raw.strip().upper()
        if not value or value.startswith('#'):continue
        values.add(value)
    return values

def append_reviewed_guid(path,guid):
    guid=str(guid or '').strip().upper()
    if not guid:return False
    existing=load_reviewed_guids(path)
    if guid in existing:return False
    needs_newline=path.exists() and path.stat().st_size>0
    with path.open('a',encoding='utf-8',newline='') as handle:
        if needs_newline:handle.write('\n')
        handle.write(guid)
        handle.flush()
    return True

def run(config_path):
    from src.auth import legacy_login
    settings,_=load_all(config_path);settings=dict(settings);settings['logout_after_login']=False;settings['validate_dispute_amount']='NO'
    source=Path(str(settings.get('batch_test_classified_file') or settings.get('classified_case_file'))).expanduser()
    print('09_CHARGEBACK_CLASSIFIED source:',source)
    # Use exactly one GUID-to-PAN mapping file. No merge and no fallback scan.
    mapping_key='batch_test_guid_pan_mapping_file'
    mapping_raw=str(settings.get(mapping_key) or '').strip()
    if not mapping_raw:
        raise ValueError('CASE_REVIEW_MAPPING_SETTING_EMPTY:'+mapping_key)
    mapping_path=Path(mapping_raw).expanduser()
    if not mapping_path.is_absolute():mapping_path=(config_path.parent/mapping_path).resolve()
    print('GUID-to-PAN mapping setting:',mapping_key)
    print('GUID-to-PAN mapping file:',mapping_path)
    if not mapping_path.exists():
        raise FileNotFoundError('CASE_REVIEW_MAPPING_FILE_NOT_FOUND:'+str(mapping_path))
    mapping,errors=load_mapping(mapping_path,str(settings.get('guid_pan_encoding','utf-8-sig')))
    if errors:
        print('GUID-to-PAN non-fatal mapping line errors:',len(errors))
    print('GUID-to-PAN mapping records:',len(mapping))
    # Prepare the persistent review clone before loading/grouping cases.
    reviewed_name=str(settings.get('case_reviewed_guid_file') or 'reviewed_guids.txt').strip()
    reviewed_guid_path=Path(reviewed_name).expanduser()
    if not reviewed_guid_path.is_absolute():reviewed_guid_path=(config_path.parent/reviewed_guid_path).resolve()
    reviewed_guid_path.parent.mkdir(parents=True,exist_ok=True)
    print('REVIEWED GUID REGISTRY LOAD START | path=',reviewed_guid_path)
    reviewed_guids=load_reviewed_guids(reviewed_guid_path)
    print('REVIEWED GUID REGISTRY LOAD COMPLETE | reviewed_guids=',len(reviewed_guids))
    print('REVIEW QUEUE BUILD START | source=',source)
    queue_started=datetime.now()
    all_groups,filter_stats=load_guid_groups(source,mapping)
    skipped=[g for g in all_groups if g['guid'].upper() in reviewed_guids]
    groups=[g for g in all_groups if g['guid'].upper() not in reviewed_guids]
    filter_stats.update({'reviewed_guid_registry_count':len(reviewed_guids),'reviewed_groups_skipped':len(skipped),'pending_groups':len(groups)})
    print('REVIEW QUEUE BUILT | total_groups=',len(all_groups),'| skipped_reviewed_guids=',len(skipped),'| pending_groups=',len(groups),'| elapsed_seconds=',round((datetime.now()-queue_started).total_seconds(),2))
    missing=[g['guid'] for g in groups if not g.get('pan')]
    print('Input filters: column U / CHECK SALE = SALE; column AH / VALID CHARGEBACK = Y; ROL500 preflight excludes ALREADY_CHARGEBACK_IN_ROL500')
    print('Input filter stats:',filter_stats)
    print('GUID groups pending:',len(groups),'| mapped:',len(groups)-len(missing),'| mapping missing:',len(missing))
    if missing:print('Mapping-missing GUID sample:',', '.join(missing[:10]))
    run_id=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]
    out_dir=config_path.parent/'runtime'/'case_reviews'/run_id;out_dir.mkdir(parents=True)
    workbook=None;headers=None;results=[]
    resume_index=0;relogin_requested=False
    def callback(portal,vrol,context,login_settings,answers,logger,login_run_dir):
        nonlocal resume_index,relogin_requested
        relogin_requested=False
        nonlocal results,groups,workbook,headers,filter_stats
        current=vrol
        if str(settings.get('rol500_preflight_enabled','YES')).upper() in {'YES','Y','TRUE','1'}:
            logger.info('CASE REVIEW ROL500 PREFLIGHT START')
            logger.info('CASE REVIEW ROL500 PREFLIGHT START | queue_not_started=true')
            rol=run_preflight(current,context,settings,source,out_dir,logger)
            (out_dir/'rol500_preflight_result.json').write_text(json.dumps(rol,ensure_ascii=False,indent=2),encoding='utf-8')
            enriched=Path(rol['enriched_workbook'])
            filter_started=time.perf_counter();logger.info('CASE REVIEW ROL500 ROW FILTER START | workbook=%s | source_groups=%s',enriched,len(all_groups))
            wb_check=load_workbook(enriched,data_only=True,read_only=True)
            try:
                ws_check=wb_check['Sheet1']
                header=next(ws_check.iter_rows(min_row=2,max_row=2,values_only=True))
                hh={str(value or '').strip():col for col,value in enumerate(header,start=1)}
                status_col=hh.get('BOT ROL500 STATUS')
                existing_rows=set()
                if status_col is not None:
                    statuses=ws_check.iter_rows(min_row=4,min_col=status_col,max_col=status_col,values_only=True)
                    existing_rows={row_no for row_no,(status,) in enumerate(statuses,start=4) if status=='ALREADY_CHARGEBACK_IN_ROL500'}
            finally: wb_check.close()
            logger.info('CASE REVIEW ROL500 ROW FILTER READ COMPLETE | matched_rows=%s | elapsed_seconds=%.2f',len(existing_rows),time.perf_counter()-filter_started)
            reviewed_skipped=[g for g in all_groups if g['guid'].upper() in reviewed_guids]
            rol_skipped=[g for g in all_groups if any(x['row_no'] in existing_rows for x in g['items'])]
            groups=[g for g in all_groups if g['guid'].upper() not in reviewed_guids and not any(x['row_no'] in existing_rows for x in g['items'])]
            filter_stats.update({'reviewed_guid_registry_count':len(reviewed_guids),'reviewed_groups_skipped':len(reviewed_skipped),'rol500_groups_skipped':len(rol_skipped),'pending_groups':len(groups)})
            logger.info('CASE REVIEW QUEUE FILTER COMPLETE | source_groups=%s | reviewed_skipped=%s | rol500_skipped=%s | pending=%s | elapsed_seconds=%.2f',len(all_groups),len(reviewed_skipped),len(rol_skipped),len(groups),time.perf_counter()-filter_started)
            logger.info('CASE REVIEW QUEUE REBUILT AFTER ROL500 | groups_total=%s | rol500_skipped=%s | pending=%s',len(all_groups),len(rol_skipped),len(groups))
            recycle_vrol_tabs_to_portal(portal,context,logger)
            retry=int(login_settings.get('max_step_retries',3));current=legacy_login.open_vrol_and_complete_mfa(portal,context,login_settings,retry,logger)
            logger.info('PASS CASE REVIEW ROL500 POST-REPORT RESET')
        output_source=enriched if str(settings.get('rol500_preflight_enabled','YES')).upper() in {'YES','Y','TRUE','1'} else source
        logger.info('CASE REVIEW OUTPUT WORKBOOK CREATE START | source=%s',output_source)
        output_started=time.perf_counter();workbook,headers=create(output_source,out_dir,run_id);logger.info('CASE REVIEW OUTPUT WORKBOOK READY | path=%s | columns=%s | elapsed_seconds=%.2f',workbook,len(headers),time.perf_counter()-output_started)
        logger.info('CASE REVIEW TRANSACTION INQUIRY START | pending_groups=%s | first_guid=%s',len(groups),groups[0]['guid'] if groups else '')
        reuse_transaction_inquiry=False
        for idx,group in enumerate(groups[resume_index:],resume_index+1):
            logger.info('GUID GROUP START | group=%s/%s | guid=%s | pan_bin6_last4=%s | rows=%s | invoices=%s',idx,len(groups),group['guid'],group['masked_pan'],[x['row_no'] for x in group['items']],[x['invoice'] for x in group['items']])
            expired,login_page,session_marker=_session_expired(context)
            if expired:
                folder=out_dir/f"group_{idx:04d}_{group['guid']}";folder.mkdir(parents=True,exist_ok=True)
                ev=_capture_tagged_failure_evidence(login_page,group,folder,'SESSION_EXPIRED_RELOGIN',logger,context)
                _write_activity_event(out_dir,{'event':'SESSION_EXPIRED','guid':group['guid'],'masked_pan':group.get('masked_pan'),'status':'RELOGIN_REQUIRED','reason_code':session_marker,'detail':'Restart login and resume same group.','screenshot':ev.get('failure_evidence_screenshot'),'html':ev.get('failure_evidence_html'),'action':'RELOGIN_AND_RESUME'})
                logger.warning('SESSION EXPIRED DETECTED | guid=%s | marker=%s | resume_group=%s | action=RELOGIN_AND_RESUME',group['guid'],session_marker,idx)
                resume_index=idx-1;relogin_requested=True;return
            if idx>1 and not reuse_transaction_inquiry:
                retry=int(login_settings.get('max_step_retries',3));current=legacy_login.open_vrol_and_complete_mfa(portal,context,login_settings,retry,logger)
            reuse_transaction_inquiry=False
            folder=out_dir/f"group_{idx:04d}_{group['guid']}";folder.mkdir(parents=True,exist_ok=True)
            if str(group.get('pan') or '').startswith('5'):
                result={'status':'NO_CHARGEBACK_REQUIRED','decision':'NO_CHARGEBACK_REQUIRED','reason_code':'NON_VISA_PAN_PREFIX_5','reason_detail':'PAN bắt đầu bằng 5, ngoài phạm vi luồng tra soát Visa; bỏ qua trước Transaction Inquiry.','issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':[{'row_no':x['row_no'],'qt':x.get('qt'),'code':x.get('code'),'invoice_raw':x.get('invoice'),'scan_status':'SKIPPED_NON_VISA_PAN_PREFIX_5','tran_types':[],'sale_selected':False} for x in group['items']],'review_action':'S','guid':group['guid']}
                _log_bot_decision(logger,group,result,'SKIP_BEFORE_INQUIRY','NON_VISA_PAN_PREFIX_5')
                update_group(workbook,headers,group,result,run_id);append_reviewed_guid(reviewed_guid_path,group['guid']);results.append(result)
                reuse_transaction_inquiry=True
                continue
            while True:
                try:
                    result=precheck_guid_group(current,context,group,settings,folder,logger)
                except Exception as exc:
                    logger.exception('GUID GROUP UNDEFINED FAILURE | guid=%s | pan_bin6_last4=%s',group['guid'],group.get('masked_pan'))
                    result={'status':'UNDEFINED_CASE','decision':'MANUAL_REVIEW_REQUIRED','reason_code':'UNDEFINED_GROUP_WORKFLOW_ERROR','reason_detail':str(exc),'issuer_action_required':False,'issuer_action_clicked':False,'invoice_results':[{'row_no':x['row_no'],'qt':x['qt'],'code':x['code'],'invoice_raw':x['invoice'],'scan_status':'NOT_SCANNED_GROUP_ERROR','tran_types':[],'sale_selected':False} for x in group['items']]}
                    (folder/'undefined_group_error.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
                if result.get('status')=='UNDEFINED_CASE':
                    result.update(_capture_tagged_failure_evidence(current,group,folder,'UNDEFINED_CASE',logger,context));action='S'
                    result['auto_review_action']='S';result['auto_review_reason']='UNDEFINED_CASE_EVIDENCE_CAPTURED'
                else:action=_auto_review_action(result,settings,logger,group['guid'])
                if action is None:
                    action=prompt(group,result,folder)
                else:
                    result['auto_review_action']=action
                    result['auto_review_reason']='AUTO_PROGRESS_RULE'
                if action=='R':
                    recycle_vrol_tabs_to_portal(portal,context,logger)
                    retry=int(login_settings.get('max_step_retries',3));current=legacy_login.open_vrol_and_complete_mfa(portal,context,login_settings,retry,logger)
                    continue
                if action=='P':
                    if result.get('status') in {'READY_FOR_ISSUER_ACTION_REVIEW','READY_FOR_MULTI_ISSUER_ACTION_REVIEW'}:
                        result.update(_capture_chargeback_table_evidence(current,group,folder,logger))
                    if result.get('status') in {'READY_FOR_PI_EVIDENCE_REVIEW','PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED'}:
                        runtime_pairs=result.get('_runtime_selected_txs') or []
                        pending_rows={inv.get('row_no') for inv in result.get('invoice_results',[]) if inv.get('pi_input','').strip().casefold()=='yes' and inv.get('pi_status')!='DOWNLOADED'}
                        pairs=[(tx,item) for tx,item in runtime_pairs if item.get('row_no') in pending_rows]
                        if not pairs:
                            result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='PI_RUNTIME_TRANSACTION_NOT_AVAILABLE',reason_detail='Không còn transaction runtime để mở View > Tran Details.',issuer_action_required=False);action='F'
                        else:
                            failures=[]
                            for tx,item in pairs:
                                try:
                                    evidence=download_pi_document(current,context,tx,item,group,folder,settings,logger)
                                    central_path=_copy_pi_to_central_folder(evidence['path'],item.get('invoice'),out_dir,logger);evidence['central_path']=central_path
                                    _write_activity_event(out_dir,{'event':'PI_EVIDENCE_CENTRAL_COPY','guid':group['guid'],'masked_pan':group.get('masked_pan'),'status':'COPIED','reason_code':'PI_YES','detail':f"invoice={item.get('invoice')}",'screenshot':'','html':'','action':central_path})
                                    for inv in result.get('invoice_results',[]):
                                        if inv.get('row_no')==item.get('row_no'):
                                            inv.update(pi_status='DOWNLOADED',pi_file=evidence['file_name'],pi_path=evidence['path'],pi_central_path=central_path,pi_evidence=evidence,scan_status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION')
                                except Exception as exc:
                                    logger.exception('PI EVIDENCE DOWNLOAD FAILED AFTER USER P | guid=%s | invoice=%s',group['guid'],item.get('invoice'))
                                    failures.append({'row_no':item.get('row_no'),'invoice':item.get('invoice'),'error':str(exc)})
                                    for inv in result.get('invoice_results',[]):
                                        if inv.get('row_no')==item.get('row_no'):inv.update(pi_status='DOWNLOAD_FAILED',pi_error=str(exc),scan_status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED')
                            if failures:
                                result.update(status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',decision='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',reason_code='PI_EVIDENCE_DOWNLOAD_FAILED',reason_detail=' | '.join(f"{x['invoice']}: {x['error']}" for x in failures),issuer_action_required=False,issuer_action_clicked=False,planned_review_action='Bấm P để thử tải lại các chứng từ PI bị lỗi',pi_download_failures=failures)
                                result.update(_capture_tagged_failure_evidence(current,group,folder,'PI_DOWNLOAD_FAILED',logger,context))
                                result['auto_review_action']='S';result['auto_review_reason']='PI_DOWNLOAD_FAILED_EVIDENCE_CAPTURED';action='S'
                            else:
                                result.update(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',decision='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',issuer_action_required=False,issuer_action_clicked=False,planned_review_action='Hoàn tất: chứng từ PI đã tải; không thực hiện Issuer Action',reason_code='PI_YES_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',reason_detail='PI = Yes: đã tải chứng từ qua View > Tran Details > Save as PDF; không cần thực hiện Issuer Action.',pi_pending_count=0)
                                C.print('[bold green]Đã tải đầy đủ chứng từ PI.[/] Group này không cần thực hiện Issuer Action.')
                            if failures:
                                action='S';result['auto_review_action']='S';result['auto_review_reason']='PI_DOWNLOAD_FAILED_EVIDENCE_CAPTURED'
                                logger.warning('AUTO CONTINUE AFTER PI DOWNLOAD FAILURE | guid=%s | failures=%s | action=S | prompt_skipped=true',group['guid'],len(failures))
                                _write_activity_event(out_dir,{'event':'CASE_ERROR','guid':group['guid'],'masked_pan':group.get('masked_pan'),'status':result.get('status'),'reason_code':result.get('reason_code'),'detail':result.get('reason_detail'),'screenshot':result.get('failure_evidence_screenshot'),'html':'','action':'CAPTURE_NOTE_CONTINUE'})
                            elif str(settings.get('case_review_auto_progress_enabled','YES')).strip().upper() in {'YES','Y','TRUE','1'}:
                                action='S';result['auto_review_action']='S';result['auto_review_reason']='PI_EVIDENCE_DOWNLOADED'
                                logger.info('AUTO REVIEW ACTION | guid=%s | status=%s | action=S | reason=PI_EVIDENCE_DOWNLOADED',group['guid'],result.get('status'))
                            else:action=prompt(group,result,folder)
                    elif result.get('selected_count',0)<1 or not result.get('_runtime_tx'):
                        result['status']=result['decision']='LOGIC_REVIEW_REQUIRED';result['reason_code']='NO_SELECTED_TRANSACTION_FOR_ISSUER_ACTION';result['reason_detail']='Không có transaction hợp lệ đã được đánh dấu để thực hiện Issuer Action.';action='F'
                    elif str(result.get('planned_issuer_action','')).startswith('UNDEFINED'):
                        result['status']=result['decision']='LOGIC_REVIEW_REQUIRED';result['reason_code']='UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES';result['reason_detail']='Không xác định được một Issuer Action duy nhất cho group.';action='F'
                    else:
                        item=result['_runtime_item'];tx=result['_runtime_tx'];settings['active_case_code']=item['code'];settings['active_selected_transaction_count']=result.get('selected_count',1);settings['allow_final_submit']='NO';settings['batch_test_case_evidence_dir']=str(folder)
                        logger.info('ISSUER ACTION PROCEED | guid=%s | selected_count=%s | transaction_ids=%s | action=%s',group['guid'],result.get('selected_count'),result.get('selected_transaction_ids'),result.get('planned_issuer_action'))
                        case_result=open_case_and_prepare(current,tx,item['code'],item,settings,folder/'downloads')
                        try:
                            if not case_result.get('ready') or case_result.get('scope') is None:
                                raise RuntimeError(case_result.get('workflow_error') or 'OPEN_CASE_NOT_READY')
                            filled=fill_test_questionnaire(case_result['scope'],item['code'],settings,item)
                        except Exception as exc:
                            open_error=str(case_result.get('workflow_error') or '')
                            if 'ROL_1545' in open_error:
                                tag='ROL_1545_DUPLICATE';reason_code='ROL_1545_DUPLICATE_SELECTED_CARD_TRANSACTION_MCSN';reason_detail=open_error
                            elif open_error:
                                tag='CASE_TIMEOUT_OR_SELECTOR_FAILED';reason_code='CASE_WORKFLOW_TIMEOUT_OR_SELECTOR_FAILED';reason_detail=open_error
                            else:
                                tag='QUESTIONAIRE_FILL_FAILED';reason_code='QUESTIONNAIRE_PROCESSING_FAILED';reason_detail=str(exc)
                            logger.exception('CASE PROCESSING FAILED - EVIDENCE CAPTURED AND CONTINUING | guid=%s | invoice=%s | code=%s | tag=%s',group['guid'],item.get('invoice'),item.get('code'),tag)
                            result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code=reason_code,reason_detail=reason_detail,issuer_action_clicked=True,issuer_action_required=True,executed_issuer_action=result.get('planned_issuer_action'),vrol_case_number=case_result.get('rol'),final_submit_clicked=False)
                            result.update(_capture_tagged_failure_evidence(case_result.get('page') or current,group,folder,tag,logger,context))
                            result['auto_review_action']='S';result['auto_review_reason']=tag+'_EVIDENCE_CAPTURED';action='S';filled=None
                        if filled is not None:
                            result.update(status='ISSUER_ACTION_COMPLETED_REVIEW_REQUIRED',decision='ISSUER_ACTION_COMPLETED_REVIEW_REQUIRED',issuer_action_clicked=True,issuer_action_required=True,executed_issuer_action=result.get('planned_issuer_action'),vrol_case_number=case_result.get('rol'),filled_fields=filled,final_submit_clicked=False)
                            stem=_evidence_stem(group);questionnaire_path=folder/f'{stem}_questionnaire_filled.png'
                            try:_capture_questionnaire_full_page(case_result['page'],case_result['scope'],questionnaire_path,logger)
                            except Exception as exc:logger.warning('QUESTIONNAIRE FILLED SCREENSHOT FAILED | guid=%s | error=%s',group['guid'],exc)
                            if str(settings.get('case_review_auto_create_to_questionnaire_enabled','YES')).strip().upper() in {'YES','Y','TRUE','1'}:
                                result.update(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',decision='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',questionnaire_screenshot=str(questionnaire_path),final_submit_clicked=False,auto_review_action='S',auto_review_reason='QUESTIONNAIRE_FILLED_NO_FINAL_SUBMIT')
                                logger.info('AUTO QUESTIONNAIRE CHECKPOINT COMPLETE | guid=%s | rol=%s | screenshot=%s | final_submit_clicked=false | next_group=true',group['guid'],case_result.get('rol'),questionnaire_path)
                                action='S';post='AUTO_CHECKPOINT'
                            else:post=post_issuer_review(group,result,folder)
                        else:
                            post='AUTO_FAILURE_CHECKPOINT' if result.get('auto_review_reason')=='QUESTIONAIRE_FILL_FAILED_EVIDENCE_CAPTURED' else 'F'
                        if post=='AUTO_FAILURE_CHECKPOINT':
                            pass
                        elif post=='AUTO_CHECKPOINT':
                            pass
                        elif post=='T':
                            confirm=input('Gõ chính xác SUBMIT để xác nhận gửi case thật: ').strip()
                            if confirm=='SUBMIT':
                                submit_result=_click_final_submit(case_result['page'],settings,logger,folder);result.update(status='FINAL_SUBMIT_COMPLETED',decision='FINAL_SUBMIT_COMPLETED',final_submit_clicked=True,final_submit_selector=submit_result.get('selector'),final_submit_outcome=submit_result.get('outcome'),final_submit_detail=submit_result.get('detail',''),rol500_reconciliation_required=submit_result.get('rol500_reconciliation_required',False));action='T'
                            else:
                                result.update(status='ISSUER_ACTION_COMPLETED_REVIEW_REQUIRED',reason_code='FINAL_SUBMIT_CONFIRMATION_CANCELLED',reason_detail='User không nhập đúng SUBMIT; case chưa được gửi.');action='O'
                        elif post=='F':
                            result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='USER_FEEDBACK_AFTER_ISSUER_ACTION',reason_detail='User phản hồi cần xem lại logic sau khi bot thực hiện Issuer Action.',final_submit_clicked=False);action='F'
                        elif post=='R':
                            recycle_vrol_tabs_to_portal(portal,context,logger);retry=int(login_settings.get('max_step_retries',3));current=legacy_login.open_vrol_and_complete_mfa(portal,context,login_settings,retry,logger);continue
                        elif post=='Q':action='Q'
                        else:action='O'
                if action=='S':
                    result['bot_decision_before_review']=result.get('decision') or result.get('status')
                    result['user_review_confirmation']='BOT_DECISION_CONFIRMED_CORRECT'
                    result['review_note']='User xác nhận quyết định của bot là phù hợp.'
                    # Preserve the business decision instead of replacing it with USER_SKIPPED.
                    result['reason_detail']=result.get('reason_detail') or 'User xác nhận quyết định của bot là phù hợp.'
                if action=='F':
                    result['status']=result['decision']='LOGIC_REVIEW_REQUIRED'
                    result['reason_code']='USER_FEEDBACK_REVIEW_BOT_LOGIC'
                    result['reason_detail']='User phản hồi cần xem lại logic xử lý của case này.'
                    result['issuer_action_required']=False;result['issuer_action_clicked']=False
                result.pop('_runtime_tx',None);result.pop('_runtime_item',None);result.pop('_runtime_selected_txs',None);result['review_action']=action
                _log_bot_decision(logger,group,result,action,result.get('auto_review_reason') or result.get('reason_code') or 'BOT_RULE')
                update_group(workbook,headers,group,result,run_id)
                if action in {'S','O','T'}:
                    append_reviewed_guid(reviewed_guid_path,group['guid'])
                    reviewed_guids.add(group['guid'].upper())
                    print('REVIEWED GUID SAVED | guid=',group['guid'],'| action=',action,'| registry=',reviewed_guid_path)
                result['guid']=group['guid'];results.append(result)
                _write_activity_event(out_dir,{'event':'CASE_RESULT','guid':group['guid'],'masked_pan':group.get('masked_pan'),'status':result.get('status'),'reason_code':result.get('reason_code'),'detail':result.get('reason_detail'),'screenshot':result.get('failure_evidence_screenshot'),'html':'','action':action})
                if action=='Q':raise KeyboardInterrupt('CASE_REVIEW_STOPPED_BY_USER')
                break
            expired,login_page,session_marker=_session_expired(context)
            if expired:
                resume_index=idx;relogin_requested=True
                _write_activity_event(out_dir,{'event':'SESSION_EXPIRED','guid':group['guid'],'masked_pan':group.get('masked_pan'),'status':'RELOGIN_REQUIRED','reason_code':session_marker,'detail':'Resume next group after complete login.','action':'RELOGIN_AND_RESUME'})
                return
            terminal_no_issuer=result.get('status') in {'NO_CHARGEBACK_REQUIRED','ROL_897_NO_MATCHING_TRANSACTIONS','PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION','READY_FOR_PI_EVIDENCE_REVIEW'}
            issuer_action_was_clicked=bool(result.get('issuer_action_clicked',False))
            logger.info('RESULTS BACK ELIGIBILITY | guid=%s | status=%s | issuer_action_clicked=%s | eligible=%s',group['guid'],result.get('status'),issuer_action_was_clicked,terminal_no_issuer and not issuer_action_was_clicked)
            if terminal_no_issuer and not issuer_action_was_clicked:
                reuse_transaction_inquiry=_back_to_transaction_inquiry(current,settings,logger)
            if not reuse_transaction_inquiry:
                recycle_vrol_tabs_to_portal(portal,context,logger)
        if str(settings.get('rol500_postflight_enabled','YES')).upper() in {'YES','Y','TRUE','1'}:
            try:
                recycle_vrol_tabs_to_portal(portal,context,logger)
                current=legacy_login.open_vrol_and_complete_mfa(portal,context,login_settings,int(login_settings.get('max_step_retries',3)),logger)
                logger.info('CASE REVIEW ROL500 POSTFLIGHT START | processed_groups=%s',len(results))
                post=run_preflight(current,context,settings,workbook,out_dir/'postflight',logger)
                (out_dir/'rol500_postflight_result.json').write_text(json.dumps(post,ensure_ascii=False,indent=2),encoding='utf-8')
                logger.info('CASE REVIEW ROL500 POSTFLIGHT COMPLETE | enriched_workbook=%s',post.get('enriched_workbook'))
            except Exception as exc:
                logger.exception('CASE REVIEW ROL500 POSTFLIGHT FAILED | review_results_preserved=true | error=%s',exc)
    rc=1;relogin_cycles=0;max_relogin_cycles=int(settings.get('max_session_relogin_cycles',10))
    while True:
        rc=legacy_login.run(config_path,after_login=callback,settings_override=settings)
        if not relogin_requested:break
        relogin_cycles+=1;_write_activity_event(out_dir,{'event':'SESSION_RELOGIN','status':'RESTARTING_LOGIN_WORKFLOW','reason_code':'SESSION_EXPIRED','detail':f'cycle={relogin_cycles}; resume_index={resume_index}','action':'RESTART_LEGACY_LOGIN'})
        if relogin_cycles>=max_relogin_cycles:rc=1;break
    final_status='COMPLETED' if rc==0 else 'COMPLETED_WITH_ISSUES'
    summary={'run_id':run_id,'status':final_status,'group_count':len(groups),'input_filter':filter_stats,'results':results,'output_workbook':str(workbook),'reviewed_guid_file':str(reviewed_guid_path),'skipped_reviewed_groups':len(skipped),'legacy_login_return_code':rc,'session_relogin_cycles':relogin_cycles,'activity_report_csv':str(out_dir/'activity_report.csv'),'activity_report_jsonl':str(out_dir/'activity_report.jsonl'),'pi_evidence_central_folder':str(out_dir/'PI_EVIDENCE_PDFS')}
    (out_dir/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False,indent=2));return 0 if rc==0 else 2
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',default='config.xlsx');a=p.parse_args();raise SystemExit(run(Path(a.config).resolve()))
