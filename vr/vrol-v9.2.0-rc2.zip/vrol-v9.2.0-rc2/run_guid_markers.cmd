@echo off
setlocal
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
if "%~1"=="" (
  echo Usage: run_guid_markers.cmd "C:\path\to\run_id"
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" -m async_runtime.guid_markers --run-dir "%~1"
exit /b %ERRORLEVEL%
