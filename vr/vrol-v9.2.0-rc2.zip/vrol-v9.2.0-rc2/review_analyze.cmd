@echo off
rem Usage: review_analyze.cmd RUN_DIR [RUN_DIR ...]  -> runtime\review_report.md
cd /d "%~dp0"
".venv\Scripts\python.exe" review_tools\analyze_runs.py %* > runtime\review_report.md
type runtime\review_report.md
