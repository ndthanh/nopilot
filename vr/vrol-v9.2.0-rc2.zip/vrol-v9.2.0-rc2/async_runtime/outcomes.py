"""Shared classification: a finished task is not necessarily a completed case."""
COMPLETED = {'NO_CHARGEBACK_REQUIRED', 'PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',
             'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT','FINAL_SUBMIT_COMPLETED'}
CHECKPOINTS = {'INQUIRY_ONLY_CHECKPOINT', 'ISSUER_ACTION_DEFERRED_TEST_MODE'}

def needs_review(result):
    return str(result.get('status') or '') not in COMPLETED | CHECKPOINTS

def technical_failure(result):
    status = str(result.get('status') or '')
    return status in {'LOGIC_REVIEW_REQUIRED', 'UNDEFINED_CASE', 'PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',
                     'FINAL_SUBMIT_FORM_ERROR', 'FINAL_SUBMIT_RECONCILIATION_REQUIRED'}
