"""Durable case-side-effect holds, separate from the completed-GUID registry."""
import json
import re
from pathlib import Path


def hold_case(settings, guid, **data):
    root = settings.get('_review_hold_dir')
    if not root:
        return
    if not re.fullmatch(r'[A-Za-z0-9_-]+', guid):
        raise ValueError('INVALID_HOLD_GUID')
    path = Path(root) / (guid.upper() + '.json')
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(dict(guid=guid, disposition='HOLD_REVIEW', **data), ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def held_guids(folder):
    holds = {}
    for path in Path(folder).glob('*.json'):
        try:
            record = json.loads(path.read_text(encoding='utf-8'))
            if record.get('disposition') == 'HOLD_REVIEW':
                holds[str(record['guid']).upper()] = record
        except (OSError, ValueError, KeyError):
            # A damaged hold must block rather than permit case recreation.
            holds[path.stem.upper()] = dict(reason_code='REVIEW_HOLD_UNREADABLE')
    return holds


def seed_existing_holds(runs_dir, hold_dir):
    """Import latest unresolved side effects; never rewrite historical artifacts."""
    from .outcomes import COMPLETED
    latest={}
    for path in sorted(Path(runs_dir).glob('*/groups/*/guid_result.json')):
        try:
            record=json.loads(path.read_text(encoding='utf-8'));guid=str(record['guid']).upper()
            latest[guid]=(path,record)
        except (OSError,ValueError,KeyError):continue
    for guid,(path,record) in latest.items():
        if (Path(hold_dir)/(guid+'.json')).exists():continue
        result=record.get('result') or record
        if result.get('status') in COMPLETED:continue
        try:saved=json.loads((path.parent/'case_checkpoint.json').read_text(encoding='utf-8'))
        except (OSError,ValueError):saved={}
        if not (result.get('issuer_action_clicked') or saved.get('issuer_action_clicked') or saved.get('submit_dispatched')):continue
        hold_case(dict(_review_hold_dir=str(hold_dir)),guid,reason_code=result.get('reason_code') or 'UNRESOLVED_CASE_SIDE_EFFECT',
                  rol=result.get('rol') or saved.get('rol'),folder=str(path.parent),screenshots=record.get('screenshots') or [])
    for checkpoint in Path(runs_dir).glob('*/groups/*/case_checkpoint.json'):
        if (checkpoint.parent/'guid_result.json').exists():continue
        try:
            saved=json.loads(checkpoint.read_text(encoding='utf-8'))
            state=json.loads((checkpoint.parent/'guid_state.json').read_text(encoding='utf-8'))
            guid=str(state['guid']).upper()
        except (OSError,ValueError,KeyError):continue
        if (Path(hold_dir)/(guid+'.json')).exists() or not saved.get('issuer_action_clicked'):continue
        hold_case(dict(_review_hold_dir=str(hold_dir)),guid,reason_code='INTERRUPTED_AFTER_ISSUER_ACTION',
                  rol=saved.get('rol'),folder=str(checkpoint.parent),screenshots=[str(p) for p in checkpoint.parent.glob('*.png')])


def interrupted_side_effects(runs_dir):
    """Checkpoints showing a Visa side effect whose run never produced a CASE_RESULT.

    The legacy hold folder is retired; these become ledger outcomes (AM 'Review: ...').
    """
    items=[]
    for checkpoint in Path(runs_dir).glob('*/groups/*/case_checkpoint.json'):
        folder=checkpoint.parent
        if (folder/'guid_result.json').exists():continue
        try:
            saved=json.loads(checkpoint.read_text(encoding='utf-8'))
            guid=str(json.loads((folder/'guid_state.json').read_text(encoding='utf-8'))['guid']).upper()
        except (OSError,ValueError,KeyError):continue
        if not (saved.get('issuer_action_clicked') or saved.get('submit_dispatched') or saved.get('rol')):continue
        rol=saved.get('rol') or saved.get('vrol_case_number')
        items.append(dict(guid=guid,label='Review: INTERRUPTED_AFTER_ISSUER_ACTION',reason='INTERRUPTED_AFTER_ISSUER_ACTION',
                          rols=[str(rol)] if rol else [],folder=str(folder)))
    return items


def read_only_recheck_guids(runs_dir):
    """Permit PI/no-CB re-observation without replaying any known case action."""
    latest={};side_effects=set()
    for path in sorted(Path(runs_dir).glob('*/groups/*/guid_result.json')):
        try:
            record=json.loads(path.read_text(encoding='utf-8'));guid=str(record['guid']).upper()
            result=record.get('result') or record;latest[guid]=result
            saved=result.get('case_checkpoint') or {}
            if result.get('issuer_action_clicked') or result.get('rol') or result.get('vrol_case_number') or saved.get('issuer_action_clicked') or saved.get('rol'):side_effects.add(guid)
        except (OSError,ValueError,KeyError):continue
    return {guid for guid,result in latest.items() if guid not in side_effects and result.get('status') in {'NO_CHARGEBACK_REQUIRED','PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION'}}
