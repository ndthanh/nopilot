from contextvars import ContextVar

emit_log = ContextVar('vrol_emit_log', default=None)

class ContextLogger:
    def _write(self, level, message, *args):
        callback = emit_log.get()
        if callback:
            callback(level, message % args if args else str(message))
    def info(self, message, *args): self._write('info', message, *args)
    def debug(self, message, *args): self._write('info', message, *args)
    def warning(self, message, *args): self._write('warning', message, *args)
    warn = warning
    def error(self, message, *args): self._write('error', message, *args)
    def exception(self, message, *args): self._write('error', message, *args)

LOGGER = ContextLogger()
