"""Reconcile deferred master writes / prune registry without Chrome or OTP."""
import argparse,json
from datetime import datetime
from pathlib import Path
from .business_status import BusinessState
from .config import load_settings
from .run_monitor import RunLock

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='config.xlsx');parser.add_argument('--master-workbook')
    parser.add_argument('--run-dir',help='Original run whose writeback/output should be reconciled')
    parser.add_argument('--cleanup',action='store_true')
    args=parser.parse_args();root=Path(__file__).resolve().parents[1]
    config=Path(args.config).resolve();settings=load_settings(config)
    original=Path(args.run_dir).resolve() if args.run_dir else None
    state_file=original/'run_state.json' if original else None
    run_state=json.loads(state_file.read_text(encoding='utf-8')) if state_file and state_file.is_file() else {}
    raw=args.master_workbook or run_state.get('master_workbook') or settings.get('async_master_workbook') or settings.get('batch_test_classified_file') or settings.get('classified_case_file')
    if not raw:parser.error('Set --master-workbook or async_master_workbook')
    master=Path(str(raw));master=master if master.is_absolute() else config.parent/master
    report_dir=original or root/'runtime'/'business_maintenance'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    report_dir.mkdir(parents=True,exist_ok=True)
    with RunLock(root/'runtime'/'vrol_process.lock'):
        state=BusinessState(root/'runtime'/'business_state.sqlite3',master,report_dir,int(settings.get('business_state_retention_days') or 180))
        try:
            if args.cleanup:
                raw_registry=Path(str(settings.get('case_reviewed_guid_file') or 'reviewed_guids.txt'))
                registry=raw_registry if raw_registry.is_absolute() else config.parent/raw_registry
                print(json.dumps(state.cleanup(registry,master),ensure_ascii=False,indent=2))
            output=original/'09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx' if original else None
            report=state.sync(output if output and output.is_file() else None)
            print(json.dumps(report,ensure_ascii=False,indent=2))
            return 2 if report['status'] in {'PENDING','CONFLICT'} else 0
        finally:state.close()

if __name__=='__main__':raise SystemExit(main())
