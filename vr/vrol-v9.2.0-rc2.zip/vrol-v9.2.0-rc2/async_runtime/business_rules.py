"""User-confirmed non-submit rules; evaluate only invoice-matched VROL rows.

GUID-wide PI discovery runs before this function. These are vetoes, so a known
refund/duplicate is reported even when a Sale/Cash row is absent or non-unique.
"""
import re

ECI_REJECT = 'lỗi dữ liệu - ECI = 5/6/blank'
DUPLICATE_REJECT = 'Duplicate - assoc dispute = D'


def no_submit_rule(code, transactions):
    code=str(code)
    if code not in {'10.4','13.1','13.9'}:return None
    refund='Cash Rev' if code=='13.9' else 'Credit'
    for tx in transactions:
        if str(tx.tran_type or '').strip().casefold()==refund.casefold():
            return dict(reason_code='GROUP_REJECT_TRAN_TYPE',cb_reject='Refund - tran type = '+refund,
                        trigger_tran_type=refund,scan_status='STOPPED_GROUP_REJECT')
    for tx in transactions:
        if str(tx.assoc_dispute or '').strip().upper()=='D':
            return dict(reason_code='GROUP_CONTAINS_ASSOC_DISPUTE_D',cb_reject=DUPLICATE_REJECT,
                        trigger_tran_type=tx.tran_type,trigger_assoc_dispute='D',trigger_transaction_id=tx.transaction_id,
                        scan_status='STOPPED_ASSOC_DISPUTE_D')
    if code=='10.4':
        for tx in transactions:
            if not re.fullmatch(r'Sale(?:\s*-\s*WT)?',str(tx.tran_type or '').strip(),re.I):continue
            eci=str(tx.moto_eci or '').strip()
            if eci in {'','5','6'}:
                return dict(reason_code='GROUP_REJECT_MOTO_ECI',cb_reject=ECI_REJECT,
                            trigger_tran_type=tx.tran_type,trigger_moto_eci=eci,scan_status='STOPPED_GROUP_REJECT')
    return None
