import asyncio, json, time
from pathlib import Path
from .native_precheck import precheck_guid_group
from .native_pi import download_pi
from .native_case import open_case_and_fill
from .observability import LOGGER,emit_log
from .session import SharedSessionExpired,is_session_expired
from .associated_transactions import AssociatedScreenDetected,stop as stop_associated

async def run_native_group(page,registry,group,settings,folder,emit):
    settings=dict(settings,validate_dispute_amount='NO',batch_test_case_evidence_dir=str(folder),_current_guid=group.guid,_popup_registry=registry)
    g=dict(guid=group.guid,pan=group.full_pan,masked_pan=group.masked_pan,start_date=group.start_date,items=group.items)
    token=emit_log.set(emit);timings={};started=time.monotonic()
    settings['_timings']=timings
    try:
        if await is_session_expired(page):raise SharedSessionExpired('SESSION_EXPIRED_BEFORE_INQUIRY')
        t0=time.monotonic()
        result=await precheck_guid_group(page,page.context,g,settings,Path(folder),LOGGER)
        timings['precheck_s']=round(time.monotonic()-t0,2)
        status=result.get('status','')
        if settings.get('_inquiry_only') and status.startswith('READY_FOR_'):
            result.update(status='INQUIRY_ONLY_CHECKPOINT',decision='INQUIRY_ONLY_CHECKPOINT',reason_code='TEST_STOP_BEFORE_VIEW_OR_ISSUER')
        elif status=='READY_FOR_PI_EVIDENCE_REVIEW':
            failures=[]
            from .native_table import reacquire_transaction
            for selected,item in result.get('_runtime_selected_txs',[]):
                inv=next(x for x in result['invoice_results'] if x['row_no']==item['row_no'] and x.get('transaction_id')==selected.transaction_id and x.get('tran_type',selected.tran_type)==selected.tran_type)
                if inv.get('sale_selected'):
                    current=await reacquire_transaction(page,selected,item,settings)
                    await current.locator.get_by_role('checkbox').first.uncheck(force=True)
            for tx,item in result.get('_runtime_selected_txs',[]):
                inv=next(x for x in result['invoice_results'] if x['row_no']==item['row_no'] and x.get('transaction_id')==tx.transaction_id and x.get('tran_type',tx.tran_type)==tx.tran_type)
                if inv.get('pi_status')!='PENDING_USER_ACTION':continue
                try:
                    t_pi=time.monotonic()
                    ev=await download_pi(page,registry,tx,item,group,settings,folder,LOGGER)
                    timings.setdefault('pi_download_s',[]).append(round(time.monotonic()-t_pi,2))
                    inv.update(pi_status='DOWNLOADED',pi_file=ev['file_name'],pi_path=ev['path'],pi_central_path=ev['central_path'],pi_evidence=ev,scan_status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION')
                except Exception as exc:
                    inv.update(pi_status='DOWNLOAD_FAILED',pi_error=str(exc),scan_status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED')
                    shots=[]
                    for index,owned in enumerate(registry.pages(page),1):
                        path=Path(folder)/f'pi_error_{item["row_no"]}_{len(failures)+1}_{index:02d}.png'
                        try:await owned.screenshot(path=str(path),full_page=True,timeout=5000);shots.append(str(path))
                        except Exception:pass
                    inv['error_screenshots']=shots
                    failures.append(item['invoice']+':'+str(exc));LOGGER.error('PI FAILED | invoice=%s | error=%s',item['invoice'],exc)
            pending=sum(x.get('pi_status')=='PENDING_USER_ACTION' for x in result['invoice_results'])
            result['pi_pending_count']=pending
            if pending:failures.append(f'UNPROCESSED_PI_ROWS:{pending}')
            if failures:
                result.update(status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',decision='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',reason_code='PI_DOWNLOAD_FAILED',reason_detail=' | '.join(failures))
            else:result.update(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',decision='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',reason_code='PI_YES_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',pi_pending_count=0)
        elif status in {'READY_FOR_ISSUER_ACTION_REVIEW','READY_FOR_MULTI_ISSUER_ACTION_REVIEW'}:
            if str(result.get('planned_issuer_action','')).startswith('UNDEFINED'):
                result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES')
            elif group.guid in settings.get('_held_case_records',{}):
                held=settings['_held_case_records'][group.guid]
                result.update(status='CASE_RECONCILIATION_REQUIRED',decision='CASE_RECONCILIATION_REQUIRED',reason_code='EXISTING_CASE_REQUIRES_QUESTIONNAIRE_REVIEW',
                              rol=held.get('rol') or '',issuer_action_clicked=True,disposition='HOLD_REVIEW',previous_reason_code=held.get('reason_code'),reason_detail='Re-queried transaction; do not recreate an existing or uncertain case')
            elif settings.get('_pi_only'):
                result.update(status='ISSUER_ACTION_DEFERRED_TEST_MODE',decision='ISSUER_ACTION_DEFERRED_TEST_MODE',reason_code='TEST_PI_ONLY_NO_CASE_CREATED')
            else:
                chosen=result['_runtime_tx'];selected_item=dict(result['_runtime_item'])
                if not chosen.values.get('transaction_date'):raise RuntimeError('SELECTED_TRANSACTION_DATE_MISSING')
                selected_item.update(_expected_card_bin6=group.full_pan[:6],_expected_card_last4=group.full_pan[-4:],_expected_summary_date=chosen.values['transaction_date'])
                t_case=time.monotonic()
                result.update(await open_case_and_fill(page,registry,selected_item,result,settings,folder,LOGGER))
                timings['case_s']=round(time.monotonic()-t_case,2)
        result={k:v for k,v in result.items() if not k.startswith('_runtime_')}
        timings['engine_total_s']=round(time.monotonic()-started,2);result['timings']=timings
        from .jsonio import atomic_write_json
        atomic_write_json(Path(folder)/'group_result.json',result)
        return result
    except AssociatedScreenDetected as exc:
        result=await stop_associated(exc.found,settings,folder,'',LOGGER)
        (Path(folder)/'group_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        return result
    except Exception as exc:
        if "result" in locals():exc.partial_result={k:v for k,v in result.items() if not k.startswith("_runtime_")}
        if await is_session_expired(page):
            from .jsonio import read_json_safe
            from .outcome_policy import side_effect_state
            saved=read_json_safe(Path(folder)/'case_checkpoint.json',{}) or {}
            unsafe=side_effect_state(saved)
            if not unsafe:
                raise SharedSessionExpired('SESSION_EXPIRED_BEFORE_CASE_SIDE_EFFECT')
        raise
    finally:emit_log.reset(token)
