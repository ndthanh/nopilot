"""Sync dispute rules, with the requested GUID-wide PI evidence priority."""
import re, json, time
from pathlib import Path
from .native_ui import (open_transaction_inquiry, fill_transaction_inquiry_pan, fill_transaction_inquiry_start_date,
 click_transaction_inquiry_submit, wait_transaction_results, normalize_invoice_number, apply_invoice_filter,
 UnknownScenario, BusinessReview)
from .native_table import schema_from_dom, parse_row_for_code
from src.vrol.transaction_table import transaction_id_matches_invoice
from .business_rules import no_submit_rule

async def _no_matching_transaction_message(frame):
    selectors = ['span.errorSummary', 'td span.errorSummary', '.errorSummary']
    for selector in selectors:
        try:
            loc = frame.locator(selector)
            for i in range(await loc.count()):
                text = ' '.join((await loc.nth(i).inner_text() or '').split())
                if re.search('ROL-897\\s*:\\s*No matching transactions found', text, re.I):
                    return text
        except Exception:
            pass
    return ''

def _no_matching_result(group, message):
    return {'status': 'MANUAL_REVIEW_REQUIRED', 'decision': 'MANUAL_REVIEW_REQUIRED', 'reason_code': 'ROL_897_NO_MATCHING_TRANSACTIONS', 'reason_detail': message, 'issuer_action_required': False, 'issuer_action_clicked': False, 'selected_count': 0, 'invoice_results': [{'row_no': x['row_no'], 'qt': x['qt'], 'code': x['code'], 'invoice_raw': x['invoice'], 'scan_status': 'NO_MATCHING_TRANSACTIONS_AT_PAN_DATE_SEARCH', 'tran_types': [], 'sale_selected': False} for x in group['items']]}

async def _transaction_count_from_page(body):
    """Read the VROL reported transaction count without mutating DataTables."""
    try:
        text = ' '.join((await body.locator('body').inner_text(timeout=1500) or '').split())
        match = re.search('([0-9,]+)\\s+Transactions?\\s+Found', text, re.I)
        if match:
            return int(match.group(1).replace(',', ''))
    except Exception:
        pass
    return None

async def _transaction_result_text(body):
    try:return ' '.join((await body.locator('body').inner_text(timeout=1500) or '').split())
    except Exception:return ''

async def _transaction_scan_strategy(body, settings, logger):
    reported = await _transaction_count_from_page(body)
    dom_rows = await body.locator('table#results tbody > tr[data-action="summaryGridRow"]').count()
    threshold = int(settings.get('transaction_direct_scan_max_rows', 25))
    use_filter = reported is None or reported > threshold or dom_rows < reported
    strategy = 'INVOICE_FILTER' if use_filter else 'DIRECT_DOM'
    reason = 'count_unknown' if reported is None else 'reported_above_threshold' if reported > threshold else 'dom_rows_less_than_reported' if dom_rows < reported else 'small_table_fully_rendered'
    logger.info('TRANSACTION SCAN STRATEGY | strategy=%s | reported_transactions=%s | dom_rows=%s | direct_scan_max_rows=%s | reason=%s | datatables_api_used=false', strategy, reported, dom_rows, threshold, reason)
    return {'strategy': strategy, 'reported_transactions': reported, 'dom_rows': dom_rows, 'threshold': threshold, 'reason': reason}

async def _invoice_transactions(body,item,settings,scan,headers,logger):
    inv=normalize_invoice_number(item['invoice'])
    if scan['strategy']=='INVOICE_FILTER':
        body,inv,rows=await apply_invoice_filter(body,item['invoice'],settings)
        headers=await schema_from_dom(body)
    else:rows=body.locator('table#results tbody > tr[data-action="summaryGridRow"]')
    parsed=[]
    for index in range(await rows.count()):
        try:tx=await parse_row_for_code(rows.nth(index),headers,item['code'])
        except Exception as exc:
            logger.error('TRANSACTION ROW PARSE FAILED | code=%s | error=%s',item['code'],exc)
            raise
        if transaction_id_matches_invoice(tx.transaction_id,inv):parsed.append(tx)
    return parsed

async def _pi_first(body,group,settings,scan,headers,logger,date_value):
    """Discover evidence before any uniqueness/refund/duplicate/ECI decision.

    Scan every invoice, including invoices after a possible group stop. Dispute
    eligibility is still decided by the original sync rules when no PI exists.
    """
    records=[];pending=[];cache={}
    for item in group['items']:
        parsed=await _invoice_transactions(body,item,settings,scan,headers,logger)
        cache[item['row_no']]=parsed
        base=dict(row_no=item['row_no'],qt=item['qt'],code=item['code'],invoice_raw=item['invoice'],
            invoice_search=normalize_invoice_number(item['invoice']),tran_types=[tx.tran_type for tx in parsed],
            sale_selected=False,pi_source='VROL_TRANSACTION_TABLE',pi_input_excel=str(item.get('pi') or ''))
        pi_rows=[tx for tx in parsed if str(tx.pi or '').strip().casefold()=='yes']
        # Visa may flag both the authorization and its financial transaction.
        # Prefer PI-bearing Sale/Cash rows, without requiring uniqueness. Only
        # fall back to another PI row when no expected financial PI row exists.
        financial=[tx for tx in pi_rows if (str(tx.tran_type).strip().casefold()=='cash' if item['code']=='13.9'
                    else re.fullmatch(r'Sale(?:\s*-\s*WT)?',str(tx.tran_type).strip(),re.I))]
        pi_rows=list({tx.transaction_id:tx for tx in (financial or pi_rows)}.values())
        if not pi_rows:
            records.append(dict(base,pi_status='NOT_REQUIRED',scan_status='NOT_SELECTED_PI_GROUP'))
        for tx in pi_rows:
            records.append(dict(base,pi_input=str(tx.pi),pi_status='PENDING_USER_ACTION',
                scan_status='PI_DOWNLOAD_REVIEW_REQUIRED',transaction_id=tx.transaction_id,
                tran_type=tx.tran_type,assoc_dispute=str(tx.assoc_dispute or '').strip().upper(),
                planned_pre_issuer_action='View > Tran Details > Save as PDF'))
            pending.append((tx,item))
            logger.info('PI YES OVERRIDES EXCLUSION RULES | guid=%s | invoice=%s | transaction_id=%s | precedence=GUID_PI_FIRST',group['guid'],item['invoice'],tx.transaction_id)
    if not pending:return None,cache
    return dict(status='READY_FOR_PI_EVIDENCE_REVIEW',decision='READY_FOR_PI_EVIDENCE_REVIEW',
        issuer_action_required=False,issuer_action_clicked=False,selected_count=0,selected_transaction_ids=[],
        planned_review_action='View > Tran Details > Save as PDF',planned_issuer_action='Không áp dụng do PI = Yes',
        pi_pending_count=len(pending),invoice_results=records,date_value=date_value,
        _runtime_selected_txs=pending),cache

async def precheck_guid_group(page, context, group, settings, group_dir: Path, logger):
    group_dir.mkdir(parents=True, exist_ok=True)
    if not group.get('pan'):
        result = {'status': 'UNDEFINED_CASE', 'decision': 'MANUAL_REVIEW_REQUIRED', 'reason_code': 'GUID_PAN_MAPPING_NOT_FOUND', 'issuer_action_required': False, 'issuer_action_clicked': False, 'invoice_results': [{'row_no': x['row_no'], 'qt': x['qt'], 'code': x['code'], 'invoice_raw': x['invoice'], 'scan_status': 'NOT_SCANNED_MAPPING_MISSING', 'tran_types': [], 'sale_selected': False} for x in group['items']]}
        (group_dir / 'group_precheck.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        logger.warning('GUID GROUP MAPPING MISSING | guid=%s | rows=%s | review_required=true', group['guid'], [x['row_no'] for x in group['items']])
        return result
    if not group.get('start_date'):
        return {'status': 'UNDEFINED_CASE', 'reason_code': 'GROUP_START_DATE_MISSING', 'invoice_results': []}
    timings = settings.get('_timings', {}); t_inq = time.monotonic()
    body = await open_transaction_inquiry(page, settings)
    body = await fill_transaction_inquiry_pan(page, group['pan'], settings)
    body, date_value = await fill_transaction_inquiry_start_date(page, group['start_date'], settings)
    await click_transaction_inquiry_submit(page, settings)
    body = await wait_transaction_results(page, settings)
    timings['inquiry_s'] = round(time.monotonic() - t_inq, 2)
    no_match = await _no_matching_transaction_message(body)
    if no_match:
        result = _no_matching_result(group, no_match)
        logger.warning('ROL-897 NO MATCHING TRANSACTIONS | guid=%s | pan_bin6_last4=%s | start_date=%s | rows=%s | issuer_action_required=false', group['guid'], group.get('masked_pan'), group.get('start_date'), [x['row_no'] for x in group['items']])
        (group_dir / 'group_precheck.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        try:
            await page.screenshot(path=str(group_dir / 'rol_897_no_matching_transactions.png'), full_page=True)
        except Exception:
            pass
        try:
            (group_dir / 'rol_897_no_matching_transactions.html').write_text(await body.content(), encoding='utf-8')
        except Exception:
            pass
        return result
    invoice_results = []
    selected = []
    selected_txs = []
    stop = None
    scan = await _transaction_scan_strategy(body, settings, logger)
    headers = await schema_from_dom(body)
    (group_dir/'transaction_headers.json').write_text(json.dumps(headers,ensure_ascii=False,indent=2),encoding='utf-8')
    t_scan = time.monotonic()
    pi_result,scanned=await _pi_first(body,group,settings,scan,headers,logger,date_value)
    timings['scan_s'] = round(time.monotonic() - t_scan, 2); timings['scan_strategy'] = scan['strategy']; timings['reported_transactions'] = scan['reported_transactions']
    if pi_result:
        (group_dir/'group_precheck.json').write_text(json.dumps({k:v for k,v in pi_result.items() if not k.startswith('_runtime_')},ensure_ascii=False,indent=2),encoding='utf-8')
        try:await page.screenshot(path=str(group_dir/'group_precheck.png'),full_page=True)
        except Exception:pass
        return pi_result
    reported_text=await _transaction_result_text(body)
    if re.search(r'\b300\+\s+Transactions?\s+Found|first\s+300\s+matching\s+transactions',reported_text,re.I):
        return dict(status='MANUAL_REVIEW_REQUIRED',decision='MANUAL_REVIEW_REQUIRED',
                    reason_code='TRANSACTION_RESULTS_TRUNCATED_300_PLUS',
                    reason_detail='Trả user kiểm tra thủ công: VROL trả 300+ giao dịch; xử lý mở rộng để backlog.',
                    issuer_action_required=False,issuer_action_clicked=False,invoice_results=[],selected_count=0)
    result_rows = body.locator('table#results tbody > tr[data-action="summaryGridRow"]')
    total_result_rows = await result_rows.count()
    logger.info('TRANSACTION TABLE SCAN START | guid=%s | strategy=%s | reported_transactions=%s | dom_rows=%s | invoices=%s', group['guid'], scan['strategy'], scan['reported_transactions'], total_result_rows, len(group['items']))
    # PI discovery has already cached every invoice. Resolve all known group
    # vetoes before a preceding invoice can fail its Sale/Cash uniqueness check.
    # Assoc D is the explicit business marker when several vetoes coexist.
    vetoes=[(item,no_submit_rule(item['code'],scanned[item['row_no']])) for item in group['items']]
    vetoes=[(item,veto) for item,veto in vetoes if veto]
    vetoes.sort(key=lambda pair:pair[1]['reason_code']!='GROUP_CONTAINS_ASSOC_DISPUTE_D')
    ordered_items=[vetoes[0][0]] if vetoes else group['items']
    for position, item in enumerate(ordered_items, 1):
        settings['active_case_code'] = item['code']
        inv = normalize_invoice_number(item['invoice'])
        # Filtered locators can have been redrawn since PI discovery. Reacquire
        # only when selecting checkboxes, not to decide cached business vetoes.
        parsed = scanned[item['row_no']] if vetoes or scan['strategy']=='DIRECT_DOM' else await _invoice_transactions(body,item,settings,scan,headers,logger)
        logger.info('INVOICE MATCH | guid=%s | invoice=%s | matched_rows=%s | strategy=%s',group['guid'],item['invoice'],len(parsed),scan['strategy'])
        tran_types = [x.tran_type for x in parsed]
        record = {'row_no': item['row_no'], 'qt': item['qt'], 'code': item['code'], 'invoice_raw': item['invoice'], 'invoice_search': inv, 'pi_input_excel': str(item.get('pi') or ''), 'scan_status': 'SCANNED', 'tran_types': tran_types, 'assoc_disputes': sorted({x.assoc_dispute for x in parsed if x.assoc_dispute}), 'sale_selected': False}
        invoice_results.append(record)
        # PI for every invoice was already scanned above. A known non-submit
        # reason takes precedence over an otherwise ambiguous Sale/Cash count.
        veto=no_submit_rule(item['code'],parsed)
        if veto:
            record.update(scan_status=veto['scan_status'],cb_reject=veto['cb_reject'],pi_status='NOT_REQUIRED')
            if 'trigger_moto_eci' in veto:record['moto_eci']=veto['trigger_moto_eci']
            if 'trigger_assoc_dispute' in veto:record['assoc_dispute']=veto['trigger_assoc_dispute']
            stop={key:value for key,value in veto.items() if key!='scan_status'}
            stop.update(trigger_invoice=item['invoice'],trigger_invoice_search=inv)
            logger.info('GUID NON-SUBMIT RULE | guid=%s | code=%s | invoice=%s | reason=%s | label=%s',group['guid'],item['code'],item['invoice'],veto['reason_code'],veto['cb_reject'])
            break
        expected = 'Cash' if item['code'] == '13.9' else 'Sale'
        if expected == 'Sale':
            sale_family = [x for x in parsed if re.match('^Sale(?:\\s*-\\s*WT)?$', str(x.tran_type or '').strip(), re.I)]
        else:
            sale_family = [x for x in parsed if str(x.tran_type or '').strip().casefold() == 'cash']
        eligible = sale_family
        if not eligible:
            record.update(scan_status='NO_MATCHING_FINANCIAL_TRANSACTION',pi_status='NOT_REQUIRED')
            stop=dict(reason_code='NO_MATCHING_'+expected.upper()+'_TRANSACTION',cb_reject='Không có Tran Type = '+expected,
                      trigger_invoice=item['invoice'],trigger_invoice_search=inv)
            break
        if len(eligible) != 1:
            record['scan_status'] = 'UNDEFINED'
            record['reason_code'] = f'{expected.upper()}_ROW_NOT_UNIQUE:{len(eligible)}'
            return {'status': 'UNDEFINED_CASE', 'reason_code': 'ELIGIBLE_ROW_NOT_UNIQUE', 'invoice_results': invoice_results, 'selected_count': len(selected), 'date_value': date_value}
        tx = eligible[0]
        pi_value = str(tx.pi or '').strip()
        record['pi_input'] = pi_value
        record['pi_source'] = 'VROL_TRANSACTION_TABLE'
        if pi_value.casefold() == 'yes':
            record['pi_status'] = 'PENDING_USER_ACTION'
            record['scan_status'] = 'PI_DOWNLOAD_REVIEW_REQUIRED'
            record['planned_pre_issuer_action'] = 'View > Tran Details > Save as PDF'
            record['transaction_id'] = tx.transaction_id
            record['assoc_dispute'] = str(tx.assoc_dispute or '').strip().upper()
            selected_txs.append((tx, item))
            logger.info('PI YES OVERRIDES EXCLUSION RULES | guid=%s | invoice=%s | code=%s | transaction_id=%s | precedence=PI_FIRST', group['guid'], item['invoice'], item['code'], tx.transaction_id)
            continue
        record['pi_status'] = 'NOT_REQUIRED'
        assoc = str(tx.assoc_dispute or '').strip().upper()
        record['assoc_dispute'] = assoc
        if assoc not in {'', 'D'}:
            record['scan_status'] = 'UNDEFINED_ASSOC_DISPUTE_VALUE'
            return {'status': 'UNDEFINED_CASE', 'decision': 'MANUAL_REVIEW_REQUIRED', 'reason_code': 'UNDEFINED_ASSOC_DISPUTE_VALUE', 'reason_detail': 'Unexpected Assoc Dispute value: ' + assoc, 'issuer_action_required': False, 'issuer_action_clicked': False, 'invoice_results': invoice_results}
        if item['code'] == '10.4':
            moto_eci = str(tx.moto_eci or '').strip()
            record['moto_eci'] = moto_eci
        cb = tx.locator.get_by_role('checkbox').first
        if not await cb.count():
            return {'status': 'UNDEFINED_CASE', 'reason_code': 'TRANSACTION_CHECKBOX_NOT_FOUND', 'invoice_results': invoice_results}
        await cb.check()
        record['sale_selected'] = True
        record['transaction_id'] = tx.transaction_id
        selected.append(tx.transaction_id)
        selected_txs.append((tx, item))
        current_checked = bool(await cb.is_checked())
        if not current_checked:
            return {'status': 'UNDEFINED_CASE', 'reason_code': 'CURRENT_SALE_SELECTION_FAILED', 'invoice_results': invoice_results, 'expected_selected': len(selected), 'selected_transaction_ids': selected}
        logger.info('SALE SELECTION RECORDED | guid=%s | invoice=%s | selected_transaction_id=%s | cumulative_selected=%s/%s | selected_transaction_ids=%s', group['guid'], item['invoice'], tx.transaction_id, len(selected), len(group['items']), selected)
    if stop:
        scanned_rows = {x['row_no'] for x in invoice_results}
        for item in group['items']:
            if item['row_no'] not in scanned_rows:
                invoice_results.append({'row_no': item['row_no'], 'qt': item['qt'], 'code': item['code'], 'invoice_raw': item['invoice'], 'scan_status': 'NOT_SCANNED_AFTER_GROUP_STOP', 'tran_types': [], 'sale_selected': False})
        result = {'status': 'NO_CHARGEBACK_REQUIRED', 'decision': 'NO_CHARGEBACK_REQUIRED', 'issuer_action_required': False, 'issuer_action_clicked':False, 'selected_count_before_stop': len(selected), 'selected_transaction_ids': selected, 'invoice_results': invoice_results, **stop}
        if stop.get('reason_code') == 'GROUP_CONTAINS_ASSOC_DISPUTE_D':
            result['reason_detail'] = stop['cb_reject']+' | Invoice '+str(stop.get('trigger_invoice',''))
        elif stop.get('cb_reject'):
            result['reason_detail'] = 'Không tiếp tục toàn bộ cụm GUID: ' + stop['cb_reject']
            if stop.get('reason_code')=='GROUP_REJECT_MOTO_ECI':result['reason_detail']+=' | ECI thực tế: '+(stop.get('trigger_moto_eci') or 'blank')
        else:
            result['reason_detail'] = 'Không tiếp tục toàn bộ cụm GUID do Invoice ' + str(stop.get('trigger_invoice', '')) + ' có Tran Type ' + str(stop.get('trigger_tran_type', ''))
    else:
        status = 'READY_FOR_MULTI_ISSUER_ACTION_REVIEW' if len(selected) > 1 else 'READY_FOR_ISSUER_ACTION_REVIEW'
        codes = sorted({x['code'] for x in group['items']})
        planned = 'Issuer Action > Chargeback/Dispute > Fraud' if codes == ['10.4'] else 'Issuer Action > Chargeback/Dispute > Consumer' if codes in [['13.1'], ['13.9']] else 'UNDEFINED_MIXED_CODE_ISSUER_ACTION'
        pi_pending = [x for x in invoice_results if x.get('pi_status') == 'PENDING_USER_ACTION']
        if pi_pending:
            status = 'READY_FOR_PI_EVIDENCE_REVIEW'
            result = {'status': status, 'decision': status, 'issuer_action_required': False, 'issuer_action_clicked': False, 'planned_review_action': 'View > Tran Details > Save as PDF', 'planned_issuer_action': 'Không áp dụng do PI = Yes', 'pi_pending_count': len(pi_pending), 'selected_count': len(selected), 'selected_transaction_ids': selected, 'invoice_results': invoice_results, 'date_value': date_value}
        else:
            result = {'status': status, 'decision': status, 'issuer_action_required': True, 'issuer_action_clicked': False, 'planned_issuer_action': planned, 'selected_count': len(selected), 'selected_transaction_ids': selected, 'invoice_results': invoice_results, 'date_value': date_value}
    (group_dir / 'group_precheck.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    if not stop:
        result['_runtime_selected_txs'] = selected_txs
        if selected_txs:
            result['_runtime_tx'] = selected_txs[0][0]
            result['_runtime_item'] = selected_txs[0][1]
    try:
        await page.screenshot(path=str(group_dir / 'group_precheck.png'), full_page=True)
    except Exception:
        pass
    return result
