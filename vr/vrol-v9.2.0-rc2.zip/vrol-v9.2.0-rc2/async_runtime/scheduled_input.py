"""Wait for today's immutable RPA Ops contract without starting a browser."""
import asyncio,json,time
from datetime import datetime,time as day_time,timedelta,timezone
from pathlib import Path
from .input_contract import validate_contract

VIETNAM=timezone(timedelta(hours=7))

def select_contract(directory,not_before='19:30',*,now=None):
    now=now or datetime.now(VIETNAM)
    hour,minute=map(int,not_before.split(':'))
    cutoff=datetime.combine(now.date(),day_time(hour,minute),VIETNAM)
    candidates=[]
    for path in Path(directory).glob('*/manifest.json'):
        if path.parent.name.startswith('.'):continue
        try:data=json.loads(path.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):continue # An atomic publisher does not expose incomplete manifests.
        if data.get('status')!='READY' or data.get('business_date')!=now.date().isoformat():continue
        dates=[]
        for key in ('source_fc_completed_at','source_guid2pan_completed_at'):
            value=data.get(key)
            if not value:break
            try:
                date=datetime.fromisoformat(value.replace('Z','+00:00'))
                dates.append(date.replace(tzinfo=VIETNAM) if date.tzinfo is None else date.astimezone(VIETNAM))
            except ValueError:break
        if len(dates)!=2 or min(dates)<cutoff or max(dates)>now:continue
        candidates.append((max(dates),str(path),path))
    if not candidates:raise ValueError('WAITING_TODAY_READY_FC_GUID2PAN_AFTER_'+not_before)
    # Validate the newest eligible pair; never silently fall back to an older
    # bundle if that pair is corrupt or its snapshot changed.
    path=max(candidates)[2];validate_contract(path)
    return path.resolve()

async def wait_for_contract(settings,root,monitor,log):
    directory=Path(str(settings.get('scheduled_contract_dir') or 'runtime/ops_inputs'))
    if not directory.is_absolute():directory=Path(root)/directory
    cutoff=str(settings.get('scheduled_source_not_before') or '19:30')
    timeout=float(settings.get('scheduled_input_wait_seconds') or 1800)
    poll=float(settings.get('scheduled_input_poll_seconds') or 10)
    if timeout<=0 or poll<=0:raise ValueError('SCHEDULED_WAIT_AND_POLL_MUST_BE_POSITIVE')
    deadline=time.monotonic()+timeout;previous=None
    while True:
        try:
            path=await asyncio.to_thread(select_contract,directory,cutoff)
            log('success',f'INPUT CONTRACT READY | manifest={path}')
            return path
        except (OSError,ValueError,KeyError) as exc:
            reason=str(exc)
            monitor.update(stage='WAITING_INPUT',input_wait_reason=reason,contract_directory=str(directory))
            if reason!=previous:log('warning',f'WAITING INPUT CONTRACT | {reason}');previous=reason
            remaining=deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('SCHEDULED_INPUT_TIMEOUT:'+reason) from exc
            await asyncio.sleep(min(poll,remaining))
