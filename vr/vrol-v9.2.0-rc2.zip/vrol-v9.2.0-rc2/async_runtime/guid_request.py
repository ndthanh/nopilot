"""GUID-only requests bind to one immutable input pair; never override CODE CB."""
import csv,json,re
from pathlib import Path
from .input_contract import digest

def load_request(path,contract_path):
    data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    allowed={'schema','request_id','requested_at','input_contract','manifest_sha256','guids'}
    if set(data)!=allowed or data.get('schema')!='vrol-guid-request/1' or not isinstance(data.get('request_id'),str) or not data['request_id']:
        raise ValueError('GUID_REQUEST_SCHEMA_INVALID')
    if Path(data['input_contract']).resolve()!=Path(contract_path).resolve() or data.get('manifest_sha256')!=digest(contract_path):
        raise ValueError('GUID_REQUEST_INPUT_CONTRACT_CHANGED')
    guids=data.get('guids')
    if not isinstance(guids,list) or not guids or len(guids)>2000 or any(not isinstance(g,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',g) for g in guids):
        raise ValueError('GUID_REQUEST_GUID_LIST_INVALID')
    data['guids']=sorted({g.upper() for g in guids})
    return data

def build_report(folder):
    folder=Path(folder);source=folder/'guid_request.json'
    if not source.exists():source=folder/'am_force_request.json'
    if not source.exists():return
    name='am_force_report' if source.name=='am_force_request.json' else 'requested_guid_report'
    request=json.loads(source.read_text(encoding='utf-8'))
    def read(path,default):
        try:return json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError):return default
    queue={x['guid']:x for x in read(folder/'queue_manifest.json',[])}
    exclusions=read(folder/'input_exclusions.json',[]);state=read(folder/'run_state.json',{});sources=read(folder/'requested_guid_source.json',{})
    results={}
    for path in (folder/'groups').glob('*/guid_result.json'):
        data=read(path,{})
        if data.get('guid'):results[data['guid']]=data
    rows=[]
    for guid in request['guids']:
        result=results.get(guid,{});nested=result.get('result') or {};queued=queue.get(guid,{})
        skipped=sorted({x['reason'] for x in exclusions if x['guid']==guid})
        status=result.get('status') or ('SKIPPED' if skipped and not queued else ('NOT_PROCESSED' if queued else 'NOT_STARTED'))
        rows.append(dict(guid=guid,status=status,reason_code=result.get('reason_code') or ' | '.join(skipped) or state.get('error',''),
            codes=','.join(queued.get('codes') or sources.get(guid,{}).get('codes',[])),upstream_filter_overridden=bool(queued.get('upstream_filter_overridden')),
            excluded_rows=' | '.join(skipped),rol=nested.get('rol') or nested.get('vrol_case_number',''),
            pi_downloaded=sum(x.get('pi_status')=='DOWNLOADED' for x in nested.get('invoice_results',[])),
            final_submit_clicked=bool(nested.get('final_submit_clicked')),folder=result.get('folder','')))
    report=dict(request_id=request['request_id'],input_contract=request['input_contract'],requested_count=len(rows),
                completed_count=len(results),skipped_count=sum(x['status']=='SKIPPED' for x in rows),rows=rows)
    (folder/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with (folder/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]) if rows else ['guid','status']);writer.writeheader();writer.writerows(rows)
    return report
