import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from .popup_registry import PopupRegistry

class SharedSessionExpired(RuntimeError): pass
@dataclass
class SessionSnapshot:
    generation:int
    context:object
    portal:object

class SharedSessionManager:
    """Quiesce active cases before replacing a persistent profile; one relogin per generation."""
    def __init__(self,login_factory):
        self._login_factory=login_factory;self._lock=asyncio.Lock();self._gate=asyncio.Lock();self.tab_lock=asyncio.Lock()
        self._ready=asyncio.Event();self._drained=asyncio.Event();self._drained.set()
        self._generation=0;self._active=0;self._context=None;self._portal=None;self._pw=None;self._error=None;self.registry=None
        self.restart_after=100;self._issued=0
    async def start(self):
        await self._replace_session();self._ready.set();return self.snapshot()
    def snapshot(self):return SessionSnapshot(self._generation,self._context,self._portal)
    async def ensure_current(self,seen_generation):
        await self._ready.wait()
        if self._error:raise RuntimeError('SHARED_SESSION_RELOGIN_FAILED') from self._error
        return self.snapshot()
    @asynccontextmanager
    async def lease(self):
        while True:
            await self._ready.wait()
            if self.restart_after and self._issued>=self.restart_after:
                await self.relogin_once(self._generation)
                continue
            async with self._gate:
                if not self._ready.is_set():continue
                if self._error:raise RuntimeError('SHARED_SESSION_RELOGIN_FAILED') from self._error
                if self.restart_after and self._issued>=self.restart_after:continue
                self._active+=1;self._issued+=1;self._drained.clear();snapshot=self.snapshot();break
        try:yield snapshot
        finally:
            async with self._gate:
                self._active-=1
                if self._active==0:self._drained.set()
    async def relogin_once(self,failed_generation):
        async with self._lock:
            if failed_generation!=self._generation:return self.snapshot()
            self._ready.clear()
            try:
                print('SESSION RESTART | drain active workers before closing bot Chrome',flush=True)
                await self._drained.wait()
                await self._replace_session();self._error=None
                return self.snapshot()
            except BaseException as exc:
                self._error=exc;raise
            finally:self._ready.set()
    async def _replace_session(self):
        # Close the old context/profile before launching its replacement.
        await self._close_resources()
        self._pw,self._context,self._portal=await self._login_factory()
        self.registry=PopupRegistry(self._context);self._generation+=1;self._issued=0
        print(f'SESSION READY | generation={self._generation} | restart_after={self.restart_after}',flush=True)
    async def _close_resources(self):
        if self.registry:
            await self.registry.close();self.registry=None
        if self._context:
            try:await asyncio.wait_for(self._context.close(),20)
            except Exception:pass
            self._context=None
        if self._pw:
            try:await asyncio.wait_for(self._pw.stop(),10)
            except Exception:pass
            self._pw=None
    async def close(self):await self._close_resources()

async def is_session_expired(page):
    if page.is_closed():return False
    for frame in page.frames:
        url=frame.url.lower()
        if '/login/' in url or '/mfa/' in url:return True
        try:
            loc=frame.locator('#external-login-username,input[name="oneTimePassword"],#Email').first
            if await loc.count() and await loc.is_visible():return True
        except Exception:pass
    return False
