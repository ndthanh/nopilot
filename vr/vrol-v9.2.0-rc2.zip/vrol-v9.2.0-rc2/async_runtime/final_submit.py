"""Prepared production submit path. Disabled unless config explicitly enables it."""
import asyncio, re, time
from pathlib import Path
from .config import truth
from .window_layout import maximize_window,wait_layout
from .questionnaire_submit import visible_submit,probe_submit

async def maximize(page,log):
    return await maximize_window(page,log,label='QUESTIONNAIRE')

async def prepare_questionnaire(page,scope,log,*,maximize_window=True):
    window=await maximize(page,log) if maximize_window else None
    if scope is not page.main_frame:
        element=await scope.frame_element()
        await element.evaluate('el=>{el.style.width="100%";el.style.boxSizing="border-box";}')
    content=await wait_layout(scope)
    log.info('QUESTIONNAIRE PREPARED BEFORE FILL | window=%s | content=%s',window,content)
    return dict(window=window,content=content)

async def capture_questionnaire(page,scope,path,log,*,maximize_window=True):
    if maximize_window:await maximize(page,log)
    if scope is not page.main_frame:
        element=await scope.frame_element()
        await element.evaluate('el=>{el.style.width="100%";el.style.boxSizing="border-box";}')
        height=await scope.evaluate('Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)')
        await element.evaluate('(el,h)=>{el.style.height=h+"px";el.style.minHeight=h+"px"}',height)
    geometry=await wait_layout(page)
    await wait_layout(scope)
    await page.screenshot(path=str(path),full_page=True)
    return geometry

async def final_submit(root,page,scope,registry,settings,folder,log,*,verify_identity=None):
    if not truth(settings.get('allow_final_submit','NO')) or settings.get('_pre_submit_only'):
        raise RuntimeError('FINAL_SUBMIT_DISABLED')
    registry.assert_owned(root,page)
    submit=visible_submit(scope).first
    # Only the exact live questionnaire control may send the dispute.
    await submit.wait_for(state='visible',timeout=int(settings.get('final_submit_reacquire_timeout_ms') or 15000))
    probe=await probe_submit(scope)
    if not probe['dispatch_ready']:raise RuntimeError('FINAL_SUBMIT_CONTROL_NOT_UNIQUE_OR_ENABLED')
    await submit.click(trial=True)
    folder=Path(folder)
    await page.screenshot(path=str(folder/'06_before_final_submit.png'),full_page=True)
    # Layout checks and the evidence capture await browser work. Validate again
    # at the dispatch boundary if the document changed during those awaits.
    if verify_identity is not None:await verify_identity()
    registry.assert_owned(root,page)
    if not (await probe_submit(scope))['dispatch_ready']:raise RuntimeError('FINAL_SUBMIT_CONTROL_CHANGED_BEFORE_DISPATCH')
    from .native_case import checkpoint
    checkpoint(folder,'FINAL_SUBMIT_DISPATCHING',final_submit_clicked=False)
    await visible_submit(scope).first.click(timeout=int(settings.get('action_timeout_ms') or 20000),no_wait_after=True)
    checkpoint(folder,'FINAL_SUBMIT_DISPATCHED',final_submit_clicked=True)
    log.warning('FINAL SUBMIT DISPATCHED | explicitly_enabled_in_config=true')
    deadline=time.monotonic()+int(settings.get('final_submit_outcome_timeout_ms') or 30000)/1000
    while time.monotonic()<deadline:
        for candidate in registry.pages(root):
            for frame in candidate.frames:
                try:
                    text=await frame.locator('body').inner_text(timeout=400)
                    outcome='';status='';detail=''
                    if re.search(r'Reject Details|Edits\s*-\s*Dispute Rejected',text,re.I):
                        outcome='VISA_REJECT_DETAILS';status='FINAL_SUBMIT_REJECTED';detail=' '.join(text.split())[:2000]
                    else:
                        errors=frame.locator('[vcr-display-error] [ng-bind-html="currentError.message"], [role="alert"] .ng-binding').first
                        if await errors.count() and await errors.is_visible():
                            detail=' '.join((await errors.inner_text()).split())
                            if detail:outcome='VROL_FORM_ERROR';status='FINAL_SUBMIT_FORM_ERROR'
                        if not outcome and re.search(r'Case Confirmation|Dispute Submitted|submitted successfully',text,re.I):
                            outcome='CONFIRMATION';status='FINAL_SUBMIT_COMPLETED'
                    if outcome:
                        # Confirmation text may precede a slow Angular render.
                        await candidate.wait_for_load_state('domcontentloaded',timeout=5000)
                        await wait_layout(frame,timeout_ms=5000)
                        busy=frame.locator('[aria-busy="true"]:visible,.loading-spinner:visible')
                        if await busy.count():continue
                        text2=await frame.locator('body').inner_text(timeout=1000)
                        await asyncio.sleep(.3)
                        if text2!=await frame.locator('body').inner_text(timeout=1000):continue
                        # Restart classification if the result changed while it
                        # was settling (e.g. confirmation replaced by rejection).
                        if text2!=text:continue
                        path=folder/'07_final_submit_result.png'
                        await candidate.screenshot(path=str(path),full_page=True)
                        checkpoint(folder,status,final_submit_clicked=True,outcome=outcome)
                        return dict(status=status,decision=status,reason_code=outcome,reason_detail=detail,
                            final_submit_clicked=True,final_submit_outcome=outcome,final_submit_screenshot=str(path),
                            cb_reject=detail if outcome=='VISA_REJECT_DETAILS' else '')
                except Exception:continue
        await asyncio.sleep(.2)
    shots=[]
    for index,candidate in enumerate(registry.pages(root),1):
        path=folder/f'07_final_submit_outcome_unknown_{index:02d}.png'
        try:await candidate.screenshot(path=str(path),full_page=True);shots.append(str(path))
        except Exception:pass
    checkpoint(folder,'FINAL_SUBMIT_RECONCILIATION_REQUIRED',final_submit_clicked=True)
    return dict(status='FINAL_SUBMIT_RECONCILIATION_REQUIRED',decision='FINAL_SUBMIT_RECONCILIATION_REQUIRED',
        reason_code='FINAL_SUBMIT_OUTCOME_NOT_CONFIRMED',final_submit_clicked=True,rol500_reconciliation_required=True,
        reason_detail='Submit dispatched; result not confirmed. Do not resend without reconciliation.',final_submit_screenshots=shots)
