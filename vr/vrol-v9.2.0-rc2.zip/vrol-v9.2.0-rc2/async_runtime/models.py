from dataclasses import dataclass,field
import time
from pathlib import Path
from typing import Any
@dataclass
class GuidGroup:
    guid:str; masked_pan:str; full_pan:str; dates:list[str]; items:list[dict]; source_rows:list[int]
    deferred_rows:list[int]=field(default_factory=list)
    @property
    def start_date(self):
        return min(self.dates) if self.dates else ''
@dataclass
class WorkerState:
    worker_id:str; page:Any; current:GuidGroup|None=None; case_page:Any=None; stage:str='IDLE'; artifact_dir:Path|None=None; settings:dict=field(default_factory=dict)
    registry:Any=None
    session:Any=None
    generation:int=0
@dataclass
class RuntimeEvent:
    event:str; worker_id:str=''; guid:str=''; status:str=''; reason_code:str=''; detail:str=''; action:str=''; data:dict=field(default_factory=dict)
    created_at:float=field(default_factory=time.time)
