"""Full v9.0.60 decision/case-creation bridge for the async shared browser.

Each async worker owns one VROL tab. The battle-tested v9.0.60 sync decision engine
attaches to that same persistent Chromium session over localhost CDP, resolves the
worker tab by window.name, and runs the complete precheck/PI/Issuer Action/Case
Creation/questionnaire path. Final Submit remains disabled.
"""
from pathlib import Path
from threading import Lock
from playwright.sync_api import sync_playwright
from src.review.guid_group import precheck_guid_group,download_pi_document
from src.vrol.workflow import open_case_and_prepare,fill_test_questionnaire

# Shared-session popup operations must be serialized. PI Details, Save as PDF,
# Issuer Action and Case Creation all create pages in the same BrowserContext.
_VROL_POPUP_LOCK=Lock()
_ISSUER_LOCK=_VROL_POPUP_LOCK
_PI_LOCK=_VROL_POPUP_LOCK

class BridgeLogger:
 def __init__(self,emit,worker):self.emit=emit;self.worker=worker
 def _x(self,level,msg,*args):
  try:text=msg%args if args else str(msg)
  except Exception:text=f'{msg} {args}'
  self.emit(level,f'{self.worker} SYNC-PARITY | {text}')
 def info(self,m,*a):self._x('info',m,*a)
 def warning(self,m,*a):self._x('warning',m,*a)
 warn=warning
 def error(self,m,*a):self._x('error',m,*a)
 def exception(self,m,*a):self._x('error',m,*a)
 def debug(self,m,*a):self._x('info',m,*a)

def _group_dict(group):
 return {'guid':group.guid,'masked_pan':group.masked_pan,'pan':group.full_pan,
         'full_pan':group.full_pan,'start_date':group.start_date,
         'items':[dict(x) for x in group.items]}

def _find_worker_page(browser,marker):
 for context in browser.contexts:
  for page in context.pages:
   try:
    if page.evaluate('() => window.name')==marker:return context,page
   except Exception:pass
 raise RuntimeError(f'SYNC_PARITY_WORKER_PAGE_NOT_FOUND:{marker}')

def run_full_group(cdp_url,marker,group,settings,artifact_dir,emit,worker_id):
 logger=BridgeLogger(emit,worker_id);folder=Path(artifact_dir);folder.mkdir(parents=True,exist_ok=True)
 settings=dict(settings);settings['allow_final_submit']='NO';settings['validate_dispute_amount']='NO';settings['batch_test_case_evidence_dir']=str(folder)
 g=_group_dict(group)
 with sync_playwright() as pw:
  browser=pw.chromium.connect_over_cdp(cdp_url)
  context,page=_find_worker_page(browser,marker)
  pages_before={id(p) for p in context.pages}
  try:
   result=precheck_guid_group(page,context,g,settings,folder,logger)
   status=result.get('status','')
   if status in {'READY_FOR_PI_EVIDENCE_REVIEW','PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED'}:
    failures=[]
    pending={x.get('row_no') for x in result.get('invoice_results',[]) if str(x.get('pi_input','')).strip().casefold()=='yes' and x.get('pi_status')!='DOWNLOADED'}
    logger.info('PI POPUP LOCK WAIT | guid=%s | pending_invoices=%s',g['guid'],len(pending))
    with _PI_LOCK:
     logger.info('PI POPUP LOCK ACQUIRED | guid=%s | pending_invoices=%s',g['guid'],len(pending))
     for tx,item in (result.get('_runtime_selected_txs') or []):
      if item.get('row_no') not in pending:continue
      try:
       logger.info('PI INVOICE DOWNLOAD START | guid=%s | invoice=%s',g['guid'],item.get('invoice'))
       ev=download_pi_document(page,context,tx,item,g,folder,settings,logger)
       logger.info('PI INVOICE DOWNLOAD COMPLETE | guid=%s | invoice=%s | path=%s | bytes=%s',g['guid'],item.get('invoice'),ev.get('path'),ev.get('bytes'))
       for inv in result.get('invoice_results',[]):
        if inv.get('row_no')==item.get('row_no'):inv.update(pi_status='DOWNLOADED',pi_file=ev.get('file_name'),pi_path=ev.get('path'),pi_central_path=ev.get('central_path'))
      except Exception as exc:failures.append(f'{item.get("invoice")}:{exc}')
     logger.info('PI POPUP LOCK RELEASE | guid=%s | failures=%s',g['guid'],len(failures))
    if failures:result.update(status='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',decision='PI_EVIDENCE_DOWNLOAD_RETRY_REQUIRED',reason_code='PI_DOWNLOAD_FAILED',reason_detail=' | '.join(failures))
    else:result.update(status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',decision='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',reason_code='PI_EVIDENCE_DOWNLOADED',issuer_action_required=False)
   elif status in {'READY_FOR_ISSUER_ACTION_REVIEW','READY_FOR_MULTI_ISSUER_ACTION_REVIEW'}:
    if not result.get('_runtime_tx') or not result.get('_runtime_item'):
     result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='NO_SELECTED_TRANSACTION_FOR_ISSUER_ACTION')
    elif str(result.get('planned_issuer_action','')).startswith('UNDEFINED'):
     result.update(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES')
    else:
     with _ISSUER_LOCK:
      item=result['_runtime_item'];tx=result['_runtime_tx'];settings['active_case_code']=item['code'];settings['active_selected_transaction_count']=result.get('selected_count',1)
      case_result=open_case_and_prepare(page,tx,item['code'],item,settings,folder/'downloads')
      if not case_result.get('ready') or case_result.get('scope') is None:raise RuntimeError(case_result.get('workflow_error') or 'OPEN_CASE_NOT_READY')
      logger.info('QUESTIONNAIRE FILL START | guid=%s | code=%s | rol=%s',g['guid'],item['code'],case_result.get('rol'))
      filled=fill_test_questionnaire(case_result['scope'],item['code'],settings,item)
      logger.info('QUESTIONNAIRE FILL COMPLETE | guid=%s | code=%s | fields=%s | final_submit_clicked=false',g['guid'],item['code'],len(filled.get('fields',[])) if isinstance(filled,dict) else 'NA')
      case_result['page'].screenshot(path=str(folder/'04_questionnaire_filled_final_submit_not_clicked.png'),full_page=True)
      result.update(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',decision='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',reason_code='CASE_CREATED_QUESTIONNAIRE_FILLED',issuer_action_clicked=True,rol=case_result.get('rol'),questionnaire=filled,final_submit_clicked=False)
   try:page.screenshot(path=str(folder/f'{result.get("status","RESULT")}.png'),full_page=True)
   except Exception:pass
   # Runtime Playwright objects cannot cross the bridge boundary.
   return {k:v for k,v in result.items() if not k.startswith('_runtime_')}
  finally:
   # Close only pages owned by this worker. Never close another worker's PI/case popup.
   for extra in list(context.pages):
    try:
     if id(extra) in pages_before or extra is page or extra.is_closed():continue
     opener=extra.opener()
     if opener is page:
      logger.info('WORKER-OWNED POPUP CLEANUP | guid=%s | url=%s',g['guid'],extra.url)
      extra.close()
     else:
      logger.info('FOREIGN POPUP PRESERVED | guid=%s | url=%s',g['guid'],extra.url)
    except Exception as cleanup_exc:
     logger.warning('POPUP OWNERSHIP CLEANUP PROBE FAILED | guid=%s | error=%s',g['guid'],cleanup_exc)
   # Do not close the browser from a CDP attachment: it terminates the shared Chromium.
   # Leaving sync_playwright disconnects this client while the async browser remains alive.
