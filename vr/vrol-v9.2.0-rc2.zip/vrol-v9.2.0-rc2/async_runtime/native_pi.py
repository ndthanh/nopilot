import asyncio, json, re, time, uuid
from pathlib import Path
from .native_table import reacquire_transaction
from .pi_artifacts import contains_transaction,primary_transaction,publish_pi

async def _details_identity(page,transaction_id):
    try:
        for frame in page.frames:
            text=await frame.locator('body').inner_text(timeout=500)
            primary=primary_transaction(text)
            if contains_transaction(primary or text,transaction_id):return True
    except Exception:pass
    return False

async def _details_menu(page):
    for scope in page.frames:
        label=scope.locator('span#tranTxt').filter(visible=True).first
        if await label.count():return label
        candidate=scope.get_by_role('menuitem',name=re.compile(r'^Tran Details$',re.I),exact=True).filter(visible=True).first
        if await candidate.count():return candidate
    return None

async def wait_for_pi_spinner(detail,settings):
    timeout=int(settings.get('pi_spinner_hidden_timeout_ms') or 45000)/1000;deadline=time.monotonic()+timeout;stable=0
    while time.monotonic()<deadline:
        displays=[]
        for frame in detail.frames:
            displays.extend(await frame.locator('img#piSpinner').evaluate_all('els=>els.map(el=>getComputedStyle(el).display)'))
        ready=bool(displays) and all(value=='none' for value in displays)
        stable=stable+1 if ready else 0
        if stable>=int(settings.get('pi_spinner_hidden_stable_polls') or 3):return
        await asyncio.sleep(int(settings.get('pi_spinner_hidden_poll_ms') or 200)/1000)
    raise RuntimeError('PI_SPINNER_NOT_HIDDEN_BEFORE_SAVE_AS_PDF')

async def download_pi(page,registry,tx,item,group,settings,folder,log):
    for attempt in range(2):
        try:
            attempt_settings=dict(settings)
            if attempt:attempt_settings['pi_download_timeout_ms']=max(60000,int(settings.get('pi_download_timeout_ms') or 30000))
            return await _download_pi_once(page,registry,tx,item,group,attempt_settings,folder,log)
        except Exception:
            if attempt or page.is_closed():raise
            log.warning('PI READ-ONLY RETRY 1/1 | invoice=%s | reopen owned details; verify transaction again',item['invoice'])
            await registry.cleanup(page)

async def _download_pi_once(page,registry,tx,item,group,settings,folder,log):
    # Clear the preceding invoice while its row is still rendered, before redraw.
    previous=page.frame(name='bodyframe')
    if previous:
        for cb in await previous.locator('table#results input[type="checkbox"]:checked').all():
            await cb.uncheck(force=True)
    tx=await reacquire_transaction(page,tx,item,settings)
    # PI is a single-transaction View action. Remove previous invoice selections first.
    frame=page.frame(name='bodyframe')
    checked=frame.locator('table#results input[type="checkbox"]:checked')
    for cb in await checked.all():await cb.uncheck(force=True)
    checkbox=tx.locator.get_by_role('checkbox').first
    await checkbox.check(force=True)
    button_frame=page.frame(name='buttons')
    if button_frame is None:raise RuntimeError('PI_BUTTONS_IFRAME_NOT_FOUND')
    view=button_frame.locator('button#view[data-action="showViewMenu"]')
    await view.wait_for(state='visible',timeout=10000)
    # Legacy dropdowns react to focus/mouse movement in another Chrome window.
    # Dispatch to the exact DOM control without moving the shared desktop mouse.
    menu=await _details_menu(page)
    if menu is None:await view.evaluate('el => el.click()')
    deadline=time.monotonic()+int(settings.get('pi_view_menu_timeout_ms') or 10000)/1000
    while time.monotonic()<deadline and menu is None:
        menu=await _details_menu(page)
        if menu is None:await asyncio.sleep(.1)
    if menu is None:raise RuntimeError('PI_TRAN_DETAILS_MENU_NOT_FOUND')
    contract=await menu.evaluate('el=>({target:el.outerHTML,parent:el.parentElement.outerHTML})')
    (Path(folder)/f'pi_menu_contract_{item.get("row_no",item["invoice"])}.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
    log.info('PI OPEN DETAILS | invoice=%s | transaction_id=%s',item['invoice'],tx.transaction_id)
    declared=await menu.evaluate('el=>el.closest("a[data-js]")?.getAttribute("data-js") || ""')
    if declared=='top.bodyframe.viewDetails()':
        # Invoke only this confirmed application's handler in its own frame.
        # Its delegated dropdown click may be dropped when another window gains
        # focus; the handler still performs Visa's original selection validation.
        await menu.evaluate('() => { window.top.frames["bodyframe"].viewDetails(); }')
    else:
        for event in ('mousedown','mouseup','click'):
            await menu.dispatch_event(event,{'button':0,'buttons':1 if event=='mousedown' else 0})
    detail=None;deadline=time.monotonic()+int(settings.get('pi_popup_timeout_ms') or 20000)/1000
    while time.monotonic()<deadline:
        for candidate in registry.pages(page):
            if candidate is page:continue
            if await _details_identity(candidate,tx.transaction_id):
                has_pdf=any([await f.locator('button#pdfButton[data-action="saveAsPDF"]').count() for f in candidate.frames])
                if has_pdf:detail=candidate;break
        if detail:break
        await asyncio.sleep(.15)
    if detail is None:raise RuntimeError('PI_OWNED_POPUP_TRANSACTION_ID_NOT_CONFIRMED')
    registry.assert_owned(page,detail)
    await wait_for_pi_spinner(detail,settings)
    if not await _details_identity(detail,tx.transaction_id):raise RuntimeError('PI_POPUP_IDENTITY_CHANGED')
    pdf=None
    for f in detail.frames:
        loc=f.locator('button#pdfButton[data-action="saveAsPDF"]').first
        if await loc.count() and await loc.is_visible():pdf=loc;break
    if pdf is None:raise RuntimeError('PI_SAVE_AS_PDF_NOT_FOUND')
    temp_dir=Path(settings['_async_run_dir'])/'_tmp'/'pi'/group.guid/item['invoice']/uuid.uuid4().hex
    temp_dir.mkdir(parents=True,exist_ok=True);part=temp_dir/'download.pdf.part'
    download_timeout=int(settings.get('pi_download_timeout_ms') or 30000)
    async with detail.expect_download(timeout=download_timeout) as pending:
        await pdf.evaluate('el=>el.click()')
    download=await pending.value
    if download.page is not detail:raise RuntimeError('PI_FOREIGN_DOWNLOAD_REJECTED')
    try:await asyncio.wait_for(download.save_as(part),timeout=int(settings.get('pi_browser_download_ready_timeout_ms') or 60000)/1000)
    except BaseException:
        await download.cancel();raise
    ev=await asyncio.to_thread(publish_pi,part,settings['_async_run_dir'],folder,item['invoice'],group.full_pan,
        item.get('termowner') or item.get('merchant'),tx.transaction_id,int(settings.get('pi_download_minimum_pdf_bytes') or 1000))
    log.info('PI PUBLISHED | invoice=%s | bytes=%s | path=%s | central_path=%s | identity_verified=true',item['invoice'],ev['bytes'],ev['path'],ev['central_path'])
    registry.assert_owned(page,detail)
    try:await asyncio.wait_for(detail.close(),5)
    except Exception:pass
    part.unlink(missing_ok=True)
    return ev
