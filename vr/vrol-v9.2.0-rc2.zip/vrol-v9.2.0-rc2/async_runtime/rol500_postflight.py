"""Post-run ROL500 reconciliation using the sync invoice/QT matching rules."""
import asyncio
import csv
import json
import os
from pathlib import Path
from openpyxl import load_workbook
from src.vrol.reports.rol500 import parse_rol500, _norm
from .rol500_preflight import download
from .run_monitor import now


def reconcile(workbook, rows, csv_path, report_dir):
    workbook=Path(workbook);report_dir=Path(report_dir);report_dir.mkdir(parents=True,exist_ok=True)
    wb=load_workbook(workbook)
    by_tran={};by_qt={}
    for item in rows:
        if item['tran_key']:by_tran.setdefault(item['tran_key'],[]).append(item)
        if item['qt']:by_qt.setdefault(item['qt'].upper(),[]).append(item)
    details=[];stats=dict(rows_checked=0,matched=0,unmatched=0,ambiguous=0,qt_only=0,submitted_not_found=0,qt_invoice_conflicts=0)
    try:
        ws=wb['Sheet1'];headers={str(ws.cell(2,c).value or '').strip().upper():c for c in range(1,ws.max_column+1)}
        if not {'INVOICENUM','BUT TOAN'}<=headers.keys():raise ValueError('ROL500_POSTFLIGHT_HEADERS_MISSING')
        def column(name):
            key=name.upper()
            if key not in headers:
                headers[key]=ws.max_column+1;ws.cell(2,headers[key],name)
            return headers[key]
        for name in ('BOT ROL500 POST STATUS','BOT ROL500 POST CASE','BOT ROL500 POST MATCH KEY','BOT ROL500 POST SOURCE','BOT ROL500 POST AT'):column(name)
        # AK is the sync operating-file contract; do not overwrite a BOT column
        # occupying AK in a minimal workbook used by an external producer.
        ak=37
        if ws.cell(2,ak).value is None:ws.cell(2,ak,'ROL CASE')
        if str(ws.cell(2,ak).value or '').upper() not in {'ROL CASE','VROL'}:ak=column('ROL CASE')
        for row in range(4,ws.max_row+1):
            def get(name):return str(ws.cell(row,headers[name]).value or '').strip() if name in headers else ''
            invoice,qt=get('INVOICENUM'),get('BUT TOAN')
            if not invoice and not qt:continue
            stats['rows_checked']+=1
            candidates=by_tran.get(_norm(invoice),[]);method='INVOICENUM->ROL500.TRAN_ID'
            qt_conflict=False
            if qt:
                exact=[x for x in candidates if x['qt'].upper()==qt.upper()]
                if exact:candidates=exact;method+=' + QT'
                elif not candidates:
                    qt_matches=by_qt.get(qt.upper(),[])
                    if invoice and any(x['tran_key']!=_norm(invoice) for x in qt_matches):
                        qt_conflict=True;stats['qt_invoice_conflicts']+=1;method='QT_INVOICE_CONFLICT'
                    else:candidates=qt_matches;method='QT_ONLY'
            roles=sorted({x['rol_case'] for x in candidates if x['rol_case']})
            if len(roles)==1:
                status='FOUND_IN_ROL500';stats['matched']+=1
                ws.cell(row,ak,roles[0])
                if 'VROL' in headers:ws.cell(row,headers['VROL'],roles[0])
                if method=='QT_ONLY':stats['qt_only']+=1
            elif len(roles)>1:status='ROL500_AMBIGUOUS_MULTIPLE_CASES';stats['ambiguous']+=1
            else:
                status='ROL500_QT_INVOICE_CONFLICT' if qt_conflict else 'NOT_FOUND_IN_ROL500';stats['unmatched']+=1
                if get('BOT REVIEW STATUS')=='FINAL_SUBMIT_COMPLETED':stats['submitted_not_found']+=1
            # Preserve directly observed case numbers and every bot decision on
            # ambiguous/not-yet-reported rows. Report presence is not Final Submit.
            updates={'BOT ROL500 POST STATUS':status,'BOT ROL500 POST CASE':' | '.join(roles),
                     'BOT ROL500 POST MATCH KEY':method,'BOT ROL500 POST SOURCE':str(Path(csv_path).resolve()),'BOT ROL500 POST AT':now()}
            for name,value in updates.items():ws.cell(row,headers[name],value)
            details.append(dict(row_no=row,guid=get('GUID'),invoice=invoice,qt=qt,status=status,rol_cases=roles,match_key=method,
                                needs_review=qt_conflict or len(roles)>1 or (not roles and get('BOT REVIEW STATUS')=='FINAL_SUBMIT_COMPLETED')))
        temp=workbook.with_name(workbook.stem+'.postflight.tmp.xlsx')
        wb.save(temp);os.replace(temp,workbook)
    finally:wb.close()
    report=report_dir/'rol500_reconciliation.json';report.write_text(json.dumps(dict(stats=stats,rows=details),ensure_ascii=False,indent=2),encoding='utf-8')
    csv_report=report_dir/'rol500_reconciliation.csv'
    with csv_report.open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=['row_no','guid','invoice','qt','status','rol_cases','match_key','needs_review']);writer.writeheader()
        for record in details:writer.writerow(record|dict(rol_cases=' | '.join(record['rol_cases'])))
    return dict(stats=stats,reconciliation_json=str(report),reconciliation_csv=str(csv_report),output_workbook=str(workbook))


async def run(vrol, context, settings, workbook, run_dir, log):
    report_dir=Path(run_dir)/'postflight'
    csv_path,parameters=await download(vrol,context,settings,report_dir,log)
    rows=await asyncio.to_thread(parse_rol500,csv_path)
    result=await asyncio.to_thread(reconcile,workbook,rows,csv_path,report_dir)
    return result|dict(status='SUCCESS',csv_path=str(csv_path),report_rows=len(rows),parameters=parameters,completed_at=now())
