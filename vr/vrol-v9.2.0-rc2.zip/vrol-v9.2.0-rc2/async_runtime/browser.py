import asyncio,time,logging,re
from datetime import datetime
from pathlib import Path
from playwright.async_api import async_playwright,Page,BrowserContext
from .config import truth
from .window_layout import maximize_window
async def visible(page,selectors):
 for s in selectors:
  loc=page.locator(s).first
  try:
   if await loc.count() and await loc.is_visible():return loc
  except:pass
 return None

async def maximize_page(page: Page, settle_ms: int = 400):
    """Compatibility no-op. Browser starts maximized; tabs inherit that window."""
    return page

async def prepare_window_after_navigation(page: Page, url: str, timeout: int = 30000):
    await page.goto(url,wait_until='domcontentloaded',timeout=timeout)
    return page

def register_maximize_handler(context: BrowserContext):
    """No global popup hook: only explicit questionnaire preparation maximizes one."""
    return None

async def _wait_visible(locator,timeout_ms,stage):
 try:
  await locator.wait_for(state='visible',timeout=timeout_ms);return locator
 except Exception as exc:
  raise RuntimeError(f'LOGIN_{stage}_NOT_VISIBLE:timeout_ms={timeout_ms}:url={locator.page.url}') from exc

async def _fill_verified(locator,value,stage,retries=3):
 last=''
 for attempt in range(1,retries+1):
  await locator.fill(value)
  last=await locator.input_value()
  if last==value:
   print(f'ASYNC LOGIN PASS | stage={stage} | attempt={attempt}')
   return
  await locator.page.wait_for_timeout(250)
 raise RuntimeError(f'LOGIN_{stage}_VERIFY_FAILED:actual_length={len(last)}')

async def _login_outcome(portal,settings,timeout_ms):
 welcome_name=str(settings.get('welcome_name') or '').strip()
 welcome=portal.get_by_text(f'Welcome, {welcome_name}',exact=False).first if welcome_name else portal.get_by_text('Welcome',exact=False).first
 additional=portal.get_by_role('heading',name=re.compile(r'Additional Verification Required',re.I)).first
 max_session=portal.get_by_text(re.compile(r'Max Session Reached',re.I)).first
 deadline=time.monotonic()+timeout_ms/1000
 while time.monotonic()<deadline:
  for name,loc in [('SUCCESS',welcome),('ADDITIONAL_VERIFICATION',additional),('MAX_SESSION_REACHED',max_session)]:
   try:
    if await loc.count() and await loc.is_visible():return name
   except Exception:pass
  url=(portal.url or '').lower()
  if '/login/' not in url and await _find_vrol_service_link(portal):return 'SUCCESS'
  await portal.wait_for_timeout(250)
 return 'TIMEOUT'

async def _resolve_max_session(portal,settings):
 yes=portal.get_by_role('button',name='Yes',exact=True).first
 await _wait_visible(yes,int(settings.get('action_timeout_ms') or 20000),'MAX_SESSION_YES')
 await yes.click();print('ASYNC LOGIN PASS | stage=CONFIRM_MAX_SESSION_LOGOUT')
 return await _login_outcome(portal,settings,int(settings.get('login_outcome_timeout_ms') or 60000))

async def _resolve_security_question(portal,settings):
 answers=settings.get('_security_answers') or {}
 question_loc=portal.locator("label[for='default-input']").first
 await _wait_visible(question_loc,int(settings.get('action_timeout_ms') or 20000),'SECURITY_QUESTION')
 question=' '.join((await question_loc.inner_text()).split())
 normalized=re.sub(r'[\s?.!]+$','',question.strip().lower())
 if normalized not in answers:raise RuntimeError(f'LOGIN_SECURITY_ANSWER_NOT_CONFIGURED:{question}')
 field=portal.locator('#default-input').first
 await _wait_visible(field,int(settings.get('action_timeout_ms') or 20000),'SECURITY_ANSWER_FIELD')
 await _fill_verified(field,answers[normalized],'SECURITY_ANSWER')
 checkbox=portal.locator('#checkboxField').first
 if truth(settings.get('trust_device_90_days',True)) and await checkbox.count() and await checkbox.is_visible():await checkbox.check()
 submit=portal.locator("button[name='btnPrimary']").first
 await _wait_visible(submit,int(settings.get('action_timeout_ms') or 20000),'SECURITY_SUBMIT')
 await submit.click();print('ASYNC LOGIN PASS | stage=SUBMIT_SECURITY_ANSWER')
 return await _login_outcome(portal,settings,int(settings.get('login_outcome_timeout_ms') or 60000))

async def maximize_initial_login_window(page: Page):
    """Confirm native geometry before entering credentials; do not resize all popups."""
    report=await maximize_window(page,label='VISA_ACCESS')
    print(f'ASYNC LOGIN WINDOW MAXIMIZED | scope=INITIAL_VISA_ACCESS_ONLY | native_viewport=true | layout={report}')
    return report

async def launch_browser_context(pw,settings,run_dir):
    profile=Path(str(settings.get('user_data_dir') or 'browser_profile')).expanduser()
    if not profile.is_absolute():
        # Resolve like every other config path, independent of the launching CWD.
        profile=Path(str(settings.get('_config_path') or 'config.xlsx')).resolve().parent/profile
    profile=profile.resolve()
    profile.mkdir(parents=True,exist_ok=True)
    downloads=Path(run_dir)/'browser_downloads';downloads.mkdir(parents=True,exist_ok=True)
    from . import window_layout
    headless=truth(settings.get('headless'))
    size=str(settings.get('headless_window_size') or '1920x1080').lower().split('x')
    # headless_fixed_window=NO keeps native maximize semantics (offline CI checks).
    fixed=headless and str(settings.get('headless_fixed_window','YES')).strip().upper()!='NO'
    window_layout.HEADLESS_SIZE=(int(size[0]),int(size[1])) if fixed else None
    extra=[f'--window-size={size[0]},{size[1]}'] if fixed else ['--start-maximized']
    context=await pw.chromium.launch_persistent_context(
        str(profile),channel=str(settings.get('browser_channel') or 'chrome'),
        headless=truth(settings.get('headless')),accept_downloads=True,
        downloads_path=str(downloads),no_viewport=True,
        args=extra+([f"--remote-debugging-port={int(settings.get('async_cdp_port') or 9222)}"]
                                  if settings.get('async_backend')=='legacy_bridge' else []))
    from .popup_scope import context_script
    await context.add_init_script(script=context_script())
    return context

async def login(settings, run_dir):
    pw = await async_playwright().start()
    context = None
    try:
        context = await launch_browser_context(pw,settings,run_dir)
        register_maximize_handler(context)
        timeout = int(settings.get('action_timeout_ms') or 20000)
        context.set_default_timeout(timeout)
        portal = context.pages[0] if context.pages else await context.new_page()
        await maximize_initial_login_window(portal)
        login_url = str(settings.get('login_url') or 'https://www.visaonline.com/login/')
        await portal.goto(login_url, wait_until='domcontentloaded', timeout=int(settings.get('navigation_timeout_ms') or 60000))
        entry_deadline = time.monotonic() + int(settings.get('login_form_timeout_ms') or 60000) / 1000
        while time.monotonic() < entry_deadline:
            username_probe = portal.locator('#external-login-username').first
            if await username_probe.count() and await username_probe.is_visible():
                break
            if '/login/' not in (portal.url or '').lower() and await _find_vrol_service_link(portal):
                print('ASYNC LOGIN REUSED | persistent_authenticated_session=true')
                return (pw, context, portal)
            await asyncio.sleep(0.25)
        else:
            raise RuntimeError('LOGIN_ENTRY_NEITHER_FORM_NOR_AUTHENTICATED_HOME')
        username_value = str(settings.get('username') or '')
        password_value = str(settings.get('password') or '')
        if not username_value or not password_value:
            raise RuntimeError('LOGIN_CREDENTIALS_MISSING')
        username = portal.locator('#external-login-username').first
        await _wait_visible(username, int(settings.get('login_form_timeout_ms') or 60000), 'USERNAME')
        await _fill_verified(username, username_value, 'ENTER_USERNAME', int(settings.get('login_step_retries') or 3))
        password_method = portal.get_by_role('button', name='Password', exact=True).first
        await _wait_visible(password_method, timeout, 'PASSWORD_METHOD')
        await password_method.click()
        print('ASYNC LOGIN PASS | stage=SELECT_PASSWORD_METHOD')
        pwd = portal.locator('#external-login-password').first
        await _wait_visible(pwd, timeout, 'PASSWORD')
        await _fill_verified(pwd, password_value, 'ENTER_PASSWORD', int(settings.get('login_step_retries') or 3))
        submit = portal.get_by_role('button', name='Continue', exact=True).first
        await _wait_visible(submit, timeout, 'CONTINUE')
        await submit.click()
        print('ASYNC LOGIN PASS | stage=SUBMIT_CREDENTIALS')
        outcome = await _login_outcome(portal, settings, int(settings.get('login_outcome_timeout_ms') or 60000))
        max_attempts = 0
        while outcome == 'MAX_SESSION_REACHED':
            max_attempts += 1
            if max_attempts > 2:
                raise RuntimeError('LOGIN_MAX_SESSION_REPEATED')
            outcome = await _resolve_max_session(portal, settings)
        if outcome == 'ADDITIONAL_VERIFICATION':
            outcome = await _resolve_security_question(portal, settings)
            while outcome == 'MAX_SESSION_REACHED':
                outcome = await _resolve_max_session(portal, settings)
        if outcome != 'SUCCESS':
            diag = Path(run_dir) / 'login_outcome_failure.png'
            try:
                await portal.screenshot(path=str(diag), full_page=True)
            except Exception:
                pass
            raise RuntimeError(f'LOGIN_OUTCOME_NOT_SUCCESS:{outcome}:url={portal.url}:screenshot={diag}')
        if '/login/' in (portal.url or '').lower():
            raise RuntimeError(f'LOGIN_RETURN_BLOCKED_STILL_ON_LOGIN:{portal.url}')
        print(f'ASYNC LOGIN COMPLETE | outcome=SUCCESS | url={portal.url}')
        return (pw, context, portal)
    except BaseException:
        try:
            if context is not None:
                await context.close()
        except Exception:
            pass
        await pw.stop()
        raise
async def _find_vrol_service_link(portal: Page):
    candidates = [
        portal.get_by_role("link", name="Visa Resolve Online", exact=True),
        portal.locator('a:has-text("Visa Resolve Online")'),
        portal.get_by_text("Visa Resolve Online", exact=True),
    ]
    for frame in portal.frames:
        candidates.extend([
            frame.get_by_role("link", name="Visa Resolve Online", exact=True),
            frame.locator('a:has-text("Visa Resolve Online")'),
            frame.get_by_text("Visa Resolve Online", exact=True),
        ])
    for loc in candidates:
        try:
            if await loc.count() and await loc.first.is_visible():
                return loc.first
        except Exception:
            pass
    return None

async def _is_vrol_page(page: Page):
    try:
        url=(page.url or '').lower()
        if any(x in url for x in ('admindispatcher', '/rolol/', '/rolti/', '/rolrfc/')):
            return True
        return await page.locator('a#inquirymenua, iframe#bodyframe, iframe[name="bodyframe"]').count() > 0
    except Exception:
        return False

async def _wait_for_authenticated_vrol(page: Page, settings):
    timeout_ms=int(settings.get('vrol_landing_timeout_ms') or 60000)
    deadline=time.monotonic()+timeout_ms/1000
    while time.monotonic() < deadline:
        url=(page.url or '').lower()
        if 'admindispatcher' in url or any(x in url for x in ('/rolol/','/rolti/','/rolrfc/')):
            for frame in page.frames:
                try:
                    if await frame.locator('a#inquirymenua').count():
                        print(f'ASYNC VROL AUTHENTICATED | url={page.url} | frame_url={frame.url}')
                        return page
                except Exception:
                    pass
        await page.wait_for_timeout(500)
    raise RuntimeError(f'VROL_AUTHENTICATED_LANDING_NOT_READY:timeout_ms={timeout_ms}:url={page.url}')

async def _complete_vrol_mfa(page: Page, settings):
    from src.auth.legacy_login import capture_otp_baseline, wait_for_new_otp
    logger=logging.getLogger('async_vrol_mfa')
    entry_timeout=int(settings.get('vrol_entry_outcome_timeout_ms') or 60000)
    deadline=time.monotonic()+entry_timeout/1000
    while time.monotonic() < deadline:
        if await page.locator('#Email').count():
            print('ASYNC VROL MFA REQUIRED | method=EMAIL')
            await page.locator('#Email').check()
            await page.locator("button[name='btnSubmit']").click()
            send=page.locator("button[name='btnOTP']")
            await send.wait_for(state='visible', timeout=int(settings.get('action_timeout_ms') or 20000))
            print(f'ASYNC VROL OTP PROVIDER | mode={settings.get("otp_polling_mode")} | folder={settings.get("otp_folder_path")} | poll_seconds={settings.get("otp_poll_interval_seconds",3)} | timeout_seconds={settings.get("otp_timeout_seconds",90)}')
            baseline=await asyncio.to_thread(capture_otp_baseline, settings, logger)
            requested_at=datetime.now()
            print('ASYNC VROL OTP BASELINE READY | requesting_new_otp=true')
            await send.click()
            await page.get_by_text('One-Time Password successfully sent.', exact=True).wait_for(
                state='visible', timeout=int(settings.get('otp_sent_confirmation_timeout_ms') or 20000))
            print('ASYNC VROL OTP SENT | polling_provider_started=true')
            monitor=settings.get('_run_monitor')
            if monitor:monitor.update(status='WAITING_OTP',stage='OTP_FOLDER_POLL',otp_folder=str(settings.get('otp_folder_path') or ''))
            otp=await asyncio.to_thread(wait_for_new_otp, settings, requested_at, baseline, logger)
            if monitor:monitor.update(status='RUNNING',stage='OTP_RECEIVED')
            otp_input=page.locator("input[name='oneTimePassword']")
            await otp_input.wait_for(state='visible', timeout=int(settings.get('action_timeout_ms') or 20000))
            await otp_input.fill(otp)
            await page.locator("form button[name='btnSubmit']").click()
            print('ASYNC VROL OTP SUBMITTED')
            return await _wait_for_authenticated_vrol(page,settings)
        for frame in page.frames:
            try:
                if await frame.locator('a#inquirymenua').count():
                    print('ASYNC VROL MFA SKIPPED | existing_authenticated_session=true')
                    return page
            except Exception:
                pass
        await page.wait_for_timeout(500)
    raise RuntimeError(f'VROL_ENTRY_OUTCOME_NOT_DETECTED:timeout_ms={entry_timeout}:url={page.url}')

async def open_vrol(portal: Page, settings) -> Page:
    context=portal.context
    timeout_ms=int(settings.get('vrol_service_link_timeout_ms') or 60000)
    deadline=time.monotonic()+timeout_ms/1000
    print(f'ASYNC VROL SERVICE WAIT | timeout_ms={timeout_ms} | portal_url={portal.url}')
    while time.monotonic() < deadline:
        link=await _find_vrol_service_link(portal)
        if link:
            before=set(context.pages)
            try:
                async with portal.expect_popup(timeout=int(settings.get('vrol_popup_timeout_ms') or 30000)) as page_info:
                    await link.click(modifiers=['Control'])
                page=await page_info.value
            except Exception:
                created=[p for p in context.pages if p not in before and not p.is_closed() and await p.opener() is portal]
                if not created:raise RuntimeError('VROL_BASE_CTRL_CLICK_DID_NOT_OPEN_TAB')
                page=created[-1]
            try:await page.wait_for_load_state('domcontentloaded',timeout=30000)
            except Exception:pass
            print(f'ASYNC VROL TAB OPENED | opener=VISA_ACCESS_CTRL_CLICK | url={page.url}')
            page=await _complete_vrol_mfa(page,settings)
            await maximize_window(page,label='VROL_PRIMARY')
            return page
        await portal.wait_for_timeout(500)
    raise RuntimeError(f'VROL_SERVICE_LINK_NOT_FOUND_AFTER_WAIT:timeout_ms={timeout_ms}:portal_url={portal.url}')

async def open_vrol_worker_tab_from_portal(portal: Page, settings, worker_name: str) -> Page:
    """Open a fresh VROL worker tab by Ctrl+clicking the service link on Visa Access."""
    await portal.bring_to_front()
    await portal.wait_for_load_state('domcontentloaded')
    deadline=time.monotonic()+int(settings.get('vrol_service_link_timeout_ms') or 60000)/1000
    link=None
    while time.monotonic()<deadline:
        link=await _find_vrol_service_link(portal)
        if link:break
        await portal.wait_for_timeout(300)
    if not link:raise RuntimeError(f'VROL_WORKER_SERVICE_LINK_NOT_FOUND:{worker_name}')
    before=set(portal.context.pages)
    try:
        async with portal.expect_popup(timeout=15000) as info:
            await link.click(modifiers=['Control'])
        page=await info.value
    except Exception:
        created=[p for p in portal.context.pages if p not in before and not p.is_closed() and await p.opener() is portal]
        if not created:raise RuntimeError(f'VROL_WORKER_CTRL_CLICK_DID_NOT_OPEN_TAB:{worker_name}')
        page=created[-1]
    try:await page.wait_for_load_state('domcontentloaded',timeout=30000)
    except Exception:pass
    # Confirm only the worker's primary window; PI/Case Creation stay native sized.
    page=await _complete_vrol_mfa(page,settings)
    await maximize_window(page,label=worker_name)
    print(f'ASYNC VROL WORKER TAB READY | worker={worker_name} | opener=VISA_ACCESS_CTRL_CLICK | url={page.url}')
    return page

async def close_report_windows(context:BrowserContext,keep:Page):
 for p in list(context.pages):
  if p==keep or p.is_closed():continue
  u=p.url.lower()
  if 'report-ui' in u or 'rol500' in u:
   try:await p.close()
   except:pass
async def _find_frame_locator(page,selector):
 for frame in page.frames:
  try:
   loc=frame.locator(selector).first
   if await loc.count() and await loc.is_visible():return frame,loc
  except Exception:pass
 return None,None

async def _landing_frames_stable(page,timeout_ms=20000,poll_ms=250,stable_required=4):
 deadline=time.monotonic()+timeout_ms/1000;stable=0;previous=None;history=[]
 while time.monotonic()<deadline:
  body=page.frame(name='bodyframe');buttons=page.frame(name='buttons')
  body_url=body.url if body else '';buttons_url=buttons.url if buttons else ''
  sig=(body_url,buttons_url)
  if not history or history[-1]!=sig:history.append(sig)
  ready='action=InvokeHomePage'.lower() in body_url.lower() and '/rolol/jsp/buttons_index.jsp' in buttons_url.lower()
  if ready and sig==previous:stable+=1
  elif ready:stable=1
  else:stable=0
  previous=sig
  if stable>=stable_required:return
  await page.wait_for_timeout(poll_ms)
 raise RuntimeError('VROL_LANDING_FRAMES_NOT_STABLE:'+repr(history[-8:]))

async def _ti_screen_state(page):
 body=page.frame(name='bodyframe');buttons=page.frame(name='buttons')
 body_url=body.url if body else '';buttons_url=buttons.url if buttons else ''
 card=False;date=False;submit=False
 try:
  card=bool(body and await body.locator('#CardNumber').count() and await body.locator('#CardNumber').first.is_visible())
  date=bool(body and await body.locator('#StartDate').count() and await body.locator('#StartDate').first.is_visible())
  submit=bool(buttons and await buttons.locator('button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"],button#submitButton').count() and await buttons.locator('button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"],button#submitButton').first.is_visible())
 except Exception:pass
 if card and date and submit:return 'READY',(body_url,buttons_url)
 body_lower=body_url.lower();buttons_lower=buttons_url.lower()
 ti_body='/rolti/web/ti/ti-request' in body_lower
 ti_buttons='/rolti/web/ti/ti-buttons' in buttons_lower
 home='action=invokehomepage' in body_lower
 if ti_body or ti_buttons:return 'TI_LOADING',(body_url,buttons_url)
 if home:return 'LANDING',(body_url,buttons_url)
 return 'TRANSITION',(body_url,buttons_url)

async def open_transaction_inquiry(page:Page,settings=None):
 settings=settings or {}
 timeout=int(settings.get('transaction_inquiry_navigation_timeout_ms') or 30000);poll=int(settings.get('transaction_inquiry_navigation_poll_ms') or 250)
 await _landing_frames_stable(page,int(settings.get('vrol_landing_frame_settle_timeout_ms') or 20000),poll,int(settings.get('vrol_landing_frame_stable_polls') or 4))
 async def click_path(force=False):
  _,menu=await _find_frame_locator(page,'a#inquirymenua[name="inquirymenua"][role="menuitem"]')
  if not menu:raise RuntimeError('INQUIRY_MENU_NOT_FOUND')
  await menu.hover(force=force);await menu.dispatch_event('mouseover');await page.wait_for_timeout(350)
  _,submenu=await _find_frame_locator(page,'a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]')
  if not submenu:raise RuntimeError('TRANSACTION_INQUIRY_SUBMENU_NOT_FOUND')
  await submenu.click();print(f'ASYNC TRANSACTION INQUIRY CLICKED | force={force}')
 await click_path(False)
 observed=[];saw_ti=False;landing_after_ti_polls=0;deadline=time.monotonic()+timeout/1000
 while time.monotonic()<deadline:
  state,urls=await _ti_screen_state(page)
  if not observed or observed[-1]!=(state,urls):observed.append((state,urls));print(f'ASYNC TI NAV STATE | state={state} | frames={urls}')
  if state=='READY':
   size=await page.evaluate('() => ({outer:[outerWidth,outerHeight],inner:[innerWidth,innerHeight],dpr:devicePixelRatio})')
   print(f'ASYNC TRANSACTION INQUIRY READY | viewport={size} | frames={urls}');return
  if state=='TI_LOADING':
   saw_ti=True;landing_after_ti_polls=0
  elif state=='LANDING' and saw_ti:
   landing_after_ti_polls+=1
   if landing_after_ti_polls>=4:
    print(f'ASYNC TI CONFIRMED ROLLBACK | reopening once | observed={observed[-8:]}')
    await _landing_frames_stable(page,int(settings.get('vrol_landing_frame_settle_timeout_ms') or 20000),poll,int(settings.get('vrol_landing_frame_stable_polls') or 4))
    await click_path(True);saw_ti=False;landing_after_ti_polls=0;observed=[];deadline=time.monotonic()+timeout/1000
  else:landing_after_ti_polls=0
  await page.wait_for_timeout(poll)
 raise RuntimeError('TRANSACTION_INQUIRY_NOT_READY:'+repr(observed[-12:]))

