"""One exact action contract for both read-only probe and live dispatch."""
import re

FINAL_SUBMIT_SELECTOR='button[ng-click="trigger(Buttons.SUBMIT,true)"]'

def visible_submit(scope):
    return scope.locator(FINAL_SUBMIT_SELECTOR).filter(has_text=re.compile(r'^\s*Submit\s*$',re.I),visible=True)

async def probe_submit(scope):
    matches=visible_submit(scope);count=await matches.count()
    metadata=dict(selector=FINAL_SUBMIT_SELECTOR,visible_count=count,dispatch_ready=False)
    if count==1:
        button=matches.first
        metadata.update(enabled=await button.is_enabled(),contract=await button.evaluate('e=>({text:e.innerText.trim(),id:e.id,action:e.getAttribute("ng-click"),visibility:e.getAttribute("ng-show")})'))
        metadata['dispatch_ready']=metadata['enabled']
    return metadata
