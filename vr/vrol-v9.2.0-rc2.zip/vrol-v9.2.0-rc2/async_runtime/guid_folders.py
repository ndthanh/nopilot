"""Finalize an Explorer-visible outcome folder before publishing any result paths."""
import json
import re
from pathlib import Path

PREFIXES = {'NO_CHARGEBACK': 'NO_CB', 'PI_DOWNLOADED': 'PI_DOWNLOADED',
            'FRAUD': 'FRAUD', 'CONSUMER': 'CONSUMER', 'REVIEW_REQUIRED': 'REVIEW_REQUIRED'}


def rebase(value, old, new):
    if isinstance(value, dict):
        return {k: rebase(v, old, new) for k, v in value.items()}
    if isinstance(value, list):
        return [rebase(v, old, new) for v in value]
    if isinstance(value, str):
        # Require a path boundary so GUID A cannot rewrite GUID AB.
        for source, target in {(str(old), str(new)), (old.as_posix(), new.as_posix())}:
            value = re.sub(re.escape(source) + r'(?=$|[/\\\s|\"\'])', lambda _: target, value)
    return value


def finalize_folder(state, guid, category, result, shots):
    old = Path(state.artifact_dir).resolve()
    if old.parent.name != 'groups' or not re.fullmatch(r'[A-Za-z0-9_-]+', guid):
        raise ValueError('GUID_FOLDER_OUTSIDE_GROUPS')
    new = old.parent / (PREFIXES.get(category, 'REVIEW_REQUIRED') + '_' + guid)
    if old != new:
        if new.exists():
            raise FileExistsError('GUID_OUTCOME_FOLDER_ALREADY_EXISTS:' + str(new))
        old.rename(new)
        state.artifact_dir = new
        # Every per-GUID artifact is now closed. Rebase embedded paths as well as
        # the result consumed by CentralWriter; run/documents never moves.
        for path in new.rglob('*'):
            if path.suffix.lower() not in {'.json', '.jsonl', '.txt', '.log'} or not path.is_file():
                continue
            text = path.read_text(encoding='utf-8-sig')
            if path.suffix.lower() == '.json':
                try:text = json.dumps(rebase(json.loads(text), old, new), ensure_ascii=False, indent=2)
                except ValueError:text = rebase(text, old, new)
            elif path.suffix.lower() == '.jsonl':
                lines=[]
                for line in text.splitlines():
                    try:lines.append(json.dumps(rebase(json.loads(line),old,new),ensure_ascii=False))
                    except ValueError:lines.append(rebase(line,old,new))
                text='\n'.join(lines)+'\n'
            else:
                text = rebase(text, old, new)
            path.write_text(text, encoding='utf-8')
        updated = rebase(result, old, new)
        result.clear(); result.update(updated)
        shots[:] = rebase(shots, old, new)
    return new
