"""Async shared-session VROL parallel runtime."""
