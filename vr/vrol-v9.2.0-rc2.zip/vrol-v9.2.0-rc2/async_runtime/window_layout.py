"""Size only explicitly selected Chrome windows; use their real client area."""
import asyncio
import time

# Set by launch_browser_context when Chrome runs headless: there is no OS window
# to maximize, so every "maximize" becomes an explicit, fixed client size.
HEADLESS_SIZE=None

GEOMETRY_JS = '''() => ({
    innerWidth, innerHeight, outerWidth, outerHeight,
    clientWidth: document.documentElement.clientWidth,
    clientHeight: document.documentElement.clientHeight,
    scrollWidth: document.documentElement.scrollWidth,
    scrollHeight: document.documentElement.scrollHeight,
    devicePixelRatio,
    readyState: document.readyState
})'''


LAYOUT_ATTEMPTS=3


async def wait_layout(scope, timeout_ms=5000, attempts=None):
    """Wait for resize/reflow to settle, including a questionnaire iframe.

    A slow questionnaire can keep reflowing past one window (2026-11-21 rehearsal:
    WINDOW_LAYOUT_NOT_STABLE after the case already existed). Retry the wait on the
    same page instead of failing the GUID: nothing is clicked between attempts.
    """
    metrics={}
    for attempt in range(1,(attempts or LAYOUT_ATTEMPTS)+1):
        deadline=time.monotonic()+timeout_ms/1000
        previous=None;stable=0
        while time.monotonic()<deadline:
            metrics=await scope.evaluate(GEOMETRY_JS)
            signature=tuple(metrics.get(k) for k in ('innerWidth','innerHeight','clientWidth','clientHeight','scrollWidth','scrollHeight'))
            ready=metrics['innerWidth']>0 and metrics['innerHeight']>0 and metrics['readyState']!='loading'
            stable=stable+1 if ready and signature==previous else 0
            previous=signature
            if stable>=2:
                if attempt>1:metrics=dict(metrics,layout_attempts=attempt)
                return metrics
            await asyncio.sleep(.1)
        await asyncio.sleep(.5)
    raise RuntimeError('WINDOW_LAYOUT_NOT_STABLE:'+str(dict(metrics,layout_attempts=attempts or LAYOUT_ATTEMPTS)))


async def maximize_window(page,log=None,*,label='BROWSER',timeout_ms=6000):
    """Maximize the owning native window and remove fixed viewport emulation.

    No guessed title-bar offsets or minimum resolution: Chrome computes its
    client area for the current monitor, Windows DPI and browser zoom.
    """
    session=await page.context.new_cdp_session(page)
    last={}
    try:
        info=await session.send('Browser.getWindowForTarget')
        window_id=info['windowId']
        await session.send('Emulation.clearDeviceMetricsOverride')
        if HEADLESS_SIZE:
            width,height=HEADLESS_SIZE
            await session.send('Browser.setWindowBounds',{'windowId':window_id,'bounds':{'windowState':'normal','left':0,'top':0,'width':width,'height':height}})
            geometry=await wait_layout(page,timeout_ms=timeout_ms)
            last=dict(window_id=window_id,headless=True,size=[width,height],geometry=geometry)
            if log:log.info('%s HEADLESS WINDOW SIZED | size=%sx%s | geometry=%s',label,width,height,geometry)
            return last
        deadline=time.monotonic()+timeout_ms/1000
        while time.monotonic()<deadline:
            response=await session.send('Browser.getWindowBounds',{'windowId':window_id})
            bounds=response['bounds']
            last=dict(window_id=window_id,bounds=bounds)
            if bounds.get('windowState') in {'minimized','fullscreen'}:
                await session.send('Browser.setWindowBounds',{'windowId':window_id,'bounds':{'windowState':'normal'}})
                await asyncio.sleep(.1)
                continue
            if bounds.get('windowState')!='maximized':
                await session.send('Browser.setWindowBounds',{'windowId':window_id,'bounds':{'windowState':'maximized'}})
                await asyncio.sleep(.1)
                continue
            geometry=await wait_layout(page,timeout_ms=max(1,int((deadline-time.monotonic())*1000)))
            confirmed=await session.send('Browser.getWindowBounds',{'windowId':window_id})
            last=dict(window_id=window_id,bounds=confirmed['bounds'],geometry=geometry)
            if confirmed['bounds'].get('windowState')=='maximized':
                if log:log.info('%s WINDOW MAXIMIZED | native_viewport=true | bounds=%s | geometry=%s',label,last['bounds'],geometry)
                return last
        raise RuntimeError('WINDOW_MAXIMIZE_NOT_CONFIRMED:'+str(last))
    finally:
        try:await session.detach()
        except Exception:pass
