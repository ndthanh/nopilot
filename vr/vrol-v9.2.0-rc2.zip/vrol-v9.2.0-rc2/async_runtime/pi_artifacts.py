"""Validated PI publication: stable GUID folder plus a run-wide aggregate copy."""
import hashlib, json, os, re, shutil, uuid
from pathlib import Path
from pypdf import PdfReader

def safe_component(value):
    text=re.sub(r'[<>:"/\\|?*\x00-\x1f]+','_',str(value or '').strip())
    return re.sub(r'\s+',' ',text).strip(' ._')

def pi_filename(invoice,pan,termowner):
    invoice=str(invoice or '').strip();pan=re.sub(r'\D','',str(pan or ''))
    merchant=safe_component(termowner)
    if not invoice or not re.fullmatch(r'\d+',invoice):raise ValueError('PI_INVOICE_INVALID')
    if not 12<=len(pan)<=19:raise ValueError('PI_FULL_PAN_INVALID')
    if not merchant:raise ValueError('PI_TERMOWNER_MISSING')
    name=f'{invoice}_{pan[-4:]}_{merchant}.pdf'
    if len(name)>220:raise ValueError('PI_FILENAME_TOO_LONG')
    return name

def contains_transaction(text,transaction_id):
    # IDs may be spaced in a PDF extraction. Preserve digit boundaries after folding whitespace.
    folded=re.sub(r'\s+','',text or '')
    identity=str(transaction_id).strip().lstrip('0')
    suffix='' if re.search(r'-\d{2}$',identity) else r'(?:-\d{2})?'
    return bool(identity and re.search(r'(?<!\d)'+re.escape(identity)+suffix+r'(?![\d-])',folded))

def primary_transaction(text):
    match=re.search(r'\b(?:Tran\s*ID|VisaNet\s+Transaction\s+ID|Visa\s+Transaction\s+ID)\s*:\s*(\d+(?:-\d{2})?)',text or '',re.I)
    return match.group(1) if match else ''

def inspect_pdf(path,transaction_id,minimum_bytes=1000):
    path=Path(path);payload=path.read_bytes()
    if len(payload)<minimum_bytes or not payload.startswith(b'%PDF-'):
        raise ValueError('PI_EVIDENCE_INVALID_OR_EMPTY_PDF')
    reader=PdfReader(path)
    if not reader.pages:raise ValueError('PI_PDF_HAS_NO_PAGES')
    text='\n'.join(page.extract_text() or '' for page in reader.pages)
    primary=primary_transaction(text)
    if not primary:raise ValueError('PI_PDF_PRIMARY_TRANSACTION_ID_NOT_FOUND')
    if not contains_transaction(primary,transaction_id):raise ValueError('PI_PDF_TRANSACTION_ID_MISMATCH')
    return dict(bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),pages=len(reader.pages),transaction_id=transaction_id,pdf_primary_transaction_id=primary,pdf_identity_verified=True)

def _atomic_copy(source,destination,metadata):
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():
        existing=hashlib.sha256(destination.read_bytes()).hexdigest()
        if existing!=metadata['sha256']:raise ValueError('PI_FILENAME_COLLISION:'+destination.name)
        return
    temp=destination.with_name(destination.name+'.'+uuid.uuid4().hex+'.part')
    try:
        shutil.copyfile(source,temp)
        with temp.open('rb+') as f:os.fsync(f.fileno())
        if hashlib.sha256(temp.read_bytes()).hexdigest()!=metadata['sha256']:raise ValueError('PI_COPY_HASH_MISMATCH')
        # Exclusive final publication avoids silent overwrite of a different GUID's file.
        try:os.link(temp,destination)
        except FileExistsError:
            if hashlib.sha256(destination.read_bytes()).hexdigest()!=metadata['sha256']:raise ValueError('PI_FILENAME_COLLISION:'+destination.name)
        except OSError:
            # NTFS normally supports hard links; reserve the destination exclusively otherwise.
            with destination.open('xb') as out, temp.open('rb') as inp:shutil.copyfileobj(inp,out);out.flush();os.fsync(out.fileno())
    finally:temp.unlink(missing_ok=True)

def publish_pi(source,run_dir,group_dir,invoice,pan,termowner,transaction_id,minimum_bytes=1000):
    name=pi_filename(invoice,pan,termowner);metadata=inspect_pdf(source,transaction_id,minimum_bytes)
    local=Path(group_dir)/'documents'/name;central=Path(run_dir)/'documents'/name
    _atomic_copy(source,local,metadata);_atomic_copy(local,central,metadata)
    result=dict(metadata,status='DOWNLOADED',invoice=invoice,file_name=name,path=str(local.resolve()),central_path=str(central.resolve()))
    manifest=Path(group_dir)/'pi_manifest.json'
    records=json.loads(manifest.read_text(encoding='utf-8')) if manifest.exists() else {}
    records[str(invoice)]=result
    temp=manifest.with_suffix('.tmp.json');temp.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,manifest)
    return result
