"""Patch worksheet cells without rebuilding unrelated Excel parts or formula caches."""
import re,shutil
from datetime import date, datetime
from xml.dom import minidom
from zipfile import ZipFile
from openpyxl.utils.datetime import to_excel
from openpyxl.utils.cell import coordinate_from_string, column_index_from_string
from openpyxl.utils.cell import range_boundaries, get_column_letter

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def children(node, name):
    return [x for x in node.childNodes if x.nodeType==x.ELEMENT_NODE and x.localName==name]

def patch_cells(source, target, sheet_name, updates, epoch):
    """Parse only touched rows; retain other sheet bytes and ZIP parts exactly."""
    if not updates:shutil.copyfile(source,target);return
    with ZipFile(source) as zin:
        book=minidom.parseString(zin.read('xl/workbook.xml'))
        sheets=book.getElementsByTagNameNS(NS,'sheet')
        sheet=next(x for x in sheets if x.getAttribute('name')==sheet_name)
        rels=minidom.parseString(zin.read('xl/_rels/workbook.xml.rels'))
        relationship=next(x for x in rels.getElementsByTagName('Relationship') if x.getAttribute('Id')==sheet.getAttribute('r:id'))
        from posixpath import normpath
        name=normpath('xl/'+relationship.getAttribute('Target')) if not relationship.getAttribute('Target').startswith('/') else relationship.getAttribute('Target').lstrip('/')
        sheet_xml=zin.read(name)
        tag=rb'(?:[A-Za-z_][\w.-]*:)?'
        root=re.search(rb'<(?P<tag>'+tag+rb'worksheet)\b(?P<attrs>[^>]*)>',sheet_xml)
        if root is None:raise ValueError('WORKSHEET_ROOT_NOT_FOUND')
        prefix=root['tag'].decode().rsplit(':',1)[0]+':' if b':' in root['tag'] else ''
        declarations=b' '.join(re.findall(rb'\bxmlns(?::[A-Za-z_][\w.-]*)?\s*=\s*(?:"[^"]*"|\x27[^\x27]*\x27)',root['attrs']))
        wrapper=b'<wrapper '+declarations+b'>'
        def fragment(xml):
            doc=minidom.parseString(wrapper+xml+b'</wrapper>')
            return doc,next(x for x in doc.documentElement.childNodes if x.nodeType==x.ELEMENT_NODE)
        def attr(attrs,key):
            found=re.search(rb'\b'+key+rb'\s*=\s*(["\x27])([^"\x27]*)\1',attrs)
            return found[2] if found else None
        by_row={}
        for coordinate,value in updates.items():
            _,row_no=coordinate_from_string(coordinate)
            by_row.setdefault(row_no,{})[coordinate]=value
        pending=sorted(by_row)
        styles=None;date_styles={}
        if any(isinstance(v,(date,datetime)) for v in updates.values()):
            styles=minidom.parseString(zin.read('xl/styles.xml'));style_root=styles.documentElement
            style_prefix=style_root.prefix+':' if style_root.prefix else ''
            def style_element(name):return styles.createElementNS(NS,style_prefix+name)
            fmts=styles.getElementsByTagNameNS(NS,'numFmts')
            if fmts:fmts=fmts[0]
            else:
                fmts=style_element('numFmts');style_root.insertBefore(fmts,style_root.firstChild)
            matching=next((x for x in children(fmts,'numFmt') if x.getAttribute('formatCode')=='dd/mm/yyyy'),None)
            if matching:fmt_id=int(matching.getAttribute('numFmtId'))
            else:
                fmt_id=max([163]+[int(x.getAttribute('numFmtId')) for x in children(fmts,'numFmt')])+1
                fmt=style_element('numFmt');fmt.setAttribute('numFmtId',str(fmt_id));fmt.setAttribute('formatCode','dd/mm/yyyy');fmts.appendChild(fmt);fmts.setAttribute('count',str(len(children(fmts,'numFmt'))))
            xfs=styles.getElementsByTagNameNS(NS,'cellXfs')[0]
        def patch_row(xml,row_no):
            doc,row=fragment(xml)
            def element(name):return doc.createElementNS(NS,prefix+name)
            cells={x.getAttribute('r'):x for x in children(row,'c')}
            for coordinate,value in sorted(by_row[row_no].items(),key=lambda pair:column_index_from_string(coordinate_from_string(pair[0])[0])):
                col=column_index_from_string(coordinate_from_string(coordinate)[0]);cell=cells.get(coordinate)
                if cell is None:
                    cell=element('c');cell.setAttribute('r',coordinate)
                    following=next((x for x in children(row,'c') if column_index_from_string(coordinate_from_string(x.getAttribute('r'))[0])>col),None)
                    row.insertBefore(cell,following)
                for old in list(cell.childNodes):cell.removeChild(old)
                if cell.hasAttribute('t'):cell.removeAttribute('t')
                if value is None:continue
                if isinstance(value,(date,datetime)):
                    base=int(cell.getAttribute('s') or '0')
                    if base not in date_styles:
                        xf=children(xfs,'xf')[base]
                        if xf.getAttribute('numFmtId')==str(fmt_id):date_styles[base]=base
                        else:
                            date_styles[base]=len(children(xfs,'xf'));xf=xf.cloneNode(True);xf.setAttribute('numFmtId',str(fmt_id));xf.setAttribute('applyNumberFormat','1');xfs.appendChild(xf);xfs.setAttribute('count',str(len(children(xfs,'xf'))))
                    cell.setAttribute('s',str(date_styles[base]));v=element('v');v.appendChild(doc.createTextNode(str(to_excel(value,epoch))));cell.appendChild(v)
                else:
                    cell.setAttribute('t','inlineStr');inline=element('is');t=element('t');t.setAttribute('xml:space','preserve');t.appendChild(doc.createTextNode(str(value)));inline.appendChild(t);cell.appendChild(inline)
            value=row.toxml(encoding='utf-8');doc.unlink();return value
        def new_row(row_no):return patch_row(f'<{prefix}row r="{row_no}"/>'.encode(),row_no)
        def visit(match):
            number=attr(match['attrs'],b'r')
            if number is None:return match[0]
            row_no=int(number);parts=[]
            while pending and pending[0]<row_no:parts.append(new_row(pending.pop(0)))
            if pending and pending[0]==row_no:
                pending.pop(0);parts.append(patch_row(match[0],row_no))
            else:parts.append(match[0])
            return b''.join(parts)
        rows=re.compile(rb'<(?P<tag>'+tag+rb'row)\b(?P<attrs>[^>]*)(?:/>|>.*?</(?P=tag)\s*>)',re.S)
        data=re.search(rb'<(?P<tag>'+tag+rb'sheetData)\b(?P<attrs>[^>]*)(?:/>|>(?P<body>.*?)</(?P=tag)\s*>)',sheet_xml,re.S)
        if data is None:raise ValueError('SHEET_DATA_NOT_FOUND')
        body=rows.sub(visit,data['body'] or b'')
        body+=b''.join(new_row(row_no) for row_no in pending)
        # Extension payloads can also contain elements named row/c. They are
        # opaque; only sheetData participates in cell insertion or updates.
        updated=b'<'+data['tag']+data['attrs']+b'>'+body+b'</'+data['tag']+b'>'
        sheet_xml=sheet_xml[:data.start()]+updated+sheet_xml[data.end():]
        def dimension(match):
            doc,node=fragment(match[0]);left,top,right,bottom=range_boundaries(node.getAttribute('ref'))
            for coordinate in updates:
                letters,row_no=coordinate_from_string(coordinate);col=column_index_from_string(letters)
                left=min(left,col);right=max(right,col);top=min(top,row_no);bottom=max(bottom,row_no)
            node.setAttribute('ref',f'{get_column_letter(left)}{top}:{get_column_letter(right)}{bottom}');value=node.toxml(encoding='utf-8');doc.unlink();return value
        sheet_xml=re.sub(rb'<'+tag+rb'dimension\b[^>]*/>',dimension,sheet_xml,count=1)
        replacements={name:sheet_xml}
        if styles:replacements['xl/styles.xml']=styles.toxml(encoding='utf-8')
        with ZipFile(target,'w') as zout:
            for info in zin.infolist():zout.writestr(info,replacements.get(info.filename,zin.read(info.filename)))
