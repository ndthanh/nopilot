"""Recognize the association-selection screen, not a questionnaire sidebar."""
from pathlib import Path


class AssociatedScreenDetected(RuntimeError):
    def __init__(self, found):
        super().__init__('ASSOCIATED_TRANSACTIONS_SCREEN')
        self.found = found

_SIGNATURE = r"""() => {
  const visible = el => !!el && !!el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden';
  const form = [...document.forms].filter(visible).find(el => el.id === 'submit_ti_atr_selection' ||
    /\/casefolder\/submit-ti-atr-selection\.action(?:[?#]|$)/i.test(el.getAttribute('action') || ''));
  const mainHeading = [...document.querySelectorAll('.form-title,h1,h2,[role="heading"]')]
    .some(el => visible(el) && /^Associated\s+Transactions$/i.test(el.textContent.trim()));
  const title = /(?:^|[-–:]\s*)Associated\s+Transactions\s*$/i.test(document.title);
  const text = document.body?.innerText || '';
  const prompt = /Which of the listed transactions are associated with the selected transaction\?/i.test(text);
  const table = document.querySelector('table#results');
  const associatedColumn = table && visible(table) && [...table.querySelectorAll('th')]
    .some(el => /^Associated$/i.test(el.textContent.trim()));
  if (!(form || ((mainHeading || title) && prompt && associatedColumn))) return null;
  const input = document.querySelector('[name="businessObjects[0].caseNumber"]');
  const match = text.match(/VROL\s+Case\s+Number\s*:?\s*(\d{6,15})/i);
  const value = (input?.value || match?.[1] || '').trim();
  return {signature:'associated-transactions-v1', form_match:!!form,
    main_heading:mainHeading, title_match:title, rol:/^\d{6,15}$/.test(value)?value:''};
}"""


async def on_page(page):
    for frame in page.frames:
        try:
            signature = await frame.evaluate(_SIGNATURE)
            if signature:return frame, signature
        except Exception:continue
    return None


async def find(registry, root):
    for page in registry.pages(root):
        found = await on_page(page)
        if found:
            registry.assert_owned(root, page)
            return page, *found
    return None


async def stop(found, settings, folder, action, log):
    page, frame, signature = found
    rol = signature['rol']
    from .native_case import checkpoint
    shot = Path(folder) / '04_associated_transactions_review_required.png'
    reason = 'ASSOCIATED_TRANSACTIONS_SCREEN'
    checkpoint(folder, 'STOPPED_AT_ASSOCIATED_TRANSACTIONS', rol=rol,
               reason_code=reason, associated_transactions=signature,
               final_submit_clicked=False, disposition='HOLD_REVIEW')
    await page.screenshot(path=str(shot), full_page=True, timeout=10000)
    log.warning('ASSOCIATED TRANSACTIONS | STOP FOR REVIEW | rol=%s | screenshot=%s', rol, shot)
    # Worker.finally closes this worker's descendants after saving evidence.
    return dict(status='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED', decision='REVIEW_REQUIRED',
                reason_code=reason, reason_detail='Stopped without selecting associations or submitting this screen.',
                rol=rol, vrol_case_number=rol, issuer_action_clicked=bool(action), issuer_action=action,
                final_submit_clicked=False, associated_transactions=signature,
                associated_transactions_screenshot=str(shot), disposition='HOLD_REVIEW')
