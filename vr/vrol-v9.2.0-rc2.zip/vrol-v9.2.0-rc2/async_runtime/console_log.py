"""Python tee for a normal CMD console; no PowerShell dependency."""
import sys, threading

class ConsoleLog:
    def __init__(self,path):
        self.path=path;self.lock=threading.RLock();self.file=None
    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.file=self.path.open('a',encoding='utf-8')
        self.original_out,self.original_err=sys.stdout,sys.stderr
        parent=self
        class Tee:
            encoding='utf-8'
            def __init__(self,stream):self.stream=stream
            def write(self,text):
                with parent.lock:parent.file.write(text);parent.file.flush();return self.stream.write(text)
            def flush(self):
                with parent.lock:parent.file.flush();self.stream.flush()
            def isatty(self):return self.stream.isatty()
            def fileno(self):return self.stream.fileno()
        sys.stdout,sys.stderr=Tee(self.original_out),Tee(self.original_err)
        return self
    def __exit__(self,*args):
        sys.stdout,self.saved_out=self.original_out,sys.stdout
        sys.stderr,self.saved_err=self.original_err,sys.stderr
        self.file.close()
