"""Operator choices saved from the RPA Ops dashboard, applied to every later run.

File: <VROL root>\\runtime\\run_overrides.json (written by the dashboard, read here).
Precedence for each setting: command-line flag > dashboard override > config.xlsx Settings.
A missing file, a missing key or the value null means "use config.xlsx".

    {"schema": "vrol-run-overrides/1", "final_submit": "YES"|"NO"|null,
     "workers": 1..MAX_WORKERS|null, "headless": true|false|null,
     "updated_at": "...", "updated_by": "..."}
"""
import json
from pathlib import Path

SCHEMA = 'vrol-run-overrides/1'
MAX_WORKERS = 9  # highest worker count exercised end-to-end (2026-11-21 rehearsal)


def path_for(root):
    return Path(root) / 'runtime' / 'run_overrides.json'


def load(root):
    """Return validated overrides; anything invalid is ignored (falls back to config)."""
    path = path_for(root)
    try:
        data = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    out = {}
    final = str(data.get('final_submit') or '').strip().upper()
    if final in {'YES', 'NO'}:
        out['final_submit'] = final
    workers = data.get('workers')
    if isinstance(workers, int) and not isinstance(workers, bool) and 1 <= workers <= MAX_WORKERS:
        out['workers'] = workers
    if isinstance(data.get('headless'), bool):
        out['headless'] = data['headless']
    if out:
        out['updated_at'] = data.get('updated_at')
    return out


def apply(settings, overrides):
    """Apply dashboard overrides onto config settings in place; returns the source of each value.

    Command-line flags are applied by the caller afterwards, so they still win.
    """
    sources = dict(final_submit='config', workers='config', headless='config')
    if 'final_submit' in overrides:
        settings['allow_final_submit'] = overrides['final_submit']
        settings['_allow_final_submit_source'] = 'dashboard'
        sources['final_submit'] = 'dashboard'
    if 'workers' in overrides:
        settings['async_worker_count'] = overrides['workers']
        try:
            cap = int(settings.get('async_worker_max') or 0)
        except (TypeError, ValueError):
            cap = 0
        settings['async_worker_max'] = max(cap, overrides['workers'])
        sources['workers'] = 'dashboard'
    if 'headless' in overrides:
        settings['headless'] = overrides['headless']
        sources['headless'] = 'dashboard'
    return sources
