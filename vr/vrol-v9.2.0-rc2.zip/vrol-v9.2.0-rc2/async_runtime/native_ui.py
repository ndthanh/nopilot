"""Native async UI adapter ported from the confirmed sync workflow.
Business field values/selectors retain sync semantics. No sync browser objects.
"""
import asyncio, re, time
from pathlib import Path
from .config import truth as as_bool
from .observability import LOGGER
from .native_table import schema_from_dom, parse_row_for_code, visible_rows, wait_stable_visible_rows
from src.vrol.transaction_table import split_transaction_ref, transaction_id_matches_invoice
from src.vrol.selectors import body, buttons
class UnknownScenario(RuntimeError): pass
class BusinessReview(RuntimeError): pass

async def _batch_capture(page, settings, name):
    raw = str(settings.get('batch_test_case_evidence_dir') or '').strip()
    if not raw:
        return ''
    path = Path(raw) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        await page.screenshot(path=str(path), full_page=True)
        return path.name
    except Exception:
        return ''

async def _select_test_value(scope, selector, value, field, aliases=None, timeout_ms=12000):
    """Select an Angular questionnaire value, allowing delayed/hidden native selects."""
    value = str(value or '').strip()
    if not value or value.upper().startswith('CHANGE_ME'):
        return None
    selectors = []
    for item in [selector] + list(aliases or []):
        item = str(item or '').strip()
        if item and item not in selectors:
            selectors.append(item)
    deadline = time.monotonic() + timeout_ms / 1000
    last_inventory = []
    while time.monotonic() < deadline:
        for current in selectors:
            try:
                loc = scope.locator(current).first
                if not await loc.count():
                    continue
                try:
                    await loc.select_option(value=value, force=True)
                except Exception:
                    try:
                        await loc.select_option(label=value, force=True)
                    except Exception:
                        applied = await loc.evaluate("(e,v)=>{const opts=[...e.options];const o=opts.find(x=>x.value===v||x.text.trim()===v);if(!o)return false;e.value=o.value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.dispatchEvent(new Event('blur',{bubbles:true}));return true;}", value)
                        if not applied:
                            continue
                actual = ''
                selected_text = ''
                try:
                    actual = await loc.input_value()
                    selected_text = (await loc.locator('option:checked').inner_text()).strip()
                except Exception:
                    pass
                if actual == value or selected_text == value:
                    LOGGER.info('QUESTIONNAIRE SELECTED | field=%s | requested=%s | actual=%s | selected_text=%s | selector=%s', field, value, actual, selected_text, current)
                    return {'field': field, 'selector': current, 'value': value, 'actual': actual, 'selected_text': selected_text, 'visible': await loc.is_visible()}
            except Exception:
                pass
        try:
            inventory = scope.locator('select')
            last_inventory = []
            for i in range(min(await inventory.count(), 50)):
                el = inventory.nth(i)
                last_inventory.append(await el.evaluate("e=>({name:e.name||'',id:e.id||'',model:e.getAttribute('ng-model')||'',visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length),options:[...e.options].map(o=>({value:o.value,text:o.text.trim()}))})"))
        except Exception:
            pass
        try:
            await scope.page.wait_for_timeout(250)
        except Exception:
            await asyncio.sleep(0.25)
    LOGGER.error('QUESTIONNAIRE SELECT DIAGNOSTIC | field=%s | requested=%s | selectors=%s | selects=%s', field, value, selectors, last_inventory)
    raise UnknownScenario('QUESTIONNAIRE_FIELD_NOT_FOUND:' + field)

def _digits(v):
    return re.sub('[^0-9]', '', str(v or ''))

def _amount_decimal(v):
    raw = str(v or '').strip().replace(',', '').replace(' ', '')
    m = re.search('\\d+(?:\\.\\d+)?', raw)
    if not m:
        return None
    from decimal import Decimal, InvalidOperation
    try:
        return Decimal(m.group(0))
    except InvalidOperation:
        return None

async def _find_visible(scope, selectors, field):
    for selector in selectors:
        try:
            loc = scope.locator(selector).first
            if await loc.count() and await loc.is_visible():
                return (loc, selector)
        except Exception:
            pass
    raise UnknownScenario('QUESTIONNAIRE_FIELD_NOT_FOUND:' + field)

async def _validate_131_questionnaire(scope, record, settings=None):
    screen = scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not await screen.count() or not await screen.is_visible():
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name = ' '.join((await screen.inner_text()).split())
    if screen_name != 'Consumer Dispute Questionnaire':
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:' + screen_name)
    invoice_expected = _digits((record or {}).get('invoice')).lstrip('0') or '0'
    invoice_loc = scope.locator('dd[ng-bind="data.pinnedOriginalTransaction.visaTransactionId"]').first
    if not await invoice_loc.count() or not await invoice_loc.is_visible():
        raise UnknownScenario('QUESTIONNAIRE_INVOICE_NOT_FOUND')
    invoice_actual = _digits(await invoice_loc.inner_text()).lstrip('0') or '0'
    if invoice_actual != invoice_expected:
        raise UnknownScenario(f'QUESTIONNAIRE_INVOICE_MISMATCH:expected={invoice_expected}:actual={invoice_actual}')
    validate_amount = str((settings or {}).get('validate_dispute_amount', 'YES')).strip().upper() == 'YES'
    amount_selector=None;expected_amount=None;actual_raw=None;actual_amount=None
    if validate_amount:
        amount_loc, amount_selector = await _find_visible(scope, ['input[name="disputeAmount"]', 'input[ng-model="disputeRequest.disputeAmount.amount"]'], '13_1_dispute_amount')
        expected_amount = _amount_decimal((record or {}).get('amount'))
        actual_raw = await amount_loc.input_value()
        actual_amount = _amount_decimal(actual_raw)
        if expected_amount is None:
            raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount != expected_amount:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=13.1 | expected=%s | actual=%s', expected_amount, actual_amount)
    else:
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=13.1 | reason=validate_dispute_amount_NO | actual=%s', actual_raw)
    return {'screen_name': screen_name, 'invoice_expected': invoice_expected, 'invoice_actual': invoice_actual, 'amount_validation': 'VALIDATED' if validate_amount else 'SKIPPED', 'amount_expected': str(expected_amount) if expected_amount is not None else None, 'amount_actual': str(actual_amount) if actual_amount is not None else actual_raw, 'amount_selector': amount_selector}

async def _validate_consumer_139_questionnaire(scope, record, settings=None):
    screen = scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not await screen.count() or not await screen.is_visible():
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name = ' '.join((await screen.inner_text()).split())
    if screen_name != 'Consumer Dispute Questionnaire':
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:' + screen_name)
    validate_amount = str((settings or {}).get('validate_dispute_amount', 'YES')).strip().upper() == 'YES'
    if validate_amount:
        amount_loc, amount_selector = await _find_visible(scope, ['input[name="disputeAmount"]', 'input[ng-model="disputeRequest.disputeAmount.amount"]'], '13_9_dispute_amount')
        expected_amount = _amount_decimal((record or {}).get('amount'))
        actual_raw = await amount_loc.input_value()
        actual_amount = _amount_decimal(actual_raw)
        if expected_amount is None:
            raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount != expected_amount:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=13.9 | expected=%s | actual=%s', expected_amount, actual_amount)
    else:
        amount_selector = None
        expected_amount = None
        actual_amount = None
        actual_raw = None
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=13.9 | reason=validate_dispute_amount_NO | field_lookup=false')
    return {'screen_name': screen_name, 'amount_validation': 'VALIDATED' if validate_amount else 'SKIPPED', 'amount_expected': str(expected_amount) if expected_amount is not None else None, 'amount_actual': str(actual_amount) if actual_amount is not None else actual_raw, 'amount_selector': amount_selector}

async def _validate_fraud_104_questionnaire(scope, record, settings=None):
    screen = scope.locator('span[ng-bind="disputeData.screenName"]').first
    if not await screen.count() or not await screen.is_visible():
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_NOT_FOUND')
    screen_name = ' '.join((await screen.inner_text()).split())
    if screen_name != 'Fraud Dispute Questionnaire':
        raise UnknownScenario('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:' + screen_name)
    validate_amount = str((settings or {}).get('validate_dispute_amount', 'YES')).strip().upper() == 'YES'
    if validate_amount:
        amount_loc, amount_selector = await _find_visible(scope, ['input[name="disputeAmount"]', 'input[ng-model="disputeRequest.disputeAmount.amount"]'], '10_4_dispute_amount')
        expected_amount = _amount_decimal((record or {}).get('amount'))
        actual_raw = await amount_loc.input_value()
        actual_amount = _amount_decimal(actual_raw)
        if expected_amount is None:
            raise UnknownScenario('QUESTIONNAIRE_AMOUNT_EXPECTED_MISSING')
        if actual_amount is None:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_ACTUAL_PARSE_FAILED:actual={actual_raw}')
        if actual_amount != expected_amount:
            raise UnknownScenario(f'QUESTIONNAIRE_AMOUNT_MISMATCH:expected={expected_amount}:actual={actual_amount}')
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATED | code=10.4 | expected=%s | actual=%s', expected_amount, actual_amount)
    else:
        amount_selector = None
        expected_amount = None
        actual_amount = None
        actual_raw = None
        LOGGER.info('QUESTIONNAIRE AMOUNT VALIDATION SKIPPED | code=10.4 | reason=validate_dispute_amount_NO | field_lookup=false')
    condition = scope.get_by_text(re.compile('^10\\.4 Fraud - Card Absent Environment$', re.I), exact=True).first
    if not await condition.count() or not await condition.is_visible():
        raise UnknownScenario('QUESTIONNAIRE_10_4_CONDITION_NOT_FOUND')
    return {'screen_name': screen_name, 'amount_validation': 'VALIDATED' if validate_amount else 'SKIPPED', 'amount_expected': str(expected_amount) if expected_amount is not None else None, 'amount_actual': str(actual_amount) if actual_amount is not None else actual_raw, 'amount_selector': amount_selector, 'condition': '10.4 Fraud - Card Absent Environment'}

async def _check_checkbox(scope, selector, field, checked=True, timeout_ms=12000):
    loc = scope.locator(selector).first
    await loc.wait_for(state='attached', timeout=timeout_ms)
    if checked:
        await loc.check(force=True)
    else:
        await loc.uncheck(force=True)
    if bool(await loc.is_checked()) != bool(checked):
        raise UnknownScenario('QUESTIONNAIRE_CHECKBOX_STATE_FAILED:' + field)
    LOGGER.info('QUESTIONNAIRE CHECKBOX SET | field=%s | checked=%s | selector=%s', field, checked, selector)
    return {'field': field, 'selector': selector, 'value': checked}

async def _fill_member_case_number(scope, record):
    qt = str((record or {}).get('qt') or (record or {}).get('member_case') or '').strip()
    if not qt:
        raise UnknownScenario('QUESTIONNAIRE_MEMBER_CASE_NUMBER_MISSING')
    return await _fill_text_value(scope, 'input[name="memberCaseNumber"]', qt, 'member_case_number')

def _expected_receipt_date_from_record(record):
    """Read Excel column D/NGAY GD supplied in yyyyMMdd and convert for VROL MM/dd/yyyy."""
    raw = str((record or {}).get('start_date') or (record or {}).get('date') or '').strip()
    if not re.fullmatch('\\d{8}', raw):
        raise UnknownScenario('QUESTIONNAIRE_EXPECTED_RECEIPT_DATE_INVALID_YYYYMMDD:' + raw)
    try:
        parsed = time.strptime(raw, '%Y%m%d')
        return time.strftime('%m/%d/%Y', parsed)
    except ValueError:
        raise UnknownScenario('QUESTIONNAIRE_EXPECTED_RECEIPT_DATE_INVALID_YYYYMMDD:' + raw)

async def _fill_text_value(scope, selector, value, field, timeout_ms=12000):
    value = str(value or '').strip()
    if not value:
        return None
    loc = scope.locator(selector).first
    await loc.wait_for(state='attached', timeout=timeout_ms)
    await loc.fill(value, force=True)
    LOGGER.info('QUESTIONNAIRE FIELD FILLED | field=%s | selector=%s', field, selector)
    return {'field': field, 'selector': selector, 'value': value}

async def _check_radio_value(scope, name, value, field, timeout_ms=12000):
    selector = 'input[type="radio"][name="%s"][value="%s"]' % (name, value)
    loc = scope.locator(selector).first
    await loc.wait_for(state='attached', timeout=timeout_ms)
    await loc.check(force=True)
    if not await loc.is_checked():
        raise UnknownScenario('QUESTIONNAIRE_RADIO_NOT_CHECKED:' + field)
    LOGGER.info('QUESTIONNAIRE RADIO CHECKED | field=%s | value=%s', field, value)
    return {'field': field, 'selector': selector, 'value': value}

async def _inspect_final_submit(scope, settings):
    from .questionnaire_submit import probe_submit
    exact=await probe_submit(scope)
    selectors = ['button[ng-click="trigger(Buttons.SUBMIT,true)"]', 'button:has-text("Submit")', 'input[type="submit"][value="Submit"]']
    found = None
    for selector in selectors:
        try:
            loc = scope.locator(selector).filter(has_text=re.compile(r'^\s*Submit\s*$', re.I)).first if selector.startswith('button') else scope.locator(selector).first
            if await loc.count():
                found = {'selector': selector, 'visible': bool(await loc.is_visible())}
                break
        except Exception:
            pass
    allow = as_bool(settings.get('allow_final_submit', 'NO'))
    LOGGER.info('FINAL SUBMIT INSPECTION | found=%s | visible=%s | allow_final_submit=%s | clicked=false', bool(found), found.get('visible') if found else False, 'YES' if allow else 'NO')
    return {'found': bool(found), 'visible': found.get('visible') if found else False, 'selector': found.get('selector') if found else None, 'allow_final_submit': allow, 'clicked': False,'exact_contract':exact}

async def fill_test_questionnaire(scope, code, settings, record=None):
    """Fill confirmed questionnaire values and inspect Final Submit without clicking it."""
    preset={'13.1':('13_1_dispute_due','NR'),'13.9':('13_9_dispute_due','CL')}.get(code)
    if preset and str(settings.get(preset[0],preset[1]) or '').strip()!=preset[1]:
        raise UnknownScenario('QUESTIONNAIRE_PRESET_CODE_CONFLICT:'+code)
    fields = []
    validation = {}
    submit_inspection = {}
    if code == '10.4':
        validation = await _validate_fraud_104_questionnaire(scope, record or {}, settings)
        fields.append(await _fill_member_case_number(scope, record))
        fields.append(await _check_checkbox(scope, 'input[type="checkbox"][name="CardholderDeniesAuthorizingInd"]', '10_4_cardholder_denies_authorizing', True))
        x = await _select_test_value(scope, str(settings.get('10_4_fraud_type_selector', 'select[name="FraudTypeCode"]')), settings.get('10_4_fraud_type', 'FT6'), '10_4_fraud_type', aliases=['select[name="FraudTypeCode"]', 'select[ng-model="data.FraudTypeCode"]'])
        if not x:raise UnknownScenario('QUESTIONNAIRE_REQUIRED_PRESET_NOT_CONFIGURED:10_4_fraud_type')
        fields.append(x)
        submit_inspection = await _inspect_final_submit(scope, settings)
        LOGGER.info('QUESTIONNAIRE 10.4 HAPPY CASE FILLED | screen=%s | amount=%s | member_case=%s | fraud_type=FT6 | certification_checked=true | submit_found=%s | final_submit_clicked=false', validation['screen_name'], validation['amount_actual'], (record or {}).get('qt') or (record or {}).get('member_case'), submit_inspection['found'])
    elif code == '13.1':
        validation = await _validate_131_questionnaire(scope, record or {}, settings)
        fields.append(await _fill_member_case_number(scope, record))
        x = await _select_test_value(scope, str(settings.get('13_1_dispute_due_selector', 'select[name="DisputeDueTo"]')), settings.get('13_1_dispute_due', 'NR'), '13_1_dispute_due', aliases=['select[name="DisputeDueTo"]', 'select[name="disputeDueTo"]', 'select[ng-model="disputeRequest.relatedInfo.DisputeDueTo"]', 'select:has(option[value="NR"])'])
        if x:
            fields.append(x)
        x = await _select_test_value(scope, 'select[name="WhatWasNotReceived"]', settings.get('13_1_what_was_not_received', 'S'), '13_1_what_was_not_received', aliases=['select[ng-model="data.WhatWasNotReceived"]'])
        if x:
            fields.append(x)
        for name, value, field in [('NonFiatCurrencyNotDelivered', 'N', '13_1_non_fiat_not_delivered'), ('ThirdPartyGiftCardInd', 'N', '13_1_third_party_gift_card'), ('DidMerchantCancelInd', 'N', '13_1_merchant_cancelled'), ('MerchantInBankruptcyLiquidationInd', 'N', '13_1_merchant_insolvent'), ('DidCardholderCancelPriorExpectedDate', 'N', '13_1_cardholder_cancelled_prior'), ('CardholderAttemptToResolve', 'Y', '13_1_attempted_to_resolve')]:
            fields.append(await _check_radio_value(scope, name, value, field))
        text_fields = [('textarea[name="PurchasedInfo"]', settings.get('13_1_purchased_info', 'The cardholder has filed a dispute for the above-mentioned transaction, claiming that the transaction was not completed successfully and that no related goods/services were received.'), '13_1_purchased_info'), ('input[name="ExpectedReceiptDate"]', _expected_receipt_date_from_record(record), '13_1_expected_receipt_date'), ('input[name="ExpectedReceiptTime"]', settings.get('13_1_expected_receipt_time', ''), '13_1_expected_receipt_time')]
        for selector, value, field in text_fields:
            if str(value or '').strip():
                fields.append(await _fill_text_value(scope, selector, value, field))
        submit_inspection = await _inspect_final_submit(scope, settings)
        LOGGER.info('QUESTIONNAIRE 13.1 HAPPY CASE FILLED | screen=%s | invoice=%s | dispute_amount=%s | fields=%s | submit_found=%s | final_submit_clicked=false', validation['screen_name'], validation['invoice_actual'], validation['amount_actual'], [f['field'] for f in fields], submit_inspection['found'])
    elif code == '13.9':
        validation = await _validate_consumer_139_questionnaire(scope, record or {}, settings)
        fields.append(await _fill_member_case_number(scope, record))
        x = await _select_test_value(scope, str(settings.get('13_9_dispute_due_selector', 'select[name="DisputeDueTo"]')), settings.get('13_9_dispute_due', 'CL'), '13_9_dispute_due', aliases=['select[name="DisputeDueTo"]', 'select[ng-model="disputeRequest.relatedInfo.DisputeDueTo"]'])
        if x:
            fields.append(x)
        x = await _select_test_value(scope, 'select[name="WhatWasNotReceived"]', settings.get('13_9_what_was_not_received', 'C'), '13_9_what_was_not_received', aliases=['select[ng-model="data.WhatWasNotReceived"]'])
        if x:
            fields.append(x)
        submit_inspection = await _inspect_final_submit(scope, settings)
        LOGGER.info('QUESTIONNAIRE 13.9 HAPPY CASE FILLED | screen=%s | amount=%s | member_case=%s | dispute_due=CL | what_not_received=C | submit_found=%s | submit_visible=%s | final_submit_clicked=false', validation['screen_name'], validation['amount_actual'], (record or {}).get('qt') or (record or {}).get('member_case'), submit_inspection['found'], submit_inspection['visible'])
    if not fields:
        raise UnknownScenario('QUESTIONNAIRE_NO_CONFIGURED_FIELDS:' + code)
    LOGGER.info('QUESTIONNAIRE FILLED | code=%s | fields=%s | validation=%s | submit_inspection=%s | final_submit_clicked=false', code, [x['field'] for x in fields], validation, submit_inspection)
    return {'fields': fields, 'validation': validation, 'submit_inspection': submit_inspection}

async def visible(loc, timeout=1500):
    try:
        await loc.first.wait_for(state='visible', timeout=timeout)
        return True
    except Exception:
        return False

def _list_setting(settings, key_name, default):
    raw = str(settings.get(key_name, default) or default)
    return {x.strip().casefold() for x in raw.split('|') if x.strip()}

async def probe_transaction_inquiry_state(page):
    """Return a compact snapshot of the two VROL frames involved in TI navigation."""
    body = page.frame(name='bodyframe')
    buttons = None
    for frame in page.frames:
        if frame.name == 'buttons' or '/rolti/web/ti/ti-buttons' in str(frame.url or ''):
            buttons = frame
            break
    snapshot = {'body_url': str(body.url or '') if body else '', 'buttons_url': str(buttons.url or '') if buttons else '', 'pan_visible': False, 'start_visible': False, 'submit_visible': False, 'submit_enabled': False}
    if body:
        try:
            pan = body.locator('#CardNumber').first
            start = body.locator('#StartDate').first
            snapshot['pan_visible'] = bool(await pan.count() and await pan.is_visible())
            snapshot['start_visible'] = bool(await start.count() and await start.is_visible())
        except Exception:
            pass
    if buttons:
        try:
            button_body = buttons.locator('body#buttonBody').first
            submit = buttons.locator('button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]').first
            body_ready = bool(await button_body.count() and await button_body.is_visible())
            snapshot['submit_visible'] = bool(body_ready and await submit.count() and await submit.is_visible())
            snapshot['submit_enabled'] = bool(await submit.count() and await submit.is_enabled())
        except Exception:
            pass
    return snapshot

async def wait_transaction_inquiry_screen_ready(page, settings):
    """Wait for stable TI form; classify rollback only after a persistent split state."""
    timeout = int(settings.get('transaction_inquiry_screen_ready_timeout_ms', 45000))
    poll_ms = int(settings.get('transaction_inquiry_screen_ready_poll_ms', 250))
    stable_required = int(settings.get('transaction_inquiry_screen_stable_polls', 3))
    rollback_required = int(settings.get('transaction_inquiry_rollback_stable_polls', 6))
    rollback_grace_ms = int(settings.get('transaction_inquiry_rollback_grace_ms', 2500))
    body_fragment = str(settings.get('transaction_inquiry_body_url_fragment', '/rolti/web/ti/ti-request')).lower()
    buttons_fragment = str(settings.get('transaction_inquiry_buttons_url_fragment', '/rolti/web/ti/ti-buttons')).lower()
    start_time = time.monotonic()
    deadline = start_time + timeout / 1000
    stable = 0
    rollback_stable = 0
    history = []
    LOGGER.info('STEP WAIT_TRANSACTION_INQUIRY_SCREEN_READY | observing bodyframe and buttons transitions')
    while time.monotonic() < deadline:
        state = await probe_transaction_inquiry_state(page)
        signature = (state['body_url'], state['buttons_url'], state['pan_visible'], state['start_visible'], state['submit_visible'], state['submit_enabled'])
        if not history or history[-1] != signature:
            history.append(signature)
            LOGGER.info('TI FRAME PROBE | body=%s | buttons=%s | pan=%s | start=%s | submit=%s | enabled=%s', state['body_url'], state['buttons_url'], state['pan_visible'], state['start_visible'], state['submit_visible'], state['submit_enabled'])
        body_ok = body_fragment in state['body_url'].lower()
        buttons_ok = buttons_fragment in state['buttons_url'].lower()
        ready = body_ok and buttons_ok and state['pan_visible'] and state['start_visible'] and state['submit_visible'] and state['submit_enabled']
        if ready:
            stable += 1
            rollback_stable = 0
            if stable >= stable_required:
                body = page.frame(name='bodyframe')
                LOGGER.info('PASS WAIT_TRANSACTION_INQUIRY_SCREEN_READY | stable_polls=%s | body=%s | buttons=%s', stable, state['body_url'], state['buttons_url'])
                return body
        else:
            stable = 0
            split = buttons_ok and 'action=invokehomepage' in state['body_url'].lower()
            elapsed_ms = int((time.monotonic() - start_time) * 1000)
            if split and elapsed_ms >= rollback_grace_ms:
                rollback_stable += 1
                LOGGER.warning('TI PARTIAL ROLLBACK PROBE | consecutive=%s/%s | elapsed_ms=%s', rollback_stable, rollback_required, elapsed_ms)
                if rollback_stable >= rollback_required:
                    raise UnknownScenario('TRANSACTION_INQUIRY_PARTIAL_ROLLBACK')
            else:
                rollback_stable = 0
        await page.wait_for_timeout(poll_ms)
    LOGGER.error('TRANSACTION INQUIRY SCREEN NOT READY | history=%s', history[-12:])
    raise UnknownScenario('TRANSACTION_INQUIRY_SCREEN_NOT_READY:' + repr(history[-8:]))

async def wait_vrol_landing_frames_stable(page, settings):
    """Wait until both legacy homepage frames are back and stable before reopening Inquiry."""
    timeout = int(settings.get('vrol_landing_frame_settle_timeout_ms', 20000))
    poll = int(settings.get('transaction_inquiry_screen_ready_poll_ms', 250))
    stable_required = int(settings.get('vrol_landing_frame_stable_polls', 4))
    body_fragment = str(settings.get('vrol_home_body_url_fragment', 'action=InvokeHomePage')).lower()
    buttons_fragment = str(settings.get('vrol_home_buttons_url_fragment', '/rolol/jsp/buttons_index.jsp')).lower()
    deadline = time.monotonic() + timeout / 1000
    stable = 0
    previous = None
    history = []
    while time.monotonic() < deadline:
        body = page.frame(name='bodyframe')
        buttons = None
        for frame in page.frames:
            if frame.name == 'buttons':
                buttons = frame
                break
        body_url = str(body.url or '') if body else ''
        buttons_url = str(buttons.url or '') if buttons else ''
        signature = (body_url, buttons_url)
        if not history or history[-1] != signature:
            history.append(signature)
            LOGGER.info('LANDING FRAME PROBE | body=%s | buttons=%s', body_url, buttons_url)
        ready = body_fragment in body_url.lower() and buttons_fragment in buttons_url.lower()
        if ready and signature == previous:
            stable += 1
        elif ready:
            stable = 1
        else:
            stable = 0
        previous = signature
        if stable >= stable_required:
            LOGGER.info('PASS WAIT_VROL_LANDING_FRAMES_STABLE | bodyframe=%s | buttons=%s | stable_polls=%s', body_url, buttons_url, stable)
            return
        await page.wait_for_timeout(poll)
    raise UnknownScenario('VROL_LANDING_FRAMES_NOT_STABLE:' + repr(history[-8:]))

async def open_transaction_inquiry(page, settings):
    for frame in page.frames:
        try:
            if await frame.locator('#CardNumber').count() and await frame.locator('#StartDate').count() and await frame.locator('#CardNumber').is_visible():
                LOGGER.info('TRANSACTION INQUIRY FORM REUSED | strategy=RESULTS_BACK | frame=%s | url=%s', frame.name, frame.url)
                return frame
        except Exception:
            pass
    # Results > Back is a local page transition, never a context-wide reset.
    for frame in page.frames:
        back=frame.locator('button#editButton[data-action="editQuery"]').first
        if await back.count() and await back.is_visible() and await back.is_enabled():
            await back.evaluate('el => { el.focus(); el.click(); }')
            return await reacquire_transaction_inquiry_form(page,settings,'RESULTS_BACK')
    await wait_vrol_landing_frames_stable(page, settings)
    timeout = int(settings.get('transaction_inquiry_navigation_timeout_ms', 30000))
    poll_ms = int(settings.get('transaction_inquiry_navigation_poll_ms', 250))
    deadline = time.monotonic() + timeout / 1000
    inquiry = None
    inquiry_frame = None
    while time.monotonic() < deadline and inquiry is None:
        for frame in page.frames:
            try:
                candidate = frame.locator('a#inquirymenua[name="inquirymenua"][role="menuitem"]')
                if await candidate.count():
                    await candidate.first.wait_for(state='attached', timeout=poll_ms)
                    if await candidate.first.is_visible():
                        inquiry = candidate.first
                        inquiry_frame = frame
                        break
            except Exception:
                continue
        if inquiry is None:
            await page.wait_for_timeout(poll_ms)
    if inquiry is None:
        raise UnknownScenario('INQUIRY_MENU_NOT_FOUND')
    await wait_for_manual_step(settings, 'OPEN_INQUIRY_MENU', 'Hover menu Inquiry', 'a#inquirymenua[name="inquirymenua"][role="menuitem"]', inquiry)
    LOGGER.info('STEP OPEN_INQUIRY_MENU | exact selector #inquirymenua | frame=%s', inquiry_frame.url)
    await inquiry.scroll_into_view_if_needed()
    await inquiry.hover(force=True)
    await inquiry.dispatch_event('mouseover')
    LOGGER.info('PASS OPEN_INQUIRY_MENU | Inquiry hovered')
    submenu = inquiry_frame.locator('a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]').first
    try:
        await submenu.wait_for(state='visible', timeout=timeout)
    except Exception:
        await inquiry.hover(force=True)
        await inquiry.dispatch_event('mouseover')
        await submenu.wait_for(state='visible', timeout=timeout)
    await wait_for_manual_step(settings, 'OPEN_TRANSACTION_INQUIRY', 'Click submenu Transaction Inquiry', 'a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]', submenu)
    LOGGER.info('STEP OPEN_TRANSACTION_INQUIRY | selector data-js=displayTranInquiry()')
    await submenu.click()
    LOGGER.info('PASS OPEN_TRANSACTION_INQUIRY | submenu clicked')
    try:
        return await wait_transaction_inquiry_screen_ready(page, settings)
    except UnknownScenario as exc:
        if str(exc) != 'TRANSACTION_INQUIRY_PARTIAL_ROLLBACK' or not str(settings.get('transaction_inquiry_retry_partial_rollback', 'YES')).strip().upper() in {'YES', 'Y', 'TRUE', '1'}:
            raise
        LOGGER.warning('Transaction Inquiry entered a partial rollback state. Reopening menu once after landing settles.')
        await wait_vrol_landing_frames_stable(page, settings)
        inquiry = page.locator('a#inquirymenua[name="inquirymenua"][role="menuitem"]').first
        await inquiry.wait_for(state='visible', timeout=timeout)
        await inquiry.hover(force=True)
        await inquiry.dispatch_event('mouseover')
        submenu = page.locator('a[data-js="displayTranInquiry()"][data-dropmenu="hidesubmenu"][role="menuitem"]').first
        await submenu.wait_for(state='visible', timeout=timeout)
        await submenu.click()
        LOGGER.info('PASS REOPEN_TRANSACTION_INQUIRY_AFTER_PARTIAL_ROLLBACK')
        return await wait_transaction_inquiry_screen_ready(page, settings)

async def _find_buttons_frame(page, settings):
    """Find the live buttons_index.jsp frame without depending on its variable title."""
    timeout = int(settings.get('transaction_inquiry_submit_timeout_ms', 10000))
    poll = int(settings.get('transaction_inquiry_navigation_poll_ms', 250))
    deadline = time.monotonic() + timeout / 1000
    observed = []
    while time.monotonic() < deadline:
        for frame in page.frames:
            frame_name = str(frame.name or '')
            frame_url = str(frame.url or '')
            signature = f'name={frame_name}; url={frame_url}'
            if signature not in observed:
                observed.append(signature)
            if frame_name != 'buttons' and '/rolol/jsp/buttons_index.jsp' not in frame_url:
                continue
            try:
                body = frame.locator('body#buttonBody')
                submit = frame.locator('button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]').first
                if await body.count() and await submit.count() and await body.is_visible() and await submit.is_visible():
                    return (frame, submit)
            except Exception:
                continue
        await page.wait_for_timeout(poll)
    LOGGER.error('BUTTONS FRAME DISCOVERY FAILED | observed=%s', observed)
    raise UnknownScenario('BUTTONS_FRAME_NOT_FOUND:' + ' | '.join(observed[-8:]))

async def click_transaction_inquiry_submit(page, settings):
    """Click only #submitButton in the live buttons_index.jsp frame."""
    frame, submit = await _find_buttons_frame(page, settings)
    if not await submit.is_enabled():
        raise UnknownScenario('TRANSACTION_INQUIRY_SUBMIT_DISABLED')
    selector_text = 'frame[name="buttons"] or frame[url*="/rolol/jsp/buttons_index.jsp"] >> body#buttonBody >> button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]'
    await wait_for_manual_step(settings, 'SUBMIT_TRANSACTION_INQUIRY', 'Click the Transaction Inquiry Submit button', selector_text, submit)
    LOGGER.info('STEP CLICK_TRANSACTION_INQUIRY_SUBMIT | frame_name=%s | frame_url=%s | selector=%s', frame.name, frame.url, selector_text)
    await submit.click(force=True)
    LOGGER.info('PASS CLICK_TRANSACTION_INQUIRY_SUBMIT')
    return True

async def wait_transaction_results(page, settings):
    """After Submit, reacquire bodyframe because VROL may replace/navigate the frame."""
    timeout = int(settings.get('transaction_results_timeout_ms', 45000))
    poll = int(settings.get('transaction_results_poll_ms', 250))
    deadline = time.monotonic() + timeout / 1000
    observed = []
    while time.monotonic() < deadline:
        registry=settings.get('_popup_registry')
        if registry:
            from .associated_transactions import find,AssociatedScreenDetected
            associated=await find(registry,page)
            if associated:raise AssociatedScreenDetected(associated)
        frame = page.frame(name='bodyframe')
        if frame:
            try:
                result = frame.locator('table#results').first
                error_text = await frame.locator('body').inner_text(timeout=500)
                if re.search(r'ROL-897\s*:\s*No matching transactions found', error_text, re.I):
                    return frame
                if await result.count() and await result.is_visible():
                    LOGGER.info('PASS WAIT_TRANSACTION_RESULTS | frame=%s | table#results visible', frame.url)
                    return frame
                marker = (await frame.locator('body').inner_text(timeout=300))[:120].replace('\n', ' ')
                if marker and marker not in observed:
                    observed.append(marker)
            except Exception:
                pass
        await page.wait_for_timeout(poll)
    raise UnknownScenario('TRANSACTION_RESULTS_NOT_REACHED:' + ' | '.join(observed[-3:]))

async def _highlight_locator(locator, settings):
    """Apply a reversible red border/outline to the exact next target."""
    enabled = str(settings.get('step_highlight_enabled', 'YES')).strip().upper()
    if enabled not in {'YES', 'Y', 'TRUE', '1'} or locator is None:
        return False
    try:
        target = locator.first
        await target.wait_for(state='visible', timeout=int(settings.get('step_highlight_timeout_ms', 5000)))
        await target.scroll_into_view_if_needed()
        await target.evaluate("element => {\n            if (!element.dataset.copilotOriginalStyle) {\n                element.dataset.copilotOriginalStyle = element.getAttribute('style') || '';\n            }\n            element.style.setProperty(\n                'border',\n                '2px solid #ff0000',\n                'important'\n            );\n        }")
        return True
    except Exception as exc:
        LOGGER.warning('STEP HIGHLIGHT FAILED | %s', exc)
        return False

async def _remove_highlight(locator):
    if locator is None:
        return
    try:
        await locator.first.evaluate("element => {\n            const original = element.dataset.copilotOriginalStyle;\n            if (original !== undefined) {\n                if (original) element.setAttribute('style', original);\n                else element.removeAttribute('style');\n                delete element.dataset.copilotOriginalStyle;\n            }\n        }")
    except Exception:
        pass

async def wait_for_manual_step(settings, step_code, description, selector_text, locator=None):
    """Show exact selector, highlight target in red, and wait for Enter."""
    enabled = str(settings.get('step_by_step_manual_trigger_enabled', 'YES')).strip().upper()
    if enabled not in {'YES', 'Y', 'TRUE', '1'}:
        LOGGER.info('MANUAL STEP GATE SKIPPED | %s | disabled', step_code)
        return
    configured = str(settings.get('step_by_step_trigger_steps', 'ALL') or 'ALL').strip()
    allowed = {item.strip().upper() for item in configured.split('|') if item.strip()}
    if 'ALL' not in allowed and step_code.upper() not in allowed:
        LOGGER.info('MANUAL STEP GATE SKIPPED | %s | not configured', step_code)
        return
    highlighted = await _highlight_locator(locator, settings)
    LOGGER.info('MANUAL STEP READY | %s | %s | selector=%s | highlighted=%s', step_code, description, selector_text, highlighted)
    prompt = f"\n[{step_code}] {description}\nExact selector: {selector_text}\nRed highlight applied: {('YES' if highlighted else 'NO')}\nPlease confirm the highlighted target in Chrome.\nPress ENTER to execute this step... "
    await asyncio.to_thread(input, prompt)
    await _remove_highlight(locator)
    LOGGER.info('MANUAL STEP TRIGGERED | %s | selector=%s', step_code, selector_text)

async def reacquire_transaction_inquiry_form(page, settings, checkpoint):
    """Just-in-time probe and reacquire bodyframe immediately before form actions."""
    timeout = int(settings.get('transaction_inquiry_reacquire_timeout_ms', 15000))
    settle_ms = int(settings.get('transaction_inquiry_pre_action_settle_ms', 1000))
    poll_ms = int(settings.get('transaction_inquiry_screen_ready_poll_ms', 250))
    expected_fragment = str(settings.get('transaction_inquiry_body_url_fragment', '/rolti/web/ti/ti-request')).lower()
    await page.wait_for_timeout(settle_ms)
    deadline = time.monotonic() + timeout / 1000
    observed = []
    while time.monotonic() < deadline:
        frame = page.frame(name='bodyframe')
        if frame:
            url = str(frame.url or '')
            try:
                pan = frame.locator('#CardNumber').first
                start = frame.locator('#StartDate').first
                valid = expected_fragment in url.lower() and await pan.count() and await start.count() and await pan.is_visible() and await start.is_visible()
                signature = f'checkpoint={checkpoint}; url={url}; pan={await pan.count()}; start={await start.count()}'
                if signature not in observed:
                    observed.append(signature)
                if valid:
                    LOGGER.info('PASS REACQUIRE_TRANSACTION_INQUIRY_FORM | checkpoint=%s | frame=%s', checkpoint, url)
                    return frame
            except Exception as exc:
                observed.append(f'checkpoint={checkpoint}; {type(exc).__name__}:{str(exc)[:100]}')
        await page.wait_for_timeout(poll_ms)
    LOGGER.error('TRANSACTION INQUIRY FORM LOST | checkpoint=%s | page=%s | observed=%s', checkpoint, page.url, observed[-6:])
    raise UnknownScenario('TRANSACTION_INQUIRY_FORM_LOST_BEFORE_' + checkpoint.upper())

async def fill_transaction_inquiry_pan(page, pan, settings):
    """Reacquire the live bodyframe and fill PAN without using a stale locator."""
    frame = await reacquire_transaction_inquiry_form(page, settings, 'ENTER_FULL_PAN')
    field = frame.locator('#CardNumber').first
    await wait_for_manual_step(settings, 'ENTER_FULL_PAN', 'Fill the configured full PAN', '#CardNumber', field)
    LOGGER.info('STEP ENTER_FULL_PAN | frame=%s | filling masked PAN', frame.url)
    await field.fill(str(pan).strip(), timeout=int(settings.get('transaction_inquiry_field_timeout_ms', 10000)))
    await field.dispatch_event('input')
    await field.dispatch_event('change')
    LOGGER.info('PASS ENTER_FULL_PAN | frame=%s', frame.url)
    return frame

async def fill_transaction_inquiry_start_date(page, start_date, settings):
    """Reacquire again before Start Date because VROL may replace bodyframe."""
    frame = await reacquire_transaction_inquiry_form(page, settings, 'ENTER_START_DATE')
    value = normalize_start_date(start_date)
    field = frame.locator('#StartDate').first
    await wait_for_manual_step(settings, 'ENTER_START_DATE', f'Fill Start Date: {value}', '#StartDate', field)
    LOGGER.info('STEP ENTER_START_DATE | frame=%s | value=%s', frame.url, value)
    await field.fill(value, timeout=int(settings.get('transaction_inquiry_field_timeout_ms', 10000)))
    await field.dispatch_event('input')
    await field.dispatch_event('change')
    await field.evaluate('(element) => element.blur()')
    LOGGER.info('PASS ENTER_START_DATE | frame=%s | value=%s', frame.url, value)
    return (frame, value)

async def find_transaction_id_filter(frame, settings):
    """Find DataTables header filter from the whole summary frame, not table#results."""
    timeout = int(settings.get('transaction_id_filter_timeout_ms', 15000))
    poll = int(settings.get('transaction_results_poll_ms', 250))
    deadline = time.monotonic() + timeout / 1000
    selectors = ['#dtheaderSearch input.search-box[aria-label="Transaction ID / Retrieval Ref #"]', '#dtheaderSearch input[aria-label*="Transaction ID / Retrieval"]', '.dataTables_scrollHead input.search-box[aria-label*="Transaction ID"]']
    observed = []
    while time.monotonic() < deadline:
        live = frame.page.frame(name='bodyframe') or frame
        for selector in selectors:
            try:
                loc = live.locator(selector).first
                count = await loc.count()
                signature = f'{selector}:count={count}'
                if signature not in observed:
                    observed.append(signature)
                if count and await loc.is_visible() and await loc.is_enabled():
                    LOGGER.info('TRANSACTION ID FILTER FOUND | selector=%s | frame=%s', selector, live.url)
                    return (live, loc, selector)
            except Exception as exc:
                observed.append(f'{selector}:{type(exc).__name__}')
        try:
            loc = live.get_by_role('textbox', name=re.compile('Transaction\\s*ID\\s*/\\s*Retrieval', re.I)).first
            if await loc.count() and await loc.is_visible() and await loc.is_enabled():
                selector = 'role=textbox[name~="Transaction ID / Retrieval"]'
                LOGGER.info('TRANSACTION ID FILTER FOUND | selector=%s | frame=%s', selector, live.url)
                return (live, loc, selector)
        except Exception:
            pass
        await frame.page.wait_for_timeout(poll)
    LOGGER.error('TRANSACTION ID FILTER NOT FOUND | frame=%s | observed=%s', frame.url, observed[-12:])
    raise UnknownScenario('TRANSACTION_ID_FILTER_NOT_FOUND')

async def _visible_transaction_ids(frame):
    """Read visible Transaction ID cell values without invoking the full business parser."""
    rows = visible_rows(frame)
    result = []
    # Read one DOM snapshot, rather than thousands of awaited calls for a
    # 500-row result table while five workers compete for the renderer.
    raw_values=await rows.evaluate_all('(rows)=>rows.map(r=>r.children[23]?.innerText||"")')
    for raw in raw_values:
        transaction_id, _ = split_transaction_ref(raw)
        if transaction_id:
            result.append(transaction_id)
    return result

async def _invoice_filter_is_applied(frame, invoice):
    ids = await _visible_transaction_ids(frame)
    if not ids:
        return (False, ids)
    return (all((transaction_id_matches_invoice(value, invoice) for value in ids)), ids)

async def _wait_invoice_filter_effect(frame, invoice, timeout_ms, poll_ms=250):
    """Wait until every visible transaction row belongs to the normalized Invoice."""
    deadline = time.monotonic() + timeout_ms / 1000
    previous = None
    stable = 0
    while time.monotonic() < deadline:
        applied, ids = await _invoice_filter_is_applied(frame, invoice)
        signature = tuple(ids)
        if applied and signature == previous:
            stable += 1
        elif applied:
            stable = 1
        else:
            stable = 0
        previous = signature
        if applied and stable >= 2:
            return ids
        await frame.page.wait_for_timeout(poll_ms)
    return None

async def wait_datatables_ready_for_invoice_filter(frame, settings):
    """Wait until DataTables rows and the filter DOM node are stable before typing."""
    timeout = int(settings.get('invoice_filter_ready_timeout_ms', 30000))
    poll = int(settings.get('invoice_filter_ready_poll_ms', 250))
    stable_required = int(settings.get('invoice_filter_ready_stable_polls', 4))
    deadline = time.monotonic() + timeout / 1000
    stable = 0
    previous = None
    history = []
    node_token = 'copilot-invoice-filter-' + str(int(time.time() * 1000))
    LOGGER.info('STEP WAIT_INVOICE_FILTER_READY | waiting for stable table rows and filter input')
    while time.monotonic() < deadline:
        live, search, selector = await find_transaction_id_filter(frame, settings)
        rows = visible_rows(live)
        row_ids = tuple(await rows.evaluate_all('(rows)=>rows.map((r,i)=>r.id||String(i))'))
        try:
            processing = live.locator('.dataTables_processing:visible, #results_processing:visible')
            processing_visible = bool(await processing.count())
            state = await search.evaluate('(element, token) => {\n                if (!element.dataset.copilotStabilityToken) {\n                    element.dataset.copilotStabilityToken = token;\n                }\n                const rect=element.getBoundingClientRect();\n                return {\n                    token: element.dataset.copilotStabilityToken,\n                    connected: element.isConnected,\n                    width: Math.round(rect.width),\n                    height: Math.round(rect.height),\n                    value: element.value\n                };\n            }', node_token)
            signature = (str(live.url or ''), row_ids, state['token'], state['connected'], state['width'], state['height'], processing_visible)
            ready = await rows.count() > 0 and state['connected'] and (state['width'] > 0) and (state['height'] > 0) and (not processing_visible)
            if ready and signature == previous:
                stable += 1
            elif ready:
                stable = 1
            else:
                stable = 0
            previous = signature
            if not history or history[-1] != signature:
                history.append(signature)
                LOGGER.info('INVOICE FILTER READY PROBE | rows=%s | token=%s | connected=%s | size=%sx%s | processing=%s | stable=%s/%s', await rows.count(), state['token'], state['connected'], state['width'], state['height'], processing_visible, stable, stable_required)
            if ready and stable >= stable_required:
                LOGGER.info('PASS WAIT_INVOICE_FILTER_READY | rows=%s | selector=%s | stable_polls=%s', await rows.count(), selector, stable)
                return (live, search, selector)
        except Exception as exc:
            stable = 0
            history.append(('error', type(exc).__name__, str(exc)[:120]))
        await frame.page.wait_for_timeout(poll)
    raise UnknownScenario('INVOICE_FILTER_NOT_STABLE_BEFORE_INPUT:' + repr(history[-8:]))

async def _reacquire_and_reset_invoice_filter(frame, invoice, settings):
    """Reacquire a possibly replaced DataTables input and reset the full Invoice value."""
    live, search, selector = await find_transaction_id_filter(frame, settings)
    await search.fill(invoice)
    return (live, search, selector)

async def apply_invoice_filter(frame, invoice, settings):
    """Wait for stable DataTables, type Invoice, verify effect, and recover from node replacement."""
    inv = normalize_invoice_number(invoice)
    live, search, selector = await wait_datatables_ready_for_invoice_filter(frame, settings)
    await wait_for_manual_step(settings, 'FILTER_INVOICE', f'Filter Transaction ID by Invoice: {inv}', selector, search)
    timeout = int(settings.get('invoice_filter_effect_timeout_ms', 5000))
    typing_delay = int(settings.get('invoice_filter_typing_delay_ms', 60))
    # Fill the complete value, then emit the same commit events as sync's recovery.
    # This avoids interleaved Control+A/type keyboard focus across worker tabs.
    await search.fill(inv)
    await search.evaluate("el => { el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.blur(); }")
    typed_value = await search.input_value()
    if typed_value != inv:
        LOGGER.warning('INVOICE KEYBOARD INPUT INTERRUPTED | expected=%s | actual=%s | reacquiring filter', inv, typed_value)
    else:
        ids = await _wait_invoice_filter_effect(live, inv, timeout)
        if ids is not None:
            rows = await wait_stable_visible_rows(live, int(settings.get('single_test_results_timeout_ms', 20000)))
            LOGGER.info('PASS FILTER_INVOICE | strategy=STABLE_KEYBOARD_TYPE | invoice_search=%s | visible_ids=%s | visible_rows=%s', inv, ids, await rows.count())
            return (live, inv, rows)
    live, search, selector = await _reacquire_and_reset_invoice_filter(live, inv, settings)
    await search.press('Enter')
    await search.dispatch_event('change')
    await search.evaluate('(element) => element.blur()')
    ids = await _wait_invoice_filter_effect(live, inv, timeout)
    if ids is not None:
        rows = await wait_stable_visible_rows(live, int(settings.get('single_test_results_timeout_ms', 20000)))
        LOGGER.info('PASS FILTER_INVOICE | strategy=REACQUIRE_FULL_VALUE_ENTER_CHANGE_BLUR | invoice_search=%s | visible_ids=%s | visible_rows=%s', inv, ids, await rows.count())
        return (live, inv, rows)
    LOGGER.warning('INVOICE FILTER DID NOT APPLY AFTER REACQUIRE/COMMIT | value=%s | visible_ids=%s', await search.input_value(), await _visible_transaction_ids(live))
    live, search, selector = await find_transaction_id_filter(live, settings)
    await search.evaluate("(element, value) => {\n        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;\n        setter.call(element, value);\n        element.dispatchEvent(new Event('input', {bubbles: true}));\n        element.dispatchEvent(new KeyboardEvent('keydown', {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}));\n        element.dispatchEvent(new KeyboardEvent('keyup', {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}));\n        element.dispatchEvent(new Event('change', {bubbles: true}));\n        element.blur();\n    }", inv)
    ids = await _wait_invoice_filter_effect(live, inv, timeout)
    if ids is not None:
        rows = await wait_stable_visible_rows(live, int(settings.get('single_test_results_timeout_ms', 20000)))
        LOGGER.info('PASS FILTER_INVOICE | strategy=REACQUIRED_NATIVE_EVENT_SEQUENCE | invoice_search=%s | visible_ids=%s | visible_rows=%s', inv, ids, await rows.count())
        return (live, inv, rows)
    ids=await _visible_transaction_ids(live)
    if not ids and await search.input_value()==inv:
        text=await live.locator('body').inner_text(timeout=2000)
        if re.search(r'\b300\+\s+Transactions?\s+Found|first\s+300\s+matching\s+transactions',text,re.I):
            raise UnknownScenario('INVOICE_NOT_IN_TRUNCATED_TRANSACTION_RESULTS:Visa returned only its first 300 matches; no Sale/PI conclusion is safe')
    raise UnknownScenario('INVOICE_FILTER_NOT_APPLIED:' + f'value={await search.input_value()};visible_ids={ids}')

def normalize_start_date(value):
    """Nguồn Excel cố định YYYYMMDD; chuyển duy nhất sang MM/DD/YY cho VROL."""
    from datetime import datetime
    text = str(value or '').strip()
    try:
        return datetime.strptime(text, '%Y%m%d').strftime('%m/%d/%y')
    except ValueError as exc:
        raise UnknownScenario('SINGLE_TEST_START_DATE_INVALID_YYYYMMDD') from exc

def normalize_invoice_number(value):
    """Invoice dùng để search Transaction ID: trim và bỏ toàn bộ số 0 đầu."""
    raw = str(value or '').strip()
    if not raw:
        raise UnknownScenario('SINGLE_TEST_INVOICE_MISSING')
    normalized = raw.lstrip('0')
    if not normalized:
        raise UnknownScenario('SINGLE_TEST_INVOICE_INVALID')
    return normalized
