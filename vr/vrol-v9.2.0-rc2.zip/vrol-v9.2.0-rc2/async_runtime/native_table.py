"""Async DOM reads with the same confirmed 31-column schema as sync."""
import re, time
from src.vrol.transaction_table import (TransactionRow, TableContractError, norm,
    validate_confirmed_schema, split_transaction_ref, transaction_id_matches_invoice, EXPECTED_HEADER_BY_INDEX)

def visible_rows(frame):
    return frame.locator('table#results tbody > tr[data-action="summaryGridRow"]:visible')

async def schema_from_dom(frame):
    values=await frame.locator('table#results thead > tr').first.locator(':scope > th').evaluate_all('(headers) => headers.map(h => h.innerText)')
    if not values:raise TableContractError('TRANSACTION_TABLE_HEADER_NOT_FOUND')
    headers=[norm(x) for x in values]
    for index,expected in EXPECTED_HEADER_BY_INDEX.items():
        if index<len(headers) and re.sub(r'\s+','',headers[index]).casefold()==re.sub(r'\s+','',expected):
            headers[index]=expected
    return headers

async def parse_row_for_code(row,headers,code):
    schema=validate_confirmed_schema(headers,code)
    # The table/row can be visible while Visa is still appending its TDs.
    # Never classify a partially rendered row as a different business scenario.
    try:await row.locator(':scope > td').nth(30).wait_for(state='attached',timeout=10000)
    except Exception as exc:raise TableContractError('TRANSACTION_ROW_CELLS_NOT_READY') from exc
    # One browser round trip for all cells, rather than one request per cell.
    snapshot=await row.evaluate('(el) => ({id: el.id, frameName: window.name, frameUrl: location.href, cells: Array.from(el.children).filter(x => x.tagName === "TD").map(x => x.innerText)})')
    cells=snapshot['cells']
    if len(cells)<31:raise TableContractError(f'TRANSACTION_TABLE_LAYOUT_UNSUPPORTED:{len(headers)}:{len(cells)}')
    values={name:norm(cells[index]) for name,index in schema.items()}
    transaction_id,ref=split_transaction_ref(values['transaction_ref'])
    # Stable ID locators remain valid when DataTables changes visible row ordering.
    row_id=snapshot.get('id','')
    if row_id and re.fullmatch(r'[A-Za-z0-9_:.-]+',row_id):
        owners=[f for f in row.page.frames if f.name==snapshot['frameName'] and f.url==snapshot['frameUrl']]
        if len(owners)!=1:raise TableContractError('TRANSACTION_FRAME_IDENTITY_NOT_UNIQUE')
        row=owners[0].locator(f'table#results tr[id="{row_id}"]')
    return TransactionRow(row,values,transaction_id,ref)

async def wait_stable_visible_rows(frame,timeout_ms=10000,poll_ms=250):
    deadline=time.monotonic()+timeout_ms/1000;previous=None;stable=0
    while time.monotonic()<deadline:
        rows=visible_rows(frame)
        signature=await rows.evaluate_all('(rows) => rows.map(r => [r.id,r.innerText])')
        stable=stable+1 if signature==previous else 0;previous=signature
        if stable>=2:return rows
        await frame.page.wait_for_timeout(poll_ms)
    raise TableContractError('TRANSACTION_FILTER_NOT_STABLE')

async def reacquire_transaction(page,tx,item,settings,*,filter_invoice=True):
    """Never act on an nth() locator saved while another invoice was filtered."""
    from .native_ui import apply_invoice_filter
    frame=page.frame(name='bodyframe')
    if frame is None:raise TableContractError('TRANSACTION_BODYFRAME_LOST')
    if filter_invoice:frame,_,rows=await apply_invoice_filter(frame,item['invoice'],settings)
    else:rows=frame.locator('table#results tbody tr[data-action="summaryGridRow"]')
    headers=await schema_from_dom(frame);matches=[]
    for index in range(await rows.count()):
        current=await parse_row_for_code(rows.nth(index),headers,item['code'])
        if current.transaction_id==tx.transaction_id and current.tran_type==tx.tran_type:
            matches.append(current)
    if len(matches)!=1:raise TableContractError(f'TRANSACTION_IDENTITY_NOT_UNIQUE:{tx.transaction_id}:{len(matches)}')
    return matches[0]
