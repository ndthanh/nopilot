"""Run lifecycle and an OS-held process lock, independent of per-tab concurrency."""
import asyncio
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

VIETNAM = timezone(timedelta(hours=7))


def now():return datetime.now(VIETNAM).isoformat(timespec='seconds')


class RunLock:
    def __init__(self, path):self.path = Path(path); self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open('a+b')
        self.handle.seek(0, 2)
        if self.handle.tell() == 0:self.handle.write(b' '); self.handle.flush()
        self.handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.handle.close(); self.handle = None
            raise RuntimeError('VROL_ALREADY_RUNNING: wait for the active process to finish') from exc
        return self

    def __exit__(self, *args):
        if self.handle:self.handle.close()


class RunMonitor:
    def __init__(self, folder):
        self.folder = Path(folder); self.folder.mkdir(parents=True, exist_ok=True)
        self.data = dict(run_id=self.folder.name, status='RUNNING', stage='STARTING',
                         started_at=now(), pid=os.getpid(), run_dir=str(self.folder))
        self.update()

    def update(self, **data):
        self.data.update(data, heartbeat_at=now())
        path = self.folder / 'run_state.json'; temp = path.with_suffix('.tmp')
        try:
            temp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(path)
        except OSError:
            # A transient OneDrive/read lock must not kill the heartbeat task.
            return False
        return True

    def sample_resources(self):
        """Chrome/Python CPU+RAM every heartbeat, to size the worker count."""
        try:import psutil
        except ImportError:return
        try:
            chrome=[p for p in psutil.process_iter(['name','memory_info']) if (p.info['name'] or '').lower().startswith('chrome')]
            me=psutil.Process()
            row=dict(t=now(),cpu_total_pct=psutil.cpu_percent(None),ram_used_pct=psutil.virtual_memory().percent,
                     chrome_processes=len(chrome),chrome_rss_mb=round(sum(p.info['memory_info'].rss for p in chrome if p.info['memory_info'])/2**20),
                     python_rss_mb=round(me.memory_info().rss/2**20),stage=self.data.get('stage'))
            (self.folder/'logs').mkdir(exist_ok=True)
            with (self.folder/'logs'/'resources.jsonl').open('a',encoding='utf-8') as handle:handle.write(json.dumps(row)+'\n')
            return row
        except Exception:return

    async def heartbeat(self):
        while True:
            await asyncio.sleep(5)
            self.update()
            row=await asyncio.to_thread(self.sample_resources)
            dashboard=getattr(self,'dashboard',None)
            if dashboard:await asyncio.to_thread(dashboard.snapshot,dict(self.data),row)
