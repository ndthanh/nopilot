"""Scope legacy named windows to the worker without sharing a popup mutex."""
import json
import uuid

SCRIPT = r'''(explicitOwner) => {
 let owner=explicitOwner;
 if (!owner) {
   const match=(window.name||'').match(/^__VROL_SCOPE__([A-Za-z0-9_]+)__/);
   if(match) owner=match[1];
   for(const source of [window.parent, window.opener]) {
     try { if(!owner && source && source!==window) owner=source.__vrolPopupOwner; } catch(e) {}
   }
 }
 if(!owner || window.__vrolPopupOwner===owner) return;
 if(window.__vrolPopupOwner) throw new Error('POPUP_SCOPE_CONFLICT');
 window.__vrolPopupOwner=owner;
 const prefix='__VROL_SCOPE__'+owner+'__';
 const targetFor=(target, opening) => {
   target=String(target||'');
   if(/^_(self|parent|top)$/i.test(target)) return target;
   if(!target || target.toLowerCase()==='_blank') return opening ? '_blank' : target;
   if(target.startsWith(prefix)) return target;
   // Existing frame names are navigation targets, not popup names.
   try { if(window.top.frames[target]) return target; } catch(e) {}
   return prefix+target;
 };
 const originalOpen=window.open;
 window.open=function(url,target,features) {
   return Reflect.apply(originalOpen,this,[url,targetFor(target,true),features]);
 };
 const patchForm=form => { if(form.target) form.target=targetFor(form.target,false); };
 const originalSubmit=HTMLFormElement.prototype.submit;
 HTMLFormElement.prototype.submit=function() {patchForm(this);return Reflect.apply(originalSubmit,this,[]);};
 document.addEventListener('submit',e=>patchForm(e.target),true);
 document.addEventListener('click',e=>{const a=e.target.closest && e.target.closest('a[target]');if(a)a.target=targetFor(a.target,false);},true);
}'''

def context_script():
    return '('+SCRIPT+')(null);'

async def install(page, worker):
    owner=worker+'_'+uuid.uuid4().hex[:10]
    script='('+SCRIPT+')('+json.dumps(owner)+');'
    await page.add_init_script(script=script)
    for frame in page.frames:
        await frame.evaluate(SCRIPT,owner)
    return owner
