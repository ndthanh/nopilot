import time,re,asyncio,json
from pathlib import Path
from datetime import datetime
from .models import WorkerState,RuntimeEvent,GuidGroup
from .native_engine import run_native_group
from .outcomes import needs_review
from .guid_markers import classify,write_markers,start_guid
from .guid_folders import finalize_folder
from .session import SharedSessionExpired
from .evidence_names import code_token
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
_TABLE_CONSOLE=Console()
# Legacy observability labels retained for compatibility: INPUT GROUP | GUID= ; BOT DECISION |

from .jsonio import atomic_write_json,read_json_safe
from .outcome_policy import side_effect_state,outcome_class

def can_retry_read_only(saved):
    return not side_effect_state(saved)

def _append_guid_log(path,level,message):
    stamp=datetime.now().strftime('%d.%m.%Y %H:%M:%S.%f')[:-3]
    with Path(path).open('a',encoding='utf-8') as handle:
        handle.write(f'[{stamp}] [{level.upper()}] {message}\n')

def _guid_banner(state,group,phase,status=''):
    stamp=datetime.now().strftime('%d.%m.%Y %H:%M:%S')
    value=f'{phase} | worker={state.worker_id} | GUID={group.guid} | time={stamp}'
    if status:value+=f' | status={status}'
    _TABLE_CONSOLE.print(Panel.fit(value,title=f'GUID CASE {phase}',border_style='bright_blue' if phase=='START' else ('red' if needs_review({'status':status}) else 'bright_green')))
async def screenshot_all(state,tag):
 paths=[]
 for pi,p in enumerate(state.registry.pages(state.page) if state.registry else state.page.context.pages,1):
  if p.is_closed():continue
  out=state.artifact_dir/f'{state.worker_id}_{state.current.guid}_{code_token(state.current.items)}_{tag}_page{pi:02d}.png'
  try:await p.screenshot(path=str(out),full_page=True,timeout=5000);paths.append(str(out))
  except Exception:pass
 return paths
def normalize_ti_start_date_legacy(value):
    # Exact v9.0.60 contract: source must be YYYYMMDD; VROL receives MM/DD/YY.
    text=str(value or '').strip()
    if not re.fullmatch(r'\d{8}',text):
        raise RuntimeError(f'TI_INPUT_START_DATE_INVALID_YYYYMMDD:{text}')
    try:
        return datetime.strptime(text,'%Y%m%d').strftime('%m/%d/%y')
    except ValueError as exc:
        raise RuntimeError(f'TI_INPUT_START_DATE_INVALID_YYYYMMDD:{text}') from exc

async def fill_legacy_field(locator,value,blur=False):
    await locator.fill(value)
    await locator.dispatch_event('input')
    await locator.dispatch_event('change')
    if blur:
        await locator.evaluate('(element) => element.blur()')

async def find_live_ti_submit(page,timeout_ms=10000):
 deadline=time.monotonic()+timeout_ms/1000;observed=[]
 selector='button#submitButton.allbuttons[data-action="doSubmit"][accesskey="s"]'
 while time.monotonic()<deadline:
  for frame in page.frames:
   try:
    body=frame.locator('body#buttonBody').first
    submit=frame.locator(selector).first
    signature=(frame.name,frame.url,await submit.count())
    if signature not in observed:observed.append(signature)
    if await body.count() and await body.is_visible() and await submit.count() and await submit.is_visible():
     return frame,submit
   except Exception:pass
  await page.wait_for_timeout(100)
 raise RuntimeError('TI_SUBMIT_BUTTON_NOT_FOUND:'+repr(observed[-8:]))

async def back_to_transaction_inquiry(state,log):
    """Async parity of v9.0.60 _back_to_transaction_inquiry."""
    page=state.page;settings=state.settings or {}
    selector='button#editButton[data-action="editQuery"]'
    frames=[]
    exact=page.frame(name='buttons')
    if exact is not None:frames.append(exact)
    for frame in page.frames:
        if frame not in frames and ('buttons_index.jsp' in (frame.url or '') or 'ti-buttons' in (frame.url or '')):frames.append(frame)
    for frame in page.frames:
        if frame not in frames:frames.append(frame)
    observed=[]
    for frame in frames:
        try:
            back=frame.locator(selector).first
            count=await back.count();visible=bool(count and await back.is_visible());enabled=bool(count and await back.is_enabled())
            observed.append({'name':frame.name,'url':frame.url,'count':count,'visible':visible,'enabled':enabled})
            if not (count and visible and enabled):continue
            log('info',f'{state.worker_id} results Back exact button found | selector={selector} | frame={frame.url}')
            await back.evaluate('el => { el.focus(); el.click(); }')
            log('info',f'{state.worker_id} results Back click dispatched | strategy=DOM_CLICK | frame={frame.url}')
            deadline=time.monotonic()+int(settings.get('transaction_results_back_timeout_ms') or 7000)/1000
            stable=0
            while time.monotonic()<deadline:
                request_frame=None
                for live in page.frames:
                    try:
                        pan=live.locator('#CardNumber').first;date=live.locator('#StartDate').first
                        if await pan.count() and await date.count() and await pan.is_visible() and await date.is_visible():
                            request_frame=live;break
                    except Exception:pass
                if request_frame is not None:
                    stable+=1
                    if stable>=2:
                        log('success',f'{state.worker_id} results Back to Transaction Inquiry | strategy=DOM_CLICK | request_frame={request_frame.url}')
                        return request_frame
                else:stable=0
                await page.wait_for_timeout(100)
            raise RuntimeError('RESULTS_BACK_TRANSITION_TIMEOUT:'+repr(observed))
        except RuntimeError:
            raise
        except Exception as exc:
            observed.append({'name':getattr(frame,'name',''),'url':getattr(frame,'url',''),'error':str(exc)})
    raise RuntimeError('RESULTS_BACK_EXACT_BUTTON_NOT_FOUND:'+repr(observed))

async def ensure_transaction_inquiry_form(state,log):
    page=state.page
    for frame in page.frames:
        try:
            pan=frame.locator('#CardNumber').first;date=frame.locator('#StartDate').first
            if await pan.count() and await date.count() and await pan.is_visible() and await date.is_visible():
                return frame
        except Exception:pass
    # A worker remains on its previous result table. Follow sync v9.0.60 and click exact Back.
    return await back_to_transaction_inquiry(state,log)

async def inquiry(state,group,log):
 page=state.page;body=await ensure_transaction_inquiry_form(state,log);buttons=page.frame(name='buttons')
 if not body or not buttons:raise RuntimeError('TI_FRAMES_NOT_FOUND')
 pan=body.locator('#CardNumber').first;date=body.locator('#StartDate').first;submit=buttons.locator('button#submitButton').first
 await pan.wait_for(state='visible',timeout=10000);await date.wait_for(state='visible',timeout=10000);await submit.wait_for(state='visible',timeout=10000)
 full_pan=''.join(ch for ch in (group.full_pan or '') if ch.isdigit())
 raw_start_date=group.start_date
 start_date=normalize_ti_start_date_legacy(raw_start_date)
 if not full_pan:raise RuntimeError('TI_INPUT_PAN_EMPTY_MAPPING_NOT_LOADED')
 if len(full_pan)<12 or len(full_pan)>19:raise RuntimeError(f'TI_INPUT_PAN_INVALID_LENGTH:{len(full_pan)}')
 await fill_legacy_field(pan,full_pan)
 # Follow sync v9.0.60: reacquire live bodyframe, fill MM/DD/YY, dispatch input/change, then blur.
 body=page.frame(name='bodyframe')
 if not body:raise RuntimeError('TI_BODYFRAME_LOST_BEFORE_DATE')
 date=body.locator('#StartDate').first
 await date.wait_for(state='visible',timeout=10000)
 await fill_legacy_field(date,start_date,True)
 actual_date=(await date.input_value()).strip()
 if actual_date!=start_date:raise RuntimeError(f'TI_START_DATE_NOT_APPLIED:expected={start_date}:actual={actual_date}')
 # Follow v9.0.60 exactly: locate live buttonBody frame, require enabled, then force-click.
 buttons,submit=await find_live_ti_submit(page,10000)
 if not await submit.is_enabled():raise RuntimeError('TRANSACTION_INQUIRY_SUBMIT_DISABLED')
 log('info',f'{state.worker_id} inquiry submit | GUID={group.guid} | PAN={full_pan[:6]}...{full_pan[-4:]} | StartDate={start_date} | frame={buttons.url}')
 before_body=page.frame(name='bodyframe').url if page.frame(name='bodyframe') else ''
 await submit.click(force=True)
 log('success',f'{state.worker_id} submit clicked | GUID={group.guid} | force=true')
 deadline=time.monotonic()+45
 while time.monotonic()<deadline:
  body=page.frame(name='bodyframe')
  if body and await body.locator('table#results').count():return body
  try:
   txt=await body.locator('body').inner_text() if body else ''
   if 'ROL-897' in txt:return None
  except Exception:pass
  await page.wait_for_timeout(250)
 raise RuntimeError('TRANSACTION_RESULTS_TIMEOUT')
def mask_pan(value):
 digits_only=''.join(ch for ch in str(value or '') if ch.isdigit())
 if len(digits_only)>=10:return f'{digits_only[:6]}...{digits_only[-4:]}'
 return str(value or '') or 'UNKNOWN'
def group_dates(group):return ','.join(group.dates) if group.dates else 'UNKNOWN'
def group_invoices(group):return ','.join(str(item.get('invoice') or '') for item in group.items if item.get('invoice')) or 'NONE'
async def capture_decision(state,group,tag):
 out=state.artifact_dir/f'{state.worker_id}_{group.guid}_{code_token(group.items)}_{tag}.png'
 try:await state.page.screenshot(path=str(out),full_page=True,timeout=5000);return [str(out)]
 except Exception:return await screenshot_all(state,tag)

def print_group_input_table(state,group,masked,dates,invoices):
 t=Table(title=f'{state.worker_id} | GUID INPUT',show_header=False,box=None,padding=(0,1))
 t.add_column(style='cyan',width=12);t.add_column(style='white')
 t.add_row('GUID',group.guid);t.add_row('Masked PAN',masked);t.add_row('Dates',dates)
 t.add_row('Invoices',invoices);t.add_row('Rows',','.join(map(str,group.source_rows)))
 t.add_row('Folder',str(state.artifact_dir))
 _TABLE_CONSOLE.print(Panel(t,border_style='blue'))

def print_group_output_table(state,group,result,shots,elapsed):
 t=Table(title=f'{state.worker_id} | GUID OUTPUT',show_header=False,box=None,padding=(0,1))
 t.add_column(style='cyan',width=14);t.add_column(style='white',overflow='fold')
 t.add_row('Completed',datetime.now().strftime('%d.%m.%Y %H:%M'))
 t.add_row('GUID',group.guid);t.add_row('Status',str(result.get('status') or ''))
 t.add_row('Decision',str(result.get('decision') or result.get('status') or ''))
 t.add_row('Category',str(result.get('outcome_category') or ''))
 t.add_row('Action stage',str(result.get('outcome_action_stage') or ''))
 t.add_row('Reason',str(result.get('reason_code') or ''))
 t.add_row('ROL Case',str(result.get('rol') or ''))
 t.add_row('Questionnaire','FILLED - FINAL NOT SUBMITTED' if result.get('status')=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT' else 'N/A')
 invoice_results=result.get('invoice_results') or []
 if invoice_results:
  for index,item in enumerate(invoice_results,1):
   invoice=str(item.get('invoice') or item.get('invoice_input') or item.get('invoice_raw') or 'UNKNOWN')
   pi_status=str(item.get('pi_status') or '')
   pi_file=str(item.get('pi_file') or '')
   outcome=str(item.get('status') or item.get('decision') or item.get('reason_code') or pi_status or 'PROCESSED')
   detail=f'{invoice} -> {outcome}'
   if pi_file:detail+=f' -> {pi_file}'
   t.add_row(f'Invoice {index}',detail)
 elif result.get('status')=='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION':
  t.add_row('Invoices','PI downloaded; see documents subfolders')
 t.add_row('Elapsed',f'{elapsed:.1f}s');t.add_row('GUID Folder',str(state.artifact_dir))
 if shots:t.add_row('Evidence',str(shots[0]))
 _TABLE_CONSOLE.print(Panel(t,border_style='red' if needs_review(result) else 'green'))

def finalize_guid_artifacts(state,group,result,detail,shots,elapsed):
    from .business_status import result_label
    result['business_result']=result_label(result)
    result['input_am_force']=any(x.get('input_am_force') for x in group.items)
    result['upstream_filter_overridden']=any(x.get('upstream_filter_overridden') for x in group.items)
    status=str(result.get('status') or '')
    decision=str(result.get('decision') or status)
    reason=str(result.get('reason_code') or '')
    review_required=needs_review(result)
    result['outcome_class']=outcome_class(result)
    outcome=classify(result,group)
    try:current=finalize_folder(state,group.guid,outcome['category'],result,shots)
    except OSError as exc:
        # Keep the unprefixed folder; a lock must not lose the GUID result.
        current=Path(state.artifact_dir);result['folder_finalize_error']=f'{type(exc).__name__}: {exc}'
    result['outcome_category']=outcome['category']
    result['outcome_action_stage']=outcome['action_stage']
    payload={'guid':group.guid,'worker':state.worker_id,'status':status,'decision':decision,'reason_code':reason,'detail':detail,'elapsed_seconds':round(elapsed,3),'review_required':review_required,'folder':str(current),'screenshots':shots,'completed_at':datetime.now().strftime('%d.%m.%Y %H:%M:%S'),'result':result}
    payload['outcome']=outcome
    payload['marker_files']=write_markers(current,payload,outcome)
    # Review outcomes after a Visa side effect reach AM via the ledger (no hold folder).
    # Publish only final paths: screenshots, PI manifests and Excel share them.
    atomic_write_json(current/'group_result.json',result)
    atomic_write_json(current/'guid_result.json',payload)
    return payload

def _minimal_failure_record(state,group,result,detail,shots,elapsed,exc):
    """Last-resort record when artifact finalization itself failed."""
    result=dict(result,artifact_error=f'{type(exc).__name__}: {exc}')
    result['outcome_class']=outcome_class(result)
    payload={'guid':group.guid,'worker':state.worker_id,'status':result.get('status',''),'decision':result.get('decision',''),
             'reason_code':result.get('reason_code',''),'detail':detail,'elapsed_seconds':round(elapsed,3),'review_required':True,
             'folder':str(state.artifact_dir),'screenshots':shots,'completed_at':datetime.now().strftime('%d.%m.%Y %H:%M:%S'),'result':result}
    try:atomic_write_json(Path(state.artifact_dir)/'guid_result.json',payload)
    except OSError:pass
    return payload

async def finalize_safely(state,group,result,detail,shots,elapsed,log):
    try:return await asyncio.to_thread(finalize_guid_artifacts,state,group,result,detail,shots,elapsed)
    except Exception as exc:
        log('error',f'{state.worker_id} ARTIFACT FINALIZE FAILED | GUID={group.guid} | {type(exc).__name__}: {exc}')
        return _minimal_failure_record(state,group,result,detail,shots,elapsed,exc)

async def process_group(state,group,event_q,popup_sem,log):
 state.current=group;state.stage='PRECHECK'
 group_root=Path(str(state.settings.get('_async_run_dir')))/'groups'/group.guid
 group_root.mkdir(parents=True,exist_ok=True);state.artifact_dir=group_root
 (group_root/'documents').mkdir(exist_ok=True)
 start_guid(group_root,group.guid)
 (group_root/'guid_state.json').write_text(json.dumps(dict(guid=group.guid,worker=state.worker_id,status='RUNNING',stage='PRECHECK',folder=str(group_root),started_at=datetime.now().astimezone().isoformat(),source_rows=group.source_rows),ensure_ascii=False,indent=2),encoding='utf-8')
 masked=mask_pan(group.full_pan or group.masked_pan);dates=group_dates(group);invoices=group_invoices(group);started=time.monotonic()
 def group_log(kind,message):
  tagged=f'[{state.worker_id}] [GUID={group.guid}] {message}'
  _append_guid_log(state.artifact_dir/'guid_case.log',kind,tagged)
  log(kind,tagged)
 _guid_banner(state,group,'START')
 group_log('stage',f'CASE START | folder={state.artifact_dir}')
 print_group_input_table(state,group,masked,dates,invoices)
 group_log('stage',f'INPUT | PAN={masked} | transaction_dates={dates} | invoices={invoices} | source_rows={group.source_rows}')
 await event_q.put(RuntimeEvent('CASE_ASSIGNED',state.worker_id,group.guid,data={'source_rows':group.source_rows,'masked_pan':masked,'transaction_dates':group.dates}))
 history_file=group_root/'case_retry_history.json'
 case_retries=json.loads(history_file.read_text(encoding='utf-8')) if history_file.exists() else []
 read_retries=0
 try:
  # Prefix-5 groups were already removed while building the Excel queue.
  if state.settings.get('async_backend','native_async')=='legacy_bridge':
   from .sync_parity_engine import run_full_group
   await ensure_transaction_inquiry_form(state,log)
   marker=f'ASYNC_{state.worker_id}_{group.guid}'
   await state.page.evaluate('(v) => window.name=v',marker)
   cdp_url=f'http://127.0.0.1:{int(state.settings.get("async_cdp_port") or 9222)}'
   result=await asyncio.to_thread(run_full_group,cdp_url,marker,group,state.settings,state.artifact_dir,group_log,state.worker_id)
  else:
   budget=min(1800,180+45*len(group.items))
   while True:
    try:
     result=await asyncio.wait_for(run_native_group(state.page,state.registry,group,state.settings,state.artifact_dir,group_log),budget)
     if case_retries:result.update(case_retry_count=len(case_retries),case_retry_history=case_retries)
     break
    except SharedSessionExpired:raise
    except Exception as retry_error:
     saved=read_json_safe(state.artifact_dir/'case_checkpoint.json',{}) or {}
     if not state.session:raise
     from .case_retry import may_retry_case,archive_retry
     if not case_retries and may_retry_case(retry_error,saved):
      case_retries.append(await archive_retry(state,retry_error,saved))
      group_log('warning',f'CASE CHAIN RETRY 1/1 | reason={str(retry_error).split(":",1)[0]} | previous_rol={saved.get("rol") or "-"} | Final Submit has not been dispatched; a new case may get a new ROL')
     elif not case_retries and not read_retries and can_retry_read_only(saved):
      read_retries+=1
      group_log('warning','READ-ONLY RETRY 1/1 | fresh worker tab; no Issuer Action dispatched')
     else:raise
     from .browser import open_vrol_worker_tab_from_portal
     from .native_ui import open_transaction_inquiry
     from .popup_scope import install
     await state.registry.cleanup(state.page)
     old=state.page
     try:await asyncio.wait_for(old.close(),5)
     except Exception:pass
     state.registry.forget(old)
     t_tab=time.monotonic()
     async with state.session.tab_lock:
      state.page=await open_vrol_worker_tab_from_portal(state.session.snapshot().portal,state.settings,state.worker_id)
      state.registry.register(state.page,state.worker_id)
      await install(state.page,state.worker_id)
      await open_transaction_inquiry(state.page,state.settings)
     retry_tab_s=round(time.monotonic()-t_tab,2)
  shots=await capture_decision(state,group,result.get('status','RESULT'))
  evidence=[result.get('questionnaire_screenshot'),result.get('final_submit_screenshot'),result.get('associated_transactions_screenshot')]
  evidence+=result.get('final_submit_screenshots',[])+result.get('duplicate_screenshots',[])
  shots=list(dict.fromkeys([x for x in evidence if x]+shots))
  detail=f'GUID={group.guid} | PAN={masked} | transaction_dates={dates} | status={result.get("status")} | decision={result.get("decision")} | reason={result.get("reason_code")}'
  elapsed=time.monotonic()-started
  group_log('warning' if needs_review(result) else 'success',f'OUTPUT | {detail} | folder={state.artifact_dir} | screenshots={shots}')
  result.setdefault('timings',{})['guid_total_s']=round(elapsed,2)
  result['timings']['read_retries']=read_retries;result['timings']['case_retries']=len(case_retries)
  final_record=await finalize_safely(state,group,result,detail,shots,elapsed,log)
  print_group_output_table(state,group,result,shots,elapsed)
  log('warning' if final_record['review_required'] else 'success',f'{state.worker_id} GUID FOLDER FINALIZED | GUID={group.guid} | review_required={str(final_record["review_required"]).lower()} | folder={state.artifact_dir}')
  _guid_banner(state,group,'END',str(result.get('status') or ''))
  await event_q.put(RuntimeEvent('CASE_RESULT',state.worker_id,group.guid,result.get('status',''),result.get('reason_code',''),detail,'NEXT',{'source_rows':group.source_rows,'screenshots':shots,'result':result,'deferred_rows':group.deferred_rows,'review_keys':[x.get('review_key','') for x in group.items if x.get('review_key')],'updates':{'BOT GROUP DECISION':result.get('decision') or result.get('status'),'BOT GROUP REASON CODE':result.get('reason_code'),'BOT GROUP REASON DETAIL':result.get('reason_detail') or detail,'BOT WORKER':state.worker_id}}))
 except SharedSessionExpired:
  raise
 except Exception as exc:
  state.tab_cases=25
  shots=await screenshot_all(state,'UNDEFINED_CASE_WORKER_EXCEPTION')
  failure=dict(getattr(exc,'partial_result',{}),status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='ROL_1545_DUPLICATE_SELECTED_CARD_TRANSACTION_MCSN' if 'ROL_1545' in str(exc) else 'WORKER_ENGINE_EXCEPTION',reason_detail=str(exc))
  if case_retries:failure.update(case_retry_count=len(case_retries),case_retry_history=case_retries)
  code=str(exc).split(':',1)[0].strip()
  if failure['reason_code']=='WORKER_ENGINE_EXCEPTION' and re.fullmatch(r'[A-Z][A-Z0-9_]+',code):failure['reason_code']=code
  saved=read_json_safe(state.artifact_dir/'case_checkpoint.json',None)
  if saved is not None:
   failure['case_checkpoint']=saved
   for key in ('rol','final_submit_clicked','issuer_action_clicked','issuer_action'):
    if key in saved:failure[key]=saved[key]
   if isinstance(exc,asyncio.TimeoutError) and str(saved.get('stage','')).startswith('QUESTIONNAIRE_'):
    failure['reason_code']='QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT'
  detail=f'GUID={group.guid} | PAN={masked} | status={failure["status"]} | reason={failure["reason_code"]} | error={type(exc).__name__}: {exc}'
  elapsed=time.monotonic()-started
  group_log('error',f'OUTPUT | {detail} | folder={state.artifact_dir} | screenshots={shots}')
  failure['timings']=dict(guid_total_s=round(elapsed,2),read_retries=read_retries,case_retries=len(case_retries))
  final_record=await finalize_safely(state,group,failure,detail,shots,elapsed,log)
  print_group_output_table(state,group,failure,shots,elapsed)
  log('warning',f'{state.worker_id} GUID FOLDER FINALIZED | GUID={group.guid} | review_required=true | folder={state.artifact_dir}')
  _guid_banner(state,group,'END','LOGIC_REVIEW_REQUIRED')
  await event_q.put(RuntimeEvent('CASE_RESULT',state.worker_id,group.guid,failure['status'],failure['reason_code'],detail,'NEXT',{'source_rows':group.source_rows,'screenshots':shots,'result':failure,'updates':{'BOT GROUP DECISION':failure['decision'],'BOT GROUP REASON CODE':failure['reason_code'],'BOT GROUP REASON DETAIL':detail,'BOT WORKER':state.worker_id}}))
 finally:
  if state.registry:
   from .associated_transactions import on_page
   try:
    await asyncio.wait_for(state.registry.cleanup(state.page),30)
    if not state.page.is_closed() and await asyncio.wait_for(on_page(state.page),3):
     await asyncio.wait_for(state.page.close(),5)
   except Exception:pass
  state.current=None;state.stage='IDLE' 
async def worker_loop(state,queue,event_q,popup_sem,log):
 log('success',f'{state.worker_id} loop started | pending={queue.qsize()}')
 while True:
  group=await queue.get()
  try:
   if group is None:
    log('info',f'{state.worker_id} loop stopped');return
   attempts=0
   while True:
    try:
     if state.session:
      async with state.session.lease() as snapshot:
       if state.generation!=snapshot.generation or state.page.is_closed() or state.page in state.registry.crashed or getattr(state,'tab_cases',0)>=25:
        from .browser import open_vrol_worker_tab_from_portal
        from .native_ui import open_transaction_inquiry
        async with state.session.tab_lock:
         old=state.page
         if state.generation==snapshot.generation:
          try:await asyncio.wait_for(old.close(),5)
          except Exception:pass
          state.registry.forget(old)
         state.page=await open_vrol_worker_tab_from_portal(snapshot.portal,state.settings,state.worker_id)
         state.registry=state.session.registry;state.registry.register(state.page,state.worker_id)
         from .popup_scope import install
         await install(state.page,state.worker_id)
         state.tab_cases=0
         state.generation=snapshot.generation
         await open_transaction_inquiry(state.page,state.settings)
       await process_group(state,group,event_q,popup_sem,log)
       state.tab_cases=getattr(state,'tab_cases',0)+1
     else:await process_group(state,group,event_q,popup_sem,log)
     break
    except SharedSessionExpired:
     attempts+=1
     if not state.session or attempts>1:raise
     log('warning',f'{state.worker_id} session expired before case side effect; relogin and retry current GUID once')
     await state.session.relogin_once(state.generation)
    except asyncio.CancelledError:raise
    except Exception as exc:
     # Contain any per-GUID failure (tab reopen, artifacts, cleanup) so the
     # remaining queue keeps running and this GUID still gets a CASE_RESULT.
     log('error',f'{state.worker_id} GUID CONTAINED FAILURE | GUID={getattr(group,"guid","")} | {type(exc).__name__}: {exc}')
     state.tab_cases=25
     result=dict(status='LOGIC_REVIEW_REQUIRED',decision='LOGIC_REVIEW_REQUIRED',reason_code='WORKER_CONTAINED_FAILURE',reason_detail=f'{type(exc).__name__}: {exc}')
     cp=read_json_safe(Path(str(state.settings.get('_async_run_dir')))/'groups'/group.guid/'case_checkpoint.json',None)
     if cp:result['case_checkpoint']=cp
     result['outcome_class']=outcome_class(result)
     await event_q.put(RuntimeEvent('CASE_RESULT',state.worker_id,group.guid,result['status'],result['reason_code'],result['reason_detail'],'NEXT',{'source_rows':group.source_rows,'screenshots':[],'result':result,'updates':{'BOT GROUP DECISION':result['status'],'BOT GROUP REASON CODE':result['reason_code'],'BOT GROUP REASON DETAIL':result['reason_detail'],'BOT WORKER':state.worker_id}}))
     break
  finally:queue.task_done()
