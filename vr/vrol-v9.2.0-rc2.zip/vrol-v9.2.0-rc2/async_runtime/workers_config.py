"""Resolve worker count from Excel, with an optional CMD/CLI override."""
def positive_integer(value,key,default):
    if value is None or value=='':return default
    if isinstance(value,bool):raise ValueError(f'{key}_MUST_BE_A_POSITIVE_INTEGER')
    try:
        number=int(value)
        if number<1 or float(value)!=number:raise ValueError()
    except (ValueError,TypeError,OverflowError):
        raise ValueError(f'{key}_MUST_BE_A_POSITIVE_INTEGER') from None
    return number

def resolve_workers(settings,cli=None):
    configured=positive_integer(settings.get('async_worker_count'),'async_worker_count',3)
    cap=positive_integer(settings.get('async_worker_max'),'async_worker_max',5)
    requested=positive_integer(cli,'workers',configured)
    return dict(configured=configured,cap=cap,requested=requested,effective=min(requested,cap),capped=requested>cap)
