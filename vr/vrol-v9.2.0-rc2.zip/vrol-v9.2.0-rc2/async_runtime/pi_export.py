"""Publish the completed run's aggregate PI folder with a business-date name."""
import hashlib,json,os
from pathlib import Path
from datetime import date
from openpyxl import load_workbook
from .pi_artifacts import _atomic_copy
from .guid_folders import rebase
from .xlsx_patch import patch_cells

def _rebase_artifacts(run,old,new,workbook):
    # Workers and the Excel writer have stopped. Do not rewrite active logs,
    # heartbeat files, frozen XLSX inputs or the original business master.
    for path in list(run.rglob('*.json'))+list(run.rglob('*.jsonl')):
        if path.name in {'run_state.json','input_contract.json','pi_documents_export.json'}:continue
        content=path.read_text(encoding='utf-8-sig')
        if str(old) not in content.replace('\\\\','\\') and old.as_posix() not in content:continue
        if path.suffix=='.jsonl':
            updated='\n'.join(json.dumps(rebase(json.loads(line),old,new),ensure_ascii=False) for line in content.splitlines() if line.strip())+'\n'
        else:updated=json.dumps(rebase(json.loads(content),old,new),ensure_ascii=False,indent=2)
        temp=path.with_suffix(path.suffix+'.pi.tmp');temp.write_text(updated,encoding='utf-8');os.replace(temp,path)
    if workbook and Path(workbook).is_file():
        wb=load_workbook(workbook);patches={}
        try:
            ws=wb['Sheet1']
            for row in ws:
                for cell in row:
                    if isinstance(cell.value,str) and cell.data_type!='f':
                        value=rebase(cell.value,old,new)
                        if value!=cell.value:patches[cell.coordinate]=value
            if patches:
                temp=Path(workbook).with_suffix('.pi.tmp.xlsx');patch_cells(workbook,temp,'Sheet1',patches,wb.epoch);os.replace(temp,workbook)
        finally:wb.close()

def export_documents(run_dir,settings,workbook=None,*,postflight_status='SUCCESS'):
    run=Path(run_dir).resolve();source=run/'documents'
    report=dict(status='SKIPPED_NOT_CONFIGURED',local_path=str(source),export_path=None,copied=0,identical=0)
    raw=str(settings.get('pi_documents_export_dir') or '').strip()
    try:
        if not raw:return report
        destination=Path(raw).expanduser()
        if not destination.is_absolute():destination=Path(settings.get('_config_path') or run).parent/destination
        if not destination.is_dir():report['status']='SKIPPED_DESTINATION_NOT_FOUND';return report
        if postflight_status!='SUCCESS':report['status']='SKIPPED_POSTFLIGHT_NOT_SUCCESS';return report
        day=date.fromisoformat(str(settings['_run_business_date'])).strftime('%Y%m%d')
        local=run/(day+'_documents');target=(destination/(day+'_documents')).resolve()
        if target.is_relative_to(run):raise ValueError('PI_EXPORT_DESTINATION_INSIDE_RUN')
        current=source if source.is_dir() else local
        if local.exists() and source.exists():raise ValueError('PI_DATED_FOLDER_ALREADY_EXISTS')
        files=sorted(path for path in current.rglob('*') if path.is_file()) if current.is_dir() else []
        if not files:report['status']='SKIPPED_EMPTY';return report
        report['export_path']=str(target)
        # Preflight all collisions before copying anything. Same-date runs can
        # share identical files; differing PDFs are never silently replaced.
        work=[]
        for path in files:
            if not path.resolve().is_relative_to(current.resolve()):raise ValueError('PI_EXPORT_SYMLINK_OUTSIDE_DOCUMENTS')
            dest=target/path.relative_to(current);sha=hashlib.sha256(path.read_bytes()).hexdigest()
            if dest.exists():
                if not dest.is_file() or hashlib.sha256(dest.read_bytes()).hexdigest()!=sha:raise ValueError('PI_EXPORT_FILENAME_CONFLICT:'+dest.name)
                report['identical']+=1
            else:work.append((path,dest,sha))
        for path,dest,sha in work:_atomic_copy(path,dest,dict(sha256=sha));report['copied']+=1
        if source.exists():source.rename(local)
        report['local_path']=str(local)
        _rebase_artifacts(run,source,local,workbook)
        report.update(status='EXPORTED',file_count=len(files))
    except Exception as exc:
        report.update(status='FAILED',error=type(exc).__name__+': '+str(exc))
    finally:
        (run/'pi_documents_export.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
