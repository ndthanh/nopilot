"""Crash-safe JSON files: write to a temp file, fsync, then atomically replace."""
import json, os, time
from pathlib import Path


def atomic_write_json(path, data, *, retries=5):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    payload = json.dumps(data, ensure_ascii=False, indent=2, default=str)
    with temp.open('w', encoding='utf-8') as handle:
        handle.write(payload); handle.flush(); os.fsync(handle.fileno())
    for attempt in range(retries):
        try:
            os.replace(temp, path); return path
        except PermissionError:
            # Windows: antivirus/indexer/OneDrive may hold the target briefly.
            if attempt == retries - 1:
                temp.unlink(missing_ok=True); raise
            time.sleep(0.2 * (2 ** attempt))


def read_json_safe(path, default=None):
    """Return ``default`` for a missing, locked or half-written file instead of raising."""
    try:
        return json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return default
