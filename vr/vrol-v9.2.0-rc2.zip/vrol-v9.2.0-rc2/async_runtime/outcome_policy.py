"""One place that decides what a GUID result means for the business record.

Three classes drive AM/ledger/registry behaviour:

* BUSINESS_FINAL - a real business outcome (PI, NO_CB, Assoc D, FRAUD/consumer draft
  or confirmed submit). Written to AM and the ledger.
* USER_REVIEW    - a person must look (300+, several Sale/Cash, Associated
  Transactions, ROL-1537, anything after a case side effect). Written to AM.
* TRANSIENT      - a technical failure before any case side effect (timeouts,
  UI not stable, worker exceptions). NOT written to AM; retried automatically
  by later runs until ``max_attempts`` is reached.
* CHECKPOINT     - diagnostic stops (inquiry-only / pi-only). Never written.
"""
from .outcomes import COMPLETED, CHECKPOINTS

BUSINESS_FINAL = 'BUSINESS_FINAL'
USER_REVIEW = 'USER_REVIEW'
TRANSIENT = 'TRANSIENT'
CHECKPOINT = 'CHECKPOINT'

# Business-meaningful stops that a person must handle; retrying cannot change them.
USER_REVIEW_REASONS = {
    'TRANSACTION_RESULTS_TRUNCATED_300_PLUS', 'INVOICE_NOT_IN_TRUNCATED_TRANSACTION_RESULTS',
    'ELIGIBLE_ROW_NOT_UNIQUE', 'ASSOCIATED_TRANSACTIONS_SCREEN', 'ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY',
    'ROL_1545_DUPLICATE_SELECTED_CARD_TRANSACTION_MCSN', 'ROL_897_NO_MATCHING_TRANSACTIONS',
    'UNDEFINED_ASSOC_DISPUTE_VALUE', 'UNDEFINED_ISSUER_ACTION_FOR_MIXED_CODES',
    'EXISTING_CASE_REQUIRES_QUESTIONNAIRE_REVIEW', 'GUID_PAN_MAPPING_NOT_FOUND',
    'QUESTIONNAIRE_SCREEN_NAME_MISMATCH', 'QUESTIONNAIRE_INVOICE_MISMATCH',
    'QUESTIONNAIRE_MASKED_CARD_MISMATCH', 'QUESTIONNAIRE_TRANSACTION_DATE_MISMATCH',
}
REVIEW_STATUSES = {'ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED', 'CASE_RECONCILIATION_REQUIRED',
                   'FINAL_SUBMIT_REJECTED', 'FINAL_SUBMIT_FORM_ERROR', 'FINAL_SUBMIT_RECONCILIATION_REQUIRED'}
_SIDE_EFFECT_PREFIXES = ('CASE_CREATION_', 'QUESTIONNAIRE_', 'FINAL_SUBMIT_', 'ROL_749_')
_SIDE_EFFECT_STAGES = {'ISSUER_ACTION_DISPATCHING', 'CASE_TRANSITION_REVIEW_REQUIRED', 'STOPPED_AT_ASSOCIATED_TRANSACTIONS'}


def side_effect_state(checkpoint):
    """True once anything may exist on Visa for this GUID (case, draft, submit)."""
    checkpoint = checkpoint or {}
    if any(checkpoint.get(k) for k in ('issuer_action_clicked', 'rol', 'vrol_case_number', 'submit_dispatched', 'final_submit_clicked')):
        return True
    stage = str(checkpoint.get('stage') or '')
    return stage.startswith(_SIDE_EFFECT_PREFIXES) or stage in _SIDE_EFFECT_STAGES


def has_side_effect(result):
    return side_effect_state(result) or side_effect_state(result.get('case_checkpoint'))


def outcome_class(result):
    status = str(result.get('status') or '')
    reason = str(result.get('reason_code') or '')
    if status in CHECKPOINTS:
        return CHECKPOINT
    if any(x.get('pi_status') == 'DOWNLOADED' for x in result.get('invoice_results') or []):
        return BUSINESS_FINAL
    if status in COMPLETED:
        return BUSINESS_FINAL
    if has_side_effect(result) or status in REVIEW_STATUSES or reason in USER_REVIEW_REASONS:
        return USER_REVIEW
    return TRANSIENT
