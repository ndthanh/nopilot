"""Configure this Visa installation independently of the dashboard."""
import argparse,shutil
from pathlib import Path
from openpyxl import load_workbook

def configure(root,*,otp=None,contracts=None,workers=5,migration=None):
    root=Path(root).resolve()
    if not 1<=workers<=9:raise ValueError('WORKERS_MUST_BE_1_TO_9')
    config=root/'config.xlsx'
    if not config.exists():shutil.copy2(root/'config.sample.xlsx',config)
    shutil.copy2(config,root/'config.before_paths.xlsx')
    otp=Path(otp or root/'OTP'/'inbox').resolve()
    contracts=Path(contracts or root/'runtime'/'ops_inputs').resolve()
    values=dict(classified_case_file=str(root/'09_chargeback_classified.xlsx'),
        batch_test_classified_file=str(root/'09_chargeback_classified.xlsx'),async_enriched_workbook='',
        guid_pan_mapping_file=str(root/'input.txt'),batch_test_guid_pan_mapping_file=str(root/'input.txt'),
        user_data_dir=str(root/'browser_profile'),otp_folder_path=str(otp),case_reviewed_guid_file=str(root/'reviewed_guids.txt'),
        async_worker_count=workers,async_worker_max=max(5,workers),async_restart_after_guids=100,
        rol500_preflight_enabled='YES',rol500_postflight_enabled='YES',scheduled_contract_dir=str(contracts))
    defaults=dict(scheduled_source_not_before='19:30',scheduled_input_wait_seconds=1800,scheduled_input_poll_seconds=10,
                  async_master_writeback_enabled='YES',async_master_workbook='',business_state_retention_days=180,pi_documents_export_dir='')
    wb=load_workbook(config);ws=wb['Settings'];rows={str(ws.cell(r,1).value or '').strip():r for r in range(2,ws.max_row+1)}
    for key,value in (values|{k:v for k,v in defaults.items() if k not in rows}).items():
        if key in rows:ws.cell(rows[key],2,value)
        else:ws.append([key,value,'Production setup'])
    target=root/'config.paths.tmp.xlsx';wb.save(target);wb.close();target.replace(config)
    otp.mkdir(parents=True,exist_ok=True);contracts.mkdir(parents=True,exist_ok=True)
    if migration:
        migration=Path(migration).resolve();source=migration/'reviewed_guids.txt'
        if not source.is_file():raise ValueError('MIGRATION_REGISTRY_NOT_FOUND')
        registry=root/'reviewed_guids.txt'
        existing=set(registry.read_text(encoding='utf-8-sig').splitlines()) if registry.is_file() else set()
        if registry.exists():shutil.copy2(registry,root/'reviewed_guids.before_migration.txt')
        registry.write_text('\n'.join(sorted(x for x in existing|set(source.read_text(encoding='utf-8-sig').splitlines()) if x.strip()))+'\n',encoding='utf-8')
        holds=root/'runtime'/'review_holds';holds.mkdir(parents=True,exist_ok=True)
        for source in (migration/'review_holds').glob('*.json'):
            if not (holds/source.name).exists():shutil.copy2(source,holds/source.name)
    # Credentials, trace preference and Final Submit switch are preserved.
    return config

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--otp-dir');p.add_argument('--contract-dir');p.add_argument('--workers',type=int,default=5)
    p.add_argument('--migration-state-dir',help='Optional reviewed registry/holds from the private production handoff')
    args=p.parse_args();root=Path(__file__).resolve().parents[1]
    result=configure(root,otp=args.otp_dir,contracts=args.contract_dir,workers=args.workers,migration=args.migration_state_dir)
    print('Configured:',result)
    print('Enter credentials / SecurityQuestions in config.xlsx; Final Submit stays at its existing value.')
    print('Schedule run_scheduled.cmd at 19:40; upstream publishes READY contracts to runtime/ops_inputs by default.')

if __name__=='__main__':main()
