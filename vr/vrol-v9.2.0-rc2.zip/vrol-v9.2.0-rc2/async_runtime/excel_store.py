from pathlib import Path
from datetime import date, datetime, timedelta, timezone
import json, os, re, shutil
from openpyxl import load_workbook
from .models import GuidGroup
from .outcomes import COMPLETED
from src.io.group_review_output import review_key

DEFAULT_CASE_SHEET = 'Sheet1'
VIETNAM = timezone(timedelta(hours=7))
def business_date(): return datetime.now(VIETNAM).date()
def clean(v): return str(v if v is not None else '').strip()
def digits(v): return re.sub(r'\D', '', clean(v))
def read_registry(path):
    path=Path(path)
    return {x.strip().upper() for x in path.read_text(encoding='utf-8-sig').splitlines() if x.strip()} if path.exists() else set()

def load_groups(path, mapping=None, *, run_date=None, reviewed=None, requested_guids=None, blocked=None):
    """Whole-GUID ROL500 exclusion, then 15 < age < 120 and sync input rules."""
    run_date=date.fromisoformat(run_date) if isinstance(run_date,str) else run_date or business_date()
    mapping={clean(k).upper():digits(v) for k,v in (mapping or {}).items()}
    reviewed={clean(x).upper() for x in (reviewed or set())}
    requested={clean(x).upper() for x in requested_guids} if requested_guids is not None else None
    found=set();requested_source={};blocked={clean(k).upper():v for k,v in (blocked or {}).items()};pan_conflicts=set()
    stats=dict.fromkeys(['rows','eligible','sale','valid','rol500_existing','rol500_groups_skipped','ti_date_too_young','ti_date_too_old','ti_date_future','ti_date_invalid','pan_prefix_5_groups_filtered','pan_prefix_5_rows_filtered','reviewed_rows_skipped'],0)
    stats.update(run_business_date=run_date.isoformat(),exclusions=[])
    wb=load_workbook(path,data_only=True,read_only=True)
    try:
        if DEFAULT_CASE_SHEET not in wb.sheetnames:raise RuntimeError('CASE_SHEET_NOT_FOUND:Sheet1')
        ws=wb[DEFAULT_CASE_SHEET]
        h={clean(v).upper():i for i,v in enumerate(next(ws.iter_rows(min_row=2,max_row=2,values_only=True))) if v is not None}
        required={'GUID','BUT TOAN','NGAY GD','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'}
        if required-h.keys():raise RuntimeError('CASE_REVIEW_MISSING_HEADERS:'+','.join(sorted(required-h.keys())))
        # AM is a whole-GUID gate, even if the marked row itself is HOLD or
        # outside the date window. User-entered SKIP is handled by the same gate.
        # Precedence per GUID: SKIP > FORCE > any other AM value (bot result or note).
        # FORCE therefore re-runs a GUID that already carries an old bot result.
        marked=set();forced=set();skipped=set()
        for row in ws.iter_rows(min_row=4,values_only=True):
            if len(row)>=39 and clean(row[38]):
                value=clean(row[38]).upper();row_guid=clean(row[h['GUID']]).upper()
                (forced if value=='FORCE' else skipped if value=='SKIP' else marked).add(row_guid)
        forced-=skipped
        marked=(marked|skipped)-forced
        stats['am_marked_groups_skipped']=len(marked);stats['blocked_groups']=len(blocked)
        stats['am_force_groups']=len(forced)
        stats['am_force_guids']=sorted(forced & requested if requested is not None else forced)
        raw={}
        for row_no,row in enumerate(ws.iter_rows(min_row=4,values_only=True),4):
            stats['rows']+=1
            def get(name):return row[h[name]] if name in h and h[name]<len(row) else None
            row_guid=clean(get('GUID')).upper()
            if requested is not None and row_guid not in requested:continue
            if row_guid:found.add(row_guid)
            if row_guid in marked:
                stats['exclusions'].append(dict(row_no=row_no,guid=row_guid,reason='INPUT_AM_ALREADY_MARKED'));continue
            if row_guid in blocked:
                stats['exclusions'].append(dict(row_no=row_no,guid=row_guid,reason=blocked[row_guid]));continue
            explicit=requested is not None or row_guid in forced
            if explicit:
                entry=requested_source.setdefault(row_guid,dict(codes=set(),source_rows=[],upstream_values=set()))
                entry['codes'].add(clean(get('CODE CB')));entry['source_rows'].append(row_no);entry['upstream_values'].add(clean(get('VALID CHARGEBACK')).upper())
            sale,valid,rol=clean(get('CHECK SALE')).upper(),clean(get('VALID CHARGEBACK')).upper(),clean(get('BOT ROL500 STATUS')).upper()
            stats['sale']+=sale=='SALE';stats['valid']+=valid=='Y';stats['rol500_existing']+=rol=='ALREADY_CHARGEBACK_IN_ROL500'
            guid,qt,invoice=clean(get('GUID')).upper(),clean(get('BUT TOAN')),clean(get('INVOICENUM'))
            code=clean(get('CODE CB'));code=code[:-2] if code.endswith('.0') else code
            if sale!='SALE' or (valid!='Y' and not explicit) or not guid:
                reason='MISSING_GUID' if not guid else ('INPUT_CHECK_SALE_NOT_SALE' if sale!='SALE' else 'UPSTREAM_VALID_CHARGEBACK_NOT_Y')
                stats['exclusions'].append(dict(row_no=row_no,guid=guid,reason=reason));continue
            if not qt or not invoice or code not in {'10.4','13.1','13.9'}:
                stats['exclusions'].append(dict(row_no=row_no,guid=guid,reason='INVALID_CASE_INPUT'));continue
            mapped,provided=mapping.get(guid,''),digits(get('FULL PAN'))
            if mapped and provided and mapped!=provided:
                # Exclude this GUID only; one bad row must not stop the whole run.
                pan_conflicts.add(guid);stats['exclusions'].append(dict(row_no=row_no,guid=guid,reason='GUID_PAN_SOURCE_CONFLICT'));continue
            g=raw.setdefault(guid,dict(guid=guid,masked_pan=clean(get('PAN')) or clean(get('CARD NUMBER')),full_pan=mapped if explicit else mapped or provided,dates=[],items=[],source_rows=[],deferred_rows=[],rol_existing=False))
            g['rol_existing']|=rol=='ALREADY_CHARGEBACK_IN_ROL500'
            g['items'].append(dict(row_no=row_no,invoice=invoice,qt=qt,code=code,date=clean(get('NGAY GD')),start_date=clean(get('NGAY GD')),merchant=clean(get('TERMOWNER')),termowner=clean(get('TERMOWNER')),
                                  user_requested=explicit,input_am_force=guid in forced,upstream_valid_chargeback=valid,upstream_filter_overridden=explicit and valid!='Y'))
        result=[]
        for guid,g in sorted(raw.items()):
            reason=''
            if guid in pan_conflicts:
                g.pop('rol_existing',None);reason='GUID_PAN_SOURCE_CONFLICT'
            elif g.pop('rol_existing'):reason='ALREADY_CHARGEBACK_IN_ROL500';stats['rol500_groups_skipped']+=1
            elif g['full_pan'].startswith('5'):
                reason='NON_VISA_PAN_PREFIX_5';stats['pan_prefix_5_groups_filtered']+=1;stats['pan_prefix_5_rows_filtered']+=len(g['items'])
            elif (requested is not None or guid in forced) and not 12<=len(g['full_pan'])<=19:reason='GUID_PAN_MAPPING_MISSING_OR_INVALID'
            if reason:
                stats['exclusions'].extend(dict(row_no=x['row_no'],guid=guid,reason=reason) for x in g['items']);continue
            items=[]
            for item in g['items']:
                reason='';text=item['date']
                try:
                    if not re.fullmatch(r'\d{8}',text):raise ValueError('format')
                    age=(run_date-datetime.strptime(text,'%Y%m%d').date()).days;item['age_days']=age
                    if age<0:reason='TI_DATE_FUTURE';stats['ti_date_future']+=1
                    elif age<=15:reason='TI_DATE_NOT_OLDER_THAN_15_DAYS';stats['ti_date_too_young']+=1
                    elif age>=120:reason='TI_DATE_AT_LEAST_120_DAYS';stats['ti_date_too_old']+=1
                except ValueError:reason='TI_DATE_INVALID';stats['ti_date_invalid']+=1
                if reason:
                    g['deferred_rows'].append(item['row_no']);stats['exclusions'].append(dict(row_no=item['row_no'],guid=guid,reason=reason));continue
                key=review_key(guid,item['invoice'],item['qt'],item['code']).upper()
                if guid in reviewed or key in reviewed:
                    stats['reviewed_rows_skipped']+=1
                    if requested is not None or guid in forced:stats['exclusions'].append(dict(row_no=item['row_no'],guid=guid,reason='ALREADY_PROCESSED_IN_REGISTRY'))
                    continue
                item['review_key']=key;items.append(item)
            if not items:continue
            g['items']=items;g['source_rows']=[x['row_no'] for x in items];g['dates']=sorted({x['date'] for x in items})
            stats['eligible']+=len(items);result.append(GuidGroup(**g))
        stats.update(groups_with_full_pan=sum(bool(x.full_pan) for x in result),groups_missing_full_pan=sum(not x.full_pan for x in result),mapping_records=len(mapping))
        if requested_source:stats['requested_source']={g:dict(codes=sorted(x['codes']),source_rows=x['source_rows'],upstream_values=sorted(x['upstream_values'])) for g,x in requested_source.items()}
        if requested is not None:
            stats.update(requested_guids=sorted(requested),requested_guids_found=sorted(found),request_mode='USER_SELECTED_GUIDS')
            stats['exclusions'].extend(dict(row_no=None,guid=guid,reason='REQUESTED_GUID_NOT_IN_WORKBOOK') for guid in sorted(requested-found))
        return result,stats,DEFAULT_CASE_SHEET
    finally:wb.close()

class CentralWriter:
    """One consumer: journal first, atomic Excel checkpoint, completion-only registry."""
    def __init__(self,source,out,events,reviewed,flush_every=20,persistent_reviewed=None,business_state=None):
        self.out=Path(out);self.events=Path(events);self.reviewed=Path(reviewed);self.persistent_reviewed=Path(persistent_reviewed) if persistent_reviewed else None
        shutil.copy2(source,out);self.wb=load_workbook(out);self.ws=self.wb[DEFAULT_CASE_SHEET]
        from .business_status import reserve_columns
        reserve_columns(self.ws);self.business_state=business_state
        if business_state:business_state.bind(self.ws)
        self.h={clean(self.ws.cell(2,c).value):c for c in range(1,self.ws.max_column+1)};self.pending=0;self.flush_every=flush_every
        self.flush_count=0;self.last_flush_ms=None;self.last_sync_ms=None
    def _col(self,name):
        if name not in self.h:self.h[name]=self.ws.max_column+1;self.ws.cell(2,self.h[name],name)
        return self.h[name]
    def apply(self,event):
        self.events.parent.mkdir(parents=True,exist_ok=True);d=event.__dict__.copy();d['timestamp']=datetime.now(VIETNAM).isoformat(timespec='seconds')
        with self.events.open('a',encoding='utf-8') as f:
            f.write(json.dumps(d,ensure_ascii=False,default=str)+'\n')
            if event.event=='CASE_RESULT':f.flush();os.fsync(f.fileno())
        if event.event not in {'CASE_RESULT','ROW_EXCLUDED'}:return
        data=event.data;result=data.get('result',{});by_row={x['row_no']:x for x in result.get('invoice_results',[])}
        for row in data.get('source_rows',[]):
            updates=dict(data.get('updates',{}));inv=by_row.get(row,{})
            if result:
                updates.update({'BOT INVOICE SCAN STATUS':inv.get('scan_status',''),'BOT PI INPUT':inv.get('pi_input',''),'BOT PI STATUS':inv.get('pi_status',''),'BOT PI FILE':inv.get('pi_file',''),'BOT PI PATH':inv.get('pi_path',''),'BOT PI CENTRAL PATH':inv.get('pi_central_path',''),'BOT TRAN TYPES FOUND':' | '.join(inv.get('tran_types',[])),'BOT SALE SELECTED':'YES' if inv.get('sale_selected') else 'NO','BOT GROUP GUID':event.guid,'BOT SELECTED SALE COUNT':result.get('selected_count',result.get('selected_count_before_stop',0)),'BOT VROL CASE':result.get('rol') or result.get('vrol_case_number',''),'BOT FINAL SUBMIT CLICKED':'YES' if result.get('final_submit_clicked') else 'NO','BOT REVIEW STATUS':event.status,'BOT CB REJECT':result.get('cb_reject',''),'BOT ISSUER ACTION PLANNED':result.get('planned_issuer_action',''),'BOT ISSUER ACTION CLICKED':'YES' if result.get('issuer_action_clicked') else 'NO','BOT ISSUER ACTION REQUIRED':'YES' if result.get('issuer_action_required') else 'NO'})
                updates.update({'BOT INVOICE REASON':inv.get('reason_code') or inv.get('pi_error') or inv.get('scan_status',''),
                                'BOT OUTCOME CATEGORY':result.get('outcome_category',''),'BOT OUTCOME CLASS':result.get('outcome_class',''),'BOT OUTCOME ACTION STAGE':result.get('outcome_action_stage',''),
                                'BOT EVIDENCE SCREENSHOTS':' | '.join(inv.get('error_screenshots') or data.get('screenshots',[]))})
            for k,v in updates.items():self.ws.cell(int(row),self._col(k),v)
        if event.event=='CASE_RESULT' and result:
            if self.business_state:self.business_state.record(self.ws,event.guid,result)
            elif result.get('outcome_class') in {'TRANSIENT','CHECKPOINT'}:pass
            else:
                from .business_status import groups,result_label,write_group,stamp
                entry=groups(self.ws).get(event.guid)
                if entry:write_group(self.ws,entry,result_label(result),stamp(),[str(result.get('rol') or result.get('vrol_case_number'))] if result.get('rol') or result.get('vrol_case_number') else [])
        if event.event=='CASE_RESULT' and event.status in COMPLETED:
            entries=list(data.get('review_keys',[]))
            if not data.get('deferred_rows') and event.guid:entries.append(event.guid)
            for path in [self.reviewed,self.persistent_reviewed]:
                if path is None:continue
                path.parent.mkdir(parents=True,exist_ok=True)
                with path.open('a',encoding='utf-8') as f:
                    for entry in entries:f.write(entry+'\n')
        if event.event=='CASE_RESULT':self.pending+=1
        if self.pending>=self.flush_every:self.flush()
    def flush(self):
        import time
        started=time.monotonic()
        temp=self.out.with_suffix('.tmp.xlsx');self.wb.save(temp);os.replace(temp,self.out);self.pending=0
        self.last_flush_ms=round((time.monotonic()-started)*1000);synced=time.monotonic()
        if self.business_state:self.business_state.sync(self.out)
        self.last_sync_ms=round((time.monotonic()-synced)*1000);self.flush_count+=1
    def close(self):self.flush();self.wb.close()
