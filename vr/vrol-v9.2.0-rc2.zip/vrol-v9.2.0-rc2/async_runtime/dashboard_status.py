"""RPA Ops contract v2: one small, always-current file per run (dashboard_status.json).

The dashboard reads only this file for a v2 run, so it no longer depends on the
bot's internal folder layout and does not rescan thousands of guid_result.json.
Updated incrementally from CentralWriter events and written atomically on every
heartbeat (default 5 s) and at the end of the run.
"""
import json
import os
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCHEMA = 'vrol-dashboard/2'
VIETNAM = timezone(timedelta(hours=7))
STAGES = ['STARTING', 'WAITING_INPUT', 'LOGIN', 'ROL500', 'PROCESSING_GUIDS', 'ROL500_POSTFLIGHT', 'FINISHED']

# Business buckets shown as KPI tiles (order = display order).
BUCKETS = ['pi', 'no_cb', 'existing_cb', 'draft', 'submitted', 'review', 'retry_later', 'diagnostic']

# Review reason -> (group title, what the user should do). Keys are reason codes.
REVIEW_HINTS = {
    'ASSOCIATED_TRANSACTIONS_SCREEN': 'Case đã tạo trên Visa (có ROL). Đối chiếu giao dịch liên quan và hoàn tất thủ công.',
    'ELIGIBLE_ROW_NOT_UNIQUE': 'Một invoice có nhiều dòng Sale/Cash. Chọn đúng giao dịch trên VROL và xử lý tay.',
    'TRANSACTION_RESULTS_TRUNCATED_300_PLUS': 'VROL trả 300+ giao dịch. Tra cứu tay với khoảng ngày hẹp hơn.',
    'INVOICE_NOT_IN_TRUNCATED_TRANSACTION_RESULTS': 'VROL trả 300+ giao dịch, không thấy invoice. Tra cứu tay với khoảng ngày hẹp hơn.',
    'ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY': 'VROL yêu cầu tra soát từng giao dịch (ROL-1537). Tạo case riêng cho từng giao dịch.',
    'EXISTING_CASE_REQUIRES_QUESTIONNAIRE_REVIEW': 'Có thể đã có case. Kiểm tra ROL trên VROL trước khi gõ FORCE.',
    'INTERRUPTED_AFTER_ISSUER_ACTION': 'Run dừng giữa chừng sau Issuer Action. Kiểm tra ROL trên VROL trước khi gõ FORCE.',
    'QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT': 'Case đã submit nhưng questionnaire không mở kịp. Mở ROL trên VROL để kiểm tra.',
    'UNDEFINED_ASSOC_DISPUTE_VALUE': 'Giá trị Assoc Dispute lạ. Kiểm tra giao dịch trên VROL.',
    'WINDOW_LAYOUT_NOT_STABLE': 'Trang questionnaire không ổn định kể cả sau khi bot đã thử lại (chờ bố cục 3 lần + tạo lại case 1 lần). Case nháp chưa Final Submit: gõ FORCE để chạy lại (sẽ có ROL mới) hoặc điền tay trên VROL.',
    'GUID_PAN_MAPPING_NOT_FOUND': 'Thiếu PAN cho GUID trong input.txt. Bổ sung mapping rồi chạy lại.',
}


def now():return datetime.now(VIETNAM).isoformat(timespec='seconds')


def bucket_of(result):
    """Map a GUID result to one business bucket (same meaning as the AM label)."""
    from .business_status import result_label
    from .outcome_policy import outcome_class, TRANSIENT, CHECKPOINT
    kind = outcome_class(result)
    if kind == CHECKPOINT:return 'diagnostic'
    if kind == TRANSIENT:return 'retry_later'
    status = str(result.get('status') or '')
    label = result_label(result)
    if label == 'PI':return 'pi'
    if label == 'Assoc D':return 'existing_cb'
    if label == 'NO_CB':return 'no_cb'
    if status == 'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT':return 'draft'
    if status == 'FINAL_SUBMIT_COMPLETED':return 'submitted'
    return 'review'


class DashboardStatus:
    def __init__(self, run_dir, *, run_id, mode=None, input_info=None):
        self.path = Path(run_dir) / 'dashboard_status.json'
        self.lock = threading.RLock()
        self.data = dict(schema=SCHEMA, run_id=run_id, status='RUNNING', stage='STARTING', updated_at=now(),
                         stage_history=[dict(stage='STARTING', at=now())], mode=mode or {}, input=input_info or {},
                         queue=dict(total=0, excluded={}, existing_cb_rol500=0), session=dict(generation=0, restart_after=None),
                         progress=dict(done=0, running=0, pending=0, first_started_at=None, guids_per_min=None, eta_seconds=None),
                         buckets={k: 0 for k in BUCKETS}, labels={}, workers=[], review=[], drafts=[],
                         retries=dict(read_only=0, transient=0), health={}, files={}, rows=[])
        self.session = None
        self.worker_states = []
        self._first_started = None
        self._done_times = []
        self._assigned = {}

    # ---- lifecycle -------------------------------------------------------
    def stage(self, stage, status=None):
        with self.lock:
            if stage and stage != self.data['stage']:
                self.data['stage'] = stage
                self.data['stage_history'].append(dict(stage=stage, at=now()))
            if status:self.data['status'] = status

    def set_queue(self, total, excluded=None, existing_cb_rol500=0):
        with self.lock:
            counts = {}
            for item in excluded or []:
                counts[item.get('reason')] = counts.get(item.get('reason'), 0) + 1
            self.data['queue'] = dict(total=total, excluded=counts, existing_cb_rol500=existing_cb_rol500)
            self.data['progress']['pending'] = total

    def set_files(self, **files):
        with self.lock:self.data['files'].update({k: str(v) for k, v in files.items() if v})

    # ---- events from CentralWriter --------------------------------------
    def on_event(self, event):
        with self.lock:
            if event.event == 'CASE_ASSIGNED':
                self._assigned[event.worker_id] = (event.guid, time.time())
                if self._first_started is None:
                    self._first_started = time.time();self.data['progress']['first_started_at'] = now()
            elif event.event == 'CASE_RESULT':
                self._result(event)

    def _result(self, event):
        from .business_status import result_label
        data = event.data or {};result = dict(data.get('result') or {})
        result.setdefault('status', event.status);result.setdefault('reason_code', event.reason_code)
        bucket = bucket_of(result);label = result_label(result)
        if bucket == 'diagnostic':label = 'Cần tạo case – chạy chế độ đầy đủ'
        p = self.data['progress'];p['done'] += 1;p['pending'] = max(0, self.data['queue']['total'] - p['done'])
        self.data['buckets'][bucket] = self.data['buckets'].get(bucket, 0) + 1
        self.data['labels'][label] = self.data['labels'].get(label, 0) + 1
        if result.get('read_retry_count') or result.get('read_retries'):
            self.data['retries']['read_only'] += int(result.get('read_retry_count') or result.get('read_retries') or 0)
        if bucket == 'retry_later':self.data['retries']['transient'] += 1
        shots = data.get('screenshots') or []
        folder = data.get('folder') or result.get('folder') or ''
        rol = result.get('rol') or result.get('vrol_case_number') or ''
        row = dict(guid=event.guid, worker=event.worker_id, bucket=bucket, label=label, status=event.status,
                   reason_code=result.get('reason_code') or '', rol=rol, folder=folder, screenshot=shots[0] if shots else '', at=now())
        self.data['rows'].append(row)
        if bucket == 'review':
            reason = result.get('reason_code') or event.status
            self.data['review'].append(dict(row, group=label, hint=REVIEW_HINTS.get(reason, 'Xem ảnh và log của GUID; xử lý tay hoặc gõ FORCE vào AM để chạy lại.')))
        if bucket == 'draft':
            self.data['drafts'].append(dict(guid=event.guid, rol=rol, action=str(result.get('issuer_action') or ''), label=label,
                                            folder=folder, screenshot=shots[0] if shots else '', at=now()))
        self._done_times.append(time.time())

    # ---- periodic snapshot ----------------------------------------------
    def _throughput(self):
        p = self.data['progress']
        if not self._first_started or not p['done']:return
        elapsed = max(1.0, time.time() - self._first_started)
        recent = [t for t in self._done_times if t >= time.time() - 600]
        rate = (len(recent) / min(600.0, elapsed) * 60) if len(recent) >= 5 else p['done'] / elapsed * 60
        p['guids_per_min'] = round(rate, 2)
        p['eta_seconds'] = int(p['pending'] / rate * 60) if rate > 0 and p['pending'] else 0

    def _workers(self):
        out = []
        for state in self.worker_states:
            current = getattr(state, 'current', None)
            guid = getattr(current, 'guid', '') if current else ''
            assigned = self._assigned.get(state.worker_id)
            since = int(time.time() - assigned[1]) if guid and assigned and assigned[0] == guid else None
            out.append(dict(id=state.worker_id, guid=guid, stage=getattr(state, 'stage', '') or '', seconds=since))
        self.data['workers'] = out
        self.data['progress']['running'] = sum(1 for w in out if w['guid'] and w['stage'] not in {'IDLE', 'DONE'})

    def snapshot(self, monitor_data=None, resources=None):
        with self.lock:
            if monitor_data:
                self.stage(monitor_data.get('stage'), monitor_data.get('status'))
                self.data['pid'] = monitor_data.get('pid');self.data['started_at'] = monitor_data.get('started_at')
                if monitor_data.get('status') == 'WAITING_OTP':self.data['otp_folder'] = monitor_data.get('otp_folder')
                if monitor_data.get('stage') == 'WAITING_INPUT':
                    self.data['input_wait_reason'] = monitor_data.get('input_wait_reason')
                    self.data['contract_directory'] = monitor_data.get('contract_directory')
                else:self.data.pop('input_wait_reason', None)
            if self.session is not None:
                self.data['session'] = dict(generation=getattr(self.session, '_generation', 0), restart_after=getattr(self.session, 'restart_after', None),
                                            restarts=max(0, getattr(self.session, '_generation', 0) - 1))
            if resources:self.data['health'] = resources
            self._workers();self._throughput();self.data['updated_at'] = now()
            return self.write()

    def finish(self, status, summary=None):
        with self.lock:
            self.data['status'] = status;self.stage('FINISHED')
            for worker in self.data['workers']:worker.update(guid='', stage='DONE')
            self.data['progress']['running'] = 0
            if summary:
                self.data['completed_at'] = summary.get('completed_at')
                self.data['master_writeback'] = (summary.get('master_writeback') or {}).get('status')
                self.data['rol500_postflight'] = (summary.get('rol500_postflight') or {}).get('status')
            self.data['updated_at'] = now()
            return self.write()

    def write(self):
        temp = self.path.with_suffix('.tmp')
        try:
            temp.write_text(json.dumps(self.data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
            os.replace(temp, self.path)
            return True
        except OSError:
            return False  # a transient lock must never stop the run
