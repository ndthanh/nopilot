"""Make 'already charged back' skips visible: run log lines + existing_chargebacks.csv.

Two detections exist:
* ROL500 preflight  - the invoice is in the ROL500 report (recent days): the GUID never
  enters the queue (exclusion ALREADY_CHARGEBACK_IN_ROL500).
* Transaction Inquiry - a transaction of the GUID has Assoc Dispute = D: the GUID stops
  with NO_CHARGEBACK_REQUIRED / GROUP_CONTAINS_ASSOC_DISPUTE_D (AM 'Assoc D').
"""
import csv
import json
from pathlib import Path

FIELDS = ['guid', 'source', 'invoices', 'rows', 'detail']


def _write(run_dir, rows):
    path = Path(run_dir) / 'existing_chargebacks.csv'
    with path.open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    return path


def log_existing_chargebacks(excluded, run_dir, log):
    """Log one line per GUID skipped by ROL500; returns the GUID count."""
    by_guid = {}
    for item in excluded:
        if item.get('reason') == 'ALREADY_CHARGEBACK_IN_ROL500' and item.get('guid'):
            by_guid.setdefault(item['guid'], []).append(item.get('row_no'))
    rows = []
    for guid, source_rows in sorted(by_guid.items()):
        log('info', f'SKIP EXISTING CHARGEBACK | GUID={guid} | source=ROL500_PREFLIGHT | rows={source_rows}')
        rows.append(dict(guid=guid, source='ROL500_PREFLIGHT', invoices='', rows=' '.join(str(r) for r in source_rows),
                         detail='Invoice found in ROL500 report; GUID not queued'))
    if by_guid:
        log('warning', f'EXISTING CHARGEBACKS SKIPPED BY ROL500 | guids={len(by_guid)} | see existing_chargebacks.csv')
    _write(run_dir, rows)
    return len(by_guid)


ROL500_LABEL = 'Đã CB'
ROL500_REVERSAL_LABEL = 'Đã CB (reversal)'


def _rol500_reversals(csv_path):
    """Tran keys and ROL numbers of 'Dispute Financial Reversal' rows (R1/R2)."""
    import csv as _csv
    from src.vrol.reports.rol500 import _norm
    keys, rols = set(), set()
    if not csv_path or not Path(csv_path).is_file():
        return keys, rols
    for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
        try:
            with Path(csv_path).open(encoding=enc, newline='') as handle:
                data = list(_csv.reader(handle))
            break
        except UnicodeDecodeError:
            continue
    else:
        return keys, rols
    for row in data[1:]:
        if len(row) > 11 and 'REVERSAL' in str(row[1]).upper():
            keys.add(_norm(row[11]))
            if row[5].strip():
                rols.add(row[5].strip())
    return keys, rols


def rol500_outcomes(enriched_workbook, csv_path):
    """Ledger outcomes for GUIDs the ROL500 preflight found already charged back.

    Only rows the enrichment marked ALREADY_CHARGEBACK_IN_ROL500 count (invoice->Tran ID
    match, with or without QT, or QT_ONLY = this row's QT is the Member Case # of a
    filed case). Ambiguous rows (several ROL cases) are left for a person.
    """
    from openpyxl import load_workbook
    from src.vrol.reports.rol500 import _norm
    rev_keys, rev_rols = _rol500_reversals(csv_path)
    wb = load_workbook(enriched_workbook, read_only=True, data_only=True)
    try:
        ws = wb['Sheet1']
        h = {str(v).strip().upper(): i for i, v in enumerate(next(ws.iter_rows(min_row=2, max_row=2, values_only=True))) if v is not None}
        if 'BOT ROL500 STATUS' not in h:
            return []
        found = {}
        for row in ws.iter_rows(min_row=4, values_only=True):
            if str(row[h['BOT ROL500 STATUS']] or '') != 'ALREADY_CHARGEBACK_IN_ROL500':
                continue
            guid = str(row[h['GUID']] or '').strip().upper()
            if not guid:
                continue
            rol = str(row[36] or '').strip()  # AK, written by the enrichment
            entry = found.setdefault(guid, dict(rols=set(), reversal=False))
            if rol:
                entry['rols'].add(rol)
            if _norm(row[h['INVOICENUM']]) in rev_keys or rol in rev_rols:
                entry['reversal'] = True
    finally:
        wb.close()
    return [dict(guid=guid, label=ROL500_REVERSAL_LABEL if e['reversal'] else ROL500_LABEL, rols=sorted(e['rols']),
                 reason='ALREADY_CHARGEBACK_IN_ROL500' + ('_REVERSAL' if e['reversal'] else ''))
            for guid, e in sorted(found.items())]


def append_assoc_dispute_results(run_dir, records, log):
    """Add GUIDs stopped by Assoc Dispute = D during Transaction Inquiry."""
    path = Path(run_dir) / 'existing_chargebacks.csv'
    rows = []
    if path.exists():
        with path.open(encoding='utf-8-sig') as handle:
            rows = list(csv.DictReader(handle))
    found = 0
    for record in records:
        result = record.get('result') or {}
        if (result.get('reason_code') or record.get('reason_code')) != 'GROUP_CONTAINS_ASSOC_DISPUTE_D':
            continue
        invoices = [x.get('invoice_raw') or x.get('invoice_search') or '' for x in result.get('invoice_results', [])
                    if str(x.get('assoc_dispute') or '').upper() == 'D']
        rows.append(dict(guid=record.get('guid'), source='TRANSACTION_INQUIRY_ASSOC_D', invoices=' '.join(invoices),
                         rows=' '.join(str(x.get('row_no')) for x in result.get('invoice_results', []) if x.get('row_no')),
                         detail='Assoc Dispute = D on Visa; AM = Assoc D'))
        found += 1
    if found:
        log('warning', f'EXISTING CHARGEBACKS FOUND IN TRANSACTION INQUIRY | guids={found} | AM=Assoc D')
    _write(run_dir, rows)
    return found
