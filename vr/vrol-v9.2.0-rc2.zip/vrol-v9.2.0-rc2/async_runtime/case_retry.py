"""A single user-authorized case-chain retry, strictly before Final Submit."""
import asyncio,json,shutil
from pathlib import Path

REASONS={'ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY',
         'QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT',
         'OWNED_CASE_CREATION_OR_QUESTIONNAIRE_NOT_FOUND',
         'QUESTIONNAIRE_NOT_STABLE_BEFORE_FILL',
         # 2026-11-21: user OK to abandon an unsubmitted draft and create a new ROL.
         'WINDOW_LAYOUT_NOT_STABLE'}

def may_retry_case(exc,saved):
    if saved.get('final_submit_clicked') or str(saved.get('stage','')).startswith('FINAL_SUBMIT_'):return False
    # Do not weaken ownership, invoice, card, date or code validation.
    code=str(exc).split(':',1)[0].strip()
    return code in REASONS or (isinstance(exc,asyncio.TimeoutError) and str(saved.get('stage','')).startswith('QUESTIONNAIRE_'))

async def archive_retry(state,exc,saved):
    from .guid_folders import rebase
    folder=Path(state.artifact_dir);archive=folder/'case_attempt_01';archive.mkdir(exist_ok=False)
    shots=[]
    for index,page in enumerate(state.registry.pages(state.page),1):
        if page.is_closed():continue
        path=archive/f'before_retry_page{index:02d}.png'
        try:await page.screenshot(path=str(path),full_page=True,timeout=5000);shots.append(str(path))
        except Exception:pass
    # Keep original evidence, archive checkpoint before starting another chain.
    for path in folder.iterdir():
        if not path.is_file() or path.name in {'guid_case.log','guid_state.json'}:continue
        target=archive/path.name;shutil.copy2(path,target)
        if path.suffix=='.json':
            try:data=json.loads(target.read_text(encoding='utf-8-sig'))
            except ValueError:continue  # Preserve interrupted JSON evidence as-is.
            target.write_text(json.dumps(rebase(data,folder,archive),ensure_ascii=False,indent=2),encoding='utf-8')
    entry=dict(reason=str(exc),checkpoint=rebase(saved,folder,archive),screenshots=shots,archive=str(archive))
    from .jsonio import atomic_write_json
    atomic_write_json(folder/'case_retry_history.json',[entry])
    (folder/'case_checkpoint.json').unlink(missing_ok=True)
    return entry
