"""Run completion is distinct from business cases requiring human review."""
def completed_status(postflight,outcomes,held=(),writeback=None,pi_export=None):
    if postflight.get('status')=='FAILED':return 'FAILED'
    stats=postflight.get('stats') or {}
    reviews=bool(outcomes.get('needs_user_review_count') or held or stats.get('ambiguous') or stats.get('submitted_not_found'))
    reviews|=(writeback or {}).get('status') in {'PENDING','CONFLICT','USER_CLEARED'}
    reviews|=(pi_export or {}).get('status')=='FAILED'
    return 'SUCCESS_WITH_REVIEWS' if reviews else 'SUCCESS'
