"""Verify a frozen FC + GUID2PAN bundle before any browser side effect."""
import hashlib
import json
from pathlib import Path
from .excel_store import business_date, load_groups
from src.io.mapping import load_mapping


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):h.update(chunk)
    return h.hexdigest()


def validate_contract(path, *, check_coverage=True):
    path = Path(path).resolve()
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('schema') != 'vrol-input/1' or data.get('status') != 'READY':
        raise ValueError('VROL_INPUT_CONTRACT_NOT_READY')
    if data.get('business_date') != business_date().isoformat():
        raise ValueError('VROL_INPUT_CONTRACT_NOT_TODAY')
    if not data.get('source_fc_run_id') or not data.get('source_guid2pan_run_id'):
        raise ValueError('VROL_INPUT_LINEAGE_MISSING')
    files = {}
    for key in ('workbook', 'mapping'):
        resource = data['files'][key]
        file = Path(resource['path']).resolve()
        # Published inputs must be the bundle's private snapshots.
        if file.parent != path.parent:
            raise ValueError('VROL_INPUT_SNAPSHOT_OUTSIDE_BUNDLE')
        if not file.is_file() or file.stat().st_size != resource['size'] or digest(file) != resource['sha256']:
            raise ValueError('VROL_INPUT_SNAPSHOT_CHANGED:' + key)
        files[key] = file
    mapping, errors, _ = load_mapping(files['mapping'])
    if errors or any(not 12 <= len(pan) <= 19 for pan in mapping.values()):
        raise ValueError('VROL_MAPPING_INVALID')
    if check_coverage:
        groups, _, _ = load_groups(files['workbook'], mapping)
        if any(not group.full_pan for group in groups):
            raise ValueError('VROL_MAPPING_INCOMPLETE')
    return data, files
