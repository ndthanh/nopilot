import re

def code_token(items):
    return '-'.join(sorted({re.sub(r'[^A-Za-z0-9]+','_',str(x.get('code') or 'UNKNOWN')) for x in items})) or 'UNKNOWN'
