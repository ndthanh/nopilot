"""Explorer markers and one run-wide review index, including outcome-prefixed folders."""
import csv
import json
from collections import Counter
from pathlib import Path
from .config import truth
from .outcomes import needs_review

MANAGED_MARKERS={name:f'__{name}__.txt' for name in (
    'IN_PROGRESS','PI_DOWNLOADED','NO_CHARGEBACK','FRAUD','CONSUMER',
    'REVIEW_REQUIRED','AWAITING_FINAL_SUBMIT','FINAL_SUBMITTED','PI_PARTIAL','ASSOCIATED_TRANSACTIONS','MULTIPLE_SALE_ROWS')}

def atomic_text(path,text):
    path=Path(path);temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(text,encoding='utf-8');temp.replace(path)

def start_guid(folder,guid):
    folder=Path(folder)
    for name in MANAGED_MARKERS.values():(folder/name).unlink(missing_ok=True)
    atomic_text(folder/MANAGED_MARKERS['IN_PROGRESS'],f'GUID: {guid}\nState: IN_PROGRESS\n')

def classify(result,group=None):
    status=str(result.get('status') or '')
    checkpoint=result.get('case_checkpoint') or {}
    rows=result.get('invoice_results') or []
    codes=sorted({str(x.get('code')) for x in (getattr(group,'items',None) or rows) if x.get('code')})
    attempted=truth(result.get('issuer_action_clicked')) or truth(checkpoint.get('issuer_action_clicked'))
    action=str(result.get('issuer_action') or checkpoint.get('issuer_action') or '').upper()
    if action not in {'FRAUD','CONSUMER'}:
        planned=str(result.get('planned_issuer_action') or '')
        if planned.endswith('> Fraud'):action='FRAUD'
        elif planned.endswith('> Consumer'):action='CONSUMER'
        elif codes==['10.4'] or checkpoint.get('code')=='10.4':action='FRAUD'
        elif codes and set(codes)<={'13.1','13.9'}:action='CONSUMER'
        elif checkpoint.get('code') in {'13.1','13.9'}:action='CONSUMER'
        else:action=''
    if not attempted:action=''
    reported=[x for x in rows if x.get('pi_status')=='DOWNLOADED']
    downloaded=[x for x in reported if Path(str(x.get('pi_path') or '')).is_file()]
    pi_failed=sum(x.get('pi_status')=='DOWNLOAD_FAILED' for x in rows)
    pi_pending=sum(x.get('pi_status')=='PENDING_USER_ACTION' for x in rows)
    missing=len(reported)-len(downloaded)
    review_reasons=[]
    if needs_review(result):review_reasons.append(str(result.get('reason_code') or status or 'OUTCOME_NOT_MAPPED'))
    if missing:review_reasons.append('PI_FILE_MISSING')
    if pi_failed:review_reasons.append('PI_DOWNLOAD_FAILED')
    if pi_pending:review_reasons.append('PI_ACTION_PENDING')
    review=needs_review(result) or bool(missing) or bool(pi_failed or pi_pending)
    if status in {'INQUIRY_ONLY_CHECKPOINT','ISSUER_ACTION_DEFERRED_TEST_MODE'}:
        review=True;review_reasons.append('TEST_CHECKPOINT_NO_FINAL_OUTCOME')
    awaiting=status=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT'
    confirmed=status=='FINAL_SUBMIT_COMPLETED' and truth(result.get('final_submit_clicked'))
    markers=[]
    if status=='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED':markers.append('ASSOCIATED_TRANSACTIONS')
    if any(str(x.get('reason_code') or '').upper().startswith('SALE_ROW_NOT_UNIQUE') for x in rows):markers.append('MULTIPLE_SALE_ROWS')
    if downloaded:markers.append('PI_DOWNLOADED')
    if status=='NO_CHARGEBACK_REQUIRED':markers.append('NO_CHARGEBACK')
    if action:markers.append(action)
    if awaiting:markers.append('AWAITING_FINAL_SUBMIT')
    if confirmed:markers.append('FINAL_SUBMITTED')
    if downloaded and (pi_failed or pi_pending or missing):markers.append('PI_PARTIAL')
    if review:category='REVIEW_REQUIRED'
    elif status=='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION' and downloaded:category='PI_DOWNLOADED'
    elif status=='NO_CHARGEBACK_REQUIRED':category='NO_CHARGEBACK'
    elif action and (awaiting or confirmed):category=action
    else:
        category='REVIEW_REQUIRED';review=True;review_reasons.append('OUTCOME_NOT_MAPPED')
    if review:markers.append('REVIEW_REQUIRED')
    stage='FINAL_SUBMITTED' if confirmed else ('AWAITING_FINAL_SUBMIT' if awaiting else (status if status.startswith('FINAL_SUBMIT_') else ('ATTEMPTED_REVIEW_REQUIRED' if action else 'NOT_DISPATCHED')))
    return dict(category=category,issuer_action=action,action_stage=stage,codes=codes,
        review_required=review,review_reasons=sorted(set(review_reasons)),awaiting_final_submit=awaiting,needs_user_review=review or awaiting,
        pi_expected=len(reported)+pi_failed+pi_pending,pi_downloaded=len(downloaded),pi_failed=pi_failed,pi_pending=pi_pending,
        missing_pi_files=missing,markers=sorted(set(markers)),final_submit_confirmed=confirmed,
        final_submit_clicked=truth(result.get('final_submit_clicked')) or truth(checkpoint.get('final_submit_clicked')))

def write_markers(folder,record,outcome):
    folder=Path(folder);result=record.get('result') or {}
    names=[MANAGED_MARKERS[m] for m in outcome['markers']]
    details=[f'GUID: {record.get("guid",folder.name)}',f'Category: {outcome["category"]}',
        f'Status: {record.get("status",result.get("status",""))}',f'Reason: {record.get("reason_code") or result.get("reason_code","")}',
        f'Detail: {result.get("reason_detail") or record.get("detail","")}',
        'Review reasons: '+' | '.join(outcome['review_reasons']),f'Issuer action: {outcome["issuer_action"] or "NONE"}',f'Action stage: {outcome["action_stage"]}',
        f'ROL case: {result.get("rol") or result.get("vrol_case_number","")}',
        f'PI: {outcome["pi_downloaded"]}/{outcome["pi_expected"]} downloaded; failed={outcome["pi_failed"]}; pending={outcome["pi_pending"]}; missing={outcome["missing_pi_files"]}',
        f'Final submit clicked: {outcome["final_submit_clicked"]}',f'Final submit confirmed: {outcome["final_submit_confirmed"]}',f'Needs user review: {outcome["needs_user_review"]}',
        'Screenshots: '+' | '.join(record.get('screenshots') or []),'See guid_result.json and group_result.json for details.']
    for name in names:atomic_text(folder/name,'\n'.join(details)+'\n')
    for name in MANAGED_MARKERS.values():
        if name not in names:(folder/name).unlink(missing_ok=True)
    return names

def build_report(run_dir):
    run_dir=Path(run_dir);records=[]
    for folder in sorted((run_dir/'groups').iterdir()) if (run_dir/'groups').is_dir() else []:
        if not folder.is_dir():continue
        path=folder/'guid_result.json'
        try:
            record=json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(record,dict):raise ValueError('GUID_RECORD_NOT_AN_OBJECT')
            result=record.get('result') or json.loads((folder/'group_result.json').read_text(encoding='utf-8'))
            if not isinstance(result,dict):raise ValueError('GUID_RESULT_NOT_AN_OBJECT')
            outcome=classify(result)
        except (OSError,ValueError,TypeError,AttributeError,KeyError) as exc:
            result=dict(status='GUID_RESULT_MISSING_OR_UNREADABLE',reason_code='GUID_NOT_FINALIZED',reason_detail=str(exc))
            record=dict(guid=folder.name,status=result['status'],reason_code=result['reason_code'],result=result)
            outcome=classify(result)
        names=write_markers(folder,record,outcome)
        records.append(dict(guid=record.get('guid',folder.name),worker=record.get('worker',''),**outcome,
            status=result.get('status',''),business_result=result.get('business_result',''),case_retry_count=result.get('case_retry_count',0),reason_code=result.get('reason_code',''),reason_detail=result.get('reason_detail') or record.get('detail',''),
            rol=result.get('rol') or result.get('vrol_case_number',''),marker_files=names,folder=str(folder.resolve()),
            screenshots=record.get('screenshots') or [],completed_at=record.get('completed_at',''),
            outcome_class=result.get('outcome_class',''),transient_attempts=result.get('transient_attempts',''),
            elapsed_seconds=record.get('elapsed_seconds',''),**{k:(v if not isinstance(v,list) else sum(v)) for k,v in (result.get('timings') or {}).items()}))
    counts=dict(Counter(r['category'] for r in records))
    report=dict(group_count=len(records),category_counts=counts,outcome_class_counts=dict(Counter(r.get('outcome_class') or 'UNKNOWN' for r in records)),needs_user_review_count=sum(r['needs_user_review'] for r in records),
        awaiting_final_submit_count=sum(r['awaiting_final_submit'] for r in records),records=records)
    json_path=run_dir/'guid_outcomes.json';csv_path=run_dir/'guid_outcomes.csv'
    atomic_text(json_path,json.dumps(report,ensure_ascii=False,indent=2))
    fields=['guid','worker','category','status','business_result','case_retry_count','issuer_action','action_stage','codes','rol','pi_expected','pi_downloaded','pi_failed','pi_pending','missing_pi_files','review_required','review_reasons','awaiting_final_submit','needs_user_review','final_submit_clicked','final_submit_confirmed','reason_code','reason_detail','completed_at','folder','marker_files','screenshots','outcome_class','transient_attempts','elapsed_seconds','inquiry_s','scan_s','scan_strategy','reported_transactions','precheck_s','pi_download_s','case_s','engine_total_s','guid_total_s','read_retries','case_retries']
    temp=csv_path.with_suffix('.csv.tmp')
    with temp.open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
        for record in records:writer.writerow({key:' | '.join(map(str,record[key])) if isinstance(record.get(key),list) else record.get(key,'') for key in fields})
    temp.replace(csv_path)
    return {k:v for k,v in report.items() if k!='records'}|dict(json=str(json_path),csv=str(csv_path))

def main():
    import argparse
    parser=argparse.ArgumentParser(description='Rebuild GUID markers and review CSV for a stopped run; no browser or OTP.')
    parser.add_argument('--run-dir',required=True);args=parser.parse_args()
    run_dir=Path(args.run_dir).resolve()
    if not (run_dir/'groups').is_dir():parser.error('Run directory must contain groups/')
    print(json.dumps(build_report(run_dir),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
