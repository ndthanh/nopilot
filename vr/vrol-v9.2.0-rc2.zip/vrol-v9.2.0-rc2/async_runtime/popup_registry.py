"""Page ownership is explicit; title/newest-context-page never assigns ownership."""
import asyncio

class PopupRegistry:
    def __init__(self,context):
        self.context=context;self.owners={};self.parents={};self.tasks=set();self.resource_locks={};self.crashed=set()
        context.on('page',self._on_page)
    def _on_page(self,page):
        task=asyncio.create_task(self._resolve(page));self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
    async def _resolve(self,page):
        try:
            for _ in range(20):
                if page in self.owners:return
                opener=await page.opener()
                if opener in self.owners:
                    self.register(page,self.owners[opener],opener);return
                await asyncio.sleep(.05)
        except Exception:return
    def register(self,page,owner,parent=None):
        previous=self.owners.get(page)
        if previous is not None and previous!=owner:
            raise RuntimeError('POPUP_OWNERSHIP_CONFLICT')
        if previous is None:
            self.owners[page]=owner;self.parents[page]=parent
            page.on('popup',lambda child:self.register(child,owner,page))
            page.on('crash',lambda *_:self.crashed.add(page))
        return page
    def pages(self,root):
        owner=self.owners.get(root)
        if owner is None:raise RuntimeError('UNREGISTERED_WORKER_PAGE')
        return [p for p,o in self.owners.items() if o==owner and not p.is_closed()]
    def assert_owned(self,root,page):
        if self.owners.get(root)!=self.owners.get(page) or root not in self.owners:
            raise RuntimeError('FOREIGN_POPUP_REJECTED')
    async def cleanup(self,root):
        if root not in self.owners:return
        for page in reversed(self.pages(root)):
            if page is root:continue
            try:await asyncio.wait_for(page.close(),5)
            except Exception:pass
        owner=self.owners.get(root)
        # Keep the registry bounded over thousands of GUIDs. Descendants already
        # carry their own owner, including when an intermediate opener closes.
        for page,assigned in list(self.owners.items()):
            if page is not root and assigned==owner and page.is_closed():
                self.owners.pop(page,None);self.parents.pop(page,None)
                self.crashed.discard(page)
    def forget(self,page):
        self.owners.pop(page,None);self.parents.pop(page,None);self.crashed.discard(page)
    async def close(self):
        self.context.remove_listener('page',self._on_page)
        await asyncio.gather(*self.tasks,return_exceptions=True)
