"""Case Creation state transitions restricted to the worker's popup chain."""
import asyncio, json, re, time
from datetime import datetime
from pathlib import Path
from .native_ui import fill_test_questionnaire
from .config import truth
from .final_submit import capture_questionnaire,final_submit,prepare_questionnaire
from . import associated_transactions
from .evidence_names import code_token
from src.vrol.transaction_table import transaction_id_matches_invoice

def summary_date(value):
    value=str(value or '').strip()
    match=re.search(r'\d{1,2}/\d{1,2}/\d{2,4}|\d{4}-\d{2}-\d{2}|\b\d{8}\b',value)
    if not match:raise RuntimeError('QUESTIONNAIRE_TRANSACTION_DATE_UNPARSEABLE')
    for fmt in ('%m/%d/%Y','%m/%d/%y','%Y-%m-%d','%Y%m%d'):
        try:return datetime.strptime(match.group(),fmt).date().isoformat()
        except ValueError:pass
    raise RuntimeError('QUESTIONNAIRE_TRANSACTION_DATE_UNPARSEABLE')

async def validate_identity(scope,item,rol,expected_rol=None):
    if item['code'] not in {'10.4','13.1','13.9'}:raise RuntimeError('UNSUPPORTED_QUESTIONNAIRE_CODE')
    heading=scope.locator('span[ng-bind="disputeData.screenName"]').first
    await heading.wait_for(state='visible',timeout=15000)
    actual=' '.join((await heading.inner_text()).split())
    expected=('Fraud' if item['code']=='10.4' else 'Consumer')+' Dispute Questionnaire'
    if actual!=expected:raise RuntimeError('QUESTIONNAIRE_SCREEN_NAME_MISMATCH:'+actual)
    invoice=scope.locator('dd[ng-bind="data.pinnedOriginalTransaction.visaTransactionId"]').first
    await invoice.wait_for(state='visible',timeout=15000)
    actual_invoice=(await invoice.inner_text()).strip()
    if not transaction_id_matches_invoice(actual_invoice,item['invoice']):
        raise RuntimeError('QUESTIONNAIRE_INVOICE_MISMATCH')
    body=await scope.locator('body').inner_text(timeout=2000)
    match=re.search(r'VROL Case Number\s*([0-9]{6,15})',body,re.I)
    actual_rol=match.group(1) if match else ''
    if not actual_rol:
        case=scope.locator('#caseNumber').first
        actual_rol=(await case.get_attribute('value') or '') if await case.count() else ''
    if actual_rol!=rol:raise RuntimeError('QUESTIONNAIRE_ROL_IDENTITY_MISMATCH')
    if expected_rol and rol!=expected_rol:raise RuntimeError('QUESTIONNAIRE_ROL_CHANGED_DURING_PREPARATION')
    identity=dict(code=item['code'],expected_screen=expected,invoice_verified=True,rol=rol)
    if item.get('_expected_card_bin6') or item.get('_expected_summary_date'):
        pairs=await scope.locator('dt').evaluate_all('(els)=>els.map(e=>({label:e.innerText,value:e.nextElementSibling?.tagName==="DD"?e.nextElementSibling.innerText:""}))')
        values={re.sub(r'[^a-z]','',x['label'].casefold()):x['value'].strip() for x in pairs}
        card=values.get('cardaccountnumber','');date=values.get('trandate') or values.get('transactiondate','')
        card_digits=re.sub(r'\D','',card)
        if len(card_digits)<10:raise RuntimeError('QUESTIONNAIRE_MASKED_CARD_NOT_CONFIRMED')
        if card_digits[:6]!=item['_expected_card_bin6'] or card_digits[-4:]!=item['_expected_card_last4']:
            raise RuntimeError('QUESTIONNAIRE_MASKED_CARD_MISMATCH')
        if summary_date(date)!=summary_date(item['_expected_summary_date']):raise RuntimeError('QUESTIONNAIRE_TRANSACTION_DATE_MISMATCH')
        identity.update(masked_card_verified=True,masked_card=card_digits[:6]+'...'+card_digits[-4:],transaction_date_verified=True,transaction_date=summary_date(date))
    return identity

async def stable_questionnaire(registry,root,item,expected_rol=None):
    deadline=time.monotonic()+15;previous=None;stable=0;last=None
    while time.monotonic()<deadline:
        ready=await _questionnaire(registry,root)
        if ready:
            candidate,scope,rol=ready
            try:
                identity=await validate_identity(scope,item,rol,expected_rol)
                signature=(candidate,scope.url,rol)
                stable=stable+1 if signature==previous else 1;previous=signature
                if stable>=2:return ready,identity
            except Exception as exc:
                last=exc;stable=0
                if 'MISMATCH' in str(exc) or 'ROL_CHANGED' in str(exc):raise
        await asyncio.sleep(.2)
    if last:raise last
    raise RuntimeError('QUESTIONNAIRE_NOT_STABLE_BEFORE_FILL')

def checkpoint(folder,stage,**data):
    from .jsonio import atomic_write_json,read_json_safe
    path=Path(folder)/'case_checkpoint.json'
    previous=read_json_safe(path,{}) or {}
    previous.update(stage=stage,**data)
    previous.setdefault('stage_times',[]).append([stage,round(time.time(),3)])
    atomic_write_json(path,previous)

async def _questionnaire(registry,root):
    for candidate in registry.pages(root):
        for frame in candidate.frames:
            try:
                text=await frame.locator('body').inner_text(timeout=400)
                if re.search(r'ROL-1537\b',text,re.I):raise RuntimeError('ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY')
                if re.search(r'ROL-1545\b',text,re.I):raise RuntimeError('ROL_1545_DUPLICATE_SELECTED_CARD_TRANSACTION_MCSN')
                if not re.search(r'(Fraud|Consumer) Dispute Questionnaire',text,re.I):continue
                match=re.search(r'VROL Case Number\s*([0-9]{6,15})',text,re.I)
                if not match:
                    case=frame.locator('#caseNumber').first
                    value=await case.get_attribute('value') if await case.count() else ''
                    if value and value.isdigit():match=re.match(r'(\d+)',value)
                submit=frame.get_by_role('button',name=re.compile(r'^Submit$',re.I),exact=True)
                if match and await submit.count():return candidate,frame,match.group(1)
            except RuntimeError:raise
            except Exception:continue
    return None

async def _duplicate(registry,root):
    for candidate in registry.pages(root):
        for frame in candidate.frames:
            try:
                text=await frame.locator('body').inner_text(timeout=300)
                if not re.search(r'ROL[-_ ]?749|potential duplicate case',text,re.I):continue
                ok=frame.get_by_role('button',name=re.compile(r'^OK$',re.I),exact=True).first
                if not await ok.count():ok=frame.locator('#okbutton,[data-action="disableAndSubmit"]').first
                if await ok.count() and await ok.is_visible():return candidate,ok
            except Exception:continue
    return None

async def _case_submit(registry,root):
    for candidate in registry.pages(root):
        try:
            if await associated_transactions.on_page(candidate):continue
            text=' '.join([await f.locator('body').inner_text(timeout=400) for f in candidate.frames])
            title=await candidate.title()
            is_case=('Case Creation' in title or 'create-case-from-tran-inq' in candidate.url or
                     ('Case Creation' in text and 'Create Dispute' in text))
            if not is_case:continue
            for frame in candidate.frames:
                submit=frame.get_by_role('button',name=re.compile(r'^Submit$',re.I),exact=True).first
                if not await submit.count():submit=frame.locator('button#submitButton,input#submitButton,input[type="submit"][value="Submit"]').first
                if await submit.count() and await submit.is_visible() and await submit.is_enabled():
                    return candidate,frame,submit
        except Exception:continue
    return None

async def _ensure_create_dispute(candidate):
    for frame in candidate.frames:
        checkbox=frame.get_by_label('Create Dispute',exact=True).first
        if not await checkbox.count():
            label=frame.get_by_text('Create Dispute',exact=True).first
            if await label.count():checkbox=label.locator('xpath=preceding::input[@type="checkbox"][1]')
        if await checkbox.count():
            await checkbox.check(force=True)
            if not await checkbox.is_checked():raise RuntimeError('CREATE_DISPUTE_NOT_CHECKED')
            return
    raise RuntimeError('CREATE_DISPUTE_CHECKBOX_NOT_CONFIRMED')

async def open_case_and_fill(page,registry,item,result,settings,folder,log):
    action='Fraud' if item['code']=='10.4' else 'Consumer'
    # Precheck already selected the full group. Do not check a stale representative nth row.
    buttons=page.frame(name='buttons')
    if buttons is None:raise RuntimeError('ISSUER_BUTTONS_FRAME_LOST')
    checkpoint(folder,'ISSUER_ACTION_PENDING',code=item['code'],selected_transaction_ids=result.get('selected_transaction_ids',[]),final_submit_clicked=False)
    await buttons.get_by_role('button',name=re.compile('Issuer Action',re.I)).first.evaluate('el => el.click()')
    parent=None;deadline=time.monotonic()+int(settings.get('issuer_menu_probe_timeout_ms') or 10000)/1000
    while time.monotonic()<deadline:
        for frame in page.frames:
            loc=frame.get_by_text(re.compile(r'^Chargeback\s*/\s*Dispute$|^Chargeback$',re.I),exact=True).filter(visible=True).first
            if await loc.count() and await loc.is_visible():parent=loc;break
        if parent:break
        await asyncio.sleep(.1)
    if parent is None:raise RuntimeError('CHARGEBACK_DISPUTE_MENU_NOT_FOUND')
    await parent.hover(force=True);await parent.dispatch_event('mouseover')
    action_loc=None;deadline=time.monotonic()+10
    while time.monotonic()<deadline:
        for frame in page.frames:
            loc=frame.get_by_text(action,exact=True).filter(visible=True).first
            if await loc.count() and await loc.is_visible():action_loc=loc;break
        if action_loc:break
        await parent.hover(force=True);await asyncio.sleep(.1)
    if action_loc is None:raise RuntimeError('EXPECTED_ISSUER_ACTION_NOT_FOUND:'+action)
    log.info('ISSUER ACTION | code=%s | action=%s | selected_count=%s',item['code'],action,result.get('selected_count'))
    checkpoint(folder,'ISSUER_ACTION_DISPATCHING',issuer_action_clicked=True,issuer_action=action)
    await action_loc.evaluate('el => el.click()')
    deadline=time.monotonic()+int(settings.get('case_creation_document_timeout_ms') or 20000)/1000
    submitted=False;duplicate_handled=False;submitted_page=None;duplicate_evidence=[]
    while True:
        associated=await associated_transactions.find(registry,page)
        if associated:
            return await associated_transactions.stop(associated,settings,folder,action,log)
        ready=await _questionnaire(registry,page)
        if ready:
            (case_page,scope,rol),identity=await stable_questionnaire(registry,page,item)
            registry.assert_owned(page,case_page)
            checkpoint(folder,'QUESTIONNAIRE_READY',rol=rol,questionnaire_url=case_page.url,questionnaire_frame_url=scope.url)
            log.info('QUESTIONNAIRE READY | code=%s | rol=%s | page=%s',item['code'],rol,case_page.url)
            questionnaire_settings=dict(settings,validate_dispute_amount='NO')
            if settings.get('_pre_submit_only'):questionnaire_settings['allow_final_submit']='NO'
            layout=await prepare_questionnaire(case_page,scope,log)
            (case_page,scope,rol),identity=await stable_questionnaire(registry,page,item,rol)
            checkpoint(folder,'QUESTIONNAIRE_READY',questionnaire_layout=layout,questionnaire_identity=identity)
            filled=await fill_test_questionnaire(scope,item['code'],questionnaire_settings,item)
            if not (filled.get('submit_inspection') or {}).get('exact_contract',{}).get('dispatch_ready'):
                raise RuntimeError('QUESTIONNAIRE_EXACT_FINAL_SUBMIT_NOT_READY')
            (case_page,scope,rol),identity=await stable_questionnaire(registry,page,item,rol)
            checkpoint(folder,'QUESTIONNAIRE_IDENTITY_VERIFIED_AFTER_FILL',questionnaire_identity=identity)
            questionnaire_path=Path(folder)/('04_questionnaire_filled_final_submit_not_clicked_'+code_token([item])+'.png')
            await capture_questionnaire(case_page,scope,questionnaire_path,log,maximize_window=truth(settings.get('questionnaire_maximize_before_capture','YES')))
            checkpoint(folder,'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',rol=rol,final_submit_clicked=False)
            completed=dict(rol=rol,vrol_case_number=rol,questionnaire=filled,issuer_action_clicked=True,issuer_action=action,final_submit_clicked=False,
                status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',decision='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',reason_code='CASE_CREATED_QUESTIONNAIRE_FILLED',duplicate_screenshots=duplicate_evidence,questionnaire_screenshot=str(questionnaire_path),questionnaire_layout=layout)
            if truth(settings.get('allow_final_submit','NO')) and not settings.get('_pre_submit_only'):
                await validate_identity(scope,item,rol,identity['rol'])
                async def verify_final_identity():
                    await validate_identity(scope,item,rol,identity['rol'])
                completed.update(await final_submit(page,case_page,scope,registry,settings,folder,log,verify_identity=verify_final_identity))
            return completed
        duplicate=await _duplicate(registry,page)
        if duplicate:
            if duplicate_handled:raise RuntimeError('ROL_749_REPEATED_AFTER_CONTINUATION')
            owner,ok=duplicate;registry.assert_owned(page,owner)
            path=Path(folder)/('02_duplicate_rol749_'+code_token([item])+'.png')
            await owner.screenshot(path=str(path),full_page=True)
            duplicate_evidence.append(str(path))
            checkpoint(folder,'ROL_749_CONTINUATION',duplicate_screenshots=duplicate_evidence)
            log.warning('ROL-749 acknowledge on owned popup; resubmit Case Creation once')
            await ok.evaluate('el=>el.click()')
            duplicate_handled=True;submitted=False;deadline=time.monotonic()+20
            # The old document can remain visible briefly after OK. Do not
            # misclassify that rendering delay as a second duplicate warning.
            while await _duplicate(registry,page):
                if time.monotonic()>=deadline:raise RuntimeError('ROL_749_ACKNOWLEDGEMENT_TRANSITION_TIMEOUT')
                await asyncio.sleep(.2)
        if not submitted:
            contract=await _case_submit(registry,page)
            if contract:
                owner,frame,submit=contract;registry.assert_owned(page,owner)
                await _ensure_create_dispute(owner)
                await owner.screenshot(path=str(Path(folder)/'03_before_case_creation_submit.png'),full_page=True)
                checkpoint(folder,'CASE_CREATION_SUBMIT_DISPATCHING',page_url=owner.url,frame_url=frame.url)
                log.info('CASE CREATION SUBMIT | owned_page=%s | frame=%s',owner.url,frame.name)
                # One dispatch only. A lost response is reconciled, never blindly clicked again.
                await submit.evaluate('el=>el.click()')
                submitted=True;submitted_page=owner;deadline=time.monotonic()+int(settings.get('questionnaire_timeout_ms') or 45000)/1000
                checkpoint(folder,'CASE_CREATION_SUBMIT_DISPATCHED')
        if time.monotonic()>=deadline:
            checkpoint(folder,'CASE_TRANSITION_REVIEW_REQUIRED',submit_dispatched=submitted)
            raise RuntimeError('QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT' if submitted else 'OWNED_CASE_CREATION_OR_QUESTIONNAIRE_NOT_FOUND')
        await asyncio.sleep(.2)
