"""One-time migration: reviewed_guids.txt + runtime/review_holds -> AK/AL/AM in the 09 master.

After this, the master (AM) plus the ledger are the only run-to-run state:
* GUIDs in the legacy registry get the label of their latest async result
  (PI, NO_CB, Assoc D, FRAUD/consumer[ - chờ Final Submit], Review: ...), or
  'Đã xử lý (registry cũ)' when no result file survives.
* Review holds become 'Review: <reason>' with their ROL in AK (they win over history).
* Only GUIDs whose AM is empty on every row are touched; existing AM is never replaced.

Default is a dry run that writes migration_plan.csv only. --apply records the plan in
the ledger and patches the master through BusinessState.sync (backup in --report-dir).
"""
import argparse
import csv
import json
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook

from .business_status import BusinessState, groups, result_label, VN
from .outcome_policy import outcome_class, CHECKPOINT, TRANSIENT

LEGACY_LABEL = 'Đã xử lý (registry cũ)'


def registry_guids(path):
    path = Path(path)
    if not path.exists():
        return set()
    out = set()
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        guid = line.strip().split('|', 1)[0].upper()
        if guid:
            out.add(guid)
    return out


def latest_results(runs_dirs):
    latest = {}
    for runs in runs_dirs:
        for path in Path(runs).glob('*/groups/*/guid_result.json'):
            try:
                record = json.loads(path.read_text(encoding='utf-8'))
                guid = str(record['guid']).upper()
            except (OSError, ValueError, KeyError):
                continue
            # Diagnostic (pi-only/inquiry-only) and transient results are not business outcomes.
            if outcome_class(record.get('result') or record) in (CHECKPOINT, TRANSIENT):
                continue
            stamp = path.parent.parent.parent.name  # run id sorts by time
            if guid not in latest or stamp > latest[guid][0]:
                latest[guid] = (stamp, record)
    return {g: r for g, (_, r) in latest.items()}


def _when(record):
    raw = record.get('completed_at') if record else None
    try:
        return datetime.strptime(raw, '%d.%m.%Y %H:%M:%S').replace(tzinfo=VN).isoformat(timespec='seconds')
    except (TypeError, ValueError):
        return None


def build_plan(master, registry_file, hold_dir, runs_dirs):
    wb = load_workbook(master, read_only=True)
    try:
        live = groups(wb['Sheet1'])
    finally:
        wb.close()
    registry = registry_guids(registry_file)
    holds = {}
    for path in Path(hold_dir).glob('*.json') if hold_dir and Path(hold_dir).is_dir() else []:
        try:
            record = json.loads(path.read_text(encoding='utf-8'))
            holds[str(record.get('guid') or path.stem).upper()] = record
        except (OSError, ValueError):
            holds[path.stem.upper()] = dict(reason_code='REVIEW_HOLD_UNREADABLE')
    history = latest_results(runs_dirs)
    plan = []
    for guid in sorted(registry | set(holds)):
        entry = live.get(guid)
        if not entry:
            plan.append(dict(guid=guid, action='NOT_IN_MASTER'))
            continue
        if entry['marks']:
            plan.append(dict(guid=guid, action='AM_ALREADY_SET', label=' | '.join(sorted(entry['marks']))))
            continue
        record = history.get(guid)
        result = (record or {}).get('result') or {}
        if guid in holds:
            hold = holds[guid]
            label, source = 'Review: ' + str(hold.get('reason_code') or 'HOLD_REVIEW'), 'HOLD'
            rol = hold.get('rol') or result.get('rol') or result.get('vrol_case_number')
        elif record:
            label, source = result_label(result), 'RUN_HISTORY'
            rol = result.get('rol') or result.get('vrol_case_number')
        else:
            label, source, rol = LEGACY_LABEL, 'REGISTRY_ONLY', None
        plan.append(dict(guid=guid, action='WRITE', source=source, label=label, rols=[str(rol)] if rol else [],
                         processed_at=_when(record), reason=result.get('reason_code') or '', rows=len(entry['rows'])))
    return plan


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--master', required=True, help='09_CHARGEBACK_CLASSIFIED.xlsx to receive AK/AL/AM')
    parser.add_argument('--registry', required=True, help='legacy reviewed_guids.txt')
    parser.add_argument('--holds', help='legacy runtime\\review_holds folder')
    parser.add_argument('--runs', action='append', default=[], help='runtime\\async_parallel folder(s) with guid_result.json history')
    parser.add_argument('--ledger', required=True, help='business_state.sqlite3 used by the bot')
    parser.add_argument('--report-dir', required=True)
    parser.add_argument('--apply', action='store_true', help='write the ledger and the master (default: dry run)')
    args = parser.parse_args(argv)
    report = Path(args.report_dir)
    report.mkdir(parents=True, exist_ok=True)
    plan = build_plan(args.master, args.registry, args.holds, args.runs)
    with (report / 'migration_plan.csv').open('w', newline='', encoding='utf-8-sig') as handle:
        writer = csv.DictWriter(handle, fieldnames=['guid', 'action', 'source', 'label', 'rols', 'processed_at', 'reason', 'rows'])
        writer.writeheader()
        for row in plan:
            writer.writerow({**row, 'rols': ' | '.join(row.get('rols') or [])})
    counts = {}
    for row in plan:
        key = row['action'] + (':' + row['source'] if row.get('source') else '')
        counts[key] = counts.get(key, 0) + 1
    summary = dict(apply=args.apply, counts=counts, plan=str(report / 'migration_plan.csv'))
    if args.apply:
        state = BusinessState(args.ledger, args.master, report)
        try:
            seeded = state.seed_outcomes([row for row in plan if row['action'] == 'WRITE'])
            summary['ledger_seeded'] = len(seeded)
            summary['master_writeback'] = state.sync()
        finally:
            state.close()
    (report / 'migration_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
