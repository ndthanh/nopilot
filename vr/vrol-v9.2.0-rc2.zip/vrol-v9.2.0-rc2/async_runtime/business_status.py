"""Business columns AK/AL/AM and durable, identity-scoped master writeback."""
import hashlib,json,os,shutil,sqlite3,uuid
from datetime import datetime,timedelta,timezone
from pathlib import Path
from zipfile import BadZipFile
from xml.parsers.expat import ExpatError
from openpyxl import load_workbook
from .xlsx_patch import patch_cells
from .outcome_policy import outcome_class,TRANSIENT,CHECKPOINT

VN=timezone(timedelta(hours=7));AK,AL,AM=37,38,39
DRAFT_SUFFIX=' - chờ Final Submit'
ASSOCIATED_LABEL='Có associated transactions'
MULTIPLE_SALE_LABEL='Nhiều dòng Sale'
def multiple_sale_rows(result):
    return any(str(x.get('reason_code') or '').upper().startswith('SALE_ROW_NOT_UNIQUE') for x in result.get('invoice_results') or [])
def text(value):return str(value if value is not None else '').strip()
def is_force(marks):
    """AM control precedence: SKIP > FORCE > any other value (bot result or note)."""
    upper={text(x).upper() for x in marks}
    return 'FORCE' in upper and 'SKIP' not in upper
def stamp():return datetime.now(VN).isoformat(timespec='seconds')
def file_hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def groups(ws):
    headers={text(c.value).upper():c.column for c in ws[2] if c.value is not None}
    if not {'GUID','INVOICENUM','BUT TOAN','CODE CB'}<=headers.keys():raise ValueError('MASTER_IDENTITY_HEADERS_MISSING')
    out={}
    for row_no,row in enumerate(ws.iter_rows(min_row=4,max_col=max(AM,ws.max_column or AM)),4):
        get=lambda name:text(row[headers[name]-1].value)
        guid=get('GUID').upper()
        if not guid:continue
        entry=out.setdefault(guid,dict(rows=[],keys=set(),marks=set(),rols=set(),am_missing=False,al_missing=False,ak_missing=False))
        entry['rows'].append(row_no)
        entry['keys'].add((get('INVOICENUM').lstrip('0') or '0',get('BUT TOAN').upper(),get('CODE CB')))
        if text(row[AM-1].value):entry['marks'].add(text(row[AM-1].value))
        # AK holds one ROL or several written as 'ROL1 | ROL2'; compare them one by one.
        entry['rols'].update(x.strip() for x in text(row[AK-1].value).split('|') if x.strip())
        entry['am_missing']|=not text(row[AM-1].value)
        entry['al_missing']|=row[AL-1].value is None
        entry['ak_missing']|=not text(row[AK-1].value)
    for entry in out.values():
        entry['signature']=hashlib.sha256(json.dumps(sorted(entry['keys']),ensure_ascii=False).encode()).hexdigest()
    return out

def reserve_columns(ws):
    expected={AK:('VROL',{'VROL','ROL CASE'}),AL:('CB date',{'CB DATE','NGAY BOT PROCESS','BOT PROCESS DATE'}),AM:('CB reject',{'CB REJECT','VROL RESULT','BOT RESULT'})}
    for col,(name,allowed) in expected.items():
        old=text(ws.cell(2,col).value)
        if old and old.upper() not in allowed:
            if not old.upper().startswith('BOT '):raise ValueError('BUSINESS_COLUMN_ALREADY_USED:'+str(col))
            target=max(AM,ws.max_column)+1
            for row in range(1,ws.max_row+1):ws.cell(row,target,ws.cell(row,col).value);ws.cell(row,col).value=None
        if not ws.cell(2,col).value:ws.cell(2,col,name)

def result_label(result):
    reason=str(result.get('reason_code') or '');status=str(result.get('status') or '')
    if any(x.get('pi_status')=='DOWNLOADED' for x in result.get('invoice_results',[])):return 'PI'
    if status=='NO_CHARGEBACK_REQUIRED':
        duplicate=reason=='GROUP_CONTAINS_ASSOC_DISPUTE_D' or any('D' in x.get('assoc_disputes',[]) or x.get('assoc_dispute')=='D' for x in result.get('invoice_results',[]))
        return 'Assoc D' if duplicate else 'NO_CB'
    if status in {'QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT','FINAL_SUBMIT_COMPLETED'}:
        action=str(result.get('issuer_action') or '').casefold()
        # A draft (questionnaire filled, Final Submit not clicked) must not look like a sent dispute.
        draft=DRAFT_SUFFIX if status=='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT' else ''
        if action=='fraud':return 'FRAUD'+draft
        if action=='consumer':return 'consumer'+draft
    if reason in {'INVOICE_NOT_IN_TRUNCATED_TRANSACTION_RESULTS','TRANSACTION_RESULTS_TRUNCATED_300_PLUS'}:return 'Trả user: VROL trả 300+ giao dịch; cần kiểm tra thủ công (backlog)'
    if reason=='ELIGIBLE_ROW_NOT_UNIQUE':
        # One invoice with several Sale rows in Tran Type: hand back to the user as-is.
        if multiple_sale_rows(result):return MULTIPLE_SALE_LABEL
        return 'Trả user: nhiều Sale/Cash cho một invoice; cần kiểm tra thủ công'
    if reason=='ASSOCIATED_TRANSACTIONS_SCREEN' or status=='ASSOCIATED_TRANSACTIONS_REVIEW_REQUIRED':return ASSOCIATED_LABEL
    if reason=='ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY':return 'Trả user: cần tra soát từng giao dịch (ROL-1537), đã retry 1 lần' if result.get('case_retry_count') else 'Trả user: cần tra soát từng giao dịch (ROL-1537)'
    if reason in {'QUESTIONNAIRE_TRANSITION_TIMEOUT_AFTER_CASE_SUBMIT','OWNED_CASE_CREATION_OR_QUESTIONNAIRE_NOT_FOUND','QUESTIONNAIRE_NOT_STABLE_BEFORE_FILL'}:
        return 'Review: timeout questionnaire'+('; đã retry 1 lần' if result.get('case_retry_count') else '')
    return 'Review: '+(reason or status or 'chưa xác định kết quả')

def write_group(ws,entry,label,processed,rols):
    for row in entry['rows']:
        ws.cell(row,AM,label)
        if processed:
            ws.cell(row,AL,datetime.fromisoformat(processed).date());ws.cell(row,AL).number_format='dd/mm/yyyy'
        if rols:ws.cell(row,AK,' | '.join(rols))

def prepare_input_columns(source,target):
    """Reserve business columns on a private copy before BOT fields are appended."""
    source,target=Path(source),Path(target);shutil.copy2(source,target)
    wb=load_workbook(target)
    try:
        ws=wb['Sheet1'];patches={}
        allowed={AK:('VROL',{'VROL','ROL CASE'}),AL:('CB date',{'CB DATE','NGAY BOT PROCESS','BOT PROCESS DATE'}),AM:('CB reject',{'CB REJECT','VROL RESULT','BOT RESULT'})}
        for col,(name,names) in allowed.items():
            existing=text(ws.cell(2,col).value)
            if existing and existing.upper() not in names:raise ValueError('INPUT_BUSINESS_COLUMN_OCCUPIED:'+str(col))
            if not existing:patches[ws.cell(2,col).coordinate]=name
        if patches:
            temp=target.with_suffix('.columns.xlsx');patch_cells(target,temp,'Sheet1',patches,wb.epoch);os.replace(temp,target)
    finally:wb.close()
    return target

class BusinessState:
    def __init__(self,database,master,run_dir,retention_days=180,*,readonly=False,max_transient_attempts=3):
        if int(retention_days)<1:raise ValueError('BUSINESS_STATE_RETENTION_MUST_BE_POSITIVE')
        self.path=Path(database);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.master=Path(master).resolve();self.run_dir=Path(run_dir);self.retention_days=int(retention_days)
        if any(part.casefold()=='ops_inputs' for part in self.master.parts):raise ValueError('MASTER_MUST_NOT_BE_CONTRACT_SNAPSHOT')
        # All writes are serialized by CentralWriter; its executor thread can vary.
        self.db=sqlite3.connect(self.path,check_same_thread=False)
        self.db.execute('pragma journal_mode=wal')
        self.db.execute('create table if not exists outcomes(guid text primary key, signature text, label text, processed_at text, rols text, reason text)')
        self.db.execute('create table if not exists force_writebacks(guid text primary key, signature text, label text)')
        # Technical failures before any case side effect: retried, not written to AM.
        self.db.execute('create table if not exists transient_attempts(guid text primary key, signature text, attempts integer, last_reason text, last_at text)')
        # User intent carried across fresh upstream files (SKIP) and bot writes per master path.
        self.db.execute('create table if not exists user_actions(guid text primary key, signature text, action text, master text, at text)')
        self.db.execute('create table if not exists writebacks(guid text, master text, label text, at text, primary key(guid,master))')
        self.db.commit();self.backed_up=False
        self.readonly=bool(readonly);self.max_transient_attempts=int(max_transient_attempts)
        self.excluded={};self.user_cleared=[]

    def records(self):
        return {r[0]:dict(signature=r[1],label=r[2],processed_at=r[3],rols=json.loads(r[4]),reason=r[5]) for r in self.db.execute('select * from outcomes')}

    def bind(self,ws):
        self._output_ws=ws;self._output_entries=groups(ws)

    def record(self,ws,guid,result):
        """Write AM/ledger for business outcomes; keep transient failures retryable."""
        if self.readonly:return 'READ_ONLY'
        if getattr(self,'_output_ws',None) is not ws:self.bind(ws)
        entry=self._output_entries.get(guid)
        if not entry:return 'NOT_IN_OUTPUT'
        kind=outcome_class(result)
        if kind==CHECKPOINT:return kind
        label=result_label(result)
        if kind==TRANSIENT:
            row=self.db.execute('select signature,attempts from transient_attempts where guid=?',(guid,)).fetchone()
            attempts=(row[1] if row and row[0]==entry['signature'] else 0)+1
            self.db.execute('insert or replace into transient_attempts values(?,?,?,?,?)',(guid,entry['signature'],attempts,str(result.get('reason_code') or ''),stamp()))
            self.db.commit()
            result['transient_attempts']=attempts
            if attempts<self.max_transient_attempts:return kind
            label=f'{label} (đã thử {attempts} lần)'
        processed=stamp();rols=[]
        for value in [result.get('rol'),result.get('vrol_case_number')]:
            if value and str(value) not in rols:rols.append(str(value))
        write_group(ws,entry,label,processed,rols)
        self.db.execute('insert or replace into outcomes values(?,?,?,?,?,?)',(guid,entry['signature'],label,processed,json.dumps(rols),str(result.get('reason_code') or '')))
        self.db.execute('delete from transient_attempts where guid=?',(guid,))
        if is_force(entry['marks']):
            self.db.execute('insert or replace into force_writebacks values(?,?,?)',(guid,entry['signature'],label))
            self.db.execute('delete from user_actions where guid=?',(guid,))
        self.db.commit()
        return kind

    def prepare(self,source,*,restore=True):
        """Copy a frozen input; live AM edits win over carried state."""
        source=Path(source).resolve()
        if not self.master.is_file():raise ValueError('MASTER_WORKBOOK_NOT_FOUND: configure async_master_workbook or refresh the RPA Ops contract')
        if restore and not self.readonly:self.sync()
        carried=self.records() if restore else {}
        actions={r[0]:dict(signature=r[1],action=r[2],master=r[3]) for r in self.db.execute('select * from user_actions')}
        master_key=str(self.master).casefold();now=stamp()
        pending={r[0]:(r[1],r[2]) for r in self.db.execute('select * from force_writebacks')}
        target=prepare_input_columns(source,self.run_dir/'09_BUSINESS_INPUT.xlsx')
        wb=load_workbook(target);ws=wb['Sheet1'];entries=groups(ws);patches={}
        master=load_workbook(self.master,read_only=True,data_only=False)
        try:
            live=master['Sheet1'];live_groups=groups(live);identity_conflicts=[]
            for guid,entry in entries.items():
                current=live_groups.get(guid)
                marks={x.upper() for x in (current or {}).get('marks',set())}
                saved_action=actions.get(guid)
                if current and 'SKIP' in marks and not self.readonly:
                    self.db.execute('insert or replace into user_actions values(?,?,?,?,?)',(guid,current['signature'],'SKIP',master_key,now))
                elif current and not marks and saved_action and saved_action['master']==master_key and not self.readonly:
                    # The user removed SKIP from the same master: that cancels it.
                    self.db.execute('delete from user_actions where guid=?',(guid,));saved_action=None
                elif current and is_force(marks) and saved_action and not self.readonly:
                    self.db.execute('delete from user_actions where guid=?',(guid,));saved_action=None
                if current and current['marks']:
                    nonforce={x for x in current['marks'] if x.upper()!='FORCE'}
                    mark='SKIP' if 'SKIP' in marks else 'FORCE' if is_force(marks) else sorted(nonforce)[0]
                    if mark=='FORCE' and current['signature']!=entry['signature']:
                        identity_conflicts.append(guid);continue
                    saved=carried.get(guid)
                    if mark=='FORCE' and saved and pending.get(guid)==(entry['signature'],saved['label']):
                        # This FORCE has already run; its result only awaits
                        # writeback. Carry that outcome, never queue it again.
                        mark=None
                    for row in entry['rows']:ws.cell(row,AM).value=mark;patches[ws.cell(row,AM).coordinate]=mark
                elif not current or current['signature']!=entry['signature']:
                    identity_conflicts.append(guid)
                else:
                    if saved_action and saved_action['action']=='SKIP' and saved_action['signature']==entry['signature']:
                        # SKIP typed in an earlier upstream file still applies.
                        for row in entry['rows']:ws.cell(row,AM).value='SKIP';patches[ws.cell(row,AM).coordinate]='SKIP'
                        continue
                    # A user can cancel an unpublished-to-bot FORCE request by
                    # clearing it in the live master after contract publication.
                    for row in entry['rows']:
                        if text(ws.cell(row,AM).value).upper()=='FORCE':
                            ws.cell(row,AM).value=None;patches[ws.cell(row,AM).coordinate]=None
            self.db.commit()
            if identity_conflicts:
                # Exclude only the changed GUIDs; the rest of the queue still runs.
                (self.run_dir/'master_input_conflicts.json').write_text(json.dumps(dict(reason='MASTER_INPUT_IDENTITY_CHANGED',guids=identity_conflicts),indent=2),encoding='utf-8')
                self.excluded.update({guid:'MASTER_INPUT_IDENTITY_CHANGED' for guid in identity_conflicts})
        finally:master.close()
        if restore:
            for guid,record in carried.items():
                entry=entries.get(guid)
                if entry and entry['signature']==record['signature'] and not any(text(ws.cell(r,AM).value) for r in entry['rows']):
                    write_group(ws,entry,record['label'],record['processed_at'],record['rols'])
                    for row in entry['rows']:
                        for col in (AK,AL,AM):patches[ws.cell(row,col).coordinate]=ws.cell(row,col).value
        epoch=wb.epoch;wb.close()
        if patches:
            temp=target.with_suffix('.patch.xlsx');patch_cells(target,temp,'Sheet1',patches,epoch);os.replace(temp,target)
        return target

    def sync(self,output=None):
        """Merge by identity, save atomically, defer if Excel is open/changed."""
        report=dict(master=str(self.master),status='UNCHANGED',updated_guids=0,conflicts=[],missing=[],user_cleared=[],at=stamp())
        if self.readonly:
            report['status']='READ_ONLY'
            (self.run_dir/'master_writeback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
            return report
        records=self.records();intents={r[0]:(r[1],r[2]) for r in self.db.execute('select * from force_writebacks')}
        master_key=str(self.master).casefold()
        written={r[0]:r[1] for r in self.db.execute('select guid,label from writebacks where master=?',(master_key,))}
        if output:
            wb=load_workbook(output,read_only=True,data_only=True)
            try:
                ws=wb['Sheet1']
                for guid,entry in groups(ws).items():
                    record=records.get(guid)
                    if not record or record['signature']!=entry['signature']:continue
                    # Fresh postflight ROL observations update known ROLs, not
                    # the business outcome or Final Submit claim.
                    values=entry['rols']
                    if values:
                        record['rols']=sorted(values);self.db.execute('update outcomes set rols=? where guid=?',(json.dumps(record['rols']),guid))
                self.db.commit()
            finally:wb.close()
        wb=None;temp=None
        try:
            before=file_hash(self.master);wb=load_workbook(self.master,read_only=True);ws=wb['Sheet1'];patches={};applied=[]
            # The master must expose the physical business columns. Do not move
            # existing user data to make room for them during writeback.
            allowed={AK:{'','VROL','ROL CASE'},AL:{'','CB DATE','NGAY BOT PROCESS','BOT PROCESS DATE'},AM:{'','CB REJECT','VROL RESULT','BOT RESULT'}}
            for col,names in allowed.items():
                if text(ws.cell(2,col).value).upper() not in names:raise RuntimeError('MASTER_BUSINESS_COLUMN_OCCUPIED:'+str(col))
            entries=groups(ws);epoch=wb.epoch;wb.close();wb=None
            for guid,entry in entries.items():
                record=records.get(guid)
                if not record or record['signature']!=entry['signature']:continue
                force_pending=is_force(entry['marks']) and intents.get(guid)==(record['signature'],record['label'])
                same_label={x.casefold() for x in entry['marks']}=={record['label'].casefold()}
                if not entry['marks'] and guid in written:
                    # The bot wrote this master before and the user emptied AM:
                    # respect the edit, report it, require FORCE to reprocess.
                    report['user_cleared'].append(guid);continue
                if entry['marks'] and not same_label and not force_pending:
                    report['conflicts'].append(guid);continue
                # Do not replace a directly observed different ROL silently.
                existing=entry['rols']
                if record['rols'] and existing and existing!=set(record['rols']):
                    report['conflicts'].append(guid);continue
                changed=not same_label or entry['am_missing'] or entry['al_missing'] or (record['rols'] and entry['ak_missing'])
                if not changed:applied.append(guid);continue
                report['updated_guids']+=1
                applied.append(guid)
                for row in entry['rows']:
                    patches[f'AM{row}']=record['label']
                    patches[f'AL{row}']=datetime.fromisoformat(record['processed_at']).date()
                    if record['rols']:patches[f'AK{row}']=' | '.join(record['rols'])
            if report['updated_guids']:
                if not self.backed_up:
                    backup=self.run_dir/'master_backups'/self.master.name;backup.parent.mkdir(parents=True,exist_ok=True)
                    if not backup.exists():shutil.copy2(self.master,backup)
                    self.backed_up=True
                temp=self.master.with_name('.'+self.master.stem+'.vrol_'+uuid.uuid4().hex+'.xlsx');patch_cells(self.master,temp,'Sheet1',patches,epoch)
                if file_hash(self.master)!=before:raise RuntimeError('MASTER_CHANGED_DURING_WRITEBACK')
                os.replace(temp,self.master);report['status']='UPDATED'
            self.db.executemany('delete from force_writebacks where guid=?',[(guid,) for guid in applied])
            self.db.executemany('insert or replace into writebacks values(?,?,?,?)',[(guid,master_key,records[guid]['label'],report['at']) for guid in applied])
            self.db.commit()
            self.user_cleared=report['user_cleared']
            if report['conflicts']:report['status']='CONFLICT'
            elif report['user_cleared'] and report['status']=='UNCHANGED':report['status']='USER_CLEARED'
        except (OSError,RuntimeError,ValueError,KeyError,BadZipFile,ExpatError) as exc:
            report.update(status='PENDING',error=type(exc).__name__+': '+str(exc))
        finally:
            if wb:wb.close()
            if temp and temp.exists():temp.unlink(missing_ok=True)
        (self.run_dir/'master_writeback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return report

    def seed_outcomes(self,items):
        """Record outcomes found outside a CASE_RESULT (e.g. a run killed after Issuer Action).

        items: dicts with guid, label, reason, rols, processed_at. A GUID that already has
        a ledger outcome is left alone, so a later FORCE result is never overwritten.
        Returns the GUIDs recorded; they reach AM through prepare()/sync().
        """
        if self.readonly or not items:return []
        known={r[0] for r in self.db.execute('select guid from outcomes')}
        wb=load_workbook(self.master,read_only=True)
        try:live=groups(wb['Sheet1'])
        finally:wb.close()
        seeded=[]
        for item in items:
            guid=str(item['guid']).upper();entry=live.get(guid)
            # Never compete with a value already in the live AM (user SKIP/FORCE/note or older result).
            if guid in known or not entry or entry['marks']:continue
            self.db.execute('insert or replace into outcomes values(?,?,?,?,?,?)',(guid,entry['signature'],item['label'],item.get('processed_at') or stamp(),json.dumps(item.get('rols') or []),item.get('reason') or ''))
            known.add(guid);seeded.append(guid)
        self.db.commit()
        return seeded

    def cleanup(self,registry,source):
        """Expire old ledger rows. The legacy registry (if given) is only de-duplicated."""
        cutoff=(datetime.now(VN)-timedelta(days=self.retention_days)).isoformat()
        expired=0
        if not self.readonly:
            expired=self.db.execute('delete from outcomes where processed_at < ?',(cutoff,)).rowcount
            self.db.execute('delete from force_writebacks where guid not in (select guid from outcomes)')
            self.db.execute('delete from transient_attempts where last_at < ?',(cutoff,))
            self.db.commit()
        if registry is None:return dict(expired_ledger_records=expired,registry='RETIRED')
        path=Path(registry);before=path.read_text(encoding='utf-8-sig').splitlines() if path.exists() else []
        keep=sorted({x.strip().upper() for x in before if x.strip()})
        if not self.readonly and len(keep)!=len(before):
            backup=self.run_dir/'registry_backups';backup.mkdir(exist_ok=True)
            if path.exists():shutil.copy2(path,backup/path.name)
            target=path.with_suffix('.business.tmp');target.write_text('\n'.join(keep)+('\n' if keep else ''),encoding='utf-8');os.replace(target,path)
        return dict(expired_ledger_records=expired,registry_before=len(before),registry_after=len(keep) if not self.readonly else len(before))

    def close(self):self.db.close()
