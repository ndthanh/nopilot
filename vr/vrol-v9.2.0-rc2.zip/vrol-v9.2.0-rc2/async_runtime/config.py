from pathlib import Path
from openpyxl import load_workbook
def load_settings(path:Path)->dict:
 wb=load_workbook(path,data_only=True,read_only=True);out={}
 final_submit_setting=None
 for sn in ('Settings','RunSettings'):
  if sn not in wb.sheetnames:continue
  for row in wb[sn].iter_rows(min_row=2,values_only=True):
   if row and row[0] not in (None,''):
    key=str(row[0]).strip()
    # Settings is authoritative; legacy RunSettings only fills missing keys.
    if sn=='RunSettings' and key in out:
     if out[key]!=row[1]:out.setdefault('_shadowed_runsettings',[]).append(key)
     continue
    out[key]=row[1]
    if sn=='Settings' and key=='allow_final_submit':final_submit_setting=(row[1],sn)
 # One switch must be sufficient. Legacy RunSettings also contains this key;
 # Settings is authoritative for native Final Submit, even if legacy says NO.
 if final_submit_setting is not None:
  out['allow_final_submit']=final_submit_setting[0]
  out['_allow_final_submit_source']=final_submit_setting[1]
 
 # Preserve enabled security-question answers for async login parity with v9.0.60.
 answers={}
 if 'SecurityQuestions' in wb.sheetnames:
  import re
  for row in wb['SecurityQuestions'].iter_rows(min_row=2,values_only=True):
   question=row[0] if len(row)>0 else None;answer=row[1] if len(row)>1 else None;enabled=row[2] if len(row)>2 else None
   if question and answer and truth(enabled):
    key=re.sub(r'[\s?.!]+$','',re.sub(r'\s+',' ',str(question)).strip().lower())
    answers[key]=str(answer)
 out['_security_answers']=answers
 out['_config_path']=str(path.resolve())
 wb.close();return out
def truth(v):return str(v or '').strip().upper() in {'YES','Y','TRUE','1','ON'}
