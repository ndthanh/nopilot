from __future__ import annotations
import asyncio,re,time
from pathlib import Path
from datetime import datetime,timedelta
from src.vrol.reports.rol500 import parse_rol500,enrich_classified

async def _visible(page, selectors, timeout_ms=20000):
    deadline=time.monotonic()+timeout_ms/1000
    while time.monotonic()<deadline:
        for scope in [page]+[f for f in page.frames if f!=page.main_frame]:
            for sel in selectors:
                try:
                    loc=scope.locator(sel).first
                    if await loc.count() and await loc.is_visible(): return scope,loc,sel
                except Exception: pass
        await page.wait_for_timeout(150)
    raise RuntimeError('ROL500_CONTROL_NOT_FOUND:'+','.join(selectors))

async def _visible_match(scope,selector,timeout_ms=10000):
    """Return the first actually visible match instead of Locator.first.

    VROL renders duplicate responsive menu trees. The first matching Financial
    Reports anchor can remain hidden even after the active Reports menu opens.
    """
    deadline=time.monotonic()+timeout_ms/1000
    observed=[]
    while time.monotonic()<deadline:
        matches=scope.locator(selector)
        try:count=await matches.count()
        except Exception:count=0
        visible_indexes=[]
        for index in range(count):
            item=matches.nth(index)
            try:
                visible=await item.is_visible()
                if visible:return item,index,count
                visible_indexes.append(False)
            except Exception:visible_indexes.append(False)
        observed.append({'count':count,'visible':visible_indexes})
        await scope.wait_for_timeout(100)
    raise RuntimeError(f'ROL500_VISIBLE_MENU_MATCH_NOT_FOUND:selector={selector}:observed={observed[-3:]}')

async def _hover_with_fallback(locator,label,log,timeout_ms):
    try:
        await locator.hover(timeout=timeout_ms)
        log('success',f'ROL500 menu hover | menu={label} | strategy=NORMAL')
        return
    except Exception as exc:
        log('warning',f'ROL500 normal hover failed | menu={label} | error={str(exc).splitlines()[0]}')
    try:
        await locator.hover(timeout=timeout_ms,force=True)
        log('success',f'ROL500 menu hover | menu={label} | strategy=FORCE')
        return
    except Exception as exc:
        log('warning',f'ROL500 force hover failed | menu={label} | error={str(exc).splitlines()[0]}')
    await locator.evaluate("el => {const o={bubbles:true,cancelable:true,view:window};el.dispatchEvent(new MouseEvent('mouseover',o));el.dispatchEvent(new MouseEvent('mouseenter',o));el.focus();}")
    log('success',f'ROL500 menu hover | menu={label} | strategy=DOM_MOUSE_EVENTS')

async def _wait_menu_stable(vrol,settings,log):
    stable_required=int(settings.get('rol500_menu_stable_polls') or 4)
    poll_ms=int(settings.get('rol500_menu_stable_poll_ms') or 250)
    timeout_ms=int(settings.get('rol500_menu_ready_timeout_ms') or 20000)
    deadline=time.monotonic()+timeout_ms/1000;stable=0;last=None
    while time.monotonic()<deadline:
        try:
            reports=vrol.locator('a#reportmenua').first
            visible=await reports.is_visible()
            signature=(vrol.url,visible,await reports.get_attribute('aria-expanded'))
            if visible and signature==last: stable+=1
            elif visible: stable=1
            else: stable=0
            last=signature
            if stable>=stable_required:
                log('success',f'ROL500 Reports menu stable | polls={stable} | url={vrol.url}')
                return reports
        except Exception:
            stable=0
        await vrol.wait_for_timeout(poll_ms)
    raise RuntimeError('ROL500_REPORTS_MENU_NOT_STABLE')

async def _processing_request_visible(vrol):
    for frame in vrol.frames:
        try:
            loc=frame.get_by_text('processing request',exact=False).first
            if await loc.count() and await loc.is_visible():return True
        except Exception:pass
    return False

async def _wait_rol500_retry_ready(vrol,settings,log):
    timeout=int(settings.get('rol500_retry_ready_timeout_ms') or 30000)
    poll=int(settings.get('rol500_menu_stable_poll_ms') or 250)
    deadline=time.monotonic()+timeout/1000;stable=0;last=None
    while time.monotonic()<deadline:
        processing=await _processing_request_visible(vrol)
        reports=vrol.locator('a#reportmenua').first
        visible=False
        try:visible=bool(await reports.count() and await reports.is_visible())
        except Exception:pass
        signature=(vrol.url,visible,processing)
        if visible and not processing and signature==last:stable+=1
        elif visible and not processing:stable=1
        else:stable=0
        last=signature
        if stable>=int(settings.get('rol500_menu_stable_polls') or 4):
            log('success',f'ROL500 retry landing ready | polls={stable} | processing_request=false')
            return
        await vrol.wait_for_timeout(poll)
    raise RuntimeError('ROL500_RETRY_LANDING_NOT_READY')

async def _wait_parameter_controls(vrol,settings,log):
    """Require the complete ROL500 parameter form, not only Financial Type."""
    timeout=int(settings.get('rol500_parameter_timeout_ms') or 30000)
    poll=int(settings.get('rol500_parameter_controls_poll_ms') or 200)
    stable_required=int(settings.get('rol500_parameter_controls_stable_polls') or 3)
    selectors={
        'financial':'select[aria-label="Financial Type"]',
        'from':'input[name="dateFromTxt"]',
        'to':'input[name="dateToTxt"]',
    }
    deadline=time.monotonic()+timeout/1000;stable=0;last_scope='';history=[]
    while time.monotonic()<deadline:
        found={}
        for scope in [vrol]+[f for f in vrol.frames if f!=vrol.main_frame]:
            current={}
            for key,selector in selectors.items():
                try:
                    matches=scope.locator(selector);count=await matches.count();visible=None
                    for index in range(count):
                        candidate=matches.nth(index)
                        if await candidate.is_visible():visible=candidate;break
                    if visible is not None:current[key]=visible
                except Exception:pass
            if len(current)==3:
                scope_id=f'{getattr(scope,"name","")}|{getattr(scope,"url","")}'
                if scope_id==last_scope:stable+=1
                else:stable=1;last_scope=scope_id
                found=current
                if stable>=stable_required:
                    log('success',f'ROL500 complete parameter form ready | stable_polls={stable} | scope={scope_id}')
                    return scope,current['financial'],current['from'],current['to']
                break
        if not found:stable=0;last_scope=''
        history.append({'frames':[(f.name,f.url) for f in vrol.frames],'stable':stable})
        await vrol.wait_for_timeout(poll)
    raise RuntimeError('ROL500_COMPLETE_PARAMETER_FORM_NOT_READY:'+repr(history[-5:]))

async def _open_parameters(vrol,settings,log):
    attempts=int(settings.get('rol500_menu_open_attempts') or 4)
    hover_timeout=int(settings.get('rol500_menu_hover_timeout_ms') or 5000)
    hover_delay=int(settings.get('rol500_menu_hover_delay_ms') or 500)
    transition_timeout=int(settings.get('rol500_parameter_transition_timeout_ms') or 20000)
    for attempt in range(1,attempts+1):
        if attempt>1:
            await _wait_rol500_retry_ready(vrol,settings,log)
            await vrol.mouse.move(5,5)
            await vrol.wait_for_timeout(min(1000*attempt,3000))
        reports=await _wait_menu_stable(vrol,settings,log)
        try:
            financial=None;financial_index=-1;financial_count=0
            submenu_cycles=int(settings.get('rol500_submenu_reveal_cycles') or 3)
            for reveal in range(1,submenu_cycles+1):
                await _hover_with_fallback(reports,'Reports',log,hover_timeout)
                try:
                    await reports.evaluate("el => { el.dispatchEvent(new MouseEvent('mouseenter',{bubbles:true})); el.dispatchEvent(new MouseEvent('mouseover',{bubbles:true})); }")
                except Exception:pass
                await vrol.wait_for_timeout(hover_delay*reveal)
                try:
                    financial,financial_index,financial_count=await _visible_match(vrol,'a[data-menu-id="reportmenu_sub3"]',int(settings.get('rol500_submenu_visible_probe_ms') or 3000))
                    break
                except Exception as probe_exc:
                    log('warning',f'ROL500 Financial submenu still hidden | attempt={attempt}/{attempts} | reveal={reveal}/{submenu_cycles} | processing_request={str(await _processing_request_visible(vrol)).lower()} | error={probe_exc}')
                    await vrol.mouse.move(5,5);await vrol.wait_for_timeout(300)
            if financial is None:raise RuntimeError('ROL500_FINANCIAL_SUBMENU_NOT_REVEALED')
            log('info',f'ROL500 visible Financial menu resolved | index={financial_index} | matches={financial_count}')
            await _hover_with_fallback(financial,'Financial Reports',log,hover_timeout)
            await vrol.wait_for_timeout(hover_delay)
            target,target_index,target_count=await _visible_match(vrol,'a[data-js*="reportSid/33"]',10000)
            log('info',f'ROL500 visible report target resolved | index={target_index} | matches={target_count}')
            await target.click()
            log('info',f'ROL500 menu clicked | attempt={attempt}/{attempts} | path=Reports > Financial Reports > ROL 500')
        except Exception as exc:
            diag=Path(str(settings.get('_async_run_dir') or '.'))/f'rol500_menu_attempt_{attempt}.png'
            try:await vrol.screenshot(path=str(diag),full_page=True)
            except Exception:pass
            log('warning',f'ROL500 menu path failed | attempt={attempt}/{attempts} | error={type(exc).__name__}: {str(exc).splitlines()[0]} | screenshot={diag}')
            if attempt>=attempts:raise RuntimeError('ROL500_MENU_PATH_FAILED_AFTER_RETRY') from exc
            continue
        try:
            await _wait_parameter_controls(vrol,settings,log)
            log('success',f'ROL500 parameter screen ready | attempt={attempt} | url={vrol.url}')
            return
        except Exception as exc:
            processing=await _processing_request_visible(vrol)
            log('warning',f'ROL500 parameter screen not ready | attempt={attempt}/{attempts} | processing_request={str(processing).lower()}')
            if attempt>=attempts:raise RuntimeError('ROL500_PARAMETER_SCREEN_NOT_READY_AFTER_RETRY') from exc
    raise RuntimeError('ROL500_MENU_OPEN_FAILED')

async def _validation_error(vrol):
    for scope in [vrol]+[f for f in vrol.frames if f!=vrol.main_frame]:
        try:
            err=scope.locator('#errorSummary, span.errorSummary').first
            if await err.count() and await err.is_visible():
                text=' '.join((await err.inner_text() or '').split())
                if text:return text
        except Exception:pass
    return ''

async def _overwrite_to_date(vrol,value,settings,log):
    _,field,_=await _visible(vrol,['input[name="dateToTxt"]'],int(settings.get('rol500_parameter_timeout_ms') or 20000))
    # VROL can replace/repaint the field after validation. Reacquire, select all,
    # type the adjusted value and blur so its legacy validation model is updated.
    await field.click()
    await field.press('Control+A')
    await field.type(value,delay=0)
    await field.press('Tab')
    await vrol.wait_for_timeout(int(settings.get('rol500_date_reentry_settle_ms') or 250))
    _,verify,_=await _visible(vrol,['input[name="dateToTxt"]'],int(settings.get('rol500_parameter_timeout_ms') or 20000))
    actual=await verify.input_value()
    if actual.strip()!=value:
        raise RuntimeError(f'ROL500_TODATE_REENTRY_NOT_APPLIED:expected={value}:actual={actual}')
    log('success',f'ROL500 To Date re-entered and verified | value={value}')

async def download(vrol,context,settings,artifact_dir:Path,log):
    artifact_dir.mkdir(parents=True,exist_ok=True)
    await _open_parameters(vrol,settings,log)
    _,fin,fr,to=await _wait_parameter_controls(vrol,settings,log)
    await fin.select_option('O')
    today=datetime.now().date();date_from=today-timedelta(days=int(settings.get('rol500_days_back') or 3))
    fmt=str(settings.get('rol500_date_format') or '%m/%d/%y');from_value=date_from.strftime(fmt);to_date=today;to_value=to_date.strftime(fmt)
    await fr.fill(from_value);await to.fill(to_value)
    log('info',f'ROL500 parameters set | Financial Type=O | From={from_value} | To={to_value}')
    max_retries=int(settings.get('rol500_future_date_retry_count') or 1)
    response_timeout=int(settings.get('rol500_submit_response_timeout_ms') or 8000)
    poll_ms=int(settings.get('rol500_submit_response_poll_ms') or 100)
    date_retry_count=0;report=None
    while report is None:
        buttons=vrol.frame(name='buttons')
        if buttons is None:raise RuntimeError('ROL500_BUTTONS_IFRAME_NOT_FOUND')
        submit=buttons.get_by_role('button',name=re.compile('Submit',re.I)).first
        pages_before={id(p) for p in context.pages if not p.is_closed()}
        await submit.click(no_wait_after=True)
        log('info',f'ROL500 Submit clicked | From={from_value} | To={to_value} | retry={date_retry_count}/{max_retries}')
        deadline=time.monotonic()+response_timeout/1000;error_text=''
        while time.monotonic()<deadline:
            new_pages=[p for p in context.pages if not p.is_closed() and id(p) not in pages_before]
            if new_pages:
                report=new_pages[-1]
                try:await report.wait_for_load_state('domcontentloaded')
                except Exception:pass
                log('success',f'ROL500 report popup detected | url={report.url}')
                break
            error_text=await _validation_error(vrol)
            if error_text:break
            await vrol.wait_for_timeout(poll_ms)
        if report is not None:break
        if re.search(r'ROL-189\b',error_text,re.I) and date_retry_count<max_retries:
            previous=to_value;to_date=to_date-timedelta(days=1);to_value=to_date.strftime(fmt)
            log('warning',f'ROL500 ROL-189 detected | previous To={previous} | adjusted To={to_value} | retry={date_retry_count+1}/{max_retries}')
            await _overwrite_to_date(vrol,to_value,settings,log)
            date_retry_count+=1
            continue
        if error_text:raise RuntimeError('ROL500_PARAMETER_VALIDATION_ERROR:'+error_text)
        raise RuntimeError('ROL500_SUBMIT_RESPONSE_TIMEOUT')
    log('success',f'ROL500 report request accepted | From={from_value} | To={to_value} | ROL-189 retries={date_retry_count}')
    executing='Executing Report, Please wait ...';success='Report executed successfully.'
    timeout_ms=int(settings.get('rol500_execution_timeout_ms') or 180000);deadline=time.monotonic()+timeout_ms/1000;saw_executing=False
    while time.monotonic()<deadline:
        try:
            body=await report.locator('body').inner_text(timeout=1500)
            if executing in body and not saw_executing:
                saw_executing=True;log('info',f'ROL500 executing | status={executing}')
            if success in body:
                log('success',f'ROL500 execution success | status={success}');break
        except Exception:pass
        await report.wait_for_timeout(500)
    else:raise RuntimeError('ROL500_EXECUTION_TIMEOUT')
    try:
        async with report.expect_download(timeout=int(settings.get('rol500_download_timeout_ms') or 30000)) as di:
            await report.reload(wait_until='domcontentloaded')
        dl=await di.value
    except Exception as exc:
        raise RuntimeError('ROL500_DOWNLOAD_NOT_CAPTURED') from exc
    dest=artifact_dir/'ROL500.csv';await dl.save_as(str(dest))
    if not dest.exists() or dest.stat().st_size==0:raise RuntimeError('ROL500_DOWNLOAD_EMPTY')
    log('success',f'ROL500 downloaded | path={dest} | bytes={dest.stat().st_size}')
    try:await report.close()
    except Exception:pass
    return dest,{'financial_type':'O','from':from_value,'to':to_value,'original_to':today.strftime(fmt),'rol189_date_retries':date_retry_count,'executing_seen':saw_executing}

async def run(vrol,context,settings,classified:Path,batch_dir:Path,log):
    report_dir=batch_dir/'rol500_preflight';csv_path,params=await download(vrol,context,settings,report_dir,log)
    rows=await asyncio.to_thread(parse_rol500,csv_path)
    enriched=batch_dir/f'{classified.stem}_ROL500_ENRICHED.xlsx'
    class Logger:
        def info(self,msg,*args): log('info',msg%args if args else msg)
    stats=await asyncio.to_thread(enrich_classified,classified,rows,enriched,Logger())
    log('success',f'ROL500 preflight complete: rows={len(rows)}, matched={stats.get("matched",0)}, output={enriched}')
    return {'csv_path':str(csv_path),'enriched_workbook':str(enriched),'parameters':params,'report_rows':len(rows),'stats':stats}
