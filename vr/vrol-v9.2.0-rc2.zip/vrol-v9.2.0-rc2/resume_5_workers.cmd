@echo off
setlocal
cd /d "%~dp0"
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
set RPA_OPS_SELECTED_INPUT=
if "%~3"=="" (
 echo Usage: resume_5_workers.cmd RUN_DIR ENRICHED_WORKBOOK MAPPING_FILE
 exit /b 1
)
".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --workers 5 --pre-submit-only --skip-rol500 --review-existing --resume-run "%~1" --source-workbook "%~2" --mapping-file "%~3"
set RESULT=%ERRORLEVEL%
echo Run exit code: %RESULT%
pause
exit /b %RESULT%
