@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
py -3 -m venv .venv
if errorlevel 1 python -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m playwright install chrome
if errorlevel 1 goto failed
echo.
echo [OK] Environment installed. Run run_async_native_test.cmd for a bounded PI test.
exit /b 0
:failed
echo [FAIL] Installation failed. Review the error above.
exit /b 1
