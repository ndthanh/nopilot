@echo off
setlocal
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async %*
) else (
  python run_async_parallel_case_review.py --config config.xlsx --backend native_async %*
)
set RC=%ERRORLEVEL%
echo.
echo Async parallel exit code: %RC%
pause
exit /b %RC%
