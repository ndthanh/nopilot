@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONUNBUFFERED=1"
set "PYTHONIOENCODING=utf-8"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run install.cmd first.
  exit /b 1
)
if not "%~1"=="" set "RPA_OPS_SELECTED_INPUT=%~1"
if not defined RPA_OPS_SELECTED_INPUT (
  echo [ERROR] Select the FC + GUID2PAN input bundle in RPA Ops, or pass its manifest path.
  exit /b 2
)
rem RPA_OPS_RUN_MODE=PI_ONLY (set by the dashboard): inquiry + PI download only, never Issuer Action /
rem case creation; final outcomes (PI, NO_CB, Assoc D, Da CB) are still written to AK/AL/AM.
set "MODE_ARGS="
if /i "%RPA_OPS_RUN_MODE%"=="PI_ONLY" set "MODE_ARGS=--pi-only --write-master"
".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async %MODE_ARGS%
exit /b %ERRORLEVEL%
