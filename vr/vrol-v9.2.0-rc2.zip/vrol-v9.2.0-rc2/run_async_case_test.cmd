@echo off
setlocal
cd /d "%~dp0"
title VROL Native Async - Case Test - No Final Submit
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  pause
  exit /b 1
)
echo NATIVE CASE TEST - 1 GUID - STOP AFTER QUESTIONNAIRE
".venv\Scripts\python.exe" -u run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --workers 1 --limit-groups 1 --pre-submit-only %*
set RC=%ERRORLEVEL%
echo.
echo Test exit code: %RC%
pause
exit /b %RC%
