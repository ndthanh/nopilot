"""Throughput / stage-latency / resource report for one or more VROL runs (no browser).

Usage: python review_tools/analyze_runs.py RUN_DIR [RUN_DIR ...] > report.md
"""
import json, re, statistics, sys
from datetime import datetime
from pathlib import Path

STAMP = re.compile(r'^\[(\d{2}\.\d{2}\.\d{4} \d{2}:\d{2}:\d{2}\.\d{3})\]')

def pct(values, q):
    values = sorted(v for v in values if isinstance(v, (int, float)))
    if not values: return None
    k = (len(values) - 1) * q; lo = int(k); hi = min(lo + 1, len(values) - 1)
    return round(values[lo] + (values[hi] - values[lo]) * (k - lo), 1)

def find(run, name):
    """New layout keeps diagnostics in logs/; older runs have them at the root."""
    return run / 'logs' / name if (run / 'logs' / name).exists() else run / name

def log_window(run):
    starts, ends = [], []
    for line in find(run, 'run.log').read_text(encoding='utf-8', errors='replace').splitlines():
        m = STAMP.match(line)
        if not m: continue
        ts = datetime.strptime(m.group(1), '%d.%m.%Y %H:%M:%S.%f')
        if 'CASE START' in line: starts.append(ts)
        if 'GUID FOLDER FINALIZED' in line or 'GUID CONTAINED FAILURE' in line: ends.append(ts)
    return (min(starts), max(ends)) if starts and ends else (None, None)

def analyze(run):
    run = Path(run)
    summary = json.loads((run / 'async_summary.json').read_text(encoding='utf-8')) if (run / 'async_summary.json').exists() else {}
    outcomes = json.loads((run / 'guid_outcomes.json').read_text(encoding='utf-8'))['records']
    workers = summary.get('worker_count') or len({r.get('worker') for r in outcomes if r.get('worker')})
    first, last = log_window(run)
    window = (last - first).total_seconds() if first else None
    busy = sum(float(r.get('elapsed_seconds') or 0) for r in outcomes)
    res = [json.loads(x) for x in find(run, 'resources.jsonl').read_text().splitlines()] if find(run, 'resources.jsonl').exists() else []
    proc = [x for x in res if x.get('stage') == 'PROCESSING_GUIDS'] or res
    errors = {}
    for r in outcomes:
        if r.get('outcome_class') in ('TRANSIENT', 'USER_REVIEW') or r.get('category') == 'REVIEW_REQUIRED':
            errors[r.get('reason_code') or r.get('status')] = errors.get(r.get('reason_code') or r.get('status'), 0) + 1
    wm = [json.loads(x) for x in find(run, 'writer_metrics.jsonl').read_text().splitlines()] if find(run, 'writer_metrics.jsonl').exists() else []
    def col(name): return [r.get(name) for r in outcomes]
    return dict(run=run.name, mode=summary.get('test_mode'), headless=summary.get('headless'), workers=workers, guids=len(outcomes),
        processing_window_s=round(window, 1) if window else None,
        guids_per_min=round(len(outcomes) / window * 60, 2) if window else None,
        worker_utilisation_pct=round(busy / (window * workers) * 100) if window and workers else None,
        guid_p50_s=pct(col('guid_total_s') or col('elapsed_seconds'), .5), guid_p90_s=pct(col('guid_total_s') or col('elapsed_seconds'), .9),
        inquiry_p50_s=pct(col('inquiry_s'), .5), inquiry_p90_s=pct(col('inquiry_s'), .9),
        scan_p50_s=pct(col('scan_s'), .5), pi_dl_p50_s=pct(col('pi_download_s'), .5), case_p50_s=pct(col('case_s'), .5),
        read_retries=sum(int(r.get('read_retries') or 0) for r in outcomes),
        classes=summary.get('outcome_classes') or {}, review_reasons=errors,
        cpu_peak_pct=max((x['cpu_total_pct'] for x in proc), default=None), ram_peak_pct=max((x['ram_used_pct'] for x in proc), default=None),
        chrome_rss_peak_mb=max((x['chrome_rss_mb'] for x in proc), default=None), chrome_procs_peak=max((x['chrome_processes'] for x in proc), default=None),
        writer_queue_max=max((x['queue_depth'] for x in wm), default=None), writer_lag_max_s=max((x['lag_s'] for x in wm), default=None),
        # Startup bulk ROW_EXCLUDED events dominate the raw max; show the per-GUID (CASE_*) view separately.
        writer_queue_max_guid=max((x['queue_depth'] for x in wm if str(x.get('event','')).startswith('CASE_')), default=None),
        writer_lag_max_guid_s=max((x['lag_s'] for x in wm if str(x.get('event','')).startswith('CASE_')), default=None),
        writer_flush_count=sum(1 for x in wm if x.get('flush_ms') is not None),
        writer_flush_max_ms=max((x['flush_ms'] for x in wm if x.get('flush_ms') is not None), default=None),
        writer_sync_max_ms=max((x['sync_ms'] for x in wm if x.get('sync_ms') is not None), default=None),
        writer_drain_s=summary.get('writer_drain_s'))

if __name__ == '__main__':
    rows = [analyze(p) for p in sys.argv[1:]]
    keys = [k for k in rows[0] if k not in ('classes', 'review_reasons')]
    print('| ' + ' | '.join(keys) + ' |'); print('|' + '---|' * len(keys))
    for r in rows: print('| ' + ' | '.join(str(r[k]) for k in keys) + ' |')
    for r in rows: print(f"\n{r['run']}: classes={r['classes']} review_reasons={r['review_reasons']}")
