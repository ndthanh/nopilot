"""Copy the 09 workbook for a reset rehearsal and clear the bot/user columns AK/AL/AM."""
import shutil, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from openpyxl import load_workbook
from async_runtime.xlsx_patch import patch_cells

source, target = Path(sys.argv[1]), Path(sys.argv[2])
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(source, target)
wb = load_workbook(target, read_only=True)
try:
    ws = wb['Sheet1']; epoch = wb.epoch
    patches = {f'{col}{r}': None for r, row in enumerate(ws.iter_rows(min_row=4, min_col=37, max_col=39, values_only=True), 4)
               for col, value in zip(('AK', 'AL', 'AM'), row) if value not in (None, '')}
finally:
    wb.close()
if patches:
    temp = target.with_suffix('.tmp.xlsx'); patch_cells(target, temp, 'Sheet1', patches, epoch); temp.replace(target)
print(f'rehearsal master={target} | cleared_cells={len(patches)}')
