"""Write GUID lists from a finished run: all queued GUIDs, and those that would create a case."""
import json, sys
from pathlib import Path
run = Path(sys.argv[1]); count = int(sys.argv[2]) if len(sys.argv) > 2 else 5
queue = [x['guid'] for x in json.loads((run / 'queue_manifest.json').read_text(encoding='utf-8'))]
records = json.loads((run / 'guid_outcomes.json').read_text(encoding='utf-8'))['records']
case = [r['guid'] for r in records if r.get('status') == 'ISSUER_ACTION_DEFERRED_TEST_MODE'][:count]
(run / 'guids_all.txt').write_text('\n'.join(queue) + '\n', encoding='utf-8')
(run / 'guids_case.txt').write_text('\n'.join(case) + '\n', encoding='utf-8')
pre = run / 'rol500_preflight_result.json'
if pre.exists():(run / 'enriched_path.txt').write_text(json.loads(pre.read_text(encoding='utf-8'))['enriched_workbook'] + '\n', encoding='utf-8')
print(f'all={len(queue)} -> {run/"guids_all.txt"}\ncase={len(case)} -> {run/"guids_case.txt"}')
