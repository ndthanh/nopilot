@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" -m async_runtime.production_setup %*
exit /b %ERRORLEVEL%
