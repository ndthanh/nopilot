@echo off
setlocal
cd /d "%~dp0"
set PYTHONUNBUFFERED=1
set PYTHONIOENCODING=utf-8
set RPA_OPS_SELECTED_INPUT=
if "%~1"=="" (
 echo Usage: run_review_retry_5_workers.cmd --source-workbook FILE --mapping-file FILE --guid GUID
 exit /b 1
)
echo Supply --source-workbook, --mapping-file and one or more --guid arguments.
".venv\Scripts\python.exe" run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --workers 5 --pre-submit-only --skip-rol500 --review-existing --no-resume %*
set RESULT=%ERRORLEVEL%
echo Run exit code: %RESULT%
pause
exit /b %RESULT%
