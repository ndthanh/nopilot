from __future__ import annotations
import argparse, asyncio, json, uuid, threading, time, os, shutil
from datetime import datetime
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from async_runtime.config import load_settings, truth
from async_runtime.browser import login, open_vrol, open_vrol_worker_tab_from_portal, open_transaction_inquiry
from async_runtime.rol500_preflight import run as run_rol500_preflight
from async_runtime.excel_store import load_groups, CentralWriter, business_date
from src.io.mapping import load_mapping
from async_runtime.models import WorkerState, RuntimeEvent
from async_runtime.popup_registry import PopupRegistry
from async_runtime.outcomes import technical_failure
from async_runtime.console_log import ConsoleLog
from async_runtime.worker import worker_loop
from async_runtime.session import SharedSessionManager
from async_runtime.workers_config import resolve_workers
from async_runtime.guid_markers import build_report as build_guid_outcomes
from async_runtime.input_contract import validate_contract
from async_runtime.run_monitor import RunMonitor, RunLock, now as run_now
from async_runtime.review_holds import interrupted_side_effects
from async_runtime.existing_chargebacks import log_existing_chargebacks,append_assoc_dispute_results,rol500_outcomes,ROL500_LABEL,ROL500_REVERSAL_LABEL
from async_runtime.rol500_postflight import run as run_rol500_postflight

C = Console()
# Previous display marker retained for regression compatibility: Async Parallel Case Review v9.1.13.5
_RUN_LOG_PATH = None
_LOG_LOCK = threading.Lock()
# Legacy minute timestamp format retained as documentation: strftime('%d.%m.%Y %H:%M')

def log(kind: str, message: str) -> None:
    styles = {'info':'cyan','success':'bold green','warning':'yellow','error':'bold red','stage':'bold magenta'}
    labels = {'info':'INFO','success':'PASS','warning':'WARN','error':'FAIL','stage':'STAGE'}
    style = styles.get(kind, 'white')
    stamp=datetime.now().strftime('%d.%m.%Y %H:%M:%S.%f')[:-3]
    plain=f'[{stamp}] [{labels.get(kind,"INFO")}] {message}'
    with _LOG_LOCK:
        C.print(f'[{style}]{plain}[/{style}]')
        if _RUN_LOG_PATH is not None:
            with Path(_RUN_LOG_PATH).open('a',encoding='utf-8') as handle:handle.write(plain+'\n')

async def event_writer(queue: asyncio.Queue, writer: CentralWriter) -> None:
    metrics = writer.out.parent / 'logs' / 'writer_metrics.jsonl'
    metrics.parent.mkdir(exist_ok=True)
    while True:
        event = await queue.get()
        try:
            if event is None:
                return
            depth = queue.qsize(); started = time.monotonic()
            flushes_before = writer.flush_count
            await asyncio.to_thread(writer.apply, event)
            dash=getattr(writer,'dashboard',None)
            if dash:dash.on_event(event)
            row = dict(t=round(time.time(), 3), event=event.event, queue_depth=depth,
                       apply_ms=round((time.monotonic() - started) * 1000, 1),
                       lag_s=round(time.time() - getattr(event, 'created_at', time.time()), 2))
            if writer.flush_count != flushes_before:
                row.update(flush_ms=writer.last_flush_ms, sync_ms=writer.last_sync_ms)
            try:
                with metrics.open('a', encoding='utf-8') as handle: handle.write(json.dumps(row) + '\n')
            except OSError: pass
        finally:
            queue.task_done()

def resolve_source(settings: dict) -> Path:
    raw = settings.get('async_enriched_workbook') or settings.get('batch_test_classified_file') or settings.get('classified_case_file')
    if not raw:
        raise RuntimeError('ASYNC_INPUT_WORKBOOK_NOT_CONFIGURED')
    source = Path(str(raw)).expanduser().resolve()
    if not source.exists():
        raise RuntimeError(f'ASYNC_INPUT_WORKBOOK_NOT_FOUND:{source}')
    return source

def resolve_guid_pan_mapping(settings: dict, config_path: Path, root: Path):
    raw=str(settings.get('batch_test_guid_pan_mapping_file') or settings.get('guid_pan_mapping_file') or '').strip()
    candidates=[]
    if raw:
        configured=Path(raw).expanduser()
        if not configured.is_absolute(): configured=(config_path.parent/configured).resolve()
        candidates.append(configured)
    candidates.extend([(config_path.parent/'input.txt').resolve(),(root/'input.txt').resolve()])
    seen=[]
    for path in candidates:
        if str(path).lower() in seen: continue
        seen.append(str(path).lower())
        if path.exists():
            mapping,errors,used_encoding=load_mapping(path,str(settings.get('guid_pan_encoding') or 'utf-8-sig'))
            if not mapping: raise RuntimeError(f'GUID_PAN_MAPPING_EMPTY:{path}')
            return path,mapping,errors,used_encoding
    raise RuntimeError('GUID_PAN_MAPPING_FILE_NOT_FOUND:checked='+ '|'.join(str(x) for x in candidates))

def queue_table(sheet: str, groups: list, stats: dict) -> Table:
    table = Table(title='Async Queue Ready', header_style='bold blue')
    for name in ('Sheet','Groups','Rows','Eligible','ROL500 existing','TI <=15d','TI >=120d','TI invalid/future'):
        table.add_column(name, justify='right' if name != 'Sheet' else 'left')
    table.add_row(sheet, str(len(groups)), str(stats.get('rows',0)), str(stats.get('eligible',0)), str(stats.get('rol500_existing',0)), str(stats.get('ti_date_too_young',0)), str(stats.get('ti_date_too_old',0)), str(stats.get('ti_date_invalid',0)+stats.get('ti_date_future',0)))
    return table

def build_review_required_reports(run_dir:Path):
    import csv
    records=[]
    groups_dir=run_dir/'groups'
    for result_file in groups_dir.glob('*/guid_result.json') if groups_dir.exists() else []:
        try:
            record=json.loads(result_file.read_text(encoding='utf-8'))
            if record.get('review_required'):records.append(record)
        except Exception:pass
    records.sort(key=lambda x:(x.get('completed_at',''),x.get('guid','')))
    json_path=run_dir/'review_required_cases.json'
    csv_path=run_dir/'review_required_cases.csv'
    json_path.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    with csv_path.open('w',newline='',encoding='utf-8-sig') as handle:
        fields=['guid','worker','status','decision','reason_code','detail','elapsed_seconds','completed_at','folder']
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
        for row in records:writer.writerow({k:row.get(k,'') for k in fields})
    return {'count':len(records),'json':str(json_path),'csv':str(csv_path)}

async def _main_async(args, monitor) -> None:
    root = Path(__file__).resolve().parent
    config_path=Path(args.config).expanduser().resolve()
    settings = load_settings(config_path)
    settings['async_backend']=args.backend or str(settings.get('async_backend') or 'native_async')
    settings['_inquiry_only']=args.inquiry_only
    settings['_pi_only']=args.pi_only
    settings['_pre_submit_only']=args.pre_submit_only
    settings['_run_business_date']=business_date().isoformat()
    settings['_run_monitor']=monitor
    # reviewed_guids.txt and runtime\review_holds are retired: the 09 master (AK/AL/AM)
    # plus the ledger are the only run-to-run state. A new install starts from an empty ledger (reset).
    settings['_review_hold_dir']=None
    for flag in ('ignore_review_holds','review_existing','recheck_read_only'):
        if getattr(args,flag,False):log('warning',f'--{flag.replace("_","-")} is obsolete (registry/holds retired); use SKIP/FORCE in AM')
    # Precedence: command-line flag > dashboard choice (runtime\run_overrides.json) > config.xlsx.
    from async_runtime import run_overrides
    overrides=run_overrides.load(root)
    sources=run_overrides.apply(settings,overrides)
    if args.headful:settings['headless']=False;sources['headless']='command_line'
    if getattr(args,'headless',False):settings['headless']=True;sources['headless']='command_line'
    if settings['async_backend']=='legacy_bridge' and (args.inquiry_only or args.pi_only):
        raise RuntimeError('TEST_CHECKPOINT_MODES_REQUIRE_NATIVE_ASYNC')
    if getattr(args,'worker_cap',None):settings['async_worker_max']=args.worker_cap
    if args.workers is not None:sources['workers']='command_line'
    if args.pre_submit_only or args.pi_only or args.inquiry_only:sources['final_submit']='command_line'
    settings['_run_setting_sources']=sources
    if overrides:log('warning',f'DASHBOARD RUN SETTINGS APPLIED | {dict((k,v) for k,v in overrides.items() if k!="updated_at")} | updated_at={overrides.get("updated_at")} | sources={sources}')
    worker_config=resolve_workers(settings,args.workers)
    configured_workers=worker_config['configured'];worker_cap=worker_config['cap']
    workers=worker_config['effective']
    run_dir = monitor.folder
    run_id = run_dir.name
    if 'onedrive' in str(run_dir).casefold():
        log('warning','RUNTIME INSIDE ONEDRIVE | folder renames, SQLite WAL and atomic replaces may fail under sync locks; move the install outside OneDrive')
    if settings.get('_shadowed_runsettings'):
        log('warning','RunSettings keys ignored because Settings is authoritative: '+','.join(settings['_shadowed_runsettings']))
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir/'documents').mkdir(exist_ok=True)
    (run_dir/'logs').mkdir(exist_ok=True)
    global _RUN_LOG_PATH
    _RUN_LOG_PATH=run_dir/'logs'/'run.log'
    settings['_async_run_dir'] = str(run_dir)
    run_started=time.monotonic()
    # Contract v2 status exists from the first heartbeat, so a scheduled run that is
    # still WAITING_INPUT (up to scheduled_input_wait_seconds) is visible on the dashboard.
    from async_runtime.dashboard_status import DashboardStatus
    monitor.dashboard=DashboardStatus(run_dir,run_id=run_id,
        mode=dict(pre_submit_only=bool(args.pre_submit_only),final_submit_enabled=truth(settings.get('allow_final_submit','NO')) and not args.pre_submit_only,
                  headless=truth(settings.get('headless')),pi_only=bool(args.pi_only),inquiry_only=bool(args.inquiry_only),workers=workers,
                  scheduled=bool(getattr(args,'scheduled',False)),sources=dict(sources)),
        input_info=dict(origin='FC_GUID2PAN' if getattr(args,'scheduled',False) else None))
    monitor.dashboard.write()
    contract_path=getattr(args,'input_contract',None) or os.environ.get('RPA_OPS_SELECTED_INPUT')
    request_path=getattr(args,'guid_request',None) or os.environ.get('RPA_OPS_GUID_REQUEST')
    requested=None
    if request_path:
        if not contract_path or getattr(args,'scheduled',False) or args.guid or args.no_resume or getattr(args,'resume_run',None) or getattr(args,'review_existing',False) or getattr(args,'recheck_read_only',False):
            raise ValueError('GUID_REQUEST_REQUIRES_OWN_CONTRACT_RUN_WITHOUT_REPLAY_OVERRIDES')
        if settings['async_backend']!='native_async':raise ValueError('GUID_REQUEST_REQUIRES_NATIVE_ASYNC')
        from async_runtime.guid_request import load_request
        request=await asyncio.to_thread(load_request,request_path,contract_path);requested=request['guids']
        (run_dir/'guid_request.json').write_text(json.dumps(request,ensure_ascii=False,indent=2),encoding='utf-8')
        monitor.update(request_mode='USER_SELECTED_GUIDS',request_id=request['request_id'],requested_guid_count=len(requested))
    if getattr(args,'scheduled',False):
        if args.source_workbook or getattr(args,'mapping_file',None) or getattr(args,'input_contract',None):
            raise ValueError('SCHEDULED_MODE_REQUIRES_CONTRACT_DIRECTORY_ONLY')
        from async_runtime.scheduled_input import wait_for_contract
        contract_path=await wait_for_contract(settings,config_path.parent,monitor,log)
    contract=None
    if contract_path:
        if args.source_workbook or getattr(args,'mapping_file',None):raise ValueError('VROL_INPUT_CONTRACT_CANNOT_BE_MIXED_WITH_FILE_OVERRIDES')
        # Coverage is checked against the effective queue after live AM/SKIP
        # markers and carried business results have been merged.
        contract,files=await asyncio.to_thread(validate_contract,contract_path,check_coverage=False)
        source=files['workbook'];settings['batch_test_guid_pan_mapping_file']=str(files['mapping'])
        (run_dir/'input_contract.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
        monitor.update(source_fc_run_id=contract['source_fc_run_id'],source_guid2pan_run_id=contract['source_guid2pan_run_id'],bundle_id=contract['bundle_id'])
    else:
        source = Path(args.source_workbook).resolve() if args.source_workbook else resolve_source(settings)
        if getattr(args,'mapping_file',None):settings['batch_test_guid_pan_mapping_file']=str(Path(args.mapping_file).resolve())
    mapping_path,guid_pan_mapping,mapping_errors,mapping_encoding=resolve_guid_pan_mapping(settings,config_path,root)
    if mapping_errors:raise ValueError('GUID_PAN_MAPPING_INVALID:errors='+str(len(mapping_errors)))
    business_state=None
    diagnostic=bool(args.inquiry_only or args.pi_only) and not getattr(args,'write_master',False)
    if not truth(settings.get('async_master_writeback_enabled','YES')) and not diagnostic:
        # Without the registry, AM + ledger are the only protection against re-creating cases.
        raise ValueError('MASTER_WRITEBACK_REQUIRED: async_master_writeback_enabled must be YES for case runs')
    if truth(settings.get('async_master_writeback_enabled','YES')):
        from async_runtime.business_status import BusinessState
        # A dashboard 'manual' bundle names the 09 file the user picked: AM/AL/AK go back to it.
        manual_master=((contract.get('files') or {}).get('workbook') or {}).get('source_path') if contract and contract.get('origin')=='MANUAL_USER_SELECTED' else None
        master_raw=getattr(args,'master_workbook',None) or manual_master or settings.get('async_master_workbook')
        if not master_raw and contract:master_raw=((contract.get('files') or {}).get('workbook') or {}).get('source_path')
        if not master_raw:master_raw=source if not contract else settings.get('batch_test_classified_file') or settings.get('classified_case_file')
        if not master_raw:raise ValueError('MASTER_WORKBOOK_NOT_CONFIGURED')
        master=Path(str(master_raw)).expanduser()
        if not master.is_absolute():master=config_path.parent/master
        if contract and master.resolve().is_relative_to(source.parent):raise ValueError('MASTER_MUST_NOT_BE_CONTRACT_SNAPSHOT')
        if diagnostic:log('warning','DIAGNOSTIC MODE | master/ledger are READ-ONLY (use --write-master to override)')
        ledger_path=Path(args.ledger).resolve() if getattr(args,'ledger',None) else root/'runtime'/'business_state.sqlite3'
        business_state=BusinessState(ledger_path,master,run_dir,int(settings.get('business_state_retention_days') or 180),
                                     readonly=diagnostic,max_transient_attempts=int(settings.get('async_transient_retry_runs') or 3))
        monitor.business_state=business_state
        cleanup=await asyncio.to_thread(business_state.cleanup,None,source)
        # A run killed after Issuer Action leaves a checkpoint but no CASE_RESULT:
        # record it as a review outcome so AM blocks re-creating that case.
        interrupted=await asyncio.to_thread(interrupted_side_effects,root/'runtime'/'async_parallel')
        seeded=await asyncio.to_thread(business_state.seed_outcomes,interrupted)
        if seeded:log('warning',f'INTERRUPTED CASE SIDE EFFECTS RECORDED FOR REVIEW | guids={len(seeded)} | sample={seeded[:5]}')
        source=await asyncio.to_thread(business_state.prepare,source,restore=not args.no_resume)
        monitor.update(master_workbook=str(master.resolve()),business_state_cleanup=cleanup)
    else:
        from async_runtime.business_status import prepare_input_columns
        source=await asyncio.to_thread(prepare_input_columns,source,run_dir/'09_BUSINESS_INPUT.xlsx')
    monitor.update(input_workbook=str(source),input_mapping=str(mapping_path),worker_count=workers,
                   final_submit_enabled=truth(settings.get('allow_final_submit','NO')) and not args.pre_submit_only)
    log('success',f'GUID-to-PAN mapping loaded | records={len(guid_pan_mapping)} | errors={len(mapping_errors)} | encoding={mapping_encoding} | file={mapping_path}')
    sheet_requested = str(settings.get('case_review_input_sheet') or 'Sheet1')
    version=(root/'VERSION.txt').read_text(encoding='utf-8').strip() if (root/'VERSION.txt').exists() else 'UNKNOWN'
    C.print(Panel.fit(f'[bold]Async Parallel Case Review {version}[/bold]\nRun ID: {run_id}\nWorkers: {workers}\nInput: {source.name}\nRun folder: {run_dir}', border_style='blue'))
    log('info',f'Worker configuration resolved | cli={args.workers} | configured={configured_workers} | cap={worker_cap} | effective={workers} | config={config_path}')
    if worker_config['capped']:log('warning',f'WORKER REQUEST CAPPED | requested={worker_config["requested"]} | cap={worker_cap}')

    monitor.dashboard.data['input']=dict(origin=(contract or {}).get('origin') or ('FC_GUID2PAN' if contract else 'FILES'),bundle_id=(contract or {}).get('bundle_id'),
                        workbook=str(source),mapping=str(mapping_path),master=str(business_state.master) if business_state else None)
    monitor.dashboard.set_files(console_log=run_dir/'console.log',run_log=run_dir/'logs'/'run.log',documents=run_dir/'documents',groups=run_dir/'groups')
    session = SharedSessionManager(lambda: login(settings, run_dir))
    monitor.dashboard.session=session
    session.restart_after=int(settings.get('async_restart_after_guids') or 100)
    writer = None
    writer_task = None
    event_q = None
    tasks=[];registry=None;outcome_report=None
    reviewed=set()  # registry retired: completed GUIDs are skipped through AM (live or restored from the ledger)
    try:
        log('stage', 'LOGIN AND VROL MFA')
        monitor.update(stage='LOGIN')
        snap = await session.start()
        context, portal = snap.context, snap.portal
        base_vrol = await open_vrol(portal, settings)

        output_source = source
        rol_result = None
        if truth(settings.get('rol500_preflight_enabled', 'YES')) and not args.skip_rol500:
            log('stage', 'ROL500 PREFLIGHT - WORKER TABS NOT CREATED')
            monitor.update(stage='ROL500')
            full_attempts=int(settings.get('rol500_full_preflight_attempts') or 3)
            rol_result=None;rol_errors=[]
            for full_attempt in range(1,full_attempts+1):
                try:
                    log('info',f'ROL500 full preflight attempt | attempt={full_attempt}/{full_attempts} | tab_url={base_vrol.url}')
                    rol_result = await run_rol500_preflight(base_vrol, context, settings, source, run_dir, log)
                    break
                except Exception as exc:
                    rol_errors.append(f'{type(exc).__name__}: {exc}')
                    log('warning',f'ROL500 full preflight retry required | attempt={full_attempt}/{full_attempts} | error={type(exc).__name__}: {exc}')
                    try:
                        if not base_vrol.is_closed():await base_vrol.close()
                    except Exception:pass
                    if full_attempt>=full_attempts:raise RuntimeError('ROL500_FULL_PREFLIGHT_FAILED:'+ ' | '.join(rol_errors)) from exc
                    await portal.bring_to_front();await portal.wait_for_timeout(int(settings.get('rol500_full_retry_backoff_ms') or 2000)*full_attempt)
                    base_vrol=await open_vrol(portal,settings)
                    log('success',f'ROL500 fresh VROL tab ready for retry | next_attempt={full_attempt+1}/{full_attempts} | url={base_vrol.url}')
            (run_dir / 'rol500_preflight_result.json').write_text(json.dumps(rol_result, ensure_ascii=False, indent=2), encoding='utf-8')
            output_source = Path(rol_result['enriched_workbook'])
            if business_state and not business_state.readonly:
                # Persist 'already charged back' in AM/AK/AL so later runs skip the GUID
                # even after it leaves the rol500_days_back window.
                cb_items=await asyncio.to_thread(rol500_outcomes,output_source,rol_result.get('csv_path'))
                cb_seeded=await asyncio.to_thread(business_state.seed_outcomes,cb_items)
                rol_result['recorded_in_am']=dict(found=len(cb_items),recorded=len(cb_seeded),reversal=sum(x['label']==ROL500_REVERSAL_LABEL for x in cb_items if x['guid'] in set(cb_seeded)))
                log('success',f'ROL500 CHARGEBACKS RECORDED FOR AM | found_guids={len(cb_items)} | newly_recorded={len(cb_seeded)} | label={ROL500_LABEL}')
                (run_dir / 'rol500_preflight_result.json').write_text(json.dumps(rol_result, ensure_ascii=False, indent=2), encoding='utf-8')
            if not base_vrol.is_closed():
                await base_vrol.close()
                log('success', 'ROL500 VROL tab closed after download and enrichment')
            await portal.bring_to_front()
        else:
            log('warning', 'ROL500 preflight disabled by configuration')

        log('stage', 'BUILD QUEUE FROM POST-ROL500 WORKBOOK')
        blocked=dict(business_state.excluded) if business_state else {}
        groups, stats, actual_sheet = await asyncio.to_thread(load_groups, output_source, guid_pan_mapping, run_date=settings['_run_business_date'],reviewed=reviewed,requested_guids=requested,blocked=blocked)
        stats['review_hold_groups_skipped']=0
        excluded=stats.pop('exclusions',[])
        existing_cb=log_existing_chargebacks(excluded,run_dir,log)
        stats['existing_chargeback_groups_skipped']=existing_cb
        if requested is not None or stats.get('am_force_guids'):
            (run_dir/'requested_guid_source.json').write_text(json.dumps(stats.get('requested_source',{}),ensure_ascii=False,indent=2),encoding='utf-8')
        (run_dir/'input_exclusions.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2),encoding='utf-8')
        if requested is None and stats.get('am_force_guids'):
            force_guids=set(stats['am_force_guids'])
            if args.guid:force_guids&={x.upper() for x in args.guid}
            if force_guids:
                (run_dir/'am_force_request.json').write_text(json.dumps(dict(request_id=run_id+'_AM_FORCE',guids=sorted(force_guids),input_contract=str(contract_path or source)),indent=2),encoding='utf-8')
        if args.guid:
            wanted={x.upper() for x in args.guid};groups=[g for g in groups if g.guid in wanted]
            missing=wanted-{g.guid for g in groups}
            if missing:
                log('warning','REQUESTED GUID NOT ELIGIBLE | '+','.join(sorted(missing)))
                excluded.extend(dict(row_no=None,guid=g,reason='REQUESTED_GUID_NOT_ELIGIBLE') for g in sorted(missing))
                (run_dir/'input_exclusions.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2),encoding='utf-8')
            if not groups:raise RuntimeError('REQUESTED_GUID_NOT_ELIGIBLE:'+','.join(sorted(missing)))
        if getattr(args,'resume_run',None):
            previous=Path(args.resume_run)
            manifest=json.loads((previous/'queue_manifest.json').read_text(encoding='utf-8'))
            completed={}
            for file in (previous/'groups').glob('*/guid_result.json'):
                record=json.loads(file.read_text(encoding='utf-8'));completed[record['guid']]=record
            wanted={r['guid'] for r in manifest if r['guid'] not in completed or completed[r['guid']].get('review_required')}
            groups=[g for g in groups if g.guid in wanted]
            (run_dir/'resume_lineage.json').write_text(json.dumps(dict(previous_run=str(previous.resolve()),target_count=len(wanted),preserved_completed=len(completed)-sum(bool(x.get('review_required')) for x in completed.values())),indent=2),encoding='utf-8')
        limit_groups = getattr(args, 'limit_groups', None)
        if limit_groups is not None:
            available_groups = len(groups)
            groups = groups[:limit_groups]
            log('warning', f'TEST GROUP LIMIT | available={available_groups} | selected={len(groups)} | limit={limit_groups}')
        C.print(queue_table(actual_sheet, groups, stats))
        log('info',f'Excel queue filter | PAN prefix 5 groups removed={stats.get("pan_prefix_5_groups_filtered",0)} | rows removed={stats.get("pan_prefix_5_rows_filtered",0)}')
        unmapped=[g for g in groups if not g.full_pan]
        if unmapped:
            # Exclude only the unmapped GUIDs; abort when it looks like the wrong mapping file.
            if len(unmapped)>max(2,0.2*len(groups)):
                raise RuntimeError(f'GUID_PAN_MAPPING_INCOMPLETE:missing_groups={len(unmapped)}:sample={[g.guid for g in unmapped[:10]]}:mapping_file={mapping_path}')
            log('warning',f'GUID PAN MISSING | excluded={len(unmapped)} | sample={[g.guid for g in unmapped[:5]]}')
            excluded.extend(dict(row_no=r,guid=g.guid,reason='GUID_PAN_MAPPING_MISSING') for g in unmapped for r in g.source_rows)
            (run_dir/'input_exclusions.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2),encoding='utf-8')
            groups=[g for g in groups if g.full_pan]
        log('success',f'GUID-to-PAN coverage complete | groups={len(groups)} | mapped={sum(bool(g.full_pan) for g in groups)}')
        monitor.dashboard.set_queue(len(groups),excluded,existing_cb)

        output_workbook = run_dir / '09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx'
        (run_dir/'queue_manifest.json').write_text(json.dumps([dict(guid=g.guid,invoices=[x['invoice'] for x in g.items],codes=sorted({x['code'] for x in g.items}),source_rows=g.source_rows,
            user_requested=any(x.get('user_requested') for x in g.items),input_am_force=any(x.get('input_am_force') for x in g.items),upstream_filter_overridden=any(x.get('upstream_filter_overridden') for x in g.items)) for g in groups],ensure_ascii=False,indent=2),encoding='utf-8')
        # Per-run completion list only (audit); nothing reads it back as a gate.
        writer = CentralWriter(output_source, output_workbook, run_dir/'activity_report.jsonl', run_dir/'logs'/'completed_review_keys.txt', int(settings.get('async_excel_flush_case_count') or 20),persistent_reviewed=None,business_state=business_state)
        writer.dashboard=monitor.dashboard
        monitor.dashboard.set_files(output_workbook=output_workbook,existing_chargebacks=run_dir/'existing_chargebacks.csv',
                                    review_required=run_dir/'review_required_cases.csv',guid_outcomes=run_dir/'guid_outcomes.csv')
        event_q = asyncio.Queue()
        writer_task = asyncio.create_task(event_writer(event_q, writer))
        for exclusion in excluded:
            if exclusion['row_no'] is None:continue
            await event_q.put(RuntimeEvent('ROW_EXCLUDED',guid=exclusion['guid'],status='EXCLUDED',reason_code=exclusion['reason'],data={'source_rows':[exclusion['row_no']],'updates':{'BOT INPUT EXCLUSION':exclusion['reason']}}))
        work_q = asyncio.Queue()
        for group in groups:
            await work_q.put(group)
        workers=min(workers,len(groups))
        worker_config['active']=workers
        monitor.update(stage='PROCESSING_GUIDS',group_count=len(groups),worker_count=workers)
        for _ in range(workers):
            await work_q.put(None)

        registry=session.registry
        log('stage', f'CREATE {workers} TRANSACTION INQUIRY WORKER TAB(S) | backend={settings["async_backend"]}')
        pages = []
        for index in range(workers):
            worker_name=f'W{index+1:02d}'
            log('info', f'{worker_name} open VROL tab | action=CTRL_CLICK_VISA_ACCESS_SERVICE_LINK')
            page = await open_vrol_worker_tab_from_portal(portal, settings, worker_name)
            registry.register(page,worker_name)
            from async_runtime.popup_scope import install
            await install(page,worker_name)
            if settings['async_backend']=='native_async':
                from async_runtime.native_ui import open_transaction_inquiry as native_open_inquiry
                await native_open_inquiry(page,settings)
            else:await open_transaction_inquiry(page, settings)
            pages.append(page)
            log('success', f'Worker {worker_name} ready | tab_source=Visa Access Ctrl+Click | url={page.url}')

        popup_sem = asyncio.Semaphore(int(settings.get('async_popup_concurrency') or 1))
        tasks = []
        for index, page in enumerate(pages, 1):
            # Placeholder only: process_group switches artifact_dir to groups/<GUID>
            # before anything is written, so no empty worker_WXX folders are created.
            artifact_dir = run_dir / f'worker_W{index:02d}'
            state = WorkerState(f'W{index:02d}', page, artifact_dir=artifact_dir, settings=dict(settings), registry=registry,session=session,generation=snap.generation)
            monitor.dashboard.worker_states.append(state)
            tasks.append(asyncio.create_task(worker_loop(state, work_q, event_q, popup_sem, log), name=f'worker-W{index:02d}'))

        worker_group=asyncio.gather(*tasks)
        done,_=await asyncio.wait({worker_group,writer_task},return_when=asyncio.FIRST_COMPLETED)
        if writer_task in done:
            await writer_task
            raise RuntimeError('CENTRAL_WRITER_STOPPED_BEFORE_WORKERS')
        await worker_group
        workers_done=time.monotonic()
        drain=asyncio.create_task(event_q.join())
        done,_=await asyncio.wait({drain,writer_task},return_when=asyncio.FIRST_COMPLETED)
        if writer_task in done:
            drain.cancel();await writer_task
            raise RuntimeError('CENTRAL_WRITER_STOPPED_BEFORE_DRAIN')
        await drain
        await event_q.put(None)
        await writer_task
        writer_task = None
        await asyncio.to_thread(writer.close)
        writer_drain_s=round(time.monotonic()-workers_done,2)
        log('info',f'CENTRAL WRITER DRAINED | seconds_after_last_worker={writer_drain_s}')
        writer = None

        postflight=None
        if truth(settings.get('rol500_postflight_enabled','YES')) and not getattr(args,'skip_postflight',False):
            monitor.update(stage='ROL500_POSTFLIGHT')
            log('stage','ROL500 POSTFLIGHT - ALL WORKERS FINISHED; UPDATE EXCEL BY INVOICE')
            post_page=None
            try:
                # No worker owns a report tab; finish and close every worker
                # popup chain before opening this independent read-only report.
                roots=[p for p,parent in session.registry.parents.items() if parent is None]
                for state_page in roots:
                    await session.registry.cleanup(state_page)
                    if not state_page.is_closed():await state_page.close()
                current=session.snapshot()
                post_page=await open_vrol(current.portal,settings)
                postflight=await run_rol500_postflight(post_page,current.context,settings,output_workbook,run_dir,log)
                log('success',f'ROL500 POSTFLIGHT COMPLETE | stats={postflight["stats"]} | workbook={output_workbook}')
            except Exception as exc:
                postflight=dict(status='FAILED',error=f'{type(exc).__name__}: {exc}',output_workbook=str(output_workbook))
                error_dir=run_dir/'postflight';error_dir.mkdir(exist_ok=True)
                if post_page and not post_page.is_closed():
                    try:await post_page.screenshot(path=str(error_dir/'rol500_postflight_error.png'),full_page=True)
                    except Exception:pass
                log('error',f'ROL500 POSTFLIGHT FAILED | GUID results preserved | {exc}')
            finally:
                if post_page and not post_page.is_closed():
                    try:await post_page.close()
                    except Exception:pass
            (run_dir/'rol500_postflight_result.json').write_text(json.dumps(postflight,ensure_ascii=False,indent=2),encoding='utf-8')
        else:postflight=dict(status='SKIPPED',reason='EXPLICIT_CONFIG_OR_DIAGNOSTIC_FLAG')
        from async_runtime.pi_export import export_documents
        pi_export=await asyncio.to_thread(export_documents,run_dir,settings,output_workbook,postflight_status=postflight['status'])
        log('warning' if pi_export['status']=='FAILED' else 'info',f'PI DOCUMENTS EXPORT | status={pi_export["status"]} | local={pi_export["local_path"]} | destination={pi_export.get("export_path")}')
        master_writeback=await asyncio.to_thread(business_state.sync,output_workbook) if business_state else dict(status='DISABLED')

        review_report=build_review_required_reports(run_dir)
        outcome_report=await asyncio.to_thread(build_guid_outcomes,run_dir)
        log('success',f'GUID OUTCOMES | categories={outcome_report["category_counts"]} | awaiting_final_submit={outcome_report["awaiting_final_submit_count"]} | csv={outcome_report["csv"]}')
        log('warning' if review_report['count'] else 'success',f'REVIEW REQUIRED REPORT | cases={review_report["count"]} | csv={review_report["csv"]} | json={review_report["json"]}')
        records=[json.loads(f.read_text(encoding='utf-8')) for f in (run_dir/'groups').glob('*/guid_result.json')]
        # Dashboard contract: review_holds.json lists this run's GUIDs that need review
        # after a Visa side effect (case/draft may exist). Their AM carries 'Review: ...'.
        held={}
        for r in records:
            res=r.get('result') or {};cp=res.get('case_checkpoint') or {}
            if r.get('review_required') and (res.get('issuer_action_clicked') or cp.get('issuer_action_clicked') or res.get('disposition')=='HOLD_REVIEW'):
                held[r['guid']]=dict(guid=r['guid'],disposition='HOLD_REVIEW',reason_code=r.get('reason_code'),rol=res.get('rol') or res.get('vrol_case_number') or '',
                                     folder=r.get('folder'),screenshots=r.get('screenshots') or [],final_submit_clicked=bool(res.get('final_submit_clicked')))
        (run_dir/'review_holds.json').write_text(json.dumps(held,ensure_ascii=False,indent=2),encoding='utf-8')
        stats['existing_chargeback_assoc_d']=append_assoc_dispute_results(run_dir,records,log)
        failed=sum(technical_failure(r.get('result',r)) for r in records)
        outcome_classes={}
        for r in records:
            key=(r.get('result') or {}).get('outcome_class') or 'UNKNOWN';outcome_classes[key]=outcome_classes.get(key,0)+1
        summary = {'backend':settings['async_backend'],'run_business_date':settings['_run_business_date'],'technical_failures':failed,'test_mode':'inquiry_only' if args.inquiry_only else ('pi_only' if args.pi_only else ('pre_submit_only' if args.pre_submit_only else 'full')),'run_id':run_id,'status':'COMPLETED_WITH_ISSUES' if outcome_report['needs_user_review_count'] or held else 'COMPLETED','worker_count':workers,'group_count':len(groups),'review_required':review_report,'input_stats':stats,'rol500_preflight':rol_result,'output_workbook':str(output_workbook),'run_dir':str(run_dir),'run_log':str(run_dir/'logs'/'run.log'),'activity_report_jsonl':str(run_dir/'activity_report.jsonl'),'elapsed_seconds':round(time.monotonic()-run_started,3)}
        summary.update(started_at=monitor.data['started_at'],completed_at=run_now(),input_contract=contract,
                       final_submit_enabled=monitor.data['final_submit_enabled'],review_holds=str(run_dir/'review_holds.json'))
        summary['rol500_postflight']=postflight
        summary['outcome_classes']=outcome_classes
        summary['writer_drain_s']=writer_drain_s
        summary['headless']=truth(settings.get('headless'))
        summary['master_writeback']=master_writeback
        summary['pi_documents_export']=pi_export
        summary['pi_documents_dir']=pi_export['local_path']
        summary['business_rules_version']='2026-11-20-user-confirmed'
        summary['run_state_store']='MASTER_AM_PLUS_LEDGER'  # reviewed_guids.txt / review_holds folder retired
        from async_runtime.run_outcome import completed_status
        summary['status']=completed_status(postflight,outcome_report,held,master_writeback,pi_export)
        summary['worker_configuration']=worker_config;summary['guid_outcomes']=outcome_report
        (run_dir/'async_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        monitor.dashboard.finish(summary['status'],summary)
        monitor.update(status=summary['status'],stage='FINISHED',completed_at=summary['completed_at'])
        if summary['status']=='FAILED':monitor.update(error=postflight.get('error') or 'ROL500_POSTFLIGHT_FAILED')
        C.print(Panel.fit(json.dumps(summary,ensure_ascii=False,indent=2),title=summary['status'].replace('_',' '),border_style='red' if summary['status']=='FAILED' else ('yellow' if summary['status']=='SUCCESS_WITH_REVIEWS' else 'green')))
        return 2 if summary['status']=='FAILED' else 0
    finally:
        for task in tasks:
            if not task.done():task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)
        if writer_task and not writer_task.done():
            writer_task.cancel()
            await asyncio.gather(writer_task, return_exceptions=True)
        if writer:
            await asyncio.to_thread(writer.close)
        if outcome_report is None and (run_dir/'groups').is_dir():
            try:await asyncio.to_thread(build_guid_outcomes,run_dir)
            except Exception as exc:log('warning',f'PARTIAL GUID OUTCOME REPORT FAILED | {exc}')
        await session.close()
        tidy_run_dir(run_dir)


def tidy_run_dir(run_dir):
    """Drop scratch folders that carry nothing once the run is over."""
    shutil.rmtree(run_dir/'_tmp',ignore_errors=True)
    for name in ['browser_downloads']+[f'worker_W{i:02d}' for i in range(1,33)]:
        folder=run_dir/name
        try:
            if folder.is_dir() and not any(folder.iterdir()):folder.rmdir()
        except OSError:pass


async def main_async(args):
    root=Path(__file__).resolve().parent
    with RunLock(root/'runtime'/'vrol_process.lock'):
        run_id=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]
        monitor=RunMonitor(root/'runtime'/'async_parallel'/run_id)
        heartbeat=asyncio.create_task(monitor.heartbeat())
        previous_console_file=C.file
        try:
            with ConsoleLog(monitor.folder/'console.log'):
                C.file=__import__('sys').stdout
                return await _main_async(args,monitor)
        except BaseException as exc:
            monitor.update(status='FAILED',stage='INTERRUPTED' if isinstance(exc,(KeyboardInterrupt,asyncio.CancelledError)) else 'FAILED',error=f'{type(exc).__name__}: {exc}',completed_at=run_now())
            if getattr(monitor,'dashboard',None):
                monitor.dashboard.data['error']=f'{type(exc).__name__}: {exc}';monitor.dashboard.finish('FAILED')
            raise
        finally:
            C.file=previous_console_file
            business_state=getattr(monitor,'business_state',None)
            if business_state:
                try:await asyncio.to_thread(business_state.sync)
                except Exception as exc:log('warning',f'MASTER WRITEBACK FAILED | durable ledger retained | {exc}')
                finally:business_state.close()
            from async_runtime.guid_request import build_report
            try:await asyncio.to_thread(build_report,monitor.folder)
            except Exception as exc:log('warning',f'GUID REQUEST REPORT FAILED | {exc}')
            heartbeat.cancel();await asyncio.gather(heartbeat,return_exceptions=True)

def main() -> None:
    parser = argparse.ArgumentParser(description='Async parallel VROL case review')
    parser.add_argument('--config', default='config.xlsx')
    parser.add_argument('--workers', type=int)
    parser.add_argument('--backend',choices=['native_async','legacy_bridge'])
    parser.add_argument('--headful',action='store_true')
    parser.add_argument('--headless',action='store_true',help='Run Chrome headless (overrides --headful and config); comparison/diagnostic')
    parser.add_argument('--pre-submit-only',action='store_true',help='Stop after questionnaire even if config enables Final Submit')
    parser.add_argument('--console-log',help='Mirror the CMD console to a UTF-8 log file')
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument('--inquiry-only',action='store_true')
    modes.add_argument('--pi-only',action='store_true',help='Download PI but stop before any Issuer Action')
    parser.add_argument('--guid',action='append',help='Restrict to an eligible GUID; repeat to select several')
    parser.add_argument('--guid-file',help='Text file with one GUID per line (same as repeating --guid)')
    parser.add_argument('--source-workbook')
    parser.add_argument('--mapping-file',help='Explicit GUID|PAN mapping for a manual run')
    parser.add_argument('--master-workbook',help='Mutable original file 09 to receive AK/AL/AM; never a frozen contract snapshot')
    parser.add_argument('--input-contract',help='Frozen FC + GUID2PAN bundle manifest from RPA Ops')
    parser.add_argument('--scheduled',action='store_true',help='Wait for the evening READY contract before login; honors config Final Submit switch')
    parser.add_argument('--guid-request',help='GUID-only request generated by RPA Ops; keeps CODE CB from the input workbook')
    parser.add_argument('--skip-rol500',action='store_true',help='Use an existing enriched input for a bounded diagnostic test')
    parser.add_argument('--skip-postflight',action='store_true',help='Diagnostic only: skip the final ROL500 download and Excel reconciliation')
    parser.add_argument('--no-resume',action='store_true')
    parser.add_argument('--recheck-read-only',action='store_true',help='Re-observe known PI/no-CB GUIDs; never bypass case-action holds or completed case routes')
    parser.add_argument('--review-existing',action='store_true',help='Obsolete: registry/holds retired; type FORCE in AM to re-run a GUID')
    parser.add_argument('--resume-run',help='Run only unfinished and review GUIDs from the specified queue')
    parser.add_argument('--limit-groups', type=int, help='Process only the first N queued GUID groups for a bounded test')
    parser.add_argument('--write-master',action='store_true',help='Allow --pi-only/--inquiry-only to write AK/AL/AM (off by default)')
    parser.add_argument('--ignore-review-holds',action='store_true',help='Obsolete: registry/holds retired (kept so old commands still parse)')
    parser.add_argument('--ledger',help='Business ledger SQLite path (default runtime\business_state.sqlite3); use a fresh file for an isolated rehearsal')
    parser.add_argument('--worker-cap',type=int,help='Diagnostic: override async_worker_max for a throughput experiment')
    args = parser.parse_args()
    if args.guid_file:
        args.guid=(args.guid or [])+[x.strip() for x in Path(args.guid_file).read_text(encoding='utf-8-sig').split() if x.strip()]
    if args.no_resume and args.review_existing and not args.guid:
        parser.error('Explicit --guid targets are required when bypassing the registry for review retry')
    if args.limit_groups is not None and args.limit_groups < 1:
        parser.error('--limit-groups must be at least 1')
    console_path=Path(args.console_log) if args.console_log else Path(__file__).resolve().parent/'runtime'/'console_logs'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.log')
    with ConsoleLog(console_path):
        C.file=__import__('sys').stdout
        C.print(f'Console log: {console_path}')
        try:
            raise SystemExit(asyncio.run(main_async(args)))
        except KeyboardInterrupt:
            log('warning', 'Async parallel interrupted by user')
            raise
        except Exception as exc:
            log('error', f'{type(exc).__name__}: {exc}')
            raise

if __name__ == '__main__':
    main()
