NATIVE ASYNC PLAYWRIGHT - v9.2.0-rc1
==================================
Run every command below in CMD. Production does not need PowerShell.

Install:                  install.cmd
PI-only test, <=3 GUIDs:   run_async_native_test.cmd
One case, NO final submit: run_async_case_test.cmd --guid YOUR_GUID
Normal production queue:  run_async_parallel_case_review.cmd
Offline checks:           run_offline_tests.cmd
Local window/DPI check:   run_window_layout_test.cmd
Markers for a stopped run: run_guid_markers.cmd "C:\path\to\run_id"

WORKERS (Settings sheet in config.xlsx)
  async_worker_count = 3   (B176; set 3, 4 or 5)
  async_worker_max   = 5   (B177; cap)
Production CMD now uses Excel instead of forcing 3. --workers N overrides one
run, subject to the cap and eligible GUID count. PI-only 5-GUID diagnostic:
  run_async_native_test.cmd --workers 5 --limit-groups 5
3 workers have been tested on Visa; 5 native PI flows passed local simulation.

Run scripts show Chrome headful and a Rich console. Python copies console logs
to runtime/console_logs. Additional switches may follow a CMD name:
  --workers 2 --limit-groups 3 --guid GUID1 --guid GUID2
  --console-log "C:\logs\review.log"

The default backend is native_async: one async Playwright persistent context,
separate pages and recursively owned popup chains for each worker. Inquiry,
View/Tran Details and Case Creation have no global popup lock. Native downloads
use the owning page's expect_download/save_as, not a shared download-directory
switch. Direct CDP calls only maximize the browser window; no sync/CDP bridge
is used by the native workflow. Legacy bridge remains an explicit fallback.
Native PI verifies the menu's declared top.bodyframe.viewDetails() contract and
invokes that original handler in the owning frame. It reuses an already-open
View menu instead of toggling it closed between successive invoices. The legacy
backend is diagnostic only and does not inherit all native rule overrides.

BUSINESS RULES
- Input: codes 10.4/13.1/13.9, CHECK SALE=SALE, VALID CHARGEBACK=Y,
  complete GUID/PAN mapping; prefix-5 cards excluded.
- ROL500 already-chargeback excludes the whole GUID, following sync.
- Recheck NGAY GD locally: age >15 calendar days. Keep the existing async upper
  bound age <120 days. Freeze the business date in Vietnam time at run start.
- Defer excluded young rows with a reason; process eligible rows of the GUID.
  Start Date is the earliest retained date. Deferred rows are not marked done.
- USER OVERRIDE: scan every invoice for VROL PI=Yes FIRST. PI bypasses Sale/Cash
  uniqueness, refund/reversal, Assoc Dispute and ECI decisions. Any PI in the
  GUID routes to evidence download and prevents Issuer Action for that GUID.
- Without PI, preserve sync: one Sale/Sale-WT (10.4/13.1) or Cash (13.9), then
  Credit/Cash Rev group stop, Assoc D stop, unknown Assoc review, 10.4 ECI
  blank/5/6 stop. Fraud for 10.4, Consumer for 13.1/13.9. Mixed branches review.
- Questionnaire presets/selectors follow sync; no new Response Code gate.

FILES
runtime/async_parallel/<run_id>/
  groups/<OUTCOME>_<GUID>/documents/<invoice>_<last4>_<TERMOWNER>.pdf  (primary)
  groups/<OUTCOME>_<GUID>/pi_manifest.json, guid_result.json, group_result.json,
                guid_case.log, screenshots and case_checkpoint.json
  documents/<invoice>_<last4>_<TERMOWNER>.pdf               (aggregate copy)
  input_exclusions.json, review_required_cases.json/.csv
  guid_outcomes.csv, guid_outcomes.json (all processed GUID categories/stages)
  09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx, async_summary.json

Invoice leading zeros are preserved; invalid filename characters in TERMOWNER
are replaced. Success requires PDF transaction identity and hash verification
in both locations. Conflicting filenames are flagged for review, without silent
overwrite. Completion renames the GUID folder and rebases JSON/Excel evidence paths. No-chargeback reasons and technical,
duplicate and unknown outcomes are recorded. Screenshots cover owned pages.

QUESTIONNAIRE AND FINAL SUBMIT
config.xlsx > Settings:
  questionnaire_maximize_before_capture = YES
  allow_final_submit = NO   (current default)
Settings is authoritative for this flag; the duplicate legacy RunSettings value
does not override it. Change Settings!B47 to YES to enable production submit.

Chrome now uses no_viewport=True, so content follows the real client area of the
maximized native window at the current Windows DPI and screen size. Primary
Visa/VROL windows are verified maximized. PI and Case Creation popups keep their
native dimensions. Questionnaire is ALWAYS maximized and its layout settled
BEFORE filling. questionnaire_maximize_before_capture controls an additional
check immediately before capture; it cannot disable the before-fill step.
No fixed viewport size or guessed title-bar pixel offsets are used.

run_window_layout_test.cmd launches only local mock pages in a separate test
profile: 3 headful Chrome relaunch cycles, native resizes, ordinary popup sizes,
questionnaire first-input geometry and full-page screenshots. It needs no Visa
login or OTP. Evidence is written to runtime/window_layout/<timestamp>/.

Normal production runs with allow_final_submit=YES send the real dispute after
filling and capture 06_before_final_submit.png and 07_final_submit_result.png.
With NO they capture 04_questionnaire_filled_final_submit_not_clicked.png and
stop. run_async_case_test.cmd always forces the stop even if config says YES.
Unknown submit outcomes require reconciliation and are not automatically resent.
Real Final Submit has not been exercised live; only local fixtures.

OTP
Reuse the existing persistent profile. Poll only when VROL requests MFA.
Configure otp_polling_mode=FOLDER_FILENAME and otp_folder_path in config.xlsx.
The console prints the folder and polling timeout when OTP is needed. Current
Visa tests reused today's authenticated MFA session; no fresh OTP was requested.

RESUME
Only successful business outcomes enter the reviewed registry. PI errors/review
outcomes do not. Partially age-filtered GUIDs record row review keys, so a young
invoice remains eligible later. --no-resume is a diagnostic override: do not use
it to blindly repeat Case Creation or an uncertain Final Submit. Reconcile the
case number/checkpoint/ROL500 first. Existing pre-submit drafts are not submitted
retroactively merely by changing allow_final_submit to YES.

Bounded diagnostics against an existing enriched snapshot:
  run_async_native_test.cmd --guid YOUR_GUID --no-resume --skip-rol500 ^
    --source-workbook "C:\path\ROL500_ENRICHED.xlsx"
--skip-rol500 is for a known snapshot, not the normal production run.

See docs/NATIVE_ASYNC_IMPLEMENTATION_2026-11-19.md for validation and limitations.
Window layout update: docs/WINDOW_LAYOUT_2026-11-19.md.
Worker/marker guide: docs/WORKERS_AND_GUID_MARKERS_2026-11-20.md.
