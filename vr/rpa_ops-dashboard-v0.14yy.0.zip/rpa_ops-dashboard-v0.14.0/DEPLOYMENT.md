> **v9.2.0 / dashboard v0.14.0:** dùng [HUONG_DAN_TRIEN_KHAI_VROL_DASHBOARD.md](docs/HUONG_DAN_TRIEN_KHAI_VROL_DASHBOARD.md) (lịch 19:40, contract v2, AM SKIP/FORCE, Final Submit, worker). Phần dưới là ghi chú bản cũ; registry/review holds đã bỏ.

# Triển khai RPA Ops Dashboard độc lập

Copy riêng project vào C:\Apps\RPAOps. Không cần Visa ở cạnh hoặc chung virtualenv.
Windows/Python 64-bit, cài và chạy bằng CMD:

```bat
install.cmd
configure_paths.cmd --non-interactive --visa-root "D:\Bots\Visa" --fc-root "D:\Bots\FC" --guid2pan-root "D:\Bots\GUID2PAN" --reports-dir "D:\RPAReports"
run_server.cmd
```

Mở http://127.0.0.1:8765/#/bot/vrol_master. SQLite data\rpa_ops.db lưu settings;
configure chỉ sửa Dashboard, không cài/sửa config.xlsx Visa. Các root là thư mục
project thật. CMS/T24 nếu dùng cần đổi root tại Settings. Giữ bind localhost nếu
chưa có lớp kiểm soát truy cập web của môi trường.

Nút Kiểm tra cấu hình & đầu vào trong box VROL kiểm tra config/file 09/input.txt
và contract đang chọn, trả PASS/WARN/FAIL với số lượng, không lộ credentials/PAN/
OTP/GUID. Nút chỉ đọc, không login, không chạy bot hoặc gửi case.

Collector ghép FC/GUID2PAN theo lineage/cửa sổ trigger đã khai báo, kiểm tra file 09
và input.txt GUID|PAN, coverage/hash, rồi xuất contract READY vào <visa-root>\runtime\
ops_inputs. input.txt upstream thường cố định đường dẫn; contract dùng snapshot
riêng, không thay khi raw bị ghi đè.

| Setting | Ý nghĩa |
|---|---|
| SERVER_HOST / SERVER_PORT | 127.0.0.1 / 8765; restart để đổi |
| CRAWL_INTERVAL_MINUTES | 2, chu kỳ collect/publish contract |
| VROL_GUID_POLL_SECONDS | 5, poll progress VROL |
| VROL_INPUT_CONTRACT_DIR | Trống: <visa-root>\runtime\ops_inputs |
| STATIC_REPORT_OUTPUT_DIR | Thư mục báo cáo chia sẻ |

Folder contract khác: truyền --contract-dir vào configure cả Dashboard/Visa hoặc
chỉnh hai setting tương ứng. Process hai bên cần đọc/ghi được folder. Không cần
HTTP giữa hai bên khi Visa đã nhận bundle.

Upstream chạy 19:30; Task Scheduler riêng Visa gọi run_scheduled.cmd lúc 19:35/19:40,
chờ tối đa 30 phút để lấy READY ca tối. Dashboard cần collect để xuất contract;
restart server sau công bố không dừng bot. Bộ cài không tự tạo lịch đẩy case.
Visa cài dependencies/config/OTP riêng, Final Submit mặc định NO.

Output view có GUID queued/running/completed, lọc review và nút mở folder/ảnh trên
máy server. FRAUD/CONSUMER có thể chỉ là draft; đọc action_stage/final_submit_confirmed.
PI ở run\documents, ảnh từng GUID ở groups; có link Excel và ROL500/reconciliation.
Static pack ở reports\vrol\<run_id>\index.html. Offline: run_offline_tests.cmd.
Bản ZIP kèm TECHNICAL_HANDOVER.md trong project này để tra kiến trúc/API/bảo trì.
docs/USER_SELECTED_GUID_RUN.md mô tả nút chạy riêng theo GUID và báo cáo tương ứng.
