# Cài đặt VROL Visa và RPA Ops trên production

Xem [TECHNICAL_HANDOVER.md](TECHNICAL_HANDOVER.md) để bàn giao kiến trúc, module,
input contract, cấu hình, retry/Final Submit, kiểm thử và GitHub.
Mẫu phát hành đặt `trace_enabled=NO`; ảnh bằng chứng native vẫn được giữ.

Gói cung cấp `vr9.1.13.16/config.sample.xlsx` đã bỏ tài khoản, mật khẩu và câu trả lời
bảo mật; không chứa `input.txt` và `09_chargeback_classified.xlsx`. Lệnh thiết lập
copy sample thành `config.xlsx` trên máy production để bạn nhập thông tin mới.
`async_restart_after_guids` mặc định 100: chờ các GUID đang chạy hoàn tất rồi đóng
phiên Chrome của bot và login lại; không chạy lại preflight ROL500 trong lần restart.
Mỗi worker cũng thay tab sau 25 GUID để giảm tích lũy tài nguyên của trang.

## 1. Chuẩn bị máy

Dùng Windows 64-bit, Python 64-bit và quyền truy cập Visa Access/VROL, CMS GUID2PAN,
thư mục đầu vào và thư mục báo cáo. Máy kiểm thử dùng Python 3.14. Các bộ cài cần
truy cập kho Python packages và Chrome. Chạy trong phiên Windows đã đăng nhập để
thấy Chrome headful và xử lý OTP. Không chạy phiên Chrome này trong Windows service Session 0.

Hai project cài độc lập, có thể nằm ở hai ổ khác nhau. Ví dụ copy thư mục Visa vào
`D:\Bots\Visa`, Dashboard vào `C:\Apps\RPAOps`. Mỗi thư mục có tài liệu kỹ thuật,
install.cmd/configure_paths.cmd riêng. Không giải nén đè lên production đang chạy.

## 2. Cài dependencies bằng CMD

Mở Command Prompt và cài từng project:

```bat
cd /d D:\Bots\Visa
install.cmd
cd /d C:\Apps\RPAOps
install.cmd
```

Mỗi lệnh cài virtualenv của project đó; Visa cài Chrome cho Playwright. Không cần PowerShell.
Nếu giữ nguyên bundle cạnh nhau có thể dùng root install_all.cmd. Không copy
`.venv` từ máy kiểm thử sang máy production.

## 3. Thiết lập đường dẫn

```bat
cd /d D:\Bots\Visa
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --workers 5
cd /d C:\Apps\RPAOps
configure_paths.cmd --non-interactive --visa-root "D:\Bots\Visa" --fc-root "D:\Bots\FCBot" --guid2pan-root "D:\Bots\GUID2PAN" --reports-dir "D:\RPAReports"
```

Các thư mục bot phải là root thật có file/chương trình chạy, không chỉ folder output.
Configure Visa tạo config.xlsx từ mẫu nếu thiếu, sửa paths/workers/restart và backup
config.before_paths.xlsx; credentials và công tắc Final Submit hiện có được giữ.
Configure Dashboard chỉ ghi SQLite của Dashboard, không sửa config Visa. Hai bên
mặc định giao tiếp bằng contract ở <visa-root>\runtime\ops_inputs. Nếu dùng folder
chung khác, truyền cùng --contract-dir cho hai lệnh configure.

File thiết lập dashboard: `rpa_ops-dashboard-v0.13.4\data\rpa_ops.db`.
Trong giao diện Settings có thể đổi các root và thư mục báo cáo sau này. Nếu đổi
root VROL, cần chạy lại cấu hình đường dẫn trong workbook ở root mới.

## 4. Nhập thông tin Visa

Mở `vr9.1.13.16\config.xlsx` bằng Excel:

| Vị trí | Cần thiết lập |
|---|---|
| Settings: `username`, `password` | Tài khoản Visa của môi trường production |
| Settings: `welcome_name`, `vrol_logged_on_email` | Nhận dạng người dùng nếu môi trường yêu cầu |
| SecurityQuestions | Câu hỏi, câu trả lời và enabled đúng tài khoản; mẫu không có câu trả lời |
| Settings: `otp_polling_mode` | Giữ chế độ thư mục hiện có |
| Settings: `otp_folder_path` | Đúng đường dẫn vừa cấu hình |
| Settings: `async_worker_count` / `async_worker_max` | Mặc định 5 / 5 trong gói |
| Settings: `rol500_preflight_enabled` / `rol500_postflight_enabled` | YES / YES |
| Settings: `allow_final_submit` | Mặc định NO |

Đóng Excel trước khi chạy. Khi bot hiển thị WAITING_OTP, tạo/copy file OTP mới theo
quy tắc filename mà config đang dùng vào đúng thư mục. Bot lấy baseline trước khi
yêu cầu OTP nên không dùng file cũ. Phiên MFA còn hợp lệ thì không hỏi OTP mới.

Mẫu dùng FOLDER_FILENAME, pattern *.txt, OTP 8 chữ số, poll 5 giây, timeout 180 giây.
Ví dụ minh họa: sau WAITING_OTP tạo `YYYYMMDD_HHMMSS_12345678.txt`, thay 12345678 bằng
OTP thực. Bot lấy cụm số cuối tên file, hoặc fallback nội dung như `OTP: 12345678`.
Không copy file cũ giữ nguyên mtime; lưu file mới/cập nhật sau request. Độ dài khác
cần sửa otp_min_digits/otp_max_digits cho đúng môi trường.

## 5. Khởi động lần đầu

```bat
cd /d C:\Apps\RPAOps
run_server.cmd
```

Giữ cửa sổ server chạy, mở `http://127.0.0.1:8765/#/bot/vrol_master`.
Settings mặc định chỉ bind localhost. Vào Settings kiểm tra root VROL, FC, GUID2PAN,
thư mục static report và `VROL_GUID_POLL_SECONDS` (mặc định 5 giây).

Không có cặp upstream hợp lệ thì dashboard hiển thị WAITING_INPUT. FC và GUID2PAN
là một cặp: file 09 của FC và kết quả `GUID|PAN` từ chính lượt chuyển đổi tương ứng.
Một file GUID-only chưa convert không phải mapping hợp lệ. Dashboard không ghép
hai file mới nhất độc lập. Cặp READY được snapshot, kiểm tra GUID coverage và SHA-256.

Chọn cặp READY trên dashboard và chạy VROL Visa. Hoặc gọi trực tiếp:

```bat
vr9.1.13.16\run_vrol_from_ops.cmd "C:\...\manifest.json"
```

Để chạy thủ công với hai file đã có, đặt file 09 và `input.txt` vào root VROL:

```bat
cd vr9.1.13.16
run_full_5_workers.cmd
```

Lệnh thủ công vẫn hiện trên dashboard. Cả hai cách đều thực hiện ROL500 đầu/cuối,
lọc nghiệp vụ, registry và hold. Không mở đồng thời hai tiến trình VROL cùng profile.
Một tiến trình có thể chạy 5 worker độc lập.

### Ca tối theo lịch

Upstream chạy 19:30, Dashboard công bố contract READY gồm file 09 và snapshot
input.txt của đúng cặp FC + GUID2PAN. input.txt upstream có thể cố định đường dẫn;
snapshot giúp run VROL không bị ảnh hưởng khi file đó được ghi đè lần kế tiếp.

Đặt Task Scheduler gọi `D:\Bots\Visa\run_scheduled.cmd` lúc **19:40** (hoặc 19:35),
Start in = `D:\Bots\Visa`, Run only when user is logged on. Launcher chờ tối đa
30 phút, mỗi 10 giây kiểm tra contract, trước khi mở Visa. Chỉ chọn bundle hôm nay
có cả hai source hoàn tất từ 19:30 trở đi. Nếu hết hạn thì báo lỗi, không dùng cặp
cũ buổi sáng. Dashboard cần chạy để xuất contract; sau đó bot không cần HTTP để tiếp tục.

Config: scheduled_contract_dir, scheduled_source_not_before, scheduled_input_wait_seconds,
scheduled_input_poll_seconds. run_scheduled.cmd tôn trọng allow_final_submit trong
Settings; không ép pre-submit. Gói không tự tạo task đẩy case.

Trong Task Scheduler chọn Create Task, nhập chính xác:

| Trường | Giá trị ví dụ |
|---|---|
| General | Windows user vận hành; Run only when user is logged on |
| Trigger | Daily 19:40 |
| Program/script | C:\Windows\System32\cmd.exe |
| Add arguments | /d /c ""D:\Bots\Visa\run_scheduled.cmd"" |
| Start in | D:\Bots\Visa (không dấu nháy) |
| If already running | Do not start a new instance |

Không cắt task giữa full run; bỏ stop-after ngắn. Không bật restart-on-failure để
gửi lại case chưa rõ. Lần đầu Run task với Final NO, xem cửa sổ CMD/OTP và Output.
Dashboard chạy bằng run_server.cmd; task startup Dashboard nếu dùng là task riêng.

## 6. Xem tiến trình và đầu ra

Để chạy nhóm upstream đã loại (ví dụ quá 35 giao dịch), chọn contract READY và nhập
danh sách vào Chạy riêng theo GUID trên Dashboard. User chỉ nhập GUID; code và dữ
liệu khác lấy từ file 09/input.txt. Mode riêng bỏ filter VALID CHARGEBACK=Y, giữ
SALE/tuổi/ROL/registry/hold và rule VROL. Xem requested_guid_report.csv/json trong
Output của run riêng; không thay code trong Excel hoặc tự bật Final Submit.

Output VROL có GUID đang chờ, đang chạy, đã xong; tìm GUID, đổi trang hoặc lọc cần
review. Nút folder/ảnh mở trên máy đang chạy server. Live log báo bước hiện tại và OTP.

| Đầu ra | Vị trí dưới `vr9.1.13.16\runtime\async_parallel\<run_id>` |
|---|---|
| Workbook kết quả và ROL500 cập nhật | `09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx` |
| PI tổng hợp | `documents` |
| PI/ảnh/checkpoint theo GUID | `groups\<OUTCOME>_<GUID>` |
| Kết quả GUID và review | `guid_outcomes.csv` / `.json` |
| Báo cáo ROL500 cuối | `postflight\ROL500.csv` |
| Đối chiếu invoice/QT | `postflight\rol500_reconciliation.csv` / `.json` |
| Tổng kết, trạng thái và log | `async_summary.json`, `run_state.json`, `console.log` |

Tên folder: PI_DOWNLOADED, NO_CB, FRAUD, CONSUMER hoặc REVIEW_REQUIRED cộng GUID.
FRAUD/CONSUMER chưa có nghĩa là đã Final Submit. Xem `action_stage`, marker chờ
submit và `final_submit_confirmed`. Associated Transactions chỉ chụp ảnh/lưu ROL,
đóng popup và chuyển GUID khác. Review lấy cả lỗi và draft chờ Final Submit.

Static report chia sẻ ở đường dẫn đã cấu hình, với PI và ảnh trong
`vrol\<run_id>\index.html`. Không sửa/di chuyển các folder run bằng tay vì báo cáo
và workbook đang tham chiếu đường dẫn đó.

## 7. Mang trạng thái từ lượt kiểm thử sang production

Gói sạch mặc định không kèm migration_state, registry GUID, hold hoặc báo cáo có dữ
liệu thật. Khi production tiếp tục dữ liệu đã chạy, chuyển riêng migration_state
(registry GUID đã xử lý và hold chưa giải quyết) qua kênh nội bộ được phép.
Không chứa full-PAN mapping, mật khẩu, OTP, browser profile hoặc lịch sử trình duyệt.
Root configure_paths.cmd mặc định import state. Khi cài Visa độc lập, dùng:

```bat
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --migration-state-dir "D:\Handoff\migration_state"
```

Registry được hợp nhất, chỉ nhập hold chưa tồn tại; không ghi đè quyết định hold.

Giữ trạng thái này nếu production tiếp tục dữ liệu đã dùng trong lượt chạy full.
Không xóa registry/hold để ép chạy lại case đã có ROL. Hold phải được đối chiếu với
case hiện có trước khi chuyển disposition từ HOLD_REVIEW sang RELEASED.
Ảnh gốc nằm trong bộ kết quả của run trên máy kiểm thử, không nằm trong gói source.

Bật `allow_final_submit=YES` chỉ ảnh hưởng case mới đủ điều kiện trong hàng đợi.
Nó không tự mở và gửi các questionnaire/draft đã tạo ở run trước. Những draft đó
cần được review theo ROL và hoàn tất bằng quy trình đã xác nhận.

Ở báo cáo gộp nhiều run, `consolidated` chứa workbook cuối, danh sách toàn bộ GUID,
REVIEW_REQUIRED, draft chờ Final Submit và thư mục PI chung. Dashboard hiển thị
REVIEW_REQUIRED tách với draft chờ Final Submit; các nút mở file/folder dùng đường
dẫn thật của từng bằng chứng. Pack HTML chia sẻ cũng lấy ảnh từ các run trong lineage.

`INVOICE_NOT_IN_TRUNCATED_TRANSACTION_RESULTS` có nghĩa VROL chỉ trả 300 giao dịch
đầu tiên và chưa thấy invoice cần tìm. Cần tra đủ dữ liệu, chưa được coi là NO_CB
hoặc kết luận không có PI. `ROL_1537_DISPUTE_TRANSACTIONS_INDIVIDUALLY` cần thao tác
từng giao dịch riêng, hiện vẫn giữ review theo quy tắc xử lý cả GUID.

## 8. Điều kiện trước khi bật Final Submit

Đọc báo cáo kiểm thử nội bộ đi riêng và xử lý các nhóm cần review. ZIP sạch không
kèm báo cáo có dữ liệu vận hành. Lượt full được
chạy với Final Submit NO. Không suy diễn ROL500 có số case thành xác nhận đã submit.
Report chưa thấy case mới có thể do phạm vi ngày/độ trễ; workbook giữ số đã đọc trực
tiếp và ghi quan sát ROL500 riêng. Không tự tạo lại case vì báo cáo chưa cập nhật.

Các lỗi timeout chuyển màn hình, layout bảng và questionnaire field phải được
đối chiếu ảnh/checkpoint. Chạy UAT trên môi trường/điều kiện đã thống nhất trước
khi đổi công tắc Final Submit. Các case chưa hỗ trợ vẫn dừng để review.

Nút Final Submit thực đã được probe thấy/visible, chưa bấm gửi thật. Probe và click
dùng cùng exact ng-click Submit, yêu cầu đúng một nút visible/enabled. Bot kiểm tra
invoice/thẻ/ngày/code sát click; sau click chờ DOM/layout/text ổn định và hết loading
rồi chụp 07_final_submit_result.png. Confirmation/reject/form error được ghi riêng;
timeout sau click giữ hold/reconcile, không bấm lại. Regression local kiểm tra cả
trang kết quả render chậm; việc Visa chấp nhận dữ liệu thật vẫn chưa được UAT Final.

## 9. Vận hành, cập nhật và phục hồi

Trước khi đổi phiên bản, chờ run kết thúc; lưu config.xlsx, reviewed_guids.txt,
runtime/review_holds, run artifacts và database dashboard. Dừng server bằng Ctrl+C,
giải nén bản mới vào folder riêng, cấu hình lại đường dẫn và kiểm tra trạng thái.
Không thay thư mục `.venv` hoặc Chrome profile khi bot còn chạy.

Nếu Windows/process dừng giữa chừng, giữ nguyên toàn bộ run. Xem checkpoint, ROL,
ảnh và hold trước khi chạy lại. File summary/status phân biệt kết thúc với lỗi.
Task Scheduler nếu cần phải dùng chế độ tương tác người dùng đã đăng nhập;
gói không tự tạo lịch đẩy case. `install_startup_task.cmd` chỉ dành cho dashboard.
