@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"
if not defined PY (echo [ERROR] Python 3 not found.& pause&exit /b 10)
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
if errorlevel 1 (echo [ERROR] Could not create .venv.& pause&exit /b 11)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (echo [ERROR] Dependency installation failed.& pause&exit /b 12)
".venv\Scripts\python.exe" -m compileall -q app.py rpa_ops
if errorlevel 1 (echo [ERROR] Source validation failed.& pause&exit /b 13)
echo [SUCCESS] Setup completed.
