# RPA Ops — FC + GUID2PAN → VROL Visa

Start with the standalone [deployment guide](DEPLOYMENT.md). See the [technical handover](../TECHNICAL_HANDOVER.md) for architecture, settings,
input pairing, live reports, production setup and maintenance of both projects.

Install with `install.cmd` (or `setup.cmd`), start with `run_server.cmd`, and open
`http://127.0.0.1:8765`. All production launchers are CMD; Task Scheduler uses
Windows COM through pywin32.

Configure FC, GUID2PAN and VROL Visa roots using this project's configure_paths.cmd
or Settings. Visa may be installed at any configured directory; it has a separate
install.cmd and virtualenv. The final stage publishes and selects a frozen
pair of FC workbook + converted GUID|PAN mapping, then launches
`run_vrol_from_ops.cmd`. It does not automatically enable Final Submit.
For scheduled 19:35/19:40 runs, Visa's run_scheduled.cmd waits for the evening READY
contract directly on disk. Upstream inputs are file 09 and input.txt (often a fixed
path). Contracts record source completion times, lineage and snapshot hashes.

The Visa Output tab lists queued/running/completed GUIDs, includes a review filter
and opens folders/screenshots. Live polling defaults to 5 seconds; configure
`VROL_GUID_POLL_SECONDS` in Settings. PI aggregate and postflight ROL500/reconciliation
links appear alongside the output workbook. Static reporting includes a portable
PI/review pack under `vrol/<run_id>/index.html`.

Offline integration checks: `run_offline_tests.cmd`.
GUID-only selected runs: [operation and separate reports](docs/USER_SELECTED_GUID_RUN.md).
Detailed operating guide: [Visa integration](../vr9.1.13.16/docs/OPS_INTEGRATION_2026-11-20.md).

The release history below describes older versions and their earlier placeholders.

## Historical notes: v0.4 Daily Operations

- CMS On-Hold: ANY_SUCCESS_TODAY across 03:00, 04:00, 05:00, 06:00, 07:00.
- T24 Timeout: displays all actual runs today. Manual retry is an independent run, with no slot correlation.
- GUID2PAN: placeholder, future ANY_SUCCESS_TODAY at 19:30.
- Fraud and VROL/Mastercard: backlog placeholders.
- SQLite settings at `data\rpa_ops.db`, editable at `/#/settings`.
- Static snapshot at configured `reports\index.html`.

Run `setup.cmd`, then `run_server.cmd`, then open `http://127.0.0.1:8765/#/overview`.

## v0.7 UI changes
- Restored the normal light interface for local and static dashboards.
- Retry action is placed beside the bot name/status in the local detail header.
- CMS On-Hold Input tab explicitly states that the bot requires no input.
- Other bots can select an input previously recorded in historical runs before retrying.
- Input and Output remain separate tabs.

## v0.8 UI changes (shadcn/ui-style design)
- Giao diện mới theo phong cách shadcn/ui (token zinc, Button, Badge, Card, Tabs, Table, Alert, Dialog, Toast) viết bằng CSS/JS thuần, không cần Node hay bước build.
- `static/app.css` và `static/app.js` được dùng chung cho dashboard local và báo cáo tĩnh `reports\index.html` (nhúng vào một file HTML, mở offline được). Báo cáo tĩnh chạy chế độ chỉ đọc (`RPA_READONLY`): không có Thiết lập, Làm mới, Chạy lại, mở thư mục/file.
- `templates/index.html` chỉ còn khung tối thiểu và dữ liệu; toàn bộ giao diện do `app.js` dựng.
- Hộp thoại xác nhận chạy lại và thông báo (toast) thay cho `confirm()` / `alert()`.
- Nút thao tác dùng `data-*` và event delegation, nên đường dẫn chứa dấu `'` không còn làm hỏng nút.
- Báo cáo tĩnh giờ có tab Input / Output riêng, giống bản local.

### v0.8.1 packaging/validation
- Giữ nguyên visual system theo phong cách shadcn/ui của v0.8.
- Làm sạch SQLite, current status và static snapshot theo máy đóng gói; lần chạy đầu sẽ tạo lại từ cấu hình mặc định của máy vận hành.
- Đã kiểm tra Python, JavaScript, SQLite initialization, local page và standalone static report.

### v0.9.0
- Kích hoạt Fraud Classification Bot thật thay cho placeholder.
- Parser hiển thị input T24, output 09, source T24 run ID và metrics 10.4/13.1/13.9.
- Retry có thể chọn output từ lịch sử T24; FC Bot cũng tự chọn snapshot T24 thành công mới nhất.
- Cho phép chạy lại FC nhiều lần trong ngày khi 4 run T24 bổ sung dữ liệu.

### v0.9.1
- Sửa trạng thái FC còn RUNNING dù output/result_summary đã hoàn tất.
- Chỉ dùng upstream_input `.xlsx` trong dropdown, không dùng input_contract JSON.
- Thêm lựa chọn mặc định tự lấy output T24 mới nhất.
- Tự làm mới 5 giây khi có bot RUNNING.

### v0.9.2 - Daily input scope
- Báo cáo và input workflow được scope theo ngày hiện tại của máy chạy dashboard.
- CMS On-Hold không cần input.
- Các bot phía sau chỉ được chọn output từ run của bot đứng trước có ngày chạy bằng ngày hiện tại.
- FC Bot lấy output T24 mới nhất trong ngày; không tự fallback sang output ngày trước khi chạy từ dashboard.
- API retry từ chối input không thuộc run của ngày hiện tại.
- Khi chưa có input hôm nay, nút chạy bị khóa và hiển thị lý do rõ ràng.

### v0.9.3 - T24 manual input fix
- T24 Timeout nhận output CMS On-Hold thành công của ngày hiện tại làm input thủ công.
- Bổ sung `latest` contract-backed CMS result nếu parser không lặp lại resource này trong danh sách runs.
- Không loại input chỉ vì metadata `exists` trong snapshot dashboard bị cũ; đường dẫn vẫn được backend và bot kiểm tra khi thực thi.

### v0.9.4
- Refresh tạo lại `workflow_inputs` sau khi kiểm tra success file thực tế trên ổ đĩa.
- T24 Timeout lấy `main_output` mới nhất từ CMS On-Hold thành công trong ngày.
- Đọc `CUMULATIVE_FILE_PATH` trong T24 `config.xlsx` sheet `CONFIG_GENERAL`.
- Static report mặc định lưu tại `D:\OneDrive - Techcombank\RPA\01 Tra soat Visa`.

### v0.9.5
- Bắt buộc trình duyệt tải lại app.js/app.css, không dùng cache phiên bản cũ.
- API và trang dashboard trả `Cache-Control: no-store`.
- Fallback quét trực tiếp `CMS_ROOT\output\YYYYMMDD\cms-on-hold-export*.csv` khi có CMS success hôm nay nhưng parser chưa đưa được output vào workflow input.
- Thêm endpoint kiểm tra `/api/debug/workflow-inputs`.

### v0.9.6
- T24 input không còn phụ thuộc event `run_success`: backend quét đệ quy output CMS thực tế.
- Chấp nhận CSV nếu đường dẫn chứa YYYYMMDD hôm nay hoặc ngày sửa file là hôm nay.
- Endpoint debug trả cms_root, cms_root_exists và scanned_candidates.
- Giao diện hiển thị `v0.9.6` cạnh phụ đề để xác nhận server/frontend đang chạy đúng bản.

### v0.10.0 - Live run logs
- Thêm tab `Live log` cho từng run.
- Dashboard tail `process_log` theo offset mỗi 1,2 giây, không đọc lại toàn file.
- Hỗ trợ log text và JSONL; JSONL được render thành timestamp/level/message.
- Loại bỏ ANSI escape sequence của Rich trước khi hiển thị HTML.
- Tự cuộn, xóa màn hình và tự dừng polling khi run hoàn tất.

### v0.10.2 - Run detail and log fixes
- Sửa triệt để lỗi `runs.find is not a function` bằng `allRuns = Array.isArray(b.runs) ? b.runs : []`.
- Nút `Xem` được tách thành `Chi tiết` và `Log trực tiếp`/`Xem log`/`Log lỗi`.
- Nút log mở đúng route của run: `#/bot/<bot>/run/<run_id>/log`.
- Tab Live log hiển thị thực sự vì panel `logs` được đưa vào `showTab`.
- Hiển thị rõ khi run đã nhận diện nhưng file `process_log` chưa tồn tại.

### v0.11.0 - GUID2PAN integration
- GUID2PAN là bot thật thay placeholder.
- Input là `09_CHARGEBACK_CLASSIFIED.xlsx` thành công của FC trong ngày.
- Dashboard gọi wrapper `script\run_guid2pan.cmd`, wrapper chuẩn bị `input.txt` rồi gọi nguyên trạng `cms-guid2pan-v3_9\run_guid2pan.bat`.
- Hiển thị số GUID unique, blank, duplicate, handoff status và log wrapper.

### v0.11.1 hotfix
- Sửa `operations.enrich()` chỉ return payload trong nhánh GUID2PAN bị thiếu, làm static report nhận `None`.
- Viết lại operations rõ ràng, mọi nhánh luôn trả payload.

### v0.11.5 - Refresh immediately after manual run
- Sau khi API retry trả OK, dashboard refresh ngay.
- Tiếp tục refresh mỗi giây cho đến khi thấy run mới/RUNNING hoặc hết 15 lần kiểm tra.
- Nút hiển thị `Đang chờ bot khởi động…`; toast xác nhận khi bot thực sự xuất hiện trong dashboard.

### v0.11.8 - Native CMS GUID2PAN
- GUID2PAN root/command là `C:\Users\tamdtm.ttt\Downloads\cms-guid2pan-v3_9` và `run_guid2pan.bat`.
- Input dashboard là working `input.txt` được FC handoff tạo, không phải file 09.
- Parser đọc log native `bootstrap_log\guid2pan_startup.jsonl`.
- Root path vẫn cấu hình được trong màn hình Thiết lập; command được suy ra là `<root>\run_guid2pan.bat`.

### v0.11.9 - GUID2PAN terminal-state parser
- Công nhận `run_end` với `ok=true`, `state=completed`, `status=SUCCESS` là kết thúc thành công.
- Công nhận `conversion_result`, `output_file_stable`, `cms_disconnected` theo status/ok.
- Lấy output từ `run_end.output_file` và metrics size, elapsed, disconnect status.
- Không còn giữ RUNNING sau khi log đã có `run_end`.

### v0.12.0 - GUID2PAN per-run logs
- Nguồn trạng thái chính: `logs\guid2pan_YYYYMMDD_HHMMSS.jsonl`.
- Mỗi file trong `logs` là một run và chứa `run_start` đến `run_end`.
- `bootstrap_log\guid2pan_startup.jsonl` chỉ dùng tạm để báo RUNNING trong giai đoạn startup trước khi file log run xuất hiện.
- Live log mở đúng file per-run, không mở startup log chung.

### v0.12.1 - Simple CMS contract publisher
- Mỗi lần dashboard collect/refresh, nếu phát hiện CMS On-Hold SUCCESS hợp lệ của ngày hiện tại và file CSV tồn tại, dashboard tự ghi `CMS_ROOT\state\latest_success.json`.
- Publisher idempotent: cùng run/file/size thì không ghi lại; có success mới hơn thì tự cập nhật.
- Trạng thái publish hiển thị ngay trong tab Overview của CMS On-Hold.
- Không publish dữ liệu ngày cũ khi hôm nay chưa có success.
- Command mặc định của CMS On-Hold đổi về `run_unattended.bat`; phần publish do dashboard đảm nhiệm.

### v0.13.3 - T24 contract compatibility
- Contract CMS On-Hold bổ sung root field `bot_name: cms-on-hold-export`, đúng validation của T24 Timeout v0.0.25.
- Dashboard tự ghi lại contract cũ thiếu/sai `bot_name`, kể cả run_id, output path và file size không đổi.
- Giữ nguyên schema mới và resource `cms_on_hold_export_csv`; đây là thay đổi tương thích ngược, không làm mất dữ liệu publisher hiện tại.
