from pathlib import Path
from waitress import serve
from rpa_ops.app import create
from rpa_ops.db import load
R=Path(__file__).resolve().parent;s=load(R/'data'/'rpa_ops.db');serve(create(R),host=s['host'],port=s['port'],threads=6)
