# Bàn giao kỹ thuật VROL Visa và RPA Ops Dashboard

Rà soát ngày 20/11/2026. Dành cho người triển khai, vận hành và lập trình viên tiếp
nhận. Nội dung mô tả native async hiện tại. Các tài liệu khảo sát và sync trong
docs là lịch sử thiết kế; khi khác nhau cần đối chiếu mã nguồn hiện tại và các
override nghiệp vụ đã chốt dưới đây.

## 1. Cấu trúc và điểm bắt đầu

Gói chứa hai dự án, không bao gồm source FC Bot/GUID2PAN/CMS/T24 upstream. Dashboard
tham chiếu các dự án đó qua đường dẫn cấu hình. Máy kiểm thử dùng Python 3.14
64-bit. Production cài lại dependencies; không copy virtualenv từ máy phát triển.

```text
repository/
  README.md, TECHNICAL_HANDOVER.md, PRODUCTION_GUIDE.md
  install_all.cmd, configure_paths.cmd, start_dashboard.cmd, build_production.cmd
  deployment/                       Thiết lập, báo cáo, đóng gói
  vr9.1.13.16/
    config.sample.xlsx              Mẫu sạch được version control
    config.xlsx                     Cấu hình thật, không vào Git
    run_async_parallel_case_review.py
    async_runtime/                  Luồng native async
    src/                            Parser/hàm dùng chung với sync
    tests/
    runtime/                        Trạng thái và bằng chứng tại máy
  rpa_ops-dashboard-v0.13.4/
    app.py                          Waitress HTTP server
    rpa_ops/                        Flask API, collector, parser, handoff
    static/, templates/             Giao diện JavaScript/CSS/HTML
    data/rpa_ops.db                 SQLite settings tại máy
    reports/                        HTML/PDF/ảnh chia sẻ
```

Người triển khai bắt đầu ở mục 5–7; người vận hành đọc 8–11; lập trình viên đọc
2–4 và 12–15. Hướng dẫn thao tác ngắn: [PRODUCTION_GUIDE.md](PRODUCTION_GUIDE.md).

## 2. Kiến trúc và bản đồ mã nguồn

```mermaid
flowchart LR
  FC[FC Bot Excel] --> PAIR[Dashboard ghép đúng cặp]
  GP[GUID2PAN mapping] --> PAIR
  PAIR --> SNAP[Snapshot và manifest SHA256]
  SNAP --> RUN[VROL runner]
  RUN --> PRE[ROL500 preflight và queue]
  PRE --> WORK[Async workers]
  WORK --> PI[PI PDF]
  WORK --> CASE[Case Creation và Questionnaire]
  PI --> WRITER[Event queue và một Excel writer]
  CASE --> WRITER
  WRITER --> POST[ROL500 postflight]
  POST --> OUT[Excel JSON CSV ảnh PDF]
  OUT --> DASH[Dashboard live và HTML chia sẻ]
```

Dashboard khởi chạy CMD bằng subprocess; bot là tiến trình riêng. Dashboard không
giữ Playwright Page hay điều khiển popup Visa. Restart dashboard không restart bot.
Bot ghi filesystem; dashboard có thể đọc lại tiến độ sau khi server khởi động lại.

VROL dùng một persistent BrowserContext đã đăng nhập và nhiều tab worker. Mỗi
worker xử lý tuần tự các GUID của mình; workers chạy song song. Một consumer duy
nhất ghi Excel. Không mở/sửa workbook kết quả bằng Excel khi bot đang ghi.

| Thành phần | File | Trách nhiệm |
|---|---|---|
| Runner | `vr9.1.13.16/run_async_parallel_case_review.py` | CLI, config, login, preflight, queue, workers, postflight, summary |
| Login/MFA | `async_runtime/browser.py`, `src/auth/legacy_login.py` | Visa Access, security questions, OTP provider |
| Session | `async_runtime/session.py` | Lease/gate, drain, replace context, relogin theo generation |
| Worker | `async_runtime/worker.py` | Deadline, retry an toàn, evidence, kết quả và cleanup |
| Engine | `async_runtime/native_engine.py` | Chọn nhánh PI/case/review sau precheck |
| Input/Excel | `async_runtime/excel_store.py` | Filter, registry, journal và checkpoint workbook |
| Luật | `native_precheck.py`, `business_rules.py` trong async_runtime | PI priority, veto, chọn financial transaction |
| DOM | `async_runtime/native_table.py`, `native_ui.py` | Schema, filter, snapshot, questionnaire fields |
| Popup | `async_runtime/popup_registry.py`, `popup_scope.py` | Opener ownership và named target namespace |
| Case | `async_runtime/native_case.py`, `final_submit.py` | Case Creation, identity, fill, capture, Final Submit |
| PI | `async_runtime/native_pi.py`, `pi_artifacts.py` | Download, PDF identity/hash và atomic publish |
| Outcome | `run_monitor.py`, `guid_markers.py`, `guid_folders.py`, `outcomes.py` trong async_runtime | Heartbeat, state, markers và folder |
| Hold | `async_runtime/review_holds.py` | Chặn side effect chưa giải quyết |
| ROL500 | `async_runtime/rol500_preflight.py`, `rol500_postflight.py`, `src/vrol/reports/rol500.py` | Tải và đối chiếu |
| Dashboard HTTP | `rpa_ops-dashboard-v0.13.4/app.py`, `rpa_ops/app.py` | Waitress, Flask, API và mở file local |
| Dashboard data | `rpa_ops/db.py`, `collector.py`, `operations.py` | SQLite settings, crawl, trạng thái và thao tác |
| Handoff | `rpa_ops/vrol_handoff.py`, `async_runtime/input_contract.py` | Ghép cặp/snapshot và xác minh trước login |
| Chạy GUID riêng | `rpa_ops/vrol_guid_request.py`, `async_runtime/guid_request.py` | GUID-only request gắn contract/hash và báo cáo riêng |
| Dashboard VROL | `rpa_ops/parsers/vrol_visa.py`, `static/app.js` | Progress, kết quả GUID, evidence links |
| Report pack | `rpa_ops/vrol_export.py`, `static_report.py` | HTML/PDF/ảnh, có hỗ trợ lineage nhiều run |

Các đường dẫn async_runtime/src thuộc project Visa; rpa_ops/static thuộc Dashboard.
Không xóa src chỉ vì tên module/hàm còn mang dấu sync: native vẫn import parser và
quy tắc ở đó. `legacy_bridge` còn để tương thích, có CDP và serialization riêng.
Production dùng `native_async`, không cần remote debugging port để chạy Playwright.

## 3. Hợp đồng input và quy tắc nghiệp vụ

### 3.1 Ghép cặp FC và GUID2PAN

Workbook dùng Sheet1, header dòng 2, data từ dòng 4. Header bắt buộc: GUID, BUT TOAN,
NGAY GD, INVOICENUM, CODE CB, CHECK SALE, VALID CHARGEBACK. Trong file hiện tại,
CHECK SALE là cột U; loader tìm theo header. TERMOWNER dùng đặt tên PI. NGAY GD có
format YYYYMMDD. Giữ invoice/QT/GUID/PAN như text, không chuyển qua số thực khi nhập CSV.

Mapping chính thức là input.txt, thường ở một đường dẫn cố định, có dạng `GUID|PAN`,
một dòng mỗi GUID, PAN 12–19 chữ số. Thiếu mapping hoặc GUID trùng mà PAN khác nhau
phải dừng, không chọn tùy ý một bản. Dashboard snapshot file này theo lineage của
lượt GUID2PAN, không coi path cố định là bằng chứng nó thuộc cùng lượt FC. File
đã bị ghi đè sau lượt chuyển đổi phải chờ cặp mới phù hợp.

Dashboard chọn FC mới nhất thành công trong ngày và GUID2PAN liên quan: ưu tiên
source_fc_run_id, hoặc cửa sổ trigger của FC kèm cùng đường dẫn input đã khai báo.
Cửa sổ không đủ phân biệt nhiều run phải báo ambiguous. Không ghép hai output
độc lập chỉ vì mtime mới nhất.

Snapshot tại `VROL/runtime/ops_inputs/<bundle_id>/` chứa workbook phân loại,
input.txt mapping và manifest.json. Manifest schema `vrol-input/1`, status READY,
business_date, source_fc_run_id/source_guid2pan_run_id, source_fc_completed_at,
source_guid2pan_completed_at và path/size/SHA256 từng file.
Sau công bố, sửa upstream không thay đổi snapshot đã chọn. Bot kiểm tra đúng ngày,
file nằm trong bundle, size/hash và mapping coverage trước khi mở Visa. Không sửa
date/hash để ép dùng bundle cũ; chạy manual với file overrides khi cần phục hồi đã xác nhận.

### 3.2 Thứ tự filter và xử lý

1. Chỉ dòng CHECK SALE=SALE, VALID CHARGEBACK=Y, đủ định danh, code hợp lệ vào queue.
   HOLD/REVERT/CANCEL/trống có lý do loại. GUID chỉ dùng các dòng còn đủ điều kiện.
2. ROL500 preflight đánh dấu already chargeback; bất kỳ dòng eligible nào của GUID
   có flag này thì loại cả GUID. PAN đầu 5 bị loại trước Transaction Inquiry.
3. Lọc tuổi `15 < age < 120` theo ngày chạy tại Việt Nam. Dòng quá trẻ/cũ/lỗi ngày
   được ghi lý do; GUID còn dòng hợp lệ vẫn xử lý những dòng đó.
4. Completion registry và review hold chặn replay công việc hoàn tất/side effect
   chưa rõ. Resume không tự xóa trạng thái này.
5. Query PAN/ngày đầu nhỏ nhất còn lại; filter invoice, kiểm tra schema và row identity.
6. Quét PI cho mọi invoice trước các veto. PI=Yes trên VROL phải tải chứng từ và
   không đi Issuer Action cho GUID đó; không thay quan sát VROL bằng cột PI Excel.
7. Không có PI: áp dụng veto rồi chọn financial row duy nhất. Chỉ xét transaction
   khớp invoice; không chặn vì giao dịch không liên quan của cùng thẻ.

| CODE CB | Financial row | Veto khi không có PI | Questionnaire |
|---|---|---|---|
| 10.4 | Sale/Sale-WT duy nhất | Credit; Assoc D; ECI blank/5/6 | Fraud card absent, FT6 |
| 13.1 | Sale/Sale-WT duy nhất | Credit; Assoc D | Consumer, DisputeDueTo NR, WhatWasNotReceived S |
| 13.9 | Cash duy nhất | Cash Rev; Assoc D | Consumer, DisputeDueTo CL, WhatWasNotReceived C |

Veto theo thứ tự refund, duplicate, ECI, giữ lý do cụ thể. ECI chỉ chặn 10.4.
Không có Sale/Cash phù hợp thì NO_CB sau bước PI; nhiều row phù hợp thì review,
không chọn row đầu. Không tìm được invoice vì VROL chỉ trả 300 giao dịch là review,
không kết luận không có Sale/PI. Một GUID trộn code, kể cả 13.1 với 13.9, không
được chọn một preset chung. Dữ liệu/schema không xác nhận được phải dừng để review.

## 4. Popup, questionnaire và concurrency

Registry được cài trước action. Page.on(popup) gán child cùng worker; context.on(page)
theo opener() để giải quyết chuỗi con. Không chọn context.pages[-1], không gán owner
bằng title/URL. Page không có owner xác nhận được không được dùng cho worker khác.

Named window/form targets của site legacy có thể tái dùng cửa sổ. popup_scope.py
cài init script namespace target theo worker/UUID, giữ iframe target hiện hữu và
_self/_parent/_top. Window.open, form submit và anchor target là các đường đã xử lý.
Đây không phải cơ chế cô lập browser hoàn chỉnh; site đổi cách mở popup cần thêm test.

### 4.1 Identity và thứ tự thao tác

Code luôn lấy từ Excel. Hai Consumer code có cùng heading nhưng preset khác nhau;
config đổi NR của 13.1 sang CL hoặc ngược lại bị từ chối. Trước fill, sau fill và
trước Final phải kiểm tra:

- Heading/condition/fields đúng nhánh Fraud hoặc Consumer theo code.
- Tran ID trong Transaction Information khớp invoice; leading zero và lifecycle
  suffix dùng quy tắc đã xác nhận trong src/vrol/transaction_table.py.
- ROL ổn định qua prepare/maximize/reacquire frame.
- BIN 6 số và last4 của thẻ masked khớp PAN của GUID.
- Tran Date khớp financial row đã chọn trên VROL; không mặc định dùng ngày auth Excel.

Mismatch dừng và chụp evidence, không đổi code theo popup nhìn thấy. Final_submit.py
có callback tái kiểm tra identity sau ảnh trước-submit, ngay trước dispatch/click,
để không bỏ qua document đổi trong các await. Native viewport/maximize trước fill
và capture questionnaire; không maximize mọi popup PI/menu.

### 4.2 Các khóa cần giữ

| Cơ chế | Mục đích |
|---|---|
| OS RunLock runtime/vrol_process.lock | Một tiến trình dùng profile/registry tại một thời điểm |
| Session gate/lease | Không thay context khi worker còn thao tác case |
| Login lock theo generation | Worker cùng hết phiên chỉ relogin một lần |
| tab_lock | Tạo/reopen worker tab qua Visa Access có dùng focus |
| Event queue + một Excel writer | Không sửa workbook đồng thời |

Native không giữ global popup mutex xuyên suốt PI/case. Không xóa mọi lock để tăng
concurrency. async_popup_concurrency/semaphore còn trong runner không phải worker count;
đọc call path native/legacy trước khi kết luận action bị serialize.

### 4.3 Đánh giá bài viết popup race condition

[Bài The Testing Academy](https://app.thetestingacademy.com/blog/playwright-multiple-tabs-popup-race-condition#fix-the-playwright-multiple-tabs-popup-race-condition-step-by-step)
hữu ích để gợi ý kiểm tra event, opener, identity. Nội dung render khi rà soát không
có phần step-by-step theo fragment này; ví dụ code chỉ click Submit và kiểm tra
result, chưa minh họa bắt popup hoặc test race. Nó định hướng việc review nhưng
không chứng minh implementation đã đúng.

[Playwright Pages](https://playwright.dev/python/docs/pages#handling-popups) giải thích
scope popup event và đăng ký chờ trước action. Registry dùng listener thường trực
để đáp ứng cùng yêu cầu khi action có nhiều nhánh popup.
[MDN Window.open](https://developer.mozilla.org/en-US/docs/Web/API/Window/open#reuse_existing_windows_and_avoid_target_blank)
giải thích named target có thể tái dùng cửa sổ. Vì vậy chỉ expect_popup chưa đủ;
cần guard identity, cleanup và kiểm thử riêng của dự án.

## 5. Cài đặt lần đầu, hai project độc lập

Visa và Dashboard có thể nằm ở hai ổ/thư mục khác nhau, mỗi project có install.cmd,
configure_paths.cmd và .venv riêng. Không cần thư mục deployment/root monorepo để
khởi chạy. Bản ZIP cũng đặt tài liệu kỹ thuật trong từng project.

Ví dụ copy project Visa vào D:\Bots\Visa, Dashboard vào C:\Apps\RPAOps. Chạy CMD:

```bat
cd /d D:\Bots\Visa
install.cmd
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --workers 5

cd /d C:\Apps\RPAOps
install.cmd
configure_paths.cmd --non-interactive --visa-root "D:\Bots\Visa" --fc-root "D:\Bots\FC" --guid2pan-root "D:\Bots\GUID2PAN" --reports-dir "D:\RPAReports"
run_server.cmd
```

Configure Visa tạo config.xlsx từ sample nếu thiếu, backup config.before_paths.xlsx,
đổi paths/workers/restart và giữ credentials/công tắc Final Submit hiện có. Configure
Dashboard chỉ ghi DB của chính nó, không sửa workbook Visa. Nếu cần contract ở
folder chung khác, truyền cùng --contract-dir vào cả hai configure; Dashboard lưu
VROL_INPUT_CONTRACT_DIR, Visa lưu scheduled_contract_dir. Mặc định cả hai dùng
<visa-root>\runtime\ops_inputs. Tài khoản Windows chạy hai bên phải đọc/ghi được folder.

Khi tiếp tục dữ liệu của đợt kiểm thử, import state bằng lệnh trong root Visa:

```bat
configure_paths.cmd --otp-dir "D:\Secrets\VisaOTP" --migration-state-dir "D:\Handoff\migration_state"
```

Registry được hợp nhất, hold đã có không bị ghi đè. Với deployment mới dùng bộ dữ
liệu khác, cân nhắc state tương ứng trước khi import. Các wrapper root install_all.cmd,
configure_paths.cmd và start_dashboard.cmd vẫn là lựa chọn tiện khi giữ nguyên bundle
cạnh nhau; không phải phụ thuộc runtime giữa hai project. Không cần PowerShell.

Nhập username/password trong config.xlsx; SecurityQuestions cột B là answer và
cột C bật YES cho câu cần dùng. Mẫu không có credentials/answers/profile/OTP thật.
Không có root upstream thật thì chờ input, không tạo input giả để vượt kiểm tra.
Các bot CMS/T24 ngoài gói cần chỉnh root ở Settings nếu được triển khai.

Dashboard mặc định http://127.0.0.1:8765/#/bot/vrol_master. Đổi HOST/PORT cần restart.
App có quyền mở file/khởi chạy bot trên Windows và chưa có đăng nhập web riêng;
giữ localhost hoặc kiểm soát truy cập trước khi mở ra mạng. Chrome headful cần
Windows interactive session; Task Scheduler nên chạy khi user đã đăng nhập.

## 6. Config bot

Settings là key/value; loader đọc thêm RunSettings để tương thích. Key trùng thường
bị RunSettings đọc sau ghi đè, riêng allow_final_submit của Settings được ưu tiên.
Tránh tạo duplicate key giữa các sheet.

| Key | Mẫu/fallback | Ý nghĩa |
|---|---|---|
| async_backend | native_async ở launcher production | Không dùng CDP bridge cho luồng chính |
| async_worker_count | Sample/configure 5; thiếu key fallback 3 | Số workers |
| async_worker_max | 5 | CLI cao hơn bị cap |
| async_restart_after_guids | 100 sau configure | Drain/restart context sau mốc lease GUID |
| allow_final_submit | NO | YES còn chịu CLI override |
| trace_enabled | **NO** | Tắt legacy trace; native hiện không start/stop trace |
| user_data_dir | browser_profile tại root Visa | Persistent session, không dùng chung hai tiến trình |
| classified_case_file, batch_test_classified_file | Workbook input | Manual fallback source |
| async_enriched_workbook | Trống | Nếu có được ưu tiên trong resolver source |
| guid_pan_mapping_file, batch_test_guid_pan_mapping_file | input.txt | Manual mapping, có CLI/contract override |
| case_reviewed_guid_file | reviewed_guids.txt | Persistent completion registry |
| rol500_preflight_enabled / rol500_postflight_enabled | YES / YES | Báo cáo trước và sau workers |
| otp_polling_mode / otp_folder_path | FOLDER / inbox đã cấu hình | OTP provider |
| otp_poll_interval_seconds / otp_timeout_seconds | Nếu thiếu: 3s / 90s | Workbook có giá trị thì dùng giá trị đó |
| questionnaire_maximize_before_capture | Thiếu: YES | Maximize capture |
| async_excel_flush_case_count | Thiếu: 20 | Số kết quả giữa các lần save workbook |
| scheduled_contract_dir | runtime\ops_inputs, relative root config | Folder contract READY được producer xuất |
| scheduled_source_not_before | 19:30 | Cả FC và GUID2PAN hoàn tất sau mốc này trong ngày Việt Nam |
| scheduled_input_wait_seconds | 1800 | Chờ contract tối đa trước login |
| scheduled_input_poll_seconds | 10 | Khoảng kiểm tra contract |
| final_submit_reacquire_timeout_ms | Fallback 15000 | Chờ đúng nút Submit |
| final_submit_outcome_timeout_ms | Fallback 30000 | Chờ xác nhận/reject/form error sau click |

Không trộn --input-contract với --source-workbook/--mapping-file. Dashboard cấp
RPA_OPS_SELECTED_INPUT cho CMD; manual full launcher xóa biến này để không lấy input
của lần dashboard trước. Trace tắt không tắt log/ảnh native. Switch screenshot
legacy không phải master switch cho mọi ảnh native. Đổi YES hiện chưa bật tracing
native; bổ sung feature đó cần lifecycle/segmentation riêng.

## 7. Settings Dashboard và API

Settings lưu ở data/rpa_ops.db, không nằm trong config.xlsx. Configure ghi root
FC/GUID2PAN/VROL, report output và server settings; không dùng seed path máy cũ
trong db.py như cấu hình production thật.

| Setting | Sau configure/default | Tác dụng |
|---|---|---|
| SERVER_HOST / SERVER_PORT | 127.0.0.1 / 8765 | Waitress bind, restart để đổi |
| CRAWL_INTERVAL_MINUTES | 2 từ DB defaults | Collector chung |
| VROL_GUID_POLL_SECONDS | 5, API clamp 2–300 | Poll riêng view VROL |
| VROL_INPUT_CONTRACT_DIR | Trống: <visa-root>/runtime/ops_inputs | Folder producer công bố bundle; khớp scheduled_contract_dir |
| STATIC_REPORT_ENABLED | TRUE | HTML và pack PI/ảnh |
| STATIC_REPORT_OUTPUT_DIR | Path đã nhập | Output chia sẻ |
| RETENTION_DRY_RUN | TRUE | Chế độ dry run quản lý retention |

| Endpoint | Chức năng |
|---|---|
| GET /api/status | Snapshot collector |
| GET /api/vrol/live | Parse run VROL mới nhất và poll interval |
| POST /api/refresh | Collect lại |
| GET/POST /api/settings | Đọc/sửa settings |
| POST /api/bots/<bid> | Sửa root/command bot |
| POST /api/retry/vrol_master | Chạy CMD với input manifest được phép |
| POST /api/vrol/guid-request/preview | Preview danh sách GUID; code lấy từ workbook |
| POST /api/vrol/guid-request | Lưu GUID-only request, chạy process riêng |
| POST /api/vrol/checks | Kiểm tra config/input chỉ đọc; kết quả che credentials/PAN/OTP/GUID |
| GET /api/bots/<bid>/runs/<rid>/log | Log theo offset/limit |

Retry route kiểm tra command thuộc root, input trong handoff hợp lệ và chưa có
run VROL hoạt động. Đây là chạy run mới có registry protection, không phải gửi lại
request Visa timeout. Route mở file là thao tác local trên máy server; khi sửa
route phải giữ path scope validation.

## 8. Khởi chạy và OTP

Chạy từ root Visa trừ khi ghi khác. File CMD dùng Python của .venv.

| CMD | Hành vi |
|---|---|
| run_full_5_workers.cmd | Full manual với cặp root input, Final theo config |
| run_async_parallel_case_review.cmd | Queue theo config/CLI |
| run_vrol_from_ops.cmd "C:\...\manifest.json" | Cặp input do Dashboard đóng băng |
| run_scheduled.cmd | Chờ contract ca tối, Final theo config; không tự ép pre-submit |
| run_async_case_test.cmd --guid EXAMPLE_GUID | Diagnostic ép pre-submit |
| run_async_native_test.cmd | Diagnostic giới hạn, PI-only |
| resume_5_workers.cmd RUN_DIR ENRICHED_WORKBOOK MAPPING_FILE | Unfinished/review của queue cũ, ép pre-submit, dùng lại preflight |
| run_review_retry_5_workers.cmd --source-workbook FILE --mapping-file FILE --guid GUID | Retry đích tường minh, hold vẫn bảo vệ, ép pre-submit |
| run_guid_markers.cmd "C:\...\run_id" | Rebuild markers/index offline |
| run_offline_tests.cmd | Regression offline, có Chrome headless local |

--inquiry-only dừng trước PI/case. --pi-only tải PI nhưng không tạo case mới; hai
mode loại trừ nhau. --pre-submit-only luôn thắng config YES. --workers override
trong cap; --limit-groups giới hạn queue. --skip-rol500 chỉ dùng enriched input
đã xác nhận phù hợp đợt chạy; --skip-postflight chỉ dành diagnostic.

Khi Visa yêu cầu MFA, console in folder và WAITING_OTP. Provider lấy baseline trước
request và chỉ đọc dữ liệu mới theo policy. Đưa file OTP mới vào folder lúc được
yêu cầu, không dùng file cũ. Trusted session có thể bỏ qua OTP cùng ngày; không
giả định điều đó với profile mới hoặc phiên đã bị Visa thu hồi.

Mẫu dùng otp_polling_mode=FOLDER_FILENAME, otp_folder_file_pattern=*.txt,
otp_min_digits=otp_max_digits=8, poll 5 giây, timeout 180 giây. Ví dụ minh họa
(thay số bằng OTP thực): tạo file mới `YYYYMMDD_HHMMSS_12345678.txt` sau khi console
yêu cầu OTP. Provider ưu tiên cụm số cuối filename; nếu không có thì đọc nội dung
như `OTP: 12345678`. Không dùng file có nhiều mã không rõ nghĩa. File phải mới/thay
đổi so với baseline và mtime thuộc khoảng sau request; copy file cũ giữ nguyên mtime
có thể bị bỏ qua. Thay độ dài trong config nếu cơ chế OTP của môi trường khác mẫu.

### 8.1 Lịch 19:30 → 19:35/19:40

Ca upstream lúc 19:30 xuất file 09 và input.txt; Dashboard collector ghép lineage,
kiểm tra mapping, snapshot và công bố manifest READY. Task VROL nên đặt 19:40
(19:35 cũng được) với action run_scheduled.cmd, Start in là root Visa, chọn Run only
when user is logged on để Chrome headful/OTP hoạt động. Dùng Task Scheduler GUI;
gói không tự tạo task đẩy case.

Thiết lập task trong GUI bằng Create Task:

| Trường | Ví dụ |
|---|---|
| General | Đúng Windows user giữ Chrome profile; Run only when user is logged on |
| Trigger | Daily, 19:40 (hoặc 19:35) |
| Action: Program/script | C:\Windows\System32\cmd.exe |
| Action: Add arguments | /d /c ""D:\Bots\Visa\run_scheduled.cmd"" |
| Action: Start in | D:\Bots\Visa, không thêm dấu nháy |
| If task is already running | Do not start a new instance |
| Stop task if it runs longer than | Tắt hoặc đặt đủ dài cho full run; không cắt giữa case |

Giữ Dashboard đang collect trước khi upstream xong. Lần đầu dùng Run của Task
Scheduler với Final NO, quan sát CMD/OTP và kiểm tra run_state/console.log. Không
đặt restart-on-failure để gửi lặp; lỗi sau case side effect phải xem hold/reconcile.
Dashboard có run_server.cmd riêng; install_startup_task.cmd của Dashboard chỉ khởi
động server, không thay task run_scheduled.cmd của Visa.

Launcher lấy process lock và tạo heartbeat/run_state trước khi đợi, stage WAITING_INPUT.
Nó chỉ chọn bundle hôm nay có cả hai source completion >=19:30, kiểm tra size/hash,
mapping coverage, rồi mới login. Không chọn hai raw file mới nhất. Manifest cũ thiếu
source completion vẫn dùng manual được, không đủ điều kiện cho lịch tối. Nếu bundle
mới nhất hợp lệ về lịch bị hỏng, chờ sửa producer rồi timeout; không lùi về input cũ.
Hết 1800 giây chưa READY thì run FAILED/SCHEDULED_INPUT_TIMEOUT, chưa mở Visa.

Dashboard phải collect để xuất contract, có thể chậm tới CRAWL_INTERVAL_MINUTES.
Sau khi contract đã công bố, VROL đọc file trực tiếp; không phụ thuộc HTTP server
đang mở. Một run giữ nguyên snapshot đã chọn dù upstream công bố bundle tiếp theo.
Dashboard restart chỉ ảnh hưởng màn hình tiến độ/publish tiếp, không dừng bot đang chạy.

### 8.2 Chạy riêng theo danh sách GUID

Vào VROL Dashboard, chọn contract READY, nhập GUID vào phần Chạy riêng theo GUID,
bấm preview/xác nhận. Bot tự lấy code/invoice/QT/ngày/merchant từ file 09 và PAN từ
input.txt trong snapshot, không có trường đổi code. API lẫn consumer từ chối schema
có code override. Chỉ mode này bỏ điều kiện VALID CHARGEBACK=Y upstream, ví dụ nhóm
hơn 35 giao dịch đã bị upstream loại. Luồng thường/scheduled giữ filter Y.

Mode này vẫn đi cả PI/case theo code trong Excel, không mặc định PI-only. Giữ SALE,
15<age<120, định danh/code/mapping, ROL500/registry/hold và veto runtime. Không tạo
lại case cũ. Các GUID/dòng chưa đủ điều kiện được ghi lý do, không âm thầm mất khỏi
request. User không cần đánh dấu cột hoặc sửa workbook upstream.

Mỗi yêu cầu tạo runtime/guid_requests/<request_id>.json dưới Visa, bind path/hash
manifest, chỉ có GUID list và metadata request. Runner dùng env RPA_OPS_GUID_REQUEST
hoặc --guid-request, ghi request_mode USER_SELECTED_GUIDS trong run_state. Request
không trộn với scheduled/replay overrides. Run riêng có Excel/PI/evidence/postflight
và requested_guid_report.csv/json: mỗi GUID có code gốc, kết quả/lý do loại,
upstream filter override, số PI, ROL/Final flag và folder. Báo cáo tạo trong finally
kể cả run lỗi sau khi đọc request; Dashboard Output có link. Chi tiết tại
rpa_ops-dashboard-v0.13.4/docs/USER_SELECTED_GUID_RUN.md.

### 8.3 Nút kiểm tra cấu hình và đầu vào

Trong box VROL, bấm Kiểm tra cấu hình & đầu vào. API chỉ đọc config/input, không
collect/publish thêm contract, không login, không khởi chạy bot và không gửi case.
Nếu đã chọn contract trên Dashboard thì kiểm tra đúng cặp snapshot/hash hôm nay;
contract lỗi không fallback sang cặp manual để kết luận PASS. Nếu chưa có READY,
kiểm tra source/mapping paths trong config và báo rõ đang ở CONFIG mode.

Kết quả gồm launcher/venv, workbook config, các trường login đã điền hay chưa,
security questions enabled count, workers/cap, Final switch Settings authoritative,
trace, OTP folder, ROL500 flags, schema file 09, mapping format/conflict/coverage,
FULL PAN consistency nếu có và thống kê tuổi/ngày. Không trả về giá trị credentials,
OTP, PAN, GUID hay dòng mapping lỗi. PASS/WARN/FAIL là kiểm tra tĩnh tại thời điểm
đó, không chứng minh đăng nhập hoặc Visa sẽ chấp nhận Final Submit.

## 9. Chạy có Final Submit

Đặt allow_final_submit=YES trong Settings, dùng run_scheduled.cmd, run_full_5_workers.cmd hoặc Dashboard
launcher thường. Không dùng launcher diagnostic/resume ép --pre-submit-only. Key
Settings Final là authoritative, không phải đổi cả key legacy RunSettings.

Luồng: Case Creation Submit → identity → maximize → fill theo code → recheck/capture
→ identity sát dispatch → exact Submit → checkpoint và quan sát confirmation/reject/
form error → ảnh kết quả. Xem 06_before_final_submit.png, 07_final_submit_result.png
và checkpoint, không chỉ dựa vào một tên ảnh.

Trong các questionnaire thực đã probe, nút exact
`button[ng-click="trigger(Buttons.SUBMIT,true)"]` có found=true, visible=true,
clicked=false. Bản triển khai dùng chung questionnaire_submit.py cho probe và
dispatch: đúng text Submit, đúng một nút visible, enabled; không dựa vào nút Submit
chung của Case Creation. Read-only probe không click. Sau fill phải dispatch_ready;
thiếu/trùng/disabled thì dừng review. Không bắt buộc ng-show attribute chưa được
probe như một điều kiện thêm khác với selector thực đã quan sát.

Sau click chỉ đọc page/frame thuộc chain worker. Chờ DOMContentLoaded, layout ổn
định, hết aria-busy/loading-spinner và body text ổn định; nếu nội dung thay đổi thì
phân loại lại trước chụp. Các trạng thái FINAL_SUBMIT_COMPLETED, REJECTED, FORM_ERROR
được ghi riêng. Kết quả chưa nhận dạng trước deadline là RECONCILIATION_REQUIRED,
chụp các owned page còn lại và giữ hold. Không bấm lại vì timeout. Loading của site
đổi markup hoặc nội dung kết quả mới cần cập nhật detector/test; không chờ networkidle
vô hạn trên ứng dụng có background requests.

Case Creation Submit đã có thể tạo ROL trước Final. Pre-submit test vẫn có side
effect trên Visa. Draft đã tạo vào registry; bật YES không tự mở/gửi draft cũ.
Chưa có workflow tự lookup case cũ theo ROL rồi phục hồi toàn bộ questionnaire để
gửi; phải review đúng case hiện có trước khi tiếp tục.

Chưa xác nhận answers lưu server chỉ nhờ fill rồi đóng popup. Bot không bấm Save
như thay thế ngầm. Ảnh filled không chứng minh answers persisted/đã gửi. Final Submit
chưa được E2E gửi thật; cần UAT có kiểm soát. Timeout sau dispatch giữ hold, không
retry click. Flag final_submit_clicked=false tại stage DISPATCHING không chứng minh
request chưa tới Visa; cần xét cả stage và bằng chứng.

## 10. Resume, retry và OOM

| Tình huống | Chính sách |
|---|---|
| Crash/OOM trước side effect | Deadline hữu hạn, tối đa một retry read-only trên tab mới |
| PI download lỗi | Hai lần tối đa; mở lại owned details, kiểm tra lại identity; lần hai download timeout ít nhất 60s |
| Hết phiên trước case side effect | Drain/relogin chung theo generation rồi retry GUID |
| Đã Issuer Action/Case Creation, có ROL hoặc dispatch chưa rõ | Hold/reconcile; không tự tạo lại case |
| ROL-749 | Ảnh, OK một lần, đợi warning cũ rời trang rồi tiếp tục owned chain |
| Associated Transactions | Lưu trạng thái/ROL/ảnh, đóng chain, không submit screen này |
| ROL-1537 | Review, cần dispute từng giao dịch; chưa tự tách GUID |
| ROL-1545 | Duplicate selected transaction, review có evidence |
| Không unique Sale/Cash | Review, không chọn tùy ý |
| Invoice ngoài first-300 results | Review, chưa kết luận NO_CB/không PI |
| Final Submit timeout | Giữ checkpoint/hold, tra case/report trước thao tác tiếp |

reviewed_guids.txt chứa GUID và/hoặc stable key GUID|invoice|QT|code. COMPLETED của
bot gồm cả questionnaire filled/pre-submit. runtime/review_holds/<GUID>.json chặn
side effect chưa giải quyết, seed từ run cũ. Không xóa hàng loạt hoặc đổi disposition
chỉ để ép replay; xác minh case rồi mới release hold.

--review-existing query hold để phân loại/tải PI; còn eligible tạo case thì trả
CASE_RECONCILIATION_REQUIRED. --no-resume bỏ completion registry nhưng không bỏ hold;
đi cùng review-existing phải có --guid. --recheck-read-only chỉ mở lại PI/no-CB đã
biết không có lịch sử side effect. Các flag không chứng minh request trước chưa được xử lý.

Mỗi lượt engine có budget min(1800, 180 + 45 × số invoice) giây. Tab thay sau 25 GUID
mỗi worker. Mốc 100 lease chặn nhận mới, chờ active cases xong rồi đóng context/
relogin, không đóng giữa questionnaire. Preflight nằm ngoài vòng replace session,
không tải lại mỗi 100 GUID. RunLock do OS giữ; file còn tồn tại không tự có nghĩa
process còn chạy. Không xóa file lock để vượt tiến trình sống.

## 11. Output và ROL500

```text
runtime/async_parallel/<run_id>/
  run_state.json                      PID, stage, status, heartbeat
  queue_manifest.json                 GUID, code, source rows
  input_exclusions.json                Lý do loại dòng
  activity_report.jsonl                CASE_ASSIGNED/CASE_RESULT
  console.log, run.log
  09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx
  groups/<OUTCOME>_<GUID>/
    guid_result.json, group_result.json, case_checkpoint.json
    __REVIEW_REQUIRED__.txt            Marker theo outcome
    documents/<invoice>_<last4>_<termowner>.pdf
    pi_manifest.json
    *.png                             Ảnh kết quả/questionnaire có code
  documents/                          PI aggregate
  postflight/ROL500.csv
  postflight/rol500_reconciliation.csv
  async_summary.json
```

Folder outcome: PI_DOWNLOADED, NO_CB, FRAUD, CONSUMER, REVIEW_REQUIRED. FRAUD/CONSUMER
pre-submit không có nghĩa đã gửi. needs_user_review còn gồm draft; review_required_count
là nhóm REVIEW_REQUIRED riêng. UI hiển thị tách hai số.

PI phải là PDF có nội dung và primary Tran ID phù hợp, không chỉ thấy ID trong
associated section. Metadata có hash/size/pages/identity proof. Atomic publish vào
GUID và aggregate, không ghi đè cùng filename khác hash. TERMOWNER bỏ ký tự Windows
không hợp lệ, không bỏ leading zero invoice hoặc last4.

Postflight tải ROL500 mới sau workers, match invoice/Tran ID và dùng QT để thu hẹp.
QT-only không xác nhận invoice thì conflict; nhiều ROL thì ambiguous. Giữ ROL quan
sát trực tiếp nếu report chưa có, không đồng nhất report presence với Final Submit.
Preflight còn dùng enrichment chung với sync, không hoàn toàn cùng matcher với
postflight nghiêm hơn; sửa matcher phải kiểm thử cả hai.

ROL-189 có thể làm To Date được điều chỉnh; đọc parameters from/to thực tế trong
result. Không khẳng định report bao phủ ngày local mong muốn nếu Visa không nhận.
Đợt gần nhất chấp nhận 17–19/11/2026. Các dòng chỉ khớp QT cần review riêng trong Excel.

Live parser đọc filesystem, không truy vấn Visa để đoán progress. Phân biệt PID
dừng thiếu summary với completed. Heartbeat 5s chịu lỗi file replace tạm thời;
giữ journal/checkpoint khi OneDrive/Excel khóa file.

deployment/consolidate_run.py giữ raw evidence và gộp kết quả mới nhất theo GUID.
consolidated chứa REPORT.md, workbook cuối, review_required.csv, pi_documents.csv,
documents và danh sách registry-only. Snapshot gần nhất: 1.116 GUID có kết quả,
87 review, 68 draft, 338 PDF; thêm 29 registry-only. Đây không phải hằng số cho run sau.

HTML chia sẻ ở STATIC_REPORT_OUTPUT_DIR/vrol/<run_id>/index.html. Pack chỉ copy
PI/ảnh/index được phép, không mapping/config/profile/OTP. Khi gộp, chỉ cho phép ảnh
từ các run khai báo trong lineage cùng runtime root, không nới path ra ngoài.

## 12. Kiểm thử và phát triển

Visa: run_offline_tests.cmd. Tests dùng HTML giả/Chrome headless local, không gọi
Visa/OTP. Có snapshot fixture sync để không phụ thuộc project sync ngoài gói.
Dashboard từ root project:

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -p test_vrol_integration.py -q
```

Sửa popup/selector: test_popup_recovery.py, test_native_ui.py, test_native_runtime.py,
test_final_identity_boundary.py, test_final_submit_settling.py. Sửa luật: test_native_sync_rules.py, ghi rõ override
khác sync. Sửa ROL500: test_postflight.py. Sửa handoff/API/parser/export: dashboard integration.

Test có 5 chuỗi named popup/form con đồng thời, foreign-owner reject, mismatch
code/invoice/card/date, ROL stability, ROL-749 transition, file-lock heartbeat,
drain/restart, snapshot bảng 500 rows, PI hash/identity/collision, SALE/age filter,
QT conflict, paired snapshot và shared pack không copy ngoài phạm vi. Test mới đổi
invoice sau capture trước Final và xác nhận nút không được click.
Regression còn kiểm tra exact Submit dùng chung probe/dispatch, duplicate visible
Submit bị chặn, delayed result chỉ chụp sau render, input.txt snapshot → contract
→ consumer, lịch tối bỏ morning bundle, không fallback nếu newest snapshot hỏng,
WAITING_INPUT/timeout trước login và contract đến trễ. Sửa lịch: test_scheduled_input.py.
Sửa chạy GUID riêng: test_guid_request.py và Dashboard integration. Tests nhóm 36
row upstream N, giữ code trong Excel và SALE/age/ROL/registry/mapping guards,
request code override/hash đổi bị chặn, báo cáo có completed/skipped/unfinished.

Thêm dispute code cần sửa validation/schema, precheck/veto, action mapping, preset,
identity, outcome và tests. Không suy preset từ Consumer heading. Site đổi DOM cần
contract/fixture đã kiểm tra và ẩn danh; không commit HTML có dữ liệu thật.

Chưa chứng minh E2E gửi thật Final Submit, answers persisted lúc đóng popup, resume
tự động questionnaire cũ hay mọi popup biến thể tương lai. Native dùng auth context
chung, không context riêng từng worker; identity guard vẫn bắt buộc trước mọi submit.

## 13. Build, nâng cấp và rollback

Tại root repository sau khi cài dependencies:

```bat
build_production.cmd "C:\RPA\VisaOps\vr9.1.13.16\runtime\async_parallel\COMPLETED_RUN"
build_production.cmd "C:\RPA\VisaOps\vr9.1.13.16\runtime\async_parallel\COMPLETED_RUN" --source-only
```

Builder copy file Git track ở working tree; commit/kiểm tra trạng thái trước build
để manifest commit khớp source. Có SHA256SUMS, checksum ZIP, release manifest.
Credentials/answers trong sample phải trống và trace tắt, nếu không build thất bại.

| Gói | Mục đích | Kèm dữ liệu |
|---|---|---|
| Production | Cài production sạch | Không registry/GUID/hold/input/report vận hành |
| Source_GitHub | Source sạch để đưa lên Git | Không migration state hoặc operational report |
| Private_Handoff, chỉ khi --include-migration-state | Chuyển state nội bộ riêng | GUID/ROL registry, hold và validation report thực; không public |

ZIP mặc định không chứa state vận hành. Root configure import migration state nếu
operator đã chuyển riêng folder này vào bundle; Visa configure độc lập chỉ
import khi truyền --migration-state-dir. Cả hai không ghi đè hold decision đã có.
Gói source không có state; nếu tiếp tục dữ liệu thật cũ, chuyển state riêng trước
khi chạy. Git clone không phải backup đầy đủ của run ngân hàng.

Nâng cấp: đợi run dừng, backup config/DB/registry/holds/artifacts, giải nén version
mới, cài dependencies, chuyển state/config có kiểm soát, configure paths và thử
pre-submit subset. Không ghi đè profile/process đang chạy. Rollback source không
rollback case Visa; giữ registry/holds phát sinh và đối chiếu trước khi chạy lại.

## 14. GitHub và dữ liệu vận hành

Repository nguồn: https://github.com/ndthanh/vr.git. .gitignore
chỉ cho phép workbook mẫu sạch, loại config thật/input/runtime/profile/OTP/DB/report/
ZIP/migration state. Không git add -f các file thật.

Workspace Git cũ từng có GUID trong tài liệu. Source hiện đã ẩn danh nhưng commit
sửa không xóa dữ liệu khỏi lịch sử. Để đưa lên repository public, giải nén Source_GitHub
vào thư mục mới không có .git, kiểm tra source/sample rồi thực hiện tại đó:

```bat
git init
git branch -M main
git add .
git diff --cached --stat
git commit -m "Initial source import: VROL async and RPA Ops dashboard"
git remote add origin https://github.com/ndthanh/vr.git
git push -u origin main
```

Đây là hướng dẫn cho chủ repository, không phải deploy tự động. Nếu giữ history
cũ cần xử lý riêng trước khi public. Không rewrite/force-push lịch sử workspace
trong đợt bàn giao này. Gói Private_Handoff có migration data không dùng thay source ZIP.

## 15. Ưu tiên cho người tiếp nhận

1. Cài từ sample trên máy riêng, xác nhận pairing, giữ Final NO và chạy regression.
2. Theo một GUID qua queue/journal/checkpoint/Excel/ảnh/PI manifest; xem module map.
3. Kiểm tra cả ba code với identity đúng/sai; tách test local và test Visa có side effect.
4. Nếu làm resume case cũ, bắt đầu lookup read-only đúng ROL/invoice rồi xác minh
   trước khi sửa/gửi; không giải quyết bằng bỏ registry/hold.
5. Thiết kế truy vấn đủ lịch sử cho thẻ quá 300 results; không thu hẹp ngày làm
   bỏ sót refund/PI để cố giảm review.
6. Muốn tăng trên 5 workers phải đo RAM, popup lifecycle và tải server trước khi
   đổi cap. Một lần chạy thành công không chứng minh mọi biến thể concurrency.
