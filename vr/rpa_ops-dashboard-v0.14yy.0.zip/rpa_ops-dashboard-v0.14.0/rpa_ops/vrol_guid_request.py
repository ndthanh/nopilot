"""Preview GUID-only requests using the frozen pair; never accept a code override."""
import json,re
from pathlib import Path
from openpyxl import load_workbook
from .vrol_handoff import digest,mapping_file

def preview(manifest,raw):
    if isinstance(raw,str):guids=re.split(r'[\s,;]+',raw.strip())
    elif isinstance(raw,list):guids=raw
    else:raise ValueError('GUID_LIST_REQUIRED')
    if not guids or len(guids)>2000 or any(not isinstance(g,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',g) for g in guids):
        raise ValueError('GUID_LIST_INVALID: enter GUIDs only, separated by newlines, commas or spaces')
    guids=sorted({g.upper() for g in guids});manifest=Path(manifest).resolve()
    contract=json.loads(manifest.read_text(encoding='utf-8-sig'))
    if contract.get('schema')!='vrol-input/1' or contract.get('status')!='READY':raise ValueError('INPUT_NOT_READY')
    files={}
    for key in ('workbook','mapping'):
        entry=contract['files'][key];path=Path(entry['path']).resolve()
        if path.parent!=manifest.parent or path.stat().st_size!=entry['size'] or digest(path)!=entry['sha256']:raise ValueError('INPUT_SNAPSHOT_CHANGED')
        files[key]=path
    mapping=mapping_file(files['mapping']);found={};wb=load_workbook(files['workbook'],read_only=True,data_only=True)
    try:
        ws=wb['Sheet1'];headers={str(x or '').strip().upper():i for i,x in enumerate(next(ws.iter_rows(min_row=2,max_row=2,values_only=True)))}
        if not {'GUID','CODE CB','CHECK SALE','VALID CHARGEBACK'}<=headers.keys():raise ValueError('SOURCE_HEADERS_MISSING')
        for row in ws.iter_rows(min_row=4,values_only=True):
            def get(key):return str(row[headers[key]] or '').strip() if headers[key]<len(row) else ''
            guid=get('GUID').upper()
            if guid not in guids:continue
            entry=found.setdefault(guid,dict(row_count=0,codes=set(),upstream_values=set(),sale_values=set()))
            entry['row_count']+=1;entry['codes'].add(get('CODE CB'));entry['upstream_values'].add(get('VALID CHARGEBACK'));entry['sale_values'].add(get('CHECK SALE'))
    finally:wb.close()
    rows=[]
    for guid in guids:
        entry=found.get(guid,{})
        rows.append(dict(guid=guid,found=bool(entry),mapping_available=guid in mapping,row_count=entry.get('row_count',0),
            codes=sorted(entry.get('codes',[])),upstream_values=sorted(entry.get('upstream_values',[])),sale_values=sorted(entry.get('sale_values',[]))))
    return dict(guids=guids,rows=rows,manifest_sha256=digest(manifest),requested_count=len(guids),
                note='CODE CB lấy từ Excel. Chỉ vượt VALID CHARGEBACK upstream; SALE/tuổi/ROL/registry/hold và runtime rules vẫn áp dụng.')
