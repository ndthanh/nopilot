import threading,time,os
from datetime import date
from pathlib import Path
from pathlib import Path
from datetime import datetime
from .db import load
from .utils import atomic
from .parsers.cms_on_hold import parse as cms
from .parsers.t24_timeout import parse as t24
from .parsers.fraud_classification import parse as fraud
from .parsers.guid2pan import parse as guid2pan
from .parsers.vrol_visa import parse as vrol_visa
from .vrol_handoff import publish_pair, VIETNAM
from .operations import enrich
from .contract_publisher import publish_cms_success
from .task_scheduler import list_tasks

def _day(raw,run_id=None,path=None):
 try:return datetime.fromisoformat(str(raw).replace('Z','+00:00')).astimezone().date()
 except:pass
 for text in (str(run_id or ''),str(path or '')):
  import re
  m=re.search(r'(20\d{6})',text)
  if m:
   try:return datetime.strptime(m.group(1),'%Y%m%d').date()
   except:pass
 return None
def _daily_workflow_inputs(bots):
 today=datetime.now(VIETNAM).date();out={}
 chain=[('t24_timeout','cms_on_hold','main_output'),('fraud_classification','t24_timeout','final_output'),('guid2pan','fraud_classification','guid2pan_input')]
 for target,source,key in chain:
  b=bots.get(source) or {};items=[];seen=set();candidates=list(b.get('runs') or [])
  if b.get('latest'):candidates.append(b['latest'])
  for r in candidates:
   res=(r.get('resources') or {}).get(key) or {}
   path=res.get('path') if isinstance(res,dict) else None
   if r.get('status')!='SUCCESS' or not path:continue
   if _day(r.get('completed_at') or r.get('started_at'),r.get('run_id'),path)!=today:continue
   try:exists=Path(path).is_file()
   except:exists=False
   if not exists or path in seen:continue
   seen.add(path);items.append({'source_bot':source,'source_run_id':r.get('run_id'),'resource_key':key,'path':path,'completed_at':r.get('completed_at') or r.get('started_at'),'exists':True})
  # CMS authoritative fallback: discover today's real CSV output directly from CMS root.
  # Do not depend on a particular log event name or `latest_success.json` schema.
  if target=='t24_timeout' and b:
   day=today.strftime('%Y%m%d');root=Path(b.get('root_path') or '');direct=[]
   search_dirs=[root/'output'/day,root/'outputs'/day,root/'output',root/'outputs']
   for folder in search_dirs:
    if not folder.is_dir():continue
    try:direct.extend(folder.rglob('cms-on-hold-export*.csv'))
    except:pass
   # Accept only files belonging to today: YYYYMMDD in path, or file modification date today.
   direct=[q for q in direct if q.is_file() and (day in str(q) or datetime.fromtimestamp(q.stat().st_mtime).astimezone().date()==today)]
   for q in sorted(set(direct),key=lambda x:x.stat().st_mtime,reverse=True):
    qp=str(q.resolve())
    if qp in seen:continue
    seen.add(qp);items.append({'source_bot':source,'source_run_id':'CMS_FILE_'+datetime.fromtimestamp(q.stat().st_mtime).strftime('%Y%m%d_%H%M%S'),'resource_key':'main_output','path':qp,'completed_at':datetime.fromtimestamp(q.stat().st_mtime).astimezone().isoformat(),'exists':True,'discovered_by':'DIRECT_CMS_OUTPUT_SCAN'})
  items.sort(key=lambda x:x.get('completed_at') or '',reverse=True);out[target]=items
 return out


def _normpath(v):return os.path.normcase(os.path.normpath(str(v or '').strip().strip('"')))
def _task_schedules(bots):
 try:tasks=list_tasks()
 except Exception:return {},[]
 mapped={k:[] for k in bots}
 for t in tasks:
  action=' '.join(x for x in (t.get('execute'),t.get('arguments')) if x)
  action_key=_normpath(action);matches=[]
  for bid,b in bots.items():
   root=_normpath(b.get('root_path'));tokens={
    'cms_on_hold':['run_unattended.bat','run_unattended_contract.bat'],
    't24_timeout':['scripts\\run.cmd'],
    'fraud_classification':['script\\run.cmd'],
    'guid2pan':['run_guid2pan.bat'],'vrol_master':['run_vrol_from_ops.cmd','run_async_parallel_case_review.cmd','run_scheduled.cmd']}.get(bid,[])
   if root and root in action_key and any(x.lower().split('\\')[-1] in action.lower() for x in tokens):matches.append(bid)
  if not matches:
   low=action.lower()
   if 'fraud-classification-bot' in low:matches=['fraud_classification']
   elif 't24-timeout' in low and 'run.cmd' in low:matches=['t24_timeout']
   elif 'cms-guid2pan' in low:matches=['guid2pan']
   elif 'run_unattended' in low:matches=['cms_on_hold']
  for bid in matches:
   mapped.setdefault(bid,[]).append({'task_name':t.get('name'),'time':t.get('time'),'status':t.get('status'),'next_run_time':t.get('next_run_time'),'action':action,'source':'TASK_SCHEDULER'})
 for x in mapped.values():x.sort(key=lambda a:(a.get('time') or '',a.get('task_name') or ''))
 return mapped,tasks

P={'cms_on_hold':cms,'t24_timeout':t24,'fraud_classification':fraud,'guid2pan':guid2pan,'vrol_visa':vrol_visa}
class Collector:
 def __init__(self,root):self.root=Path(root);self.db=self.root/'data'/'rpa_ops.db';self.stop=threading.Event();self.error=None;self.collect_lock=threading.RLock()
 def collect(self):
  with self.collect_lock:return self._collect()
 def _collect(self):
  s=load(self.db);bots={}
  for b in s['bots']:
   if not b['enabled']:continue
   try:bots[b['bot_id']]=P[b['parser']](Path(b['root_path']))
   except Exception as e:bots[b['bot_id']]={'display_name':b['display_name'],'root_path':b['root_path'],'runs':[],'latest':{'status':'FAILED','error':str(e),'resources':{},'metrics':{}}}
  if 'cms_on_hold' in bots:
   try:bots['cms_on_hold']['contract_publish']=publish_cms_success(bots['cms_on_hold'])
   except Exception as e:bots['cms_on_hold']['contract_publish']={'status':'ERROR','message':str(e),'published':False}
  schedule_map,scheduled_tasks=_task_schedules(bots)
  for bid,b in bots.items():b['task_schedules']=schedule_map.get(bid,[])
  daily_inputs=_daily_workflow_inputs(bots)
  if 'vrol_master' in bots:
   handoff=publish_pair(bots,Path(bots['vrol_master']['root_path']),contract_dir=s.get('contract_dir') or None)
   bots['vrol_master']['input_handoff']=handoff
   daily_inputs['vrol_master']=handoff['inputs']
  p=enrich({'title':s['title'],'generated_at':datetime.now().astimezone().isoformat(timespec='seconds'),'bots':bots,'workflow_inputs':daily_inputs,'scheduled_tasks':scheduled_tasks,'settings':{'crawl_interval_minutes':s['interval'],'static_enabled':s['static'],'static_output_dir':str(s['static_dir']),'retention_dry_run':s['retention_dry']}});atomic(self.root/'data'/'current_status.json',p)
  if s['static']:from .static_report import render;render(p,s['static_dir'])
  return p
 def loop(self):
  while not self.stop.is_set():
   try:self.collect();self.error=None
   except Exception as e:self.error=str(e)
   self.stop.wait(load(self.db)['interval']*60)
 def start(self):threading.Thread(target=self.loop,daemon=True).start()
