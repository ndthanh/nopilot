"""Read-only local checks. Return counts/booleans, never credentials, PAN or GUID."""
import json,os,re,zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from .vrol_handoff import digest,mapping_file,VIETNAM

def check(root,contract=None):
    root=Path(root).resolve();checks=[]
    def add(name,status,message,**counts):checks.append(dict(name=name,status=status,message=message,**counts))
    def truth(value):return str(value or '').strip().upper() in {'YES','Y','TRUE','1','ON'}
    def path(value,default):
        p=Path(str(value or default)).expanduser();return p.resolve() if p.is_absolute() else (root/p).resolve()
    config=root/'config.xlsx';settings={}
    add('Visa launcher','PASS' if (root/'run_vrol_from_ops.cmd').is_file() else 'FAIL','run_vrol_from_ops.cmd')
    add('Python environment','PASS' if (root/'.venv'/'Scripts'/'python.exe').is_file() else 'FAIL','Cài bằng install.cmd của project Visa')
    try:
        wb=load_workbook(config,read_only=True,data_only=True);primary=None
        try:
            if 'Settings' not in wb.sheetnames:raise ValueError('CONFIG_SETTINGS_SHEET_MISSING')
            for name in ('Settings','RunSettings'):
                if name not in wb.sheetnames:continue
                for row in wb[name].iter_rows(min_row=2,values_only=True):
                    if row and row[0] is not None and len(row)>1:
                        key=str(row[0]).strip();settings[key]=row[1]
                        if name=='Settings' and key=='allow_final_submit':primary=row[1]
            if primary is not None:settings['allow_final_submit']=primary
            answers=sum(bool(len(row)>2 and row[0] and row[1] and truth(row[2])) for row in wb['SecurityQuestions'].iter_rows(min_row=2,values_only=True)) if 'SecurityQuestions' in wb.sheetnames else 0
        finally:wb.close()
        add('Config workbook','PASS','Đọc được config.xlsx; không hiển thị giá trị bí mật')
        complete=all(str(settings.get(k) or '').strip() for k in ('login_url','username','password','welcome_name'))
        add('Login fields','PASS' if complete else 'FAIL','Các trường login bắt buộc đã điền' if complete else 'Kiểm tra login_url, username, password, welcome_name trong config.xlsx')
        add('Security questions','PASS' if answers else 'WARN','Số câu hỏi có answer và enabled',enabled_count=answers)
        # Same resolution as the bot: dashboard overrides (runtime\run_overrides.json) win over config.xlsx.
        from .vrol_run_settings import MAX_WORKERS
        try:overrides=json.loads((root/'runtime'/'run_overrides.json').read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):overrides={}
        workers=int(settings.get('async_worker_count') or 3);cap=int(settings.get('async_worker_max') or 5)
        override_workers=overrides.get('workers') if isinstance(overrides.get('workers'),int) and 1<=overrides['workers']<=MAX_WORKERS else None
        effective=override_workers or min(workers,cap)
        if override_workers:cap=max(cap,override_workers)
        # The bot caps the count itself (min(count, cap)), so count > cap is a warning, not a failure.
        worker_status='FAIL' if workers<1 or cap<1 else ('WARN' if effective>MAX_WORKERS or (workers>cap and not override_workers) else 'PASS')
        add('Workers',worker_status,f'Số worker sẽ dùng: {effective}'+(' (thiết lập dashboard)' if override_workers else ' (config.xlsx)')+f'; đã kiểm chứng tới {MAX_WORKERS}',configured=workers,cap=cap,effective=effective)
        final=overrides.get('final_submit') if overrides.get('final_submit') in {'YES','NO'} else ('YES' if truth(settings.get('allow_final_submit')) else 'NO')
        source=' (thiết lập dashboard)' if overrides.get('final_submit') in {'YES','NO'} else ' (config.xlsx)'
        add('Final Submit','WARN' if final=='YES' else 'PASS',('BẬT: run thường có thể gửi case mới' if final=='YES' else 'TẮT: dừng trước Final Submit')+source)
        add('Trace','WARN' if truth(settings.get('trace_enabled')) else 'PASS','trace_enabled đang bật (native hiện không ghi trace)' if truth(settings.get('trace_enabled')) else 'trace_enabled đã tắt')
        otp=path(settings.get('otp_folder_path'),'OTP/inbox')
        folder_mode=str(settings.get('otp_polling_mode') or '').strip().upper() in {'FOLDER_FILENAME','FOLDER','FILE','FILE_NAME'}
        add('OTP folder','PASS' if folder_mode and otp.is_dir() and os.access(otp,os.R_OK) else 'FAIL','Kiểm tra FOLDER mode và folder tồn tại/đọc được; không đọc nội dung OTP')
        add('ROL500','PASS' if truth(settings.get('rol500_preflight_enabled','YES')) and truth(settings.get('rol500_postflight_enabled','YES')) else 'WARN','Preflight và postflight theo config')
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,InvalidFileException):
        add('Config validation','FAIL','Không đọc được config hoặc giá trị cấu hình sai định dạng; kiểm tra workbook tại máy')
    source=path(settings.get('async_enriched_workbook') or settings.get('batch_test_classified_file') or settings.get('classified_case_file'),'09_chargeback_classified.xlsx')
    mapping=path(settings.get('batch_test_guid_pan_mapping_file') or settings.get('guid_pan_mapping_file'),'input.txt')
    input_mode='CONFIG'
    if contract:
        try:
            manifest=Path(contract).resolve();data=json.loads(manifest.read_text(encoding='utf-8-sig'))
            if data.get('schema')!='vrol-input/1' or data.get('status')!='READY' or data.get('business_date')!=datetime.now(VIETNAM).date().isoformat() or not data.get('source_fc_run_id') or not data.get('source_guid2pan_run_id'):
                raise ValueError('INPUT_CONTRACT_NOT_READY_TODAY')
            files={}
            for key in ('workbook','mapping'):
                entry=data['files'][key];file=Path(entry['path']).resolve()
                if file.parent!=manifest.parent or file.stat().st_size!=entry['size'] or digest(file)!=entry['sha256']:raise ValueError('SNAPSHOT_CHANGED')
                files[key]=file
            source=files['workbook'];mapping=files['mapping'];input_mode='CONTRACT'
            add('Input contract','PASS','READY hôm nay, lineage và snapshot hash hợp lệ')
            if not data.get('source_fc_completed_at') or not data.get('source_guid2pan_completed_at'):
                add('Scheduled contract metadata','WARN','Bundle cũ thiếu source completion; lịch tối cần contract mới do producer công bố')
        except (OSError,ValueError,KeyError,TypeError):
            add('Input contract','FAIL','Contract không hợp lệ/không phải hôm nay hoặc snapshot thay đổi; không dùng fallback để kết luận input hợp lệ')
            return dict(status='FAIL',input_mode='INVALID_CONTRACT',checks=checks)
    else:add('Input contract','WARN','Chưa chọn contract READY; chỉ kiểm tra cặp file manual trong config')
    mapping_data={};all_guids=set();eligible=set();dates=Counter();codes=Counter();rows=0;conflicts=0
    try:
        mapping_data=mapping_file(mapping)
        add('GUID-PAN mapping','PASS','Đọc được input.txt; mỗi dòng GUID|PAN, không có mapping xung đột',mapping_count=len(mapping_data))
    except (OSError,ValueError,UnicodeError):add('GUID-PAN mapping','FAIL','input.txt thiếu hoặc sai định dạng/mapping xung đột; không hiển thị dòng chứa PAN/GUID')
    try:
        wb=load_workbook(source,read_only=True,data_only=True)
        try:
            ws=wb['Sheet1'];h={str(v or '').strip().upper():i for i,v in enumerate(next(ws.iter_rows(min_row=2,max_row=2,values_only=True)))}
            required={'GUID','BUT TOAN','NGAY GD','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'}
            if required-h.keys():raise ValueError('MISSING_HEADERS')
            for row in ws.iter_rows(min_row=4,values_only=True):
                def get(k):return str(row[h[k]] or '').strip() if k in h and h[k]<len(row) else ''
                guid=get('GUID').upper()
                if not guid:continue
                rows+=1;all_guids.add(guid);codes[get('CODE CB')]+=1
                if get('CHECK SALE').upper()=='SALE' and get('VALID CHARGEBACK').upper()=='Y' and get('CODE CB') in {'10.4','13.1','13.9'}:eligible.add(guid)
                provided=re.sub(r'\D','',get('FULL PAN'))
                if provided and guid in mapping_data and provided!=mapping_data[guid]:conflicts+=1
                try:
                    raw=get('NGAY GD')
                    if not re.fullmatch(r'\d{8}',raw):raise ValueError()
                    age=(datetime.now(VIETNAM).date()-datetime.strptime(raw,'%Y%m%d').date()).days
                    dates['valid_age' if 15<age<120 else 'excluded_age']+=1
                except ValueError:dates['invalid_date']+=1
        finally:wb.close()
        add('File 09 schema','PASS','Sheet1, header dòng 2, dữ liệu từ dòng 4',rows=rows,guid_count=len(all_guids))
        add('Normal input coverage','FAIL' if eligible-mapping_data.keys() else 'PASS','Mapping cho các GUID đủ điều kiện upstream',eligible_guids=len(eligible),missing_count=len(eligible-mapping_data.keys()))
        add('All input coverage','WARN' if all_guids-mapping_data.keys() else 'PASS','Mapping toàn bộ GUID trong file 09, gồm nhóm có thể chọn chạy riêng',missing_count=len(all_guids-mapping_data.keys()))
        add('PAN source consistency','FAIL' if conflicts else 'PASS','Đối chiếu FULL PAN nếu workbook có cột này',conflict_rows=conflicts)
        add('Transaction dates','WARN' if dates['invalid_date'] or dates['excluded_age'] else 'PASS','Tuổi/ngày được lọc lại khi bot chạy',**dates)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,InvalidFileException):add('File 09 schema','FAIL','Không đọc được file 09 hoặc thiếu sheet/header bắt buộc')
    return dict(status='FAIL' if any(x['status']=='FAIL' for x in checks) else 'WARN' if any(x['status']=='WARN' for x in checks) else 'PASS',
        input_mode=input_mode,workbook_path=str(source),mapping_path=str(mapping),checks=checks)
