import json,os,subprocess,datetime
from pathlib import Path
from flask import Flask,jsonify,render_template,request,abort
from .collector import Collector
from .db import load,admin,set_setting,set_bot,init
from .task_scheduler import list_tasks,update_task,open_action,open_scheduler,TaskSchedulerError
def create(root):
 root=Path(root);db=root/'data'/'rpa_ops.db';init(db);app=Flask(__name__,template_folder=str(root/'templates'),static_folder=str(root/'static'));c=Collector(root);c.collect();c.start()
 @app.errorhandler(400)
 @app.errorhandler(403)
 @app.errorhandler(404)
 def http_error(e):return jsonify(ok=False,error=getattr(e,'description',str(e))),e.code
 def status():return json.loads((root/'data'/'current_status.json').read_text(encoding='utf-8'))
 @app.get('/')
 def home():return render_template('index.html',data=status())
 @app.get('/api/status')
 def api():return jsonify(status())
 @app.get('/api/vrol/live')
 def visa_live():
  from .parsers.vrol_visa import parse
  bot=(status().get('bots') or {}).get('vrol_master') or {}
  if not bot.get('root_path'):abort(404)
  parsed=parse(Path(bot['root_path']),limit=1)
  settings={x['key']:x['value'] for x in admin(db)['settings']}
  try:parsed['poll_seconds']=max(2,min(300,int(settings.get('VROL_GUID_POLL_SECONDS','5'))))
  except (TypeError,ValueError):parsed['poll_seconds']=5
  return jsonify(parsed)
 @app.post('/api/vrol/checks')
 def visa_checks():
  body=request.get_json() or {};bots=admin(db)['bots'];bot=next((b for b in bots if b['bot_id']=='vrol_master'),None)
  if not bot:abort(404)
  selected=body.get('input_path') or None
  if selected:
   eligible=(status().get('workflow_inputs') or {}).get('vrol_master',[])
   if not any(Path(x['path']).resolve()==Path(selected).resolve() for x in eligible):abort(403,description='Input không thuộc contract hiện có trên dashboard')
  from .vrol_checks import check
  return jsonify(check(bot['root_path'],selected))
 @app.post('/api/refresh')
 def refresh():return jsonify(c.collect())
 @app.get('/api/debug/workflow-inputs')
 def debug_inputs():
  x=c.collect();cms=(x.get('bots') or {}).get('cms_on_hold') or {};rootp=Path(cms.get('root_path') or '');day=datetime.datetime.now().strftime('%Y%m%d');scanned=[]
  for folder in (rootp/'output'/day,rootp/'outputs'/day,rootp/'output',rootp/'outputs'):
   if folder.is_dir():
    try:scanned += [str(q) for q in folder.rglob('cms-on-hold-export*.csv')]
    except:pass
  return jsonify({'version':'0.9.6','generated_at':x.get('generated_at'),'cms_root':str(rootp),'cms_root_exists':rootp.is_dir(),'scanned_candidates':sorted(set(scanned)),'workflow_inputs':x.get('workflow_inputs'),'cms':cms,'t24':(x.get('bots') or {}).get('t24_timeout')})
 @app.get('/api/settings')
 def settings():return jsonify(admin(db))
 @app.post('/api/settings')
 def save():x=request.get_json();set_setting(db,x['key'],str(x['value']));return jsonify(ok=True)
 @app.post('/api/bots/<bid>')
 def bot(bid):
  x=request.get_json();updated=set_bot(db,bid,x['display_name'],x['root_path'],x.get('enabled',True));snapshot=c.collect();return jsonify(ok=True,bot=updated,status=(snapshot.get('bots') or {}).get(bid))
 @app.get('/api/schedules')
 def schedules():
  try:return jsonify(ok=True,folder=r'\RPA Tra Soat',tasks=list_tasks())
  except Exception as e:return jsonify(ok=False,error=str(e),tasks=[]),500
 @app.put('/api/schedules')
 def schedule_update():
  x=request.get_json() or {}
  try:return jsonify(update_task(x.get('original_name'),x.get('name'),x.get('time')))
  except Exception as e:return jsonify(ok=False,error=str(e)),400
 @app.post('/api/schedules/open-action')
 def schedule_open_action():
  try:return jsonify(open_action((request.get_json() or {}).get('name')))
  except Exception as e:return jsonify(ok=False,error=str(e)),400
 @app.post('/api/schedules/open-task-scheduler')
 def schedule_open_task_scheduler():
  try:return jsonify(open_scheduler())
  except Exception as e:return jsonify(ok=False,error=str(e)),400
 def prepare_guid_request():
  body=request.get_json() or {}
  if set(body)-{'input_path','guids','mode'}:abort(400,description='Chỉ nhập GUID; không hỗ trợ override code hoặc dữ liệu giao dịch')
  snapshot=c.collect();bot=(snapshot.get('bots') or {}).get('vrol_master') or {}
  if any(r.get('status') in {'RUNNING','WAITING_OTP'} for r in bot.get('runs',[])):abort(400,description='VROL đang chạy; đợi run hiện tại hoàn tất')
  path=Path(str(body.get('input_path') or '')).resolve()
  allowed=(snapshot.get('workflow_inputs') or {}).get('vrol_master',[])
  if not any(Path(x['path']).resolve()==path for x in allowed):abort(403,description='Chọn contract FC + GUID2PAN READY hôm nay')
  from .vrol_guid_request import preview
  try:result=preview(path,body.get('guids'))
  except (OSError,ValueError,KeyError) as exc:abort(400,description=str(exc))
  return Path(bot['root_path']).resolve(),path,result
 @app.post('/api/vrol/guid-request/preview')
 def preview_guid_request():
  _,_,result=prepare_guid_request();return jsonify(result)
 @app.post('/api/vrol/guid-request')
 def run_guid_request():
  visa,path,result=prepare_guid_request();cmd=visa/'run_vrol_from_ops.cmd'
  if not cmd.is_file():abort(404,description='Không có CMD launcher tại root VROL')
  import uuid
  from .utils import atomic
  rid=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]
  req=visa/'runtime'/'guid_requests'/(rid+'.json')
  atomic(req,dict(schema='vrol-guid-request/1',request_id=rid,requested_at=datetime.datetime.now().astimezone().isoformat(),
      input_contract=str(path),manifest_sha256=result['manifest_sha256'],guids=result['guids']))
  env=os.environ.copy();env['RPA_OPS_SELECTED_INPUT']=str(path);env['RPA_OPS_GUID_REQUEST']=str(req);env['RPA_OPS_RUN_MODE']=vrol_mode(request.get_json() or {})
  subprocess.Popen(['cmd.exe','/d','/c',str(cmd)],cwd=str(visa),env=env,creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
  return jsonify(ok=True,request_id=rid,request_file=str(req),requested_count=result['requested_count'])
 def vrol_mode(body):
  mode=str(body.get('mode') or 'FULL').upper()
  if mode not in {'FULL','PI_ONLY'}:abort(400,description='Chế độ chạy VROL không hợp lệ')
  return mode
 def vrol_root_and_guard(check_running=True):
  snapshot=c.collect();bot=(snapshot.get('bots') or {}).get('vrol_master') or {}
  if not bot.get('root_path'):abort(404,description='Chưa cấu hình root VROL')
  if check_running and any(r.get('status') in {'RUNNING','WAITING_OTP'} for r in bot.get('runs',[])):abort(400,description='VROL đang chạy; đợi run hiện tại hoàn tất')
  return Path(bot['root_path']).resolve()
 @app.get('/api/vrol/run-settings')
 def vrol_run_settings():
  from .vrol_run_settings import read
  bot=(status().get('bots') or {}).get('vrol_master') or {}
  if not bot.get('root_path'):abort(404,description='Chưa cấu hình root VROL')
  try:return jsonify(read(bot['root_path']))
  except OSError as exc:abort(400,description=str(exc))
 @app.post('/api/vrol/run-settings')
 def vrol_run_settings_save():
  from .vrol_run_settings import save
  visa=vrol_root_and_guard(check_running=False)
  try:return jsonify(save(visa,request.get_json() or {}))
  except (OSError,ValueError) as exc:abort(400,description=str(exc))
 @app.post('/api/vrol/manual-input/pick')
 def vrol_manual_pick():
  from .vrol_manual_input import pick
  body=request.get_json() or {}
  try:return jsonify(ok=True,path=pick(body.get('kind'),body.get('initial') or ''))
  except (ValueError,OSError,subprocess.SubprocessError) as exc:abort(400,description='Không mở được hộp thoại chọn file: '+str(exc))
 @app.post('/api/vrol/manual-input/check')
 def vrol_manual_check():
  from .vrol_manual_input import check
  body=request.get_json() or {}
  return jsonify(check(body.get('workbook'),body.get('mapping')))
 @app.post('/api/vrol/manual-input/run')
 def vrol_manual_run():
  from .vrol_manual_input import publish
  body=request.get_json() or {};visa=vrol_root_and_guard();cmd=visa/'run_vrol_from_ops.cmd'
  if not cmd.is_file():abort(404,description='Không có CMD launcher tại root VROL')
  try:manifest,contract=publish(visa,body.get('workbook'),body.get('mapping'),contract_dir=load(db).get('contract_dir') or None)
  except (OSError,ValueError) as exc:abort(400,description=str(exc))
  env=os.environ.copy();env['RPA_OPS_SELECTED_INPUT']=str(manifest);env.pop('RPA_OPS_GUID_REQUEST',None);env['RPA_OPS_RUN_MODE']=vrol_mode(body)
  subprocess.Popen(['cmd.exe','/d','/c',str(cmd)],cwd=str(visa),env=env,creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
  return jsonify(ok=True,manifest=str(manifest),bundle_id=contract['bundle_id'],check=contract['check'])
 @app.post('/api/retry/<bid>')
 def retry(bid):
  body=request.get_json() or {};a=admin(db);b=next((x for x in a['bots'] if x['bot_id']==bid),None)
  if not b or not b.get('command_path'):abort(404)
  root=Path(b['root_path']);input_path=str(body.get('input_path') or '')
  rel={'cms_on_hold':Path('run_unattended.bat'),'t24_timeout':Path('scripts')/'run.cmd','fraud_classification':Path('script')/'run.cmd','guid2pan':Path('run_guid2pan.bat'),'vrol_master':Path('run_vrol_from_ops.cmd')}.get(bid)
  configured=Path(b['command_path']);candidate=(root/rel) if rel else configured;cmd=candidate if candidate.is_file() else configured
  if not cmd.is_file():abort(404,description='Không tìm thấy command của bot tại root hiện tại')
  try:cmd.resolve().relative_to(root.resolve())
  except ValueError:abort(403,description='Command path không thuộc root path hiện tại')
  snapshot=c.collect() if bid=='vrol_master' else status();eligible=(snapshot.get('workflow_inputs') or {}).get(bid,[])
  if bid=='vrol_master' and any(r.get('status') in {'RUNNING','WAITING_OTP'} for r in ((snapshot.get('bots') or {}).get(bid) or {}).get('runs',[])):
   abort(400,description='VROL đang chạy. Chờ run hiện tại hoàn tất; các worker bên trong vẫn xử lý song song.')
  if bid!='cms_on_hold':
   if not input_path:abort(400,description='Bot này yêu cầu input thành công của ngày hiện tại')
   ip=Path(input_path)
   def path_key(v):return os.path.normcase(os.path.normpath(str(v).strip().strip(chr(34))))
   allowed=any(path_key(ip)==path_key(x.get('path','')) for x in eligible)
   if not allowed:abort(403,description='Input không thuộc success file của ngày hiện tại')
  cumulative=((snapshot.get('bots') or {}).get('t24_timeout') or {}).get('configured_inputs') or {}
  reqdir=root/'rpa_ops_retry_requests';reqdir.mkdir(exist_ok=True);rid=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');req=reqdir/f'{rid}.json';req.write_text(json.dumps({'bot_id':bid,'requested_at':datetime.datetime.now().astimezone().isoformat(),'selected_input':input_path,'t24_cumulative_file':((cumulative.get('cumulative_file') or {}).get('path')),'t24_cumulative_config_key':cumulative.get('config_key'),'command_path':str(cmd)},ensure_ascii=False,indent=2),encoding='utf-8')
  env=os.environ.copy();env['RPA_OPS_RETRY']='1';env['RPA_OPS_SELECTED_INPUT']=input_path;env['RPA_OPS_RETRY_REQUEST']=str(req)
  if bid=='vrol_master':env['RPA_OPS_RUN_MODE']=vrol_mode(body)
  if bid=='t24_timeout' and (cumulative.get('cumulative_file') or {}).get('path'):env['RPA_OPS_T24_CUMULATIVE_FILE']=cumulative['cumulative_file']['path']
  subprocess.Popen(['cmd.exe','/d','/c',str(cmd)],cwd=str(root),env=env,creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
  return jsonify(ok=True,request_file=str(req),note='Selected input is exposed through RPA_OPS_SELECTED_INPUT; the bot must support this environment override to consume it.')

 @app.get('/api/bots/<bid>/runs/<rid>/log')
 def run_log(bid,rid):
  try:offset=max(0,int(request.args.get('offset','0')));limit=min(max(4096,int(request.args.get('limit','65536'))),262144)
  except:abort(400)
  snap=status();bot=(snap.get('bots') or {}).get(bid)
  if not bot:abort(404)
  run=next((x for x in bot.get('runs',[]) if str(x.get('run_id'))==rid),None)
  if not run and str((bot.get('latest') or {}).get('run_id'))==rid:run=bot.get('latest')
  if not run:abort(404)
  resources=run.get('resources') or {};candidate=(resources.get('process_log') or {}).get('path')
  if not candidate:
   rd=(resources.get('run_directory') or {}).get('path')
   if rd:
    for q in (Path(rd)/'logs'/'run.jsonl',Path(rd)/'logs'/'run.log'):
     if q.is_file():candidate=str(q);break
  terminal=run.get('status') in {'SUCCESS','FAILED','COMPLETED_WITH_ISSUES','COMPLETED_WITH_REVIEWS'}
  if not candidate: return jsonify(ok=True,path=None,offset=0,next_offset=0,text='',complete=terminal,status=run.get('status'))
  q=Path(candidate)
  if not q.is_file():return jsonify(ok=True,path=str(q),offset=offset,next_offset=offset,text='',complete=terminal,status=run.get('status'))
  size=q.stat().st_size
  if offset>size:offset=max(0,size-limit)
  with q.open('rb') as h:h.seek(offset);raw=h.read(limit);n=h.tell()
  text=raw.decode('utf-8-sig',errors='replace')
  return jsonify(ok=True,path=str(q),offset=offset,next_offset=n,size=size,text=text,complete=terminal,status=run.get('status'),mtime=q.stat().st_mtime)
 @app.post('/api/open-folder')
 def folder():
  p=Path(request.get_json()['path']);p=p if p.is_dir() else p.parent
  if os.name=='nt':subprocess.Popen(['explorer.exe',str(p)])
  return jsonify(ok=True)
 @app.post('/api/open-file')
 def file():
  p=Path(request.get_json()['path'])
  if not p.is_file():abort(404)
  if os.name=='nt':os.startfile(str(p))
  return jsonify(ok=True)
 @app.get('/health')
 def health():return jsonify(status='healthy',collector_error=c.error)
 return app
