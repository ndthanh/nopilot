"""Windows Task Scheduler COM API; production does not require PowerShell."""
import os
import re
import subprocess
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

FOLDER = '\\RPA Tra Soat\\'


class TaskSchedulerError(RuntimeError):pass


@contextmanager
def service():
    if os.name != 'nt':raise TaskSchedulerError('Chức năng này chỉ chạy trên Windows')
    try:
        import pythoncom
        import win32com.client
    except ImportError as exc:
        raise TaskSchedulerError('Chạy setup.cmd để cài pywin32 cho Task Scheduler') from exc
    pythoncom.CoInitialize()
    try:
        scheduler = win32com.client.Dispatch('Schedule.Service'); scheduler.Connect()
        yield scheduler
    finally:
        scheduler=None
        pythoncom.CoUninitialize()


def date_text(value):
    try:return value.isoformat() if value.year > 1900 else None
    except (AttributeError, ValueError):return None


def list_tasks():
    with service() as scheduler:
        try:tasks = scheduler.GetFolder(FOLDER.rstrip('\\')).GetTasks(0)
        except Exception as exc:
            info=getattr(exc,'excepinfo',None)
            code=info[5] if info and len(info)>5 else getattr(exc,'hresult',None)
            if code in {-2147024894,-2147024893}:
                del scheduler
                return []
            raise TaskSchedulerError(str(exc)) from exc
        rows=[]
        for task in tasks:
            definition=task.Definition
            triggers=[t for t in definition.Triggers];daily=[t for t in triggers if t.Type==2]
            trigger=(daily or triggers or [None])[0]
            action=definition.Actions.Item(1) if definition.Actions.Count else None
            try:clock=datetime.fromisoformat(str(trigger.StartBoundary)).strftime('%H:%M') if trigger else None
            except ValueError:clock=None
            rows.append(dict(name=task.Name,path=task.Path,status={0:'Unknown',1:'Disabled',2:'Queued',3:'Ready',4:'Running'}.get(task.State,'Unknown'),
                             time=clock,next_run_time=date_text(task.NextRunTime),last_run_time=date_text(task.LastRunTime),last_result=task.LastTaskResult,
                             execute=getattr(action,'Path',None),arguments=getattr(action,'Arguments',None),working_directory=getattr(action,'WorkingDirectory',None),
                             editable=len(daily)==1 and task.State!=4))
        return sorted(rows,key=lambda x:x['name'])


def valid_name(value):
    value=str(value or '').strip()
    if not value or len(value)>200 or '\\' in value or '/' in value:raise TaskSchedulerError('Tên task không hợp lệ')
    return value


def valid_time(value):
    value=str(value or '').strip()
    if not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',value):raise TaskSchedulerError('Giờ phải theo HH:MM')
    return value


def update_task(old,new,time):
    old,new,time=valid_name(old),valid_name(new),valid_time(time)
    with service() as scheduler:
        folder=scheduler.GetFolder(FOLDER.rstrip('\\'));task=folder.GetTask(old)
        if task.State==4:raise TaskSchedulerError('Không thể sửa task đang chạy')
        definition=task.Definition;daily=[t for t in definition.Triggers if t.Type==2]
        if len(daily)!=1:raise TaskSchedulerError('Chỉ hỗ trợ task có đúng một Daily trigger')
        if definition.Principal.LogonType in {1,6}:raise TaskSchedulerError('Task này cần mật khẩu; hãy chỉnh trực tiếp trong Task Scheduler')
        if new!=old:
            try:folder.GetTask(new)
            except Exception:pass
            else:raise TaskSchedulerError('Tên task đã tồn tại: '+new)
        original=task.Xml;actions=definition.Actions.XmlText
        daily[0].StartBoundary=re.sub(r'T\d{2}:\d{2}:\d{2}', 'T'+time+':00',str(daily[0].StartBoundary),count=1)
        registered=folder.RegisterTaskDefinition(new,definition,6,definition.Principal.UserId or None,None,definition.Principal.LogonType,None)
        if registered.Definition.Actions.XmlText!=actions:
            if new!=old:folder.DeleteTask(new,0)
            else:folder.RegisterTask(old,original,6,definition.Principal.UserId or None,None,definition.Principal.LogonType,None)
            raise TaskSchedulerError('Action thay đổi ngoài ý muốn; đã hủy cập nhật')
        if new!=old:
            try:folder.DeleteTask(old,0)
            except Exception:
                folder.DeleteTask(new,0)
                raise
        return dict(ok=True,old_name=old,name=new,time=time,action=actions)


def task_action(name):
    name=valid_name(name)
    task=next((x for x in list_tasks() if x['name']==name),None)
    if not task:raise TaskSchedulerError('Không tìm thấy task')
    return task


def open_action(name):
    task=task_action(name);text=' '.join(filter(None,[task.get('execute'),task.get('arguments')]))
    candidates=re.findall(r'"([A-Za-z]:\\[^"\r\n]+?\.(?:bat|cmd|py|exe))"',text,re.I)
    candidates+=re.findall(r'([A-Za-z]:\\[^\r\n]+?\.(?:bat|cmd|py|exe))(?=\s|$)',text,re.I)
    target=next((Path(x.strip()) for x in candidates if Path(x.strip()).exists()),None)
    if not target:raise TaskSchedulerError('Không xác định được file Action đang tồn tại từ task này')
    subprocess.Popen(['explorer.exe','/select,',str(target)])
    return dict(ok=True,path=str(target))


def open_scheduler():
    if os.name!='nt':raise TaskSchedulerError('Chỉ hỗ trợ Windows')
    os.startfile('taskschd.msc');return {'ok':True}
