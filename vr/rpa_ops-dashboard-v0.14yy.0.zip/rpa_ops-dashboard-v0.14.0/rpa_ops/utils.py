import json,os
from pathlib import Path
def read_jsonl(p):
 out=[]
 if not p.is_file():return out
 for x in p.read_text(encoding='utf-8-sig',errors='replace').splitlines():
  try:out.append(json.loads(x))
  except:pass
 return out
def latest(e,n):return next((x for x in reversed(e) if x.get('event')==n),None)
def meta(p):
 if not p:return {'path':None,'exists':False}
 p=Path(p);return {'path':str(p),'exists':p.exists(),'file_size':p.stat().st_size if p.is_file() else None,'folder_path':str(p.parent if p.is_file() else p)}
def atomic(p,d):p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(t,p)
