import sqlite3
from pathlib import Path
from contextlib import contextmanager

DEFAULT={
 'DASHBOARD_TITLE':'RPA Tra Soát','SERVER_HOST':'127.0.0.1','SERVER_PORT':'8765',
 'CRAWL_INTERVAL_MINUTES':'2','VROL_GUID_POLL_SECONDS':'5','VROL_INPUT_CONTRACT_DIR':'','INPUT_SCOPE':'CURRENT_DAY','STATIC_REPORT_ENABLED':'TRUE',
 'STATIC_REPORT_OUTPUT_DIR':r'D:\OneDrive - Techcombank\RPA\01 Tra soat Visa','RETENTION_DRY_RUN':'TRUE'
}
BOTS=[
 ('cms_on_hold','CMS On-Hold Report',r'C:\Users\tamdtm.ttt\Downloads\v26_3_3_rich_verified_attach_retry_early_batch','cms_on_hold',1,10),
 ('t24_timeout','T24 Timeout',r'C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\t24-timeout-v0.0.25','t24_timeout',1,20),
   ('fraud_classification','Phân loại Fraud',r'C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\fraud-classification-bot-v1.4.1','fraud_classification',1,30),
   ('guid2pan','CMS Convert GUID → PAN',r'C:\Users\tamdtm.ttt\Downloads\cms-guid2pan-v3_9','guid2pan',1,40),
   ('vrol_master','VROL Visa',str(Path(__file__).resolve().parents[2]/'vr9.1.13.16'),'vrol_visa',1,50)
]
COMMANDS={
 'cms_on_hold':r'C:\Users\tamdtm.ttt\Downloads\v26_3_3_rich_verified_attach_retry_early_batch\run_unattended.bat',
 't24_timeout':r'C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\t24-timeout-v0.0.25\scripts\run.cmd',
   'fraud_classification':r'C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\fraud-classification-bot-v1.4.1\script\run.cmd',
   'guid2pan':r'C:\Users\tamdtm.ttt\Downloads\cms-guid2pan-v3_9\run_guid2pan.bat',
   'vrol_master':str(Path(__file__).resolve().parents[2]/'vr9.1.13.16'/'run_vrol_from_ops.cmd')
}
@contextmanager
def conn(p):
 p.parent.mkdir(parents=True,exist_ok=True);c=sqlite3.connect(p);c.row_factory=sqlite3.Row
 try:
  c.execute('pragma journal_mode=wal')
  with c:yield c
 finally:c.close()
def init(p):
 with conn(p) as c:
  c.executescript("""
  create table if not exists settings(key text primary key,value text);
  create table if not exists bots(
    bot_id text primary key, display_name text, root_path text, parser text,
    enabled integer, display_order integer, command_path text default ''
  );
  create table if not exists audit(
    id integer primary key, created_at text default current_timestamp,
    action text, entity text, old_value text, new_value text
  );
  """)
  cols=[r['name'] for r in c.execute('pragma table_info(bots)')]
  if 'command_path' not in cols:c.execute("alter table bots add column command_path text default ''")
  for x in DEFAULT.items():c.execute('insert or ignore into settings(key,value) values(?,?)',x)
  old=c.execute("select value from settings where key='STATIC_REPORT_OUTPUT_DIR'").fetchone()
  if old and str(old['value']).strip() in {'','reports'}:c.execute("update settings set value=? where key='STATIC_REPORT_OUTPUT_DIR'",(r'D:\OneDrive - Techcombank\RPA\01 Tra soat Visa',))
  for x in BOTS:c.execute('insert or ignore into bots(bot_id,display_name,root_path,parser,enabled,display_order) values(?,?,?,?,?,?)',x)
  for bid,path in COMMANDS.items():c.execute("update bots set command_path=? where bot_id=? and coalesce(command_path,'')=''",(path,bid))
  c.execute("update bots set root_path=?,command_path=? where bot_id='fraud_classification' and (root_path like '%fraud-classification-bot-v1.1%' or root_path like '%fraud-classification-bot-v1.2%' or command_path like '%fraud-classification-bot-v1.2%')",(r'C:\Users\tamdtm.ttt\Downloads\visa-tra-soat\fraud-classification-bot-v1.3',COMMANDS['fraud_classification']))
  # Keep configured production roots: init/load must never reset GUID2PAN.
  c.execute("update bots set command_path=? where bot_id='cms_on_hold' and command_path like '%run_unattended_contract.bat%'",(COMMANDS['cms_on_hold'],))
def load(p):
 init(p)
 with conn(p) as c:g={r['key']:r['value'] for r in c.execute('select * from settings')};bots=[dict(r) for r in c.execute('select * from bots order by display_order')]
 out=Path(g['STATIC_REPORT_OUTPUT_DIR']);out=out if out.is_absolute() else p.parent.parent/out
 return {'title':g['DASHBOARD_TITLE'],'host':g['SERVER_HOST'],'port':int(g['SERVER_PORT']),'interval':int(g['CRAWL_INTERVAL_MINUTES']),'static':g['STATIC_REPORT_ENABLED'].upper()=='TRUE','static_dir':out,'contract_dir':g['VROL_INPUT_CONTRACT_DIR'].strip(),'retention_dry':g['RETENTION_DRY_RUN'].upper()=='TRUE','bots':bots}
def admin(p):
 init(p)
 with conn(p) as c:return {'settings':[dict(r) for r in c.execute('select * from settings order by key')],'bots':[dict(r) for r in c.execute('select * from bots order by display_order')]}
def set_setting(p,k,v):
 with conn(p) as c:
  old=c.execute('select value from settings where key=?',(k,)).fetchone();c.execute('insert into settings(key,value) values(?,?) on conflict(key) do update set value=excluded.value',(k,v));c.execute('insert into audit(action,entity,old_value,new_value) values(?,?,?,?)',('UPDATE_SETTING',k,old['value'] if old else None,v))
def set_bot(p,bid,name,root,enabled):
 root=str(root).strip();rel={'cms_on_hold':'run_unattended.bat','t24_timeout':r'scripts\run.cmd','fraud_classification':r'script\run.cmd','guid2pan':'run_guid2pan.bat','vrol_master':'run_vrol_from_ops.cmd'}.get(bid)
 command=str(Path(root)/rel) if rel else None
 with conn(p) as c:
  old=c.execute('select root_path,command_path from bots where bot_id=?',(bid,)).fetchone()
  if command:c.execute('update bots set display_name=?,root_path=?,command_path=?,enabled=? where bot_id=?',(name,root,command,int(enabled),bid))
  else:c.execute('update bots set display_name=?,root_path=?,enabled=? where bot_id=?',(name,root,int(enabled),bid))
  c.execute('insert into audit(action,entity,old_value,new_value) values(?,?,?,?)',('UPDATE_BOT',bid,str(dict(old)) if old else None,root))
 return {'bot_id':bid,'display_name':name,'root_path':root,'command_path':command,'enabled':bool(enabled)}
