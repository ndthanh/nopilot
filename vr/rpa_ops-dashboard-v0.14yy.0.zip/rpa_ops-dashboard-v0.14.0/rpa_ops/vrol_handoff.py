"""Publish one immutable FC + GUID2PAN pair for the Visa stage."""
import hashlib
import json
import os
import re
import shutil
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from openpyxl import load_workbook
from .utils import atomic

VIETNAM = timezone(timedelta(hours=7))


def moment(value):
    try:
        value = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return value.replace(tzinfo=VIETNAM) if value.tzinfo is None else value.astimezone(VIETNAM)
    except (ValueError, TypeError):return None


def resource(run, key):return ((run.get('resources') or {}).get(key) or {}).get('path')
def path_key(path):return os.path.normcase(os.path.abspath(str(path or '')))


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):h.update(chunk)
    return h.hexdigest()


def mapping_file(path):
    raw = Path(path).read_bytes()
    encoding = 'utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
    mapping = {}
    for number, line in enumerate(raw.decode(encoding).splitlines(), 1):
        if not line.strip():continue
        parts = [x.strip() for x in line.split('|')]
        if len(parts) != 2 or not parts[0] or not re.fullmatch(r'\d{12,19}', parts[1]):
            raise ValueError(f'GUID2PAN_OUTPUT_NOT_MAPPING:line={number}')
        guid, pan = parts[0].upper(), parts[1]
        if guid in mapping and mapping[guid] != pan:raise ValueError('GUID2PAN_CONFLICTING_MAPPING:' + guid)
        mapping[guid] = pan
    if not mapping:raise ValueError('GUID2PAN_MAPPING_EMPTY')
    return mapping


def workbook_guids(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb['Sheet1']
        header = {str(x).strip().upper(): i for i, x in enumerate(next(ws.iter_rows(min_row=2, max_row=2, values_only=True))) if x is not None}
        required = {'GUID','BUT TOAN','NGAY GD','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'}
        if required - header.keys():raise ValueError('FC_WORKBOOK_HEADERS_MISSING:' + ','.join(sorted(required-header.keys())))
        guids = set()
        for row in ws.iter_rows(min_row=4, values_only=True):
            def get(name):return str(row[header[name]] or '').strip().upper()
            if get('CHECK SALE') == 'SALE' and get('VALID CHARGEBACK') == 'Y' and get('CODE CB') in {'10.4','13.1','13.9'} and get('GUID'):
                guids.add(get('GUID'))
        return guids
    finally:wb.close()


def paired_run(fc, conversions):
    """FC and GUID2PAN run together: use explicit lineage or their coupled window.

    The window also requires the same declared input path. Never associate two
    independent 'latest' files solely by file modification time.
    """
    matches = []
    lower = moment((fc.get('metrics') or {}).get('guid2pan_trigger_started_at') or fc.get('started_at'))
    upper = moment((fc.get('metrics') or {}).get('guid2pan_trigger_completed_at'))
    expected = {path_key(resource(fc, key)) for key in ('guid2pan_input','guid2pan_input_snapshot') if resource(fc, key)}
    for run in conversions:
        if run.get('status') != 'SUCCESS':continue
        source = (run.get('metrics') or {}).get('source_fc_run_id')
        if source:
            if source == fc.get('run_id'):matches.append((run, 'EXPLICIT_SOURCE_FC_RUN_ID'))
            continue
        start = moment(run.get('started_at'))
        if not lower or not start or start < lower or (upper and start > upper):continue
        if start.date() != lower.date():continue
        if path_key(resource(run, 'input_txt')) not in expected:continue
        matches.append((run, 'FC_GUID2PAN_COUPLED_WINDOW'))
    if not matches:return None
    # Several independent conversion successes in an open-ended FC window are
    # ambiguous. An explicit ID or a bounded FC trigger window resolves this.
    explicit = [x for x in matches if x[1] == 'EXPLICIT_SOURCE_FC_RUN_ID']
    if explicit:matches = explicit
    if len(matches) > 1 and not explicit and not upper:raise ValueError('FC_GUID2PAN_PAIR_AMBIGUOUS')
    return max(matches, key=lambda x: moment(x[0].get('completed_at')) or moment(x[0].get('started_at')))


def publish_pair(bots, vrol_root, *, today=None, contract_dir=None):
    today = today or datetime.now(VIETNAM).date()
    result = dict(status='WAITING_INPUT', message='Chờ cặp output FC + GUID2PAN hôm nay', inputs=[])
    fc_bot = bots.get('fraud_classification') or {}; gp_bot = bots.get('guid2pan') or {}
    runs = fc_bot.get('runs') or []
    if not runs:return result
    fc = max(runs, key=lambda r: moment(r.get('started_at') or r.get('completed_at')) or datetime.min.replace(tzinfo=VIETNAM))
    result['source_fc_run_id'] = fc.get('run_id')
    when = moment(fc.get('completed_at') or fc.get('started_at'))
    if fc.get('status') != 'SUCCESS' or not when or when.date() != today:return result
    try:
        pair = paired_run(fc, gp_bot.get('runs') or [])
        if not pair:return result
        gp, evidence = pair
        bundle_id = today.strftime('%Y%m%d') + '_' + hashlib.sha256((str(fc['run_id'])+'|'+str(gp['run_id'])).encode()).hexdigest()[:20]
        base = Path(contract_dir).resolve() if contract_dir else Path(vrol_root).resolve() / 'runtime' / 'ops_inputs'
        folder = base / bundle_id; manifest = folder / 'manifest.json'
        # Once published, use the frozen pair even if GUID2PAN reuses input.txt.
        if manifest.is_file():
            contract = json.loads(manifest.read_text(encoding='utf-8'))
            for entry in contract['files'].values():
                file = Path(entry['path'])
                if file.parent != folder or file.stat().st_size != entry['size'] or digest(file) != entry['sha256']:
                    raise ValueError('VROL_FROZEN_INPUT_CHANGED')
        else:
            workbook = Path(resource(fc, 'final_output') or '')
            mapping = Path(resource(gp, 'final_output') or '')
            if not workbook.is_file() or not mapping.is_file():raise ValueError('FC_GUID2PAN_OUTPUT_MISSING')
            completed = moment(gp.get('completed_at'))
            if not completed or completed.date() != today:raise ValueError('GUID2PAN_NOT_COMPLETED_TODAY')
            if datetime.fromtimestamp(mapping.stat().st_mtime, VIETNAM) > completed + timedelta(seconds=5):
                raise ValueError('GUID2PAN_OUTPUT_CHANGED_AFTER_RUN: waiting for matching conversion')
            base.mkdir(parents=True, exist_ok=True)
            temp = Path(tempfile.mkdtemp(prefix='.pending_', dir=base))
            try:
                files = {}
                for key, source, name in [('workbook', workbook, '09_chargeback_classified.xlsx'), ('mapping', mapping, 'input.txt')]:
                    before = digest(source); target = temp/name
                    shutil.copyfile(source, target)
                    if digest(target) != before or digest(source) != before:raise ValueError('UPSTREAM_INPUT_CHANGED_DURING_SNAPSHOT')
                    files[key] = dict(path=str(folder/name), sha256=before, size=target.stat().st_size)
                converted = mapping_file(temp/'input.txt')
                missing = workbook_guids(temp/'09_chargeback_classified.xlsx') - converted.keys()
                if missing:raise ValueError('GUID2PAN_COVERAGE_INCOMPLETE:groups='+str(len(missing)))
                # The FC GUID-only snapshot is additional evidence for the pair.
                original = resource(fc, 'guid2pan_input_snapshot')
                if original and Path(original).is_file():
                    raw = Path(original).read_bytes()
                    text = raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
                    expected = {line.split('|',1)[0].strip().upper() for line in text.splitlines() if line.strip()}
                    if expected - converted.keys():raise ValueError('GUID2PAN_FC_SNAPSHOT_COVERAGE_MISMATCH')
                contract = dict(schema='vrol-input/1', status='READY', bundle_id=bundle_id,
                                business_date=today.isoformat(), source_fc_run_id=fc['run_id'], source_guid2pan_run_id=gp['run_id'],
                                source_fc_completed_at=fc['completed_at'],source_guid2pan_completed_at=gp['completed_at'],
                                pairing_evidence=evidence, published_at=datetime.now(VIETNAM).isoformat(timespec='seconds'), files=files)
                atomic(temp/'manifest.json', contract)
                temp.rename(folder)
            finally:
                # Only remove the exact temporary directory we just created.
                if temp.exists() and temp.parent.resolve() == base.resolve() and temp.name.startswith('.pending_'):shutil.rmtree(temp)
        atomic(base/'latest_ready.json', contract | dict(manifest_path=str(manifest)))
        entry = dict(source_bot='fraud_classification+guid2pan', source_run_id=fc['run_id'],
                     source_fc_run_id=fc['run_id'], source_guid2pan_run_id=gp['run_id'], resource_key='fc_guid2pan_bundle',
                     path=str(manifest), completed_at=contract['published_at'], exists=True, bundle_id=bundle_id)
        return dict(status='READY', message='Đã có cặp file 09 + GUID|PAN cùng run FC', inputs=[entry], **{k:contract[k] for k in ('bundle_id','source_fc_run_id','source_guid2pan_run_id')})
    except (OSError, ValueError, KeyError, UnicodeError) as exc:
        return result | dict(message='Chưa thể giao input VROL: '+str(exc), reason=str(exc))
