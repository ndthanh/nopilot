"""A shared read-only PI/review pack, excluding mapping and browser credentials."""
import csv
import html
import json
import os
import re
import shutil
from pathlib import Path
from urllib.parse import quote


def copy_artifact(source, destination, run_dir):
    source=Path(source).resolve();destination=Path(destination)
    roots=run_dir if isinstance(run_dir,(list,tuple)) else [run_dir]
    if not any(source.is_relative_to(Path(root).resolve()) for root in roots):return None
    if not source.is_file():return None
    destination.parent.mkdir(parents=True,exist_ok=True)
    if not destination.is_file() or destination.stat().st_size!=source.stat().st_size or destination.stat().st_mtime_ns!=source.stat().st_mtime_ns:
        temp=destination.with_suffix(destination.suffix+'.tmp');shutil.copy2(source,temp);os.replace(temp,destination)
    return destination


def publish(bot, output):
    # Latest completed run gets a portable pack; earlier packs remain available.
    run=next((r for r in bot.get('runs',[]) if r.get('status') in {'SUCCESS','COMPLETED_WITH_ISSUES','COMPLETED_WITH_REVIEWS','FAILED'}),None)
    if not run:return
    resource=run.get('resources') or {};path=(resource.get('run_directory') or {}).get('path')
    if not path:return
    source=Path(path).resolve();target=Path(output)/'vrol'/source.name;target.mkdir(parents=True,exist_ok=True)
    allowed=[source]
    combined=source/'consolidated'/'summary.json'
    if combined.is_file():
        data=json.loads(combined.read_text(encoding='utf-8'))
        for name in [data.get('original_queue'),*data.get('resume_runs',[]),*data.get('historical_runs',[])]:
            if isinstance(name,str) and re.fullmatch(r'[A-Za-z0-9_]+',name):
                candidate=(source.parent/name).resolve()
                if candidate.parent==source.parent and candidate.is_dir():allowed.append(candidate)
    documents=Path((resource.get('pi_documents') or {}).get('path') or source/'documents')
    for pdf in documents.glob('*.pdf'):copy_artifact(pdf,target/'documents'/pdf.name,allowed)
    rows=[]
    for result in run.get('guid_results') or []:
        links=[]
        folder=result.get('folder')
        if folder:
            for image in result.get('screenshots') or []:
                image_path=Path(image)
                dest=copy_artifact(image_path,target/'groups'/Path(folder).name/image_path.name,allowed)
                if dest:links.append(dest.relative_to(target).as_posix())
        rows.append(dict(guid=result.get('guid'),label=result.get('label') or '',bucket=result.get('category') or '',status=result.get('status'),
                         reason=result.get('reason_code'),rol=result.get('rol'),needs_review=result.get('needs_user_review'),screenshots=' | '.join(links)))
    fields=['guid','label','bucket','status','reason','rol','needs_review','screenshots']
    temp=target/'guid_results.csv.tmp'
    with temp.open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader();writer.writerows(rows)
    os.replace(temp,target/'guid_results.csv')
    esc=lambda value:html.escape(str(value if value is not None else ''))
    pdf_links=''.join(f'<li><a href="{quote("documents/"+p.name)}">{esc(p.name)}</a></li>' for p in sorted((target/'documents').glob('*.pdf')))
    shots={row['guid']:row['screenshots'] for row in rows}
    def shot_links(guid):return ''.join(f'<a href="{quote(link)}">Ảnh</a> ' for link in (shots.get(guid) or '').split(' | ') if link)
    live=run.get('live')
    if live:doc=v2_document(run,live,rows,target,source,allowed,esc,pdf_links,shot_links)
    else:
        table=''.join('<tr>'+''.join('<td>'+esc(row[key])+'</td>' for key in ('guid','status','reason','rol','needs_review'))+'<td>'+shot_links(row['guid'])+'</td></tr>' for row in rows)
        doc=f'<!doctype html><html lang="vi"><meta charset="utf-8"><title>VROL {esc(source.name)}</title><style>body{{font:14px system-ui;margin:24px}}td,th{{padding:8px;border:1px solid #ddd}}table{{border-collapse:collapse}}</style><h1>VROL Visa · {esc(source.name)}</h1><p>{esc(run["status"])} · <a href="guid_results.csv">Kết quả GUID CSV</a></p><h2>PI PDF</h2><ul>{pdf_links}</ul><h2>Kết quả từng GUID</h2><table><tr><th>GUID</th><th>Trạng thái</th><th>Lý do</th><th>ROL</th><th>Cần review</th><th>Ảnh</th></tr>{table}</table></html>'
    temp=target/'index.html.tmp';temp.write_text(doc,encoding='utf-8');os.replace(temp,target/'index.html')
    resource['shared_review_pack']=dict(path=str(target/'index.html'),exists=True,href=f'vrol/{quote(source.name)}/index.html')


STATUS_TEXT={'SUCCESS':'Hoàn tất','COMPLETED_WITH_REVIEWS':'Hoàn tất – còn GUID cần review / case chờ Final Submit','COMPLETED_WITH_ISSUES':'Hoàn tất – còn GUID cần review','FAILED':'Run dừng lỗi'}
BUCKETS=[('pi','Đã tải PI'),('no_cb','NO_CB'),('existing_cb','Đã có chargeback'),('draft','Nháp chờ Final Submit'),('submitted','Đã Final Submit'),('review','Cần review'),('retry_later','Thử lại run sau'),('diagnostic','Cần tạo case (chạy đầy đủ)')]
ORIGIN_TEXT={'MANUAL_USER_SELECTED':'File tự chọn trên dashboard','FC_GUID2PAN':'FC + GUID2PAN (bundle hằng ngày)','FILES':'File theo cấu hình'}
SOURCE_TEXT={'dashboard':'dashboard','command_line':'lệnh chạy','config':'config.xlsx'}


def v2_document(run,live,rows,target,source,allowed,esc,pdf_links,shot_links):
    """Contract vrol-dashboard/2 pack: what ran, business outcome counts, what the user must do."""
    mode=live.get('mode') or {};sources=mode.get('sources') or {};q=live.get('queue') or {};b=live.get('buckets') or {};p=live.get('progress') or {}
    src=lambda k:' ('+SOURCE_TEXT.get(sources.get(k),'config.xlsx')+')'
    settings=[('Luồng chạy','Theo lịch (run_scheduled.cmd)' if mode.get('scheduled') else 'Chạy tay'),
              ('Chế độ','Chỉ tải chứng từ (PI = Yes)' if mode.get('pi_only') else 'Đầy đủ'),
              ('Final Submit',('BẬT' if mode.get('final_submit_enabled') else 'Tắt – dừng trước Final Submit')+src('final_submit')),
              ('Worker',str(mode.get('workers') or '?')+src('workers')),('Trình duyệt',('Headless' if mode.get('headless') else 'Headful')+src('headless')),
              ('Input',ORIGIN_TEXT.get((live.get('input') or {}).get('origin'),(live.get('input') or {}).get('origin') or '')),('Bắt đầu',live.get('started_at') or ''),('Kết thúc',live.get('completed_at') or ''),
              ('GUID',f"{p.get('done',0)}/{q.get('total',0)}"),('Tốc độ',f"{p.get('guids_per_min') or '-'} GUID/phút"),
              ('Restart Chrome',(live.get('session') or {}).get('restarts',0)),('Ghi file 09',live.get('master_writeback') or '-')]
    counts=dict(b);counts['existing_cb']=b.get('existing_cb',0)+(q.get('existing_cb_rol500') or 0)
    kpis=''.join(f'<div class="kpi"><span>{esc(label)}</span><strong>{esc(counts.get(key,0))}</strong></div>' for key,label in BUCKETS if key!='diagnostic' or counts.get(key))
    groups={}
    for item in live.get('review') or []:groups.setdefault(item.get('group') or 'Review',[]).append(item)
    review=''.join(f'<h3>{esc(name)} ({len(items)})</h3><p class="hint">{esc(items[0].get("hint"))}</p><table><tr><th>GUID</th><th>ROL</th><th>Lý do</th><th>Ảnh</th></tr>'
                   +''.join(f'<tr><td>{esc(x.get("guid"))}</td><td>{esc(x.get("rol") or "-")}</td><td>{esc(x.get("reason_code"))}</td><td>{shot_links(x.get("guid"))}</td></tr>' for x in items)+'</table>'
                   for name,items in sorted(groups.items(),key=lambda kv:-len(kv[1]))) or '<p>Không có GUID cần review.</p>'
    drafts=live.get('drafts') or []
    temp=target/'drafts.csv.tmp'
    with temp.open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=['guid','rol','action','label']);writer.writeheader()
        writer.writerows(dict(guid=d.get('guid'),rol=d.get('rol'),action=d.get('action'),label=d.get('label')) for d in drafts)
    os.replace(temp,target/'drafts.csv')
    draft_table=('<table><tr><th>GUID</th><th>ROL</th><th>Loại</th><th>Ảnh</th></tr>'+''.join(f'<tr><td>{esc(d.get("guid"))}</td><td>{esc(d.get("rol"))}</td><td>{esc(d.get("action") or d.get("label"))}</td><td>{shot_links(d.get("guid"))}</td></tr>' for d in drafts)+'</table>') if drafts else '<p>Không có case nháp.</p>'
    existing=copy_artifact(source/'existing_chargebacks.csv',target/'existing_chargebacks.csv',allowed)
    stages=' → '.join(f'{esc(x.get("stage"))} {esc(str(x.get("at") or "")[11:16])}' for x in live.get('stage_history') or [])
    table=''.join(f'<tr><td>{esc(r["guid"])}</td><td>{esc(r["label"] or r["status"])}</td><td>{esc(r["reason"])}</td><td>{esc(r["rol"] or "-")}</td><td>{shot_links(r["guid"])}</td></tr>' for r in rows)
    status=run.get('status');tone={'FAILED':'#b91c1c','SUCCESS':'#15803d','COMPLETED_WITH_REVIEWS':'#15803d'}.get(status,'#b45309')
    style='body{font:14px system-ui;margin:24px;color:#18181b}td,th{padding:6px 8px;border:1px solid #e4e4e7;text-align:left}table{border-collapse:collapse;margin:8px 0 16px}' \
          '.kpis{display:flex;flex-wrap:wrap;gap:8px}.kpi{border:1px solid #e4e4e7;border-radius:8px;padding:8px 12px;min-width:130px}.kpi span{display:block;font-size:12px;color:#71717a}' \
          '.kpi strong{font-size:22px}.status{color:'+tone+';font-weight:600}.hint{color:#52525b;margin:4px 0}h2{margin-top:24px}'
    links=' · '.join(x for x in ['<a href="guid_results.csv">Kết quả GUID (CSV)</a>','<a href="drafts.csv">Case nháp (CSV)</a>',
                                 '<a href="existing_chargebacks.csv">Chargeback đã có (CSV)</a>' if existing else ''] if x)
    return (f'<!doctype html><html lang="vi"><meta charset="utf-8"><title>VROL {esc(source.name)}</title><style>{style}</style>'
            f'<h1>VROL Visa · {esc(source.name)}</h1><p class="status">{esc(STATUS_TEXT.get(status,status))}</p><p>{links}</p>'
            '<table>'+''.join(f'<tr><th>{esc(k)}</th><td>{esc(v)}</td></tr>' for k,v in settings)+'</table>'
            f'<p class="hint">Các bước: {stages}</p><h2>Kết quả</h2><div class="kpis">{kpis}</div>'
            f'<h2>Cần xử lý ({len(live.get("review") or [])})</h2>{review}'
            f'<h2>Case nháp chờ Final Submit ({len(drafts)})</h2>{draft_table}'
            f'<h2>Chứng từ PI</h2><ul>{pdf_links or "<li>Không có PDF.</li>"}</ul>'
            f'<h2>Tất cả GUID ({len(rows)})</h2><table><tr><th>GUID</th><th>Kết quả (AM)</th><th>Lý do</th><th>ROL</th><th>Ảnh</th></tr>{table}</table></html>')
