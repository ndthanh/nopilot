"""VROL run settings chosen on the dashboard (Final Submit, workers, headless).

Saved to <VROL root>\\runtime\\run_overrides.json, which the bot reads at the start of
EVERY run (scheduled 19:40 runs included). null = use config.xlsx. Command-line flags
of a diagnostic launcher still win inside the bot.
"""
import json
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook

from .utils import atomic
from .vrol_handoff import VIETNAM

SCHEMA = 'vrol-run-overrides/1'
MAX_WORKERS = 9
KEYS = ('allow_final_submit', 'async_worker_count', 'async_worker_max', 'headless')


def truth(value):
    return str(value or '').strip().upper() in {'YES', 'Y', 'TRUE', '1', 'ON'}


def config_values(root):
    """Only the 3 operational keys are read from config.xlsx (never credentials)."""
    path = Path(root) / 'config.xlsx'
    found = {}
    if path.is_file():
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            if 'Settings' in wb.sheetnames:
                for row in wb['Settings'].iter_rows(min_row=2, values_only=True):
                    if row and row[0] and str(row[0]).strip() in KEYS:
                        found[str(row[0]).strip()] = row[1] if len(row) > 1 else None
        finally:
            wb.close()
    try:workers = int(found.get('async_worker_count') or 3)
    except (TypeError, ValueError):workers = 3
    try:cap = int(found.get('async_worker_max') or 5)
    except (TypeError, ValueError):cap = 5
    return dict(config_found=path.is_file(), final_submit='YES' if truth(found.get('allow_final_submit')) else 'NO',
                workers=min(workers, cap), headless=truth(found.get('headless')))


def read(root):
    root = Path(root)
    path = root / 'runtime' / 'run_overrides.json'
    try:saved = json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):saved = {}
    config = config_values(root)
    overrides = dict(final_submit=saved.get('final_submit') if saved.get('final_submit') in {'YES', 'NO'} else None,
                     workers=saved.get('workers') if isinstance(saved.get('workers'), int) and 1 <= saved['workers'] <= MAX_WORKERS else None,
                     headless=saved.get('headless') if isinstance(saved.get('headless'), bool) else None)
    effective = {k: (overrides[k] if overrides[k] is not None else config[k]) for k in ('final_submit', 'workers', 'headless')}
    return dict(path=str(path), config=config, overrides=overrides, effective=effective,
                updated_at=saved.get('updated_at'), max_workers=MAX_WORKERS)


def save(root, body):
    """body values: final_submit CONFIG|YES|NO, workers CONFIG|1..9, headless CONFIG|HEADLESS|HEADFUL."""
    final = str(body.get('final_submit', 'CONFIG')).upper()
    if final not in {'CONFIG', 'YES', 'NO'}:raise ValueError('final_submit phải là CONFIG, YES hoặc NO')
    raw_workers = str(body.get('workers', 'CONFIG')).upper()
    if raw_workers == 'CONFIG':workers = None
    else:
        try:workers = int(raw_workers)
        except ValueError:raise ValueError('workers phải là CONFIG hoặc số 1-%d' % MAX_WORKERS)
        if not 1 <= workers <= MAX_WORKERS:raise ValueError('workers phải trong khoảng 1-%d' % MAX_WORKERS)
    mode = str(body.get('headless', 'CONFIG')).upper()
    if mode not in {'CONFIG', 'HEADLESS', 'HEADFUL'}:raise ValueError('headless phải là CONFIG, HEADLESS hoặc HEADFUL')
    data = dict(schema=SCHEMA, final_submit=None if final == 'CONFIG' else final, workers=workers,
                headless=None if mode == 'CONFIG' else mode == 'HEADLESS',
                updated_at=datetime.now(VIETNAM).isoformat(timespec='seconds'), updated_by='rpa-ops-dashboard')
    atomic(Path(root) / 'runtime' / 'run_overrides.json', data)
    return read(root)
