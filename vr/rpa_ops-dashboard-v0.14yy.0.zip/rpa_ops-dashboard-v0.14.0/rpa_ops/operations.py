from datetime import datetime, time

def dt(v):
    try:
        return datetime.fromisoformat(str(v).replace('Z', '+00:00')).astimezone()
    except Exception:
        return None

def schedules(bot):return [str(x.get('time')) for x in bot.get('task_schedules',[]) if x.get('time')]
def today(bot):
    current = datetime.now().astimezone().date()
    runs = []
    for run in bot.get('runs', []):
        when = dt(run.get('started_at') or run.get('completed_at'))
        if when and when.date() == current:
            runs.append(run)
    return sorted(runs, key=lambda run: dt(run.get('started_at') or run.get('completed_at')))

def cms(bot):
    now = datetime.now().astimezone()
    runs = today(bot)
    success = [x for x in runs if x['status'] == 'SUCCESS']
    running = [x for x in runs if x['status'] == 'RUNNING']
    if success:
        status, message = 'SUCCESS', 'Đã có ít nhất một file CMS hợp lệ hôm nay'
    elif running:
        status, message = 'RUNNING', 'CMS On-Hold đang chạy'
    elif now.time() < time(3):
        status, message = 'NOT_DUE', 'Chưa đến lịch chạy đầu tiên'
    elif now.time() <= time(7, 45):
        status, message = 'WAITING_FOR_RETRY', 'Chưa có success, vẫn còn lịch retry tự động'
    else:
        status, message = 'ACTION_REQUIRED', 'Không có CMS export thành công hôm nay'
    return {'policy':'ANY_SUCCESS_TODAY','status':status,'message':message,'runs_today':len(runs),'success_count':len(success),'failed_count':len([x for x in runs if x['status']=='FAILED']),'schedule':schedules(bot),'next_action':'TODO: Hướng dẫn xuất tay CMS và nơi lưu file' if status=='ACTION_REQUIRED' else None}

def t24(bot):
    runs=today(bot);success=[x for x in runs if x['status']=='SUCCESS'];failed=[x for x in runs if x['status']=='FAILED'];running=[x for x in runs if x['status']=='RUNNING'];last=runs[-1] if runs else None
    if running:status,message='RUNNING','T24 Timeout đang chạy'
    elif last and last['status']=='FAILED':status,message='ATTENTION','Lần chạy gần nhất thất bại, có thể retry thủ công'
    elif success and failed:status,message='RECOVERED','Có lỗi trong ngày nhưng đã có run thành công'
    elif success:status,message='ON_TRACK','Các run gần nhất đang thành công'
    elif datetime.now().astimezone().time()<time(8,20):status,message='NOT_DUE','Chưa đến lịch chạy đầu tiên'
    else:status,message='ATTENTION','Chưa có run thành công hôm nay'
    return {'policy':'TRACK_ALL_RUNS','status':status,'message':message,'runs_today':len(runs),'success_count':len(success),'failed_count':len(failed),'schedule':schedules(bot),'next_action':'Chạy lại task T24 Timeout' if status=='ATTENTION' else None}

def fraud(bot):
    runs=today(bot);success=[x for x in runs if x['status']=='SUCCESS'];failed=[x for x in runs if x['status']=='FAILED'];last=runs[-1] if runs else None
    if last and last['status']=='RUNNING':status,message='RUNNING','Fraud Classification đang chạy'
    elif last and last['status']=='FAILED':status,message='ATTENTION','Lần chạy Fraud Classification gần nhất thất bại'
    elif success and failed:status,message='RECOVERED','Có lỗi trong ngày nhưng lần chạy gần nhất đã hoàn tất'
    elif success:status,message='SUCCESS','Đã phân loại trên snapshot T24 được chọn; có thể chạy lại khi T24 có dữ liệu bổ sung'
    elif datetime.now().astimezone().time()<time(19,30):status,message='NOT_DUE','Chưa đến lịch chạy 19:30'
    else:status,message='ACTION_REQUIRED','Chưa có kết quả Fraud Classification hôm nay'
    return {'policy':'RERUN_ON_LATEST_T24_SNAPSHOT','status':status,'message':message,'runs_today':len(runs),'success_count':len(success),'failed_count':len(failed),'schedule':schedules(bot),'next_action':'Chạy lại Fraud Classification với output T24 mới nhất' if status in {'ATTENTION','ACTION_REQUIRED'} else None}

def guid(bot):
    runs=today(bot);success=[x for x in runs if x['status']=='SUCCESS'];failed=[x for x in runs if x['status']=='FAILED'];last=runs[-1] if runs else None
    if last and last['status']=='RUNNING':status,message='RUNNING','GUID2PAN đang chuẩn bị input hoặc convert'
    elif last and last['status']=='FAILED':status,message='ATTENTION','Lần chạy GUID2PAN gần nhất thất bại'
    elif success:status,message='SUCCESS','Đã chuẩn bị/chuyển đổi GUID từ kết quả FC hôm nay'
    else:status,message='NOT_DUE','Chưa có run GUID2PAN hôm nay'
    return {'policy':'FC_SUCCESS_TO_GUID2PAN','status':status,'message':message,'runs_today':len(runs),'success_count':len(success),'failed_count':len(failed),'schedule':schedules(bot),'next_action':'Chạy với output FC mới nhất hôm nay' if status in {'ATTENTION','NOT_DUE'} else None}

def placeholder(bot_id, name, schedule, status='NOT_CONFIGURED'):
    return {'display_name':name,'root_path':'','runs':[],'latest':{'status':status,'resources':{},'metrics':{}},'operations':{'status':status,'policy':'ANY_SUCCESS_TODAY','message':'Chưa cấu hình','runs_today':0,'success_count':0,'failed_count':0,'schedule':schedule,'next_action':'TODO'}}

def visa(bot):
    runs=today(bot);last=bot.get('latest') or {};handoff=bot.get('input_handoff') or {}
    status=last.get('status')
    if status in {'RUNNING','WAITING_OTP'}:message='VROL đang chờ file OTP trong thư mục cấu hình' if status=='WAITING_OTP' else 'VROL Visa đang xử lý GUID'
    elif runs and status=='FAILED':message='VROL dừng do lỗi; xem ảnh và checkpoint trước khi chạy lại'
    elif runs and status in {'COMPLETED_WITH_REVIEWS','COMPLETED_WITH_ISSUES'}:message='Đã chạy xong; còn GUID cần review hoặc case chờ Final Submit'
    elif runs and status=='SUCCESS':message='VROL đã hoàn tất; xem PI và kết quả từng GUID'
    else:status=handoff.get('status','WAITING_INPUT');message=handoff.get('message','Chờ cặp FC + GUID2PAN')
    return dict(policy='PAIRED_FC_GUID2PAN_TO_VROL',status=status,message=message,runs_today=len(runs),
                success_count=sum(r.get('status')=='SUCCESS' for r in runs),failed_count=sum(r.get('status')=='FAILED' for r in runs),
                review_run_count=sum(r.get('status') in {'COMPLETED_WITH_REVIEWS','COMPLETED_WITH_ISSUES'} for r in runs),schedule=schedules(bot))

def enrich(payload):
    bots = payload['bots']
    if 'cms_on_hold' in bots:
        bots['cms_on_hold']['operations'] = cms(bots['cms_on_hold'])
    else:
        bots['cms_on_hold'] = placeholder('cms_on_hold','CMS On-Hold Report',[])
    if 't24_timeout' in bots:
        bots['t24_timeout']['operations'] = t24(bots['t24_timeout'])
    else:
        bots['t24_timeout'] = placeholder('t24_timeout','T24 Timeout',[])
    if 'fraud_classification' in bots:
        bots['fraud_classification']['operations'] = fraud(bots['fraud_classification'])
    else:
        bots['fraud_classification'] = placeholder('fraud_classification','Phân loại Fraud',['19:30'])
    if 'guid2pan' in bots:
        bots['guid2pan']['operations'] = guid(bots['guid2pan'])
    else:
        bots['guid2pan'] = placeholder('guid2pan','CMS Convert GUID → PAN',[])
    if 'vrol_master' in bots:bots['vrol_master']['operations']=visa(bots['vrol_master'])
    else:bots['vrol_master'] = placeholder('vrol_master','VROL Visa',[], 'NOT_CONFIGURED')
    payload['workflow_order'] = ['cms_on_hold','t24_timeout','fraud_classification','guid2pan','vrol_master']
    return payload
