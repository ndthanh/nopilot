"""Configure the dashboard without importing or modifying Visa."""
import argparse
from pathlib import Path
from .db import init,set_bot,set_setting

def configure(root,*,visa,fc,guid,reports=None,contracts=None):
    root=Path(root).resolve();db=root/'data'/'rpa_ops.db';init(db)
    for bid,name,path in [('fraud_classification','Phan loai Fraud',fc),('guid2pan','GUID2PAN',guid),('vrol_master','VROL Visa',visa)]:
        set_bot(db,bid,name,str(Path(path).expanduser().resolve()),True)
    reports=Path(reports or root/'reports').resolve();reports.mkdir(parents=True,exist_ok=True)
    for key,value in dict(STATIC_REPORT_OUTPUT_DIR=str(reports),STATIC_REPORT_ENABLED='TRUE',SERVER_HOST='127.0.0.1',SERVER_PORT='8765',VROL_GUID_POLL_SECONDS='5',VROL_INPUT_CONTRACT_DIR=str(Path(contracts).resolve()) if contracts else '').items():
        set_setting(db,key,value)
    return db

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('visa-root','fc-root','guid2pan-root','reports-dir','contract-dir'):p.add_argument('--'+key)
    p.add_argument('--non-interactive',action='store_true');args=p.parse_args()
    def ask(value,label):
        if value:return value.strip('"')
        if args.non_interactive:p.error('Required path: '+label)
        result=input(label+': ').strip().strip('"')
        if not result:p.error('Required path: '+label)
        return result
    visa=ask(args.visa_root,'--visa-root');fc=ask(args.fc_root,'--fc-root');guid=ask(args.guid2pan_root,'--guid2pan-root')
    db=configure(Path(__file__).resolve().parents[1],visa=visa,fc=fc,guid=guid,reports=args.reports_dir,contracts=args.contract_dir)
    print('Configured dashboard database:',db)
    print('Visa has its own install.cmd / configure_paths.cmd. This command does not edit Visa config.xlsx.')
    print('Run run_server.cmd; READY bundles are published under <visa-root>/runtime/ops_inputs.')

if __name__=='__main__':main()
