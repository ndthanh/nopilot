import json
from datetime import date, datetime
from pathlib import Path
from .utils import atomic, meta


def _run_day(run):
    raw = run.get('completed_at') or run.get('started_at')
    try:
        return datetime.fromisoformat(str(raw).replace('Z', '+00:00')).astimezone().date()
    except Exception:
        pass
    for text in (str(run.get('run_id') or ''), str(((run.get('resources') or {}).get('main_output') or {}).get('path') or '')):
        import re
        m = re.search(r'(20\d{6})', text)
        if m:
            try:
                return datetime.strptime(m.group(1), '%Y%m%d').date()
            except Exception:
                pass
    return None


def _sort_key(run):
    return str(run.get('completed_at') or run.get('started_at') or '')


def publish_cms_success(cms_bot):
    """Publish today's newest valid CMS success. Safe to call on every dashboard refresh."""
    root = Path(cms_bot.get('root_path') or '')
    state = root / 'state' / 'latest_success.json'
    today = date.today()
    valid = []
    for run in cms_bot.get('runs') or []:
        if run.get('status') != 'SUCCESS' or _run_day(run) != today:
            continue
        resource = ((run.get('resources') or {}).get('main_output') or {})
        path = resource.get('path')
        if not path:
            continue
        output = Path(path)
        try:
            if not output.is_file() or output.stat().st_size <= 0:
                continue
        except OSError:
            continue
        valid.append((run, output))

    if not valid:
        existing = None
        if state.is_file():
            try:
                existing = json.loads(state.read_text(encoding='utf-8-sig'))
            except Exception:
                existing = None
        return {
            'status': 'WAITING',
            'message': 'Chưa có CMS On-Hold success hợp lệ hôm nay để publish',
            'contract_path': str(state),
            'contract_exists': state.is_file(),
            'published': False,
            'current_contract_business_date': (existing or {}).get('business_date'),
        }

    run, output = max(valid, key=lambda item: _sort_key(item[0]))
    size = output.stat().st_size
    completed = run.get('completed_at') or run.get('started_at')
    contract = {
        # Backward-compatible identity required by t24-timeout v0.0.25.
        'bot_name': 'cms-on-hold-export',
        'schema_version': '1.0',
        'workflow': 'visa-dispute',
        'producer': 'cms-on-hold',
        'consumer': ['t24-timeout'],
        'status': 'SUCCESS',
        'business_date': today.strftime('%Y%m%d'),
        'run_id': run.get('run_id'),
        'started_at': run.get('started_at'),
        'completed_at': completed,
        'published_at': datetime.now().astimezone().isoformat(timespec='seconds'),
        'resources': {
            'cms_on_hold_export_csv': {
                'path': str(output.resolve()),
                'file_name': output.name,
                'file_size': size,
                'exists': True,
            }
        },
        'source': {
            'published_by': 'rpa_ops_dashboard',
            'source_run_id': run.get('run_id'),
            'process_log': (((run.get('resources') or {}).get('process_log') or {}).get('path')),
        },
    }

    changed = True
    if state.is_file():
        try:
            old = json.loads(state.read_text(encoding='utf-8-sig'))
            old_res = ((old.get('resources') or {}).get('cms_on_hold_export_csv') or {})
            changed = not (
                old.get('bot_name') == 'cms-on-hold-export'
                and old.get('run_id') == contract['run_id']
                and old.get('business_date') == contract['business_date']
                and old_res.get('path') == contract['resources']['cms_on_hold_export_csv']['path']
                and old_res.get('file_size') == size
            )
            if not changed:
                contract = old
        except Exception:
            changed = True

    if changed:
        atomic(state, contract)

    # Expose publisher state immediately in the same dashboard refresh.
    cms_bot['contract_publish'] = {
        'status': 'PUBLISHED',
        'message': 'Đã publish CMS success mới nhất hôm nay cho T24 Timeout (schema tương thích v0.0.25)',
        'bot_name': contract.get('bot_name'),
        'published': changed,
        'contract_path': str(state),
        'run_id': contract.get('run_id'),
        'business_date': contract.get('business_date'),
        'published_at': contract.get('published_at'),
        'output_path': contract['resources']['cms_on_hold_export_csv']['path'],
        'output_size': contract['resources']['cms_on_hold_export_csv']['file_size'],
    }
    latest = cms_bot.get('latest') or {}
    if latest.get('run_id') == run.get('run_id'):
        latest.setdefault('resources', {})['contract'] = meta(state)
    return cms_bot['contract_publish']
