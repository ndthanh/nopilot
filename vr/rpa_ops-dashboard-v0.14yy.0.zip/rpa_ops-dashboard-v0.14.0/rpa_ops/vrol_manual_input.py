"""VROL input chosen by the user on the dashboard (09_chargeback_classified.xlsx + input.txt).

The pair is frozen into the same immutable bundle format as the FC + GUID2PAN
handoff (schema vrol-input/1), so the bot validates both paths identically.
Differences: origin=MANUAL_USER_SELECTED, lineage ids 'MANUAL:<file>', and the
workbook entry keeps source_path so the bot writes AK/AL/AM back to the chosen 09 file.
"""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

from .utils import atomic
from .vrol_handoff import VIETNAM, digest, mapping_file, workbook_guids

ORIGIN = 'MANUAL_USER_SELECTED'


def check(workbook, mapping):
    """Validate the pair without copying anything. Returns a report the UI can show."""
    report = dict(ok=False, errors=[], warnings=[], workbook=str(workbook or ''), mapping=str(mapping or ''))
    wb, mp = Path(str(workbook or '').strip().strip('"')), Path(str(mapping or '').strip().strip('"'))
    if not wb.is_file() or wb.suffix.lower() not in {'.xlsx', '.xlsm'}:
        report['errors'].append('Không tìm thấy file 09 (.xlsx)')
    if not mp.is_file() or mp.suffix.lower() != '.txt':
        report['errors'].append('Không tìm thấy file GUID|PAN (.txt)')
    if report['errors']:return report
    report.update(workbook=str(wb.resolve()), mapping=str(mp.resolve()))
    try:guids = workbook_guids(wb)
    except (OSError, ValueError, KeyError) as exc:
        report['errors'].append('File 09 không hợp lệ: ' + str(exc));return report
    try:pans = mapping_file(mp)
    except (OSError, ValueError, UnicodeError) as exc:
        report['errors'].append('File input.txt không hợp lệ: ' + str(exc));return report
    missing = sorted(guids - pans.keys())
    report.update(eligible_guids=len(guids), mapping_guids=len(pans), missing_guids=len(missing), missing_sample=missing[:10],
                  visa_pan_guids=sum(1 for g in guids if pans.get(g, '').startswith('4')))
    # Same rule as the bot: a few unmapped GUIDs are excluded, many mean a wrong file.
    if missing and len(missing) > max(2, 0.2 * max(1, len(guids))):
        report['errors'].append(f'input.txt thiếu PAN cho {len(missing)}/{len(guids)} GUID đủ điều kiện: có thể chọn nhầm file')
    elif missing:
        report['warnings'].append(f'{len(missing)} GUID không có PAN sẽ bị loại khỏi run')
    if not guids:report['warnings'].append('File 09 không có GUID đủ điều kiện (SALE, VALID CHARGEBACK=Y, code 10.4/13.1/13.9)')
    try:
        with wb.open('r+b'):pass
    except OSError:
        report['warnings'].append('File 09 đang mở (Excel?). Bot vẫn chạy được nhưng chỉ ghi AK/AL/AM khi file được đóng')
    report['ok'] = not report['errors']
    return report


def publish(vrol_root, workbook, mapping, *, contract_dir=None):
    """Freeze the checked pair into <ops_inputs>/manual_<stamp>_<hash>/ and return its manifest path."""
    report = check(workbook, mapping)
    if not report['ok']:raise ValueError('; '.join(report['errors']))
    wb, mp = Path(report['workbook']), Path(report['mapping'])
    now = datetime.now(VIETNAM)
    base = Path(contract_dir).resolve() if contract_dir else Path(vrol_root).resolve() / 'runtime' / 'ops_inputs'
    base.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256((digest(wb) + '|' + digest(mp)).encode()).hexdigest()[:12]
    bundle_id = 'manual_' + now.strftime('%Y%m%d_%H%M%S') + '_' + key
    folder = base / bundle_id
    if (folder / 'manifest.json').is_file():
        # Same files (sha256 in the name) submitted twice within one second: reuse the frozen bundle.
        return folder / 'manifest.json', json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    temp = Path(tempfile.mkdtemp(prefix='.pending_', dir=base))
    try:
        files = {}
        for name, source, target in [('workbook', wb, '09_chargeback_classified.xlsx'), ('mapping', mp, 'input.txt')]:
            before = digest(source);shutil.copyfile(source, temp / target)
            if digest(temp / target) != before:raise ValueError('INPUT_CHANGED_DURING_SNAPSHOT:' + name)
            files[name] = dict(path=str(folder / target), sha256=before, size=(temp / target).stat().st_size, source_path=str(source))
        contract = dict(schema='vrol-input/1', status='READY', origin=ORIGIN, bundle_id=bundle_id, business_date=now.date().isoformat(),
                        source_fc_run_id='MANUAL:' + wb.name, source_guid2pan_run_id='MANUAL:' + mp.name,
                        published_at=now.isoformat(timespec='seconds'), check=report, files=files)
        atomic(temp / 'manifest.json', contract)
        temp.rename(folder)
    finally:
        if temp.exists() and temp.parent.resolve() == base.resolve() and temp.name.startswith('.pending_'):shutil.rmtree(temp)
    return folder / 'manifest.json', contract


PICKER = r'''
import sys, tkinter as tk
from tkinter import filedialog
root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
kind = sys.argv[1]
types = [('Excel 09', '*.xlsx *.xlsm')] if kind == 'workbook' else [('GUID|PAN', '*.txt')]
title = 'Chọn file 09_chargeback_classified.xlsx' if kind == 'workbook' else 'Chọn file input.txt (GUID|PAN)'
path = filedialog.askopenfilename(title=title, filetypes=types + [('Tất cả', '*.*')], initialdir=sys.argv[2] or None)
sys.stdout.write(path or '')
'''


def pick(kind, initial=''):
    """Native Windows file dialog on the dashboard PC (the dashboard runs locally)."""
    if kind not in {'workbook', 'mapping'}:raise ValueError('kind must be workbook or mapping')
    start = Path(initial).parent if initial and Path(initial).parent.is_dir() else ''
    done = subprocess.run([sys.executable, '-c', PICKER, kind, str(start)], capture_output=True, text=True, timeout=600,
                          creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    return done.stdout.strip().replace('/', '\\') if sys.platform == 'win32' else done.stdout.strip()
