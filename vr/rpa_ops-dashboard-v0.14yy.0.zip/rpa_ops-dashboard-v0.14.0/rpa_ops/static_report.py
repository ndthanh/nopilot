from __future__ import annotations
import html,json,os
from pathlib import Path

STATIC=Path(__file__).resolve().parent.parent/'static'

def _inline(text,tag):
    # Prevent the inlined asset from closing its own <script>/<style> element.
    return text.replace('</'+tag,'<\\/'+tag)

def render(payload,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    from .vrol_export import publish
    visa=(payload.get('bots') or {}).get('vrol_master')
    if visa:publish(visa,out)
    css=_inline((STATIC/'app.css').read_text(encoding='utf-8'),'style')
    js=_inline((STATIC/'app.js').read_text(encoding='utf-8'),'script')
    data=json.dumps(payload,ensure_ascii=False).replace('</','<\\/')
    title=html.escape(str(payload.get('title') or 'RPA Tra Soát'))
    doc=(
        '<!doctype html><html lang="vi"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{title}</title><style>{css}</style></head><body><div id="app"></div>'
        f'<script>window.RPA_DATA={data};window.RPA_READONLY=true;</script>'
        f'<script>{js}</script></body></html>'
    )
    t=out/'index.html.tmp';t.write_text(doc,encoding='utf-8-sig');os.replace(t,out/'index.html')
