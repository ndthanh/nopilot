from datetime import datetime
from pathlib import Path
from ..utils import read_jsonl,meta
SUCCESS_EVENTS={'run_end','conversion_result','output_file_stable'}
FAIL_EVENTS={'run_failed','flow_failed','guid_full_flow_failed','conversion_failed','fatal_error','run_error'}
def ts(x):return (x or {}).get('ts') or (x or {}).get('timestamp') or (x or {}).get('time')
def success(x):return x.get('event') in SUCCESS_EVENTS and (x.get('ok') is True or str(x.get('status','')).upper()=='SUCCESS' or str(x.get('state','')).lower()=='completed')
def failure(x):return x.get('event') in FAIL_EVENTS or str(x.get('status','')).upper() in {'FAILED','ERROR'} or bool(x.get('error_message'))
def _one(log):
 e=read_jsonl(log);start=next((x for x in e if x.get('event')=='run_start'),None);end=next((x for x in reversed(e) if x.get('event')=='run_end'),None);ok=next((x for x in reversed(e) if success(x)),None);bad=next((x for x in reversed(e) if failure(x)),None)
 if ok and bad and e.index(bad)<e.index(ok):bad=None
 status='FAILED' if bad else ('SUCCESS' if ok else 'RUNNING')
 stem=log.stem.replace('guid2pan_','');rid=stem or str(ts(start) or log.stat().st_mtime)
 input_file=next((x.get('input_file') for x in reversed(e) if x.get('input_file')),None)
 output=next((x.get('output_file') or x.get('file_path') for x in reversed(e) if x.get('output_file') or (x.get('event') in {'conversion_result','output_file_stable'} and x.get('file_path'))),None)
 terminal=end or ok or bad
 return {'run_id':rid,'status':status,'started_at':ts(start) or datetime.fromtimestamp(log.stat().st_mtime).astimezone().isoformat(),'completed_at':ts(terminal) if status!='RUNNING' else None,'error':(bad or {}).get('error_message') or (bad or {}).get('error'),'resources':{'input_txt':meta(input_file),'final_output':meta(output),'process_log':meta(log),'run_directory':meta(log.parent)},'metrics':{'event_count':len(e),'last_event':(e[-1].get('event') if e else None),'terminal_event':(terminal or {}).get('event'),'output_size_bytes':(terminal or {}).get('output_size_bytes') or (terminal or {}).get('size_bytes'),'output_elapsed_sec':(terminal or {}).get('output_elapsed_sec') or (terminal or {}).get('elapsed_sec'),'disconnect_status':(end or {}).get('disconnect_status'),'auto_run':(start or {}).get('auto_run')}}
def one(log):
 run=_one(log)
 source=next((x.get('source_fc_run_id') or x.get('fc_run_id') for x in reversed(read_jsonl(log)) if x.get('source_fc_run_id') or x.get('fc_run_id')),None)
 run['metrics']['source_fc_run_id']=source
 return run

def startup_fallback(root):
 log=root/'bootstrap_log'/'guid2pan_startup.jsonl';e=read_jsonl(log)
 st=next((x for x in reversed(e) if x.get('event')=='flow_process_started'),None)
 if not st:return None
 # Startup log is only a pre-run fallback. Once any per-run log exists, it is authoritative.
 normal=list((root/'logs').glob('guid2pan_*.jsonl')) if (root/'logs').is_dir() else []
 if normal:return None
 rid='startup_'+str(ts(st) or '').replace('-','').replace(':','').replace('T','_')[:15]
 return {'run_id':rid,'status':'RUNNING','started_at':ts(st),'completed_at':None,'error':None,'resources':{'input_txt':meta(root/'input.txt'),'final_output':meta(None),'process_log':meta(log),'run_directory':meta(root)},'metrics':{'last_event':e[-1].get('event') if e else None,'startup_only':True}}
def parse(root):
 ld=root/'logs';files=sorted(ld.glob('guid2pan_*.jsonl'),key=lambda x:x.stat().st_mtime,reverse=True)[:50] if ld.is_dir() else [];runs=[one(x) for x in files];fallback=startup_fallback(root)
 if fallback:runs.insert(0,fallback)
 return {'display_name':'CMS Convert GUID → PAN','root_path':str(root),'runs':runs,'latest':runs[0] if runs else {'status':'NOT_FOUND','resources':{},'metrics':{}},'configured_input':meta(root/'input.txt'),'configured_command':meta(root/'run_guid2pan.bat'),'log_source':str(ld/'guid2pan_YYYYMMDD_HHMMSS.jsonl')}
