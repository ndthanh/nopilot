import json
from datetime import datetime
from pathlib import Path
from ..utils import read_jsonl,meta
def _ts(x):return (x or {}).get('ts') or (x or {}).get('timestamp')
def parse(root):
 runs=[];ld=root/'log'
 if ld.is_dir():
  for day in sorted(ld.glob('20*'),reverse=True)[:7]:
   for q in sorted(day.glob('log_*.txt'),key=lambda x:x.stat().st_mtime,reverse=True):
    e=read_jsonl(q);s=next((x for x in reversed(e) if x.get('event')=='run_success'),None);f=next((x for x in reversed(e) if x.get('event') in {'run_failed','attempt_failed'}),None);st=next((x for x in e if x.get('event') in {'run_start','run_started'}),None);x=s or f or st or {};status='SUCCESS' if s else ('FAILED' if f else 'RUNNING');fallback=datetime.fromtimestamp(q.stat().st_mtime).astimezone().isoformat()
    runs.append({'run_id':f'{day.name}_{q.stem}','status':status,'started_at':_ts(st) or fallback,'completed_at':_ts(x) or fallback,'error':x.get('error_message') or x.get('error'),'resources':{'main_output':meta(x.get('output_path')),'process_log':meta(q)},'metrics':{'attempt':x.get('attempt'),'output_size':x.get('output_size')}})
 state=root/'state'/'latest_success.json';latest=runs[0] if runs else {'status':'NOT_FOUND','resources':{},'metrics':{}}
 if state.is_file():
  try:
   d=json.loads(state.read_text(encoding='utf-8-sig'));r=(d.get('resources') or {}).get('cms_on_hold_export_csv') or {};latest={'run_id':d.get('run_id'),'status':'SUCCESS','started_at':d.get('started_at') or d.get('completed_at'),'completed_at':d.get('completed_at'),'error':None,'resources':{'main_output':meta(r.get('path')),'contract':meta(state)},'metrics':{'output_size':r.get('file_size')}}
  except:pass
 return {'display_name':'CMS On-Hold Report','root_path':str(root),'runs':runs[:50],'latest':latest}
