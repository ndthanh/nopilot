import json
from datetime import datetime,timezone
from ..utils import read_jsonl,latest,meta
def _json(p):
 try:return json.loads(p.read_text(encoding="utf-8-sig")) if p.is_file() else {}
 except:return {}
def _one(p):
 e=read_jsonl(p/'logs'/'run.jsonl');st=latest(e,'run_started');done=latest(e,'run_completed') or latest(e,'classification_completed');fail=latest(e,'run_failed');summary=_json(p/'manifests'/'result_summary.json');out=p/'outputs'/'09_CHARGEBACK_CLASSIFIED.xlsx'
 # A saved result summary/output is authoritative completion evidence even if the final JSONL line was missed.
 if not done and summary and out.is_file():done={'event':'run_completed','timestamp':datetime.fromtimestamp(out.stat().st_mtime).astimezone().isoformat(),**summary}
 status='SUCCESS' if done else ('FAILED' if fail else 'RUNNING');x=done or fail or st or {}
 handoff=_json(p/'handoff'/'guid2pan_handoff.json')
 return {'run_id':p.name,'status':status,'started_at':(st or {}).get('timestamp'),'completed_at':x.get('timestamp'),'error':(fail or {}).get('error_message'),'resources':{'upstream_input':meta((st or {}).get('input_path')),'final_output':meta((done or {}).get('final_output_path') or (out if out.is_file() else None)),'guid2pan_input':meta(handoff.get('working_input')),'guid2pan_input_snapshot':meta(handoff.get('snapshot_input')),'input_contract':meta(p/'manifests'/'input_contract.json'),'result_summary':meta(p/'manifests'/'result_summary.json'),'process_log':meta(p/'logs'/'run.jsonl'),'run_directory':meta(p)},'metrics':{'source_t24_run_id':(done or st or {}).get('source_t24_run_id'),'processed_rows':(done or {}).get('processed_rows'),'eligible_104':(done or {}).get('eligible_104'),'eligible_131':(done or {}).get('eligible_131'),'eligible_139':(done or {}).get('eligible_139'),'rejected_rows':(done or {}).get('rejected_rows')}}
def one(p):
 run=_one(p);events=read_jsonl(p/'logs'/'run.jsonl')
 trigger=latest(events,'guid2pan_trigger_started') or {}
 done=latest(events,'guid2pan_input_preparation_completed') or {}
 run['metrics'].update(guid2pan_trigger_started_at=trigger.get('timestamp') or trigger.get('ts'),guid2pan_trigger_completed_at=done.get('timestamp') or done.get('ts'))
 return run

def parse(root):
 rd=root/'runs';ps=sorted([x for x in rd.iterdir() if x.is_dir()],key=lambda x:x.stat().st_mtime,reverse=True)[:50] if rd.is_dir() else [];runs=[one(x) for x in ps];return {'display_name':'Phân loại Fraud','root_path':str(root),'runs':runs,'latest':runs[0] if runs else {'status':'NOT_FOUND','resources':{},'metrics':{}}}
