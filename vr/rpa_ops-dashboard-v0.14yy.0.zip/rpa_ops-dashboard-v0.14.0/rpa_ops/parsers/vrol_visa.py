"""Read Visa async artifacts without opening Chrome or modifying the run."""
import json
import os
from collections import Counter
from datetime import datetime, timedelta, timezone
from ..utils import meta

VIETNAM = timezone(timedelta(hours=7))


def read(path):
    try:return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):return {}


def alive(pid):
    if not pid:return False
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, int(pid))
        if not handle:return None if ctypes.get_last_error() == 5 else False
        try:
            code = wintypes.DWORD()
            return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code)) and code.value == 259)
        finally:kernel.CloseHandle(handle)
    try:os.kill(int(pid), 0); return True
    except (OSError, ValueError):return False


# A finished run that only leaves GUIDs for user review is a normal, green outcome.
V2_STATUS = {'SUCCESS': 'SUCCESS', 'SUCCESS_WITH_REVIEWS': 'COMPLETED_WITH_REVIEWS', 'COMPLETED_WITH_ISSUES': 'COMPLETED_WITH_REVIEWS',
             'COMPLETED': 'SUCCESS', 'FAILED': 'FAILED', 'RUNNING': 'RUNNING', 'WAITING_OTP': 'WAITING_OTP'}


def one_v2(folder, live):
    """Contract v2: the bot publishes one small dashboard_status.json per run."""
    status = V2_STATUS.get(live.get('status'), live.get('status') or 'RUNNING')
    if status in {'RUNNING', 'WAITING_OTP'}:
        try:stale = (datetime.now(VIETNAM)-datetime.fromisoformat(live.get('updated_at'))).total_seconds() > 120
        except (ValueError, TypeError):stale = True
        if stale and alive(live.get('pid')) is False:
            status = 'FAILED'; live = dict(live, error=live.get('error') or 'PROCESS_STOPPED_WITHOUT_SUMMARY_REVIEW_CHECKPOINTS')
    files = live.get('files') or {}
    resources = {key: meta(path) for key, path in files.items()}
    resources.update(run_directory=meta(folder), summary=meta(folder/'async_summary.json'), run_state=meta(folder/'run_state.json'),
                     activity_report=meta(folder/'activity_report.jsonl'), dashboard_status=meta(folder/'dashboard_status.json'),
                     final_output=meta(files.get('output_workbook')), process_log=meta(files.get('console_log') or folder/'console.log'),
                     pi_documents=meta(files.get('documents')), guid_groups=meta(files.get('groups')),
                     review_required_cases=meta(files.get('review_required')), guid_outcomes_csv=meta(files.get('guid_outcomes')),
                     source_fc_workbook=meta((live.get('input') or {}).get('workbook')), input_guid_pan_mapping=meta((live.get('input') or {}).get('mapping')))
    p, b, q = live.get('progress') or {}, live.get('buckets') or {}, live.get('queue') or {}
    metrics = dict(group_count=q.get('total'), completed_groups=p.get('done'), worker_count=(live.get('mode') or {}).get('workers'),
                   pi_guid_count=b.get('pi', 0), no_cb_count=b.get('no_cb', 0), existing_cb_count=b.get('existing_cb', 0) + (q.get('existing_cb_rol500') or 0),
                   awaiting_final_submit_count=b.get('draft', 0), final_submitted_count=b.get('submitted', 0),
                   needs_user_review_count=b.get('review', 0), retry_later_count=b.get('retry_later', 0),
                   final_submit_enabled=(live.get('mode') or {}).get('final_submit_enabled', False), stage=live.get('stage'),
                   guids_per_min=p.get('guids_per_min'), eta_seconds=p.get('eta_seconds'), session_restarts=(live.get('session') or {}).get('restarts'))
    guid_results = [dict(guid=r.get('guid'), category=r.get('bucket'), status=r.get('status'), label=r.get('label'), reason_code=r.get('reason_code'),
                         rol=r.get('rol'), needs_user_review=r.get('bucket') == 'review', folder=r.get('folder'),
                         screenshots=[r['screenshot']] if r.get('screenshot') else []) for r in live.get('rows') or []]
    return dict(run_id=folder.name, status=status, started_at=live.get('started_at') or datetime.fromtimestamp(folder.stat().st_mtime, VIETNAM).isoformat(),
                completed_at=live.get('completed_at'), error=live.get('error'), resources=resources, metrics=metrics,
                guid_results=guid_results, contract='vrol-dashboard/2', live={k: v for k, v in live.items() if k != 'rows'})


def one(folder):
    live = read(folder/'dashboard_status.json')
    if live.get('schema') == 'vrol-dashboard/2':return one_v2(folder, live)
    summary = read(folder/'async_summary.json'); state = read(folder/'run_state.json')
    combined=read(folder/'consolidated'/'summary.json')
    outcomes = read(folder/'guid_outcomes.json'); contract = summary.get('input_contract') or read(folder/'input_contract.json')
    records = outcomes.get('records') or []
    if combined:
        records=read(folder/'consolidated'/'guid_results.json') or []
        outcomes={};summary=dict(summary,group_count=combined['queued'])
    if not records:
        for group_dir in (folder/'groups').iterdir() if (folder/'groups').is_dir() else []:
            if not group_dir.is_dir():continue
            record=read(group_dir/'guid_result.json')
            if not record:
                record=read(group_dir/'guid_state.json');case=read(group_dir/'case_checkpoint.json')
                if not record:continue
                record.update(status='RUNNING',folder=str(group_dir),rol=case.get('rol'),action_stage=case.get('stage') or record.get('stage'),category='IN_PROGRESS')
            records.append(record)
    queue=read(folder/'queue_manifest.json')
    known={r.get('guid') for r in records}
    for item in queue if isinstance(queue,list) else []:
        if item.get('guid') not in known:records.append(dict(guid=item['guid'],status='QUEUED',category='PENDING',action_stage='WAITING_WORKER'))
    status = state.get('status') or 'RUNNING'
    review_count = outcomes.get('needs_user_review_count', sum(bool(r.get('needs_user_review') or r.get('review_required') or (r.get('outcome') or {}).get('needs_user_review')) for r in records))
    if summary and status != 'FAILED':
        status = 'COMPLETED_WITH_REVIEWS' if summary.get('status') in {'COMPLETED_WITH_ISSUES','SUCCESS_WITH_REVIEWS'} or review_count else 'SUCCESS'
    elif status in {'RUNNING','WAITING_OTP'}:
        try:recent = (datetime.now(VIETNAM)-datetime.fromisoformat(state.get('heartbeat_at'))).total_seconds() < 120
        except (ValueError, TypeError):recent = False
        if (state and alive(state.get('pid')) is False) or (not state and datetime.now().timestamp()-folder.stat().st_mtime > 120):
            status = 'FAILED'; state['error'] = 'PROCESS_STOPPED_WITHOUT_SUMMARY_REVIEW_CHECKPOINTS'
    if status=='FAILED':
        for record in records:
            if record.get('status') in {'RUNNING','QUEUED'}:
                record.update(status='INTERRUPTED_REVIEW_REQUIRED' if record['status']=='RUNNING' else 'NOT_PROCESSED',needs_user_review=True)
    resources = {
        'input_contract':meta(folder/'input_contract.json'),
        'guid_request':meta(folder/'guid_request.json'),
        'requested_guid_report':meta(folder/'requested_guid_report.csv'),
        'requested_guid_report_json':meta(folder/'requested_guid_report.json'),
        'source_fc_workbook':meta(state.get('input_workbook') or ((contract.get('files') or {}).get('workbook') or {}).get('path')),
        'input_guid_pan_mapping':meta(state.get('input_mapping') or ((contract.get('files') or {}).get('mapping') or {}).get('path')),
        'final_output':meta(summary.get('output_workbook') or folder/'09_CHARGEBACK_CLASSIFIED_ASYNC_REVIEW.xlsx'),
        'pi_documents':meta(folder/'documents'), 'guid_groups':meta(folder/'groups'),
        'guid_outcomes_csv':meta(folder/'guid_outcomes.csv'), 'guid_outcomes_json':meta(folder/'guid_outcomes.json'),
        'review_required_cases':meta(folder/'review_required_cases.csv'), 'review_holds':meta(folder/'review_holds.json'),
        'rol500_postflight_csv':meta((summary.get('rol500_postflight') or {}).get('csv_path')),
        'rol500_reconciliation_csv':meta(folder/'postflight'/'rol500_reconciliation.csv'),
        'summary':meta(folder/'async_summary.json'), 'run_state':meta(folder/'run_state.json'),
        'activity_report':meta(folder/'activity_report.jsonl'), 'process_log':meta(folder/'console.log' if (folder/'console.log').is_file() else folder/'run.log'), 'run_directory':meta(folder)}
    stats = outcomes.get('category_counts') or (summary.get('guid_outcomes') or {}).get('category_counts') or {}
    if combined:
        stats=combined['category_counts']
        resources.update(final_output=meta(folder/'consolidated'/'09_CHARGEBACK_CLASSIFIED_FINAL.xlsx'),pi_documents=meta(folder/'consolidated'/'documents'),
                         guid_outcomes_csv=meta(folder/'consolidated'/'all_guid_results.csv'),review_required_cases=meta(folder/'consolidated'/'review_required.csv'))
    if not stats:stats=dict(Counter((r.get('outcome') or r).get('category') for r in records if (r.get('outcome') or r).get('category')))
    confirmed = sum(bool((r.get('outcome') or r).get('final_submit_confirmed')) for r in records)
    metrics = dict(request_mode=state.get('request_mode'),request_id=state.get('request_id'),requested_guid_count=state.get('requested_guid_count'),source_fc_run_id=contract.get('source_fc_run_id'), source_guid2pan_run_id=contract.get('source_guid2pan_run_id'),
                   group_count=summary.get('group_count', state.get('group_count')), completed_groups=sum(r.get('status') not in {'RUNNING','QUEUED'} for r in records),
                   worker_count=summary.get('worker_count',state.get('worker_count')), pi_guid_count=stats.get('PI_DOWNLOADED',0),
                   pi_pdf_count=combined.get('pi_pdfs') if combined else len(list((folder/'documents').glob('*.pdf'))), no_cb_count=stats.get('NO_CHARGEBACK',0),
                   fraud_count=stats.get('FRAUD',0), consumer_count=stats.get('CONSUMER',0),
                   review_required_count=stats.get('REVIEW_REQUIRED',0), needs_user_review_count=review_count,
                   historical_registry_only=combined.get('historical_registry_only',0),
                   awaiting_final_submit_count=outcomes.get('awaiting_final_submit_count',sum(bool((r.get('outcome') or r).get('awaiting_final_submit')) for r in records)), final_submitted_count=confirmed,
                   held_guid_count=(summary.get('input_stats') or {}).get('review_hold_groups_skipped',0),
                   final_submit_enabled=summary.get('final_submit_enabled',state.get('final_submit_enabled',False)), stage=state.get('stage'),otp_folder=state.get('otp_folder'),
                   rol500_postflight_status=(summary.get('rol500_postflight') or {}).get('status'))
    reconciliation=read(folder/'postflight'/'rol500_reconciliation.json')
    by_guid={}
    for row in reconciliation.get('rows',[]):by_guid.setdefault(row.get('guid'),[]).append(row)
    guid_results=[]
    for record in records:
        outcome=record.get('outcome') or record; result=record.get('result') or record
        post=by_guid.get(record.get('guid'),[])
        guid_results.append(dict(guid=record.get('guid'),category=outcome.get('category'),status=result.get('status'),
                                 reason_code=result.get('reason_code'),rol=result.get('rol') or result.get('vrol_case_number'),
                                 needs_user_review=bool(outcome.get('needs_user_review') or record.get('review_required') or any(x.get('needs_review') for x in post)),
                                 action_stage=outcome.get('action_stage'),folder=record.get('folder'),screenshots=record.get('screenshots') or [],
                                 rol500_post_status=' | '.join(sorted({x['status'] for x in post})),reported_rol_cases=sorted({rol for x in post for rol in x['rol_cases']})))
    for guid, hold in read(folder/'review_holds.json').items():
        if not any(x['guid']==guid for x in guid_results):
            guid_results.append(dict(guid=guid,category='REVIEW_REQUIRED',status='HOLD_REVIEW_EXISTING_CASE',reason_code=hold.get('reason_code'),
                                     rol=hold.get('rol'),needs_user_review=True,folder=hold.get('folder'),screenshots=hold.get('screenshots') or []))
    metrics['needs_user_review_count']=sum(x['needs_user_review'] for x in guid_results)
    return dict(run_id=folder.name, status=status, started_at=state.get('started_at') or summary.get('started_at') or datetime.fromtimestamp(folder.stat().st_mtime,VIETNAM).isoformat(),
                completed_at=summary.get('completed_at') or state.get('completed_at'), error=state.get('error'), resources=resources, metrics=metrics,guid_results=guid_results)


def parse(root,limit=50):
    directory = root/'runtime'/'async_parallel'
    folders = sorted((p for p in directory.iterdir() if p.is_dir()), key=lambda p:p.name, reverse=True)[:limit] if directory.is_dir() else []
    runs = [one(p) for p in folders]
    return dict(display_name='VROL Visa', root_path=str(root), runs=runs,
                latest=runs[0] if runs else dict(status='NOT_FOUND',resources={},metrics={}))
