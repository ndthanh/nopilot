from pathlib import Path
from openpyxl import load_workbook
from ..utils import read_jsonl,latest,meta

def first_path(event):
    if not event:return None
    for key in ('path','input_path','selected_path','source_path','file_path','cms_on_hold_path','resource_path'):
        if event.get(key):return event.get(key)
    resource=event.get('resource') or {}
    return resource.get('path') if isinstance(resource,dict) else None

def one(p):
    log=p/'logs'/'run.jsonl';e=read_jsonl(log)
    st=latest(e,'run_started');done=latest(e,'full_pipeline_completed');fail=latest(e,'run_failed')
    cms=latest(e,'cms_on_hold_mapping_completed') or {};brd=latest(e,'brd_2_1_1_completed') or {};cl=latest(e,'transaction_classification_completed') or {}
    upstream=latest(e,'upstream_resource_selected') or latest(e,'cms_on_hold_resource_selected') or latest(e,'input_selected') or {}
    input_path=first_path(upstream) or (st or {}).get('input_path')
    status='SUCCESS' if done else ('FAILED' if fail else 'RUNNING')
    final=(done or {}).get('final_output_path') or cms.get('output_path')
    resources={'upstream_input':meta(input_path),'final_output':meta(final),'process_log':meta(log),'run_directory':meta(p)}
    return {'run_id':p.name,'status':status,'started_at':(st or {}).get('timestamp'),'completed_at':(done or fail or {}).get('timestamp'),'error':(fail or {}).get('error_message'),'resources':resources,'metrics':{'accepted_rows':brd.get('accepted_rows'),'rejected_rows':brd.get('rejected_rows'),'classified_rows':cl.get('classified_count') or cl.get('processed_row_count'),'revert':cms.get('mapped_revert_count'),'cancel':cms.get('mapped_cancel_count'),'hold':cms.get('mapped_hold_count'),'sale':cms.get('mapped_sale_count')}}

def _cumulative(root):
    cfg=root/'config.xlsx'
    if not cfg.is_file():return None
    try:
        wb=load_workbook(cfg,read_only=True,data_only=True);ws=wb['CONFIG_GENERAL']
        for row in ws.iter_rows(values_only=True):
            if str(row[0] or '').strip().upper()=='CUMULATIVE_FILE_PATH':
                raw=str(row[1] or '').strip();q=Path(raw);return q if q.is_absolute() else cfg.parent/q
    except:pass
    return None

def parse(root):
    rd=root/'runs';ps=sorted([x for x in rd.iterdir() if x.is_dir()],key=lambda x:x.stat().st_mtime,reverse=True)[:50] if rd.is_dir() else []
    runs=[one(x) for x in ps]
    
    result={'display_name':'T24 Timeout','root_path':str(root),'runs':runs,'latest':runs[0] if runs else {'status':'NOT_FOUND','resources':{},'metrics':{}}}
    cumulative=_cumulative(root)
    if cumulative:result['configured_inputs']={'cumulative_file':meta(cumulative),'config_key':'CUMULATIVE_FILE_PATH'}
    return result
