@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" -m rpa_ops.production_setup %*
exit /b %ERRORLEVEL%
