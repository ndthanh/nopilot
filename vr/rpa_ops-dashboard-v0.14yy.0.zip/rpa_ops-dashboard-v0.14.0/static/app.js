/* RPA Ops dashboard. Shared by the Flask UI and the static snapshot (window.RPA_READONLY). */
(() => {
'use strict';

const READONLY = !!window.RPA_READONLY;
let DATA = window.RPA_DATA || { bots: {} };
let selectedBot = null;
let visaGuidDraft = '';
let currentTab = 'runs';
let logTimer = null, logOffset = 0, logRunKey = '', logBusy = false;
let visaFilter = 'all', visaPollSeconds = 5, visaBusy = false, visaPage = 0, visaSearch = '';
let vrolBucket = 'all';
const vrolModeLabel = () => ({ FULL: 'Đầy đủ: tạo case theo rule, Final Submit theo Thiết lập chạy VROL', PI_ONLY: 'Chỉ tải chứng từ (PI = Yes): không tạo case' })[($('vrolRunMode') || {}).value || 'FULL'];
const vrolModeValue = () => ($('vrolRunMode') || {}).value || 'FULL';

const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const go = p => { location.hash = '#' + p; };

/* ---------- formatting ---------- */
const fmt = v => {
  if (!v) return '-';
  const d = new Date(v);
  if (isNaN(d)) return String(v);
  return new Intl.DateTimeFormat('vi-VN', { dateStyle: 'short', timeStyle: 'medium' }).format(d);
};
const sizeOf = n => {
  let x = Number(n);
  if (n == null || !Number.isFinite(x)) return '-';
  for (const u of ['B', 'KB', 'MB', 'GB', 'TB']) {
    if (x < 1024 || u === 'TB') return `${u === 'B' ? x : x.toFixed(1)} ${u}`;
    x /= 1024;
  }
};

/* ---------- icons (lucide paths) ---------- */
const ICONS = {
  activity: '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  sliders: '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3"/>',
  folder: '<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  file: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  back: '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  alert: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  check: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  pointer: '<path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>',
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

/* ---------- status -> tone ---------- */
const TONES = { SUCCESS: 'success', COMPLETED_WITH_REVIEWS: 'success', ON_TRACK: 'success', RECOVERED: 'success', FAILED: 'danger', ATTENTION: 'danger', ACTION_REQUIRED: 'danger', RUNNING: 'info', WAITING_OTP: 'warn', READY: 'info', WAITING_INPUT: 'warn', COMPLETED_WITH_ISSUES: 'warn', WAITING_FOR_RETRY: 'warn' };
const isActive = status => ['RUNNING', 'WAITING_OTP'].includes(status);
const TONE_ICON = { success: 'check', danger: 'alert', info: 'info', warn: 'clock', neutral: 'info' };
const tone = s => TONES[s] || 'neutral';
const badge = s => `<span class="badge badge-${tone(s)}"><i class="dot"></i>${esc(String(s ?? 'UNKNOWN').replaceAll('_', ' '))}</span>`;
const PLACEHOLDER_BOTS = ['vrol_master'];

/* ---------- shell ---------- */
function buildShell() {
  document.title = DATA.title || 'RPA Ops';
  $('app').innerHTML = `
<div class="page">
  <header class="topbar">
    <div class="brand">
      <div class="logo">${ic('activity')}</div>
      <div><h1 id="mainTitle"></h1><p>Theo dõi kết quả vận hành bot trong ngày · v0.14.0</p></div>
    </div>
    <div class="topbar-actions">
      <span class="small muted" id="updated"></span>
      ${READONLY
        ? '<span class="badge badge-outline badge-neutral">Read-only snapshot</span>'
        : `<button type="button" class="btn btn-outline" data-action="schedules">${ic('clock')}Lịch chạy</button>
           <button type="button" class="btn btn-outline" data-action="settings">${ic('sliders')}Thiết lập</button>
           <button type="button" class="btn btn-outline" id="refreshButton" data-action="refresh">${ic('refresh')}Làm mới</button>`}
    </div>
  </header>
  <main>
    <nav id="flow" class="flow" aria-label="Quy trình bot"></nav>
    <section id="detail">
      <div id="empty" class="empty large">${ic('pointer')}<div>Chọn một giai đoạn phía trên để xem kết quả.</div></div>
      <div id="content" class="card" hidden>
        <div class="card-header">
          <div style="min-width:0">
            <h2 class="card-title" id="title"></h2>
            <div id="root" class="path muted" style="margin-top:4px"></div>
          </div>
          <div class="header-actions">
            <span id="status"></span>
            <button type="button" id="retryButton" class="btn btn-default btn-sm" data-action="retry" hidden></button>
            <button type="button" id="visaChecksButton" class="btn btn-outline btn-sm" data-action="vrol-checks" hidden>Kiểm tra cấu hình &amp; đầu vào</button>
          </div>
        </div>
        <div class="card-content">
          <details id="vrolRunSettings" class="manual-input" hidden>
            <summary>${ic('sliders')}Thiết lập chạy VROL <span class="small muted">(ghi nhớ cho mọi lần chạy sau, kể cả lịch 19:40)</span></summary>
            <div class="manual-grid">
              <label class="label" for="vrolSetFinal">Final Submit</label>
              <select id="vrolSetFinal" class="select"><option value="CONFIG">Theo config.xlsx</option><option value="NO">Tắt: dừng trước Final Submit (case nháp)</option><option value="YES">BẬT: gửi Final Submit thật</option></select>
              <label class="label" for="vrolSetWorkers">Số worker</label>
              <select id="vrolSetWorkers" class="select"><option value="CONFIG">Theo config.xlsx</option>${[1,2,3,4,5,6,7,8,9].map(n => `<option value="${n}">${n} worker</option>`).join('')}</select>
              <label class="label" for="vrolSetHeadless">Trình duyệt</label>
              <select id="vrolSetHeadless" class="select"><option value="CONFIG">Theo config.xlsx</option><option value="HEADFUL">Headful: hiện cửa sổ Chrome</option><option value="HEADLESS">Headless: Chrome chạy ẩn</option></select>
            </div>
            <div class="pick-actions"><button type="button" class="btn btn-default btn-sm" data-action="vrol-settings-save">Lưu thiết lập</button><button type="button" class="btn btn-outline btn-sm" data-action="vrol-settings-reset">Dùng lại config.xlsx cho cả 3</button></div>
            <div id="vrolSettingsInfo" class="help small muted"></div>
          </details>
          <div id="vrolModeRow" class="retry-row" hidden>
            <label class="label" for="vrolRunMode">Chế độ chạy VROL</label>
            <select id="vrolRunMode" class="select">
              <option value="FULL">Đầy đủ: tra cứu, tải PI, tạo case (Final Submit theo Thiết lập chạy VROL)</option>
              <option value="PI_ONLY">Chỉ tải chứng từ (PI = Yes): không bấm Issuer Action, không tạo case</option>
            </select>
            <div class="help small muted">Áp dụng cho cả 3 cách chạy bên dưới. Chế độ chỉ tải chứng từ vẫn ghi PI / NO_CB / Assoc D / Đã CB vào AM; GUID cần tạo case để trống AM cho run đầy đủ.</div>
          </div>
          <div id="retryInputRow" class="retry-row" hidden>
            <label class="label" for="retryInput">Input dùng để chạy lại</label>
            <select id="retryInput" class="select"></select>
            <div id="retryHelp" class="help small muted"></div>
          </div>
          <div id="visaGuidRequest" class="retry-row" hidden>
            <label class="label" for="visaGuidList">Chạy riêng theo GUID</label>
            <textarea id="visaGuidList" class="select" rows="3" placeholder="Mỗi dòng một GUID; bot tự lấy code và thông tin từ input"></textarea>
            <button type="button" id="visaGuidRunButton" class="btn btn-outline" data-action="vrol-guid-run">Xem trước và chạy danh sách GUID</button>
            <div class="help small muted">Cho phép vượt VALID CHARGEBACK upstream; giữ code trong Excel, rule VROL và bảo vệ case cũ. Có báo cáo riêng cho danh sách này.</div>
          </div>
          <details id="visaManualInput" class="manual-input" hidden>
            <summary>${ic('file')}Chạy VROL với file tự chọn (09 + input.txt)</summary>
            <div class="manual-grid">
              <label class="label" for="vrolWorkbook">File 09_chargeback_classified.xlsx</label>
              <div class="pick-row"><input id="vrolWorkbook" class="input" placeholder="C:\\...\\09_CHARGEBACK_CLASSIFIED.xlsx" autocomplete="off"><button type="button" class="btn btn-outline btn-sm" data-action="vrol-pick" data-kind="workbook">Chọn…</button></div>
              <label class="label" for="vrolMapping">File input.txt (GUID|PAN)</label>
              <div class="pick-row"><input id="vrolMapping" class="input" placeholder="C:\\...\\input.txt" autocomplete="off"><button type="button" class="btn btn-outline btn-sm" data-action="vrol-pick" data-kind="mapping">Chọn…</button></div>
            </div>
            <div class="pick-actions"><button type="button" class="btn btn-outline btn-sm" data-action="vrol-manual-check">Kiểm tra 2 file</button><button type="button" class="btn btn-default btn-sm" id="vrolManualRun" data-action="vrol-manual-run" disabled>${ic('play')}Chạy VROL với 2 file này</button></div>
            <div id="vrolManualReport"></div>
            <div class="help small muted">Dashboard đóng băng bản sao 2 file vào runtime\\ops_inputs\\manual_…; bot ghi kết quả AK/AL/AM ngược vào chính file 09 đã chọn. Final Submit theo Thiết lập chạy VROL.</div>
          </details>
          <div id="banner"></div>
          <div id="summary" class="stats"></div>
          <div id="schedule" class="chips"></div>
          <div>
            <div class="tabs-list" role="tablist">
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="vrol" id="vrolTabButton" hidden>Theo dõi run</button>
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="runs">Runs today</button>
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="inputs">Input</button>
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="outputs">Output</button>
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="overview">Overview</button>
              <button type="button" class="tab" role="tab" data-action="tab" data-tab="logs">Live log</button>
            </div>
          </div>
          <div id="vrol" role="tabpanel" hidden></div>
          <div id="runs" role="tabpanel"></div>
          <div id="inputs" role="tabpanel" hidden></div>
          <div id="outputs" role="tabpanel" hidden></div>
          <div id="overview" role="tabpanel" hidden></div>
          <div id="logs" role="tabpanel" hidden><div class="live-log-toolbar"><span id="logStatus" class="muted">Chọn run để xem log</span><label class="log-follow"><input id="logFollow" type="checkbox" checked> Tự cuộn</label><button class="btn btn-secondary btn-sm" data-action="clear-log">Xóa màn hình</button></div><pre id="liveLog" class="live-log">Chưa có dữ liệu log.</pre></div>
        </div>
      </div>
    </section>
    <section id="settings" class="card" hidden>
      <div class="card-header">
        <div><h2 class="card-title">Thiết lập</h2><p class="card-desc">Các thiết lập RPA-Ops được lưu trong SQLite.</p></div>
        <div class="header-actions"><button type="button" class="btn btn-outline btn-sm" data-action="back">${ic('back')}Quay lại</button></div>
      </div>
      <div class="card-content" id="settingsBody"></div>
    </section>
    <section id="schedules" class="card" hidden>
      <div class="card-header"><div><h2 class="card-title">Lịch chạy Task Scheduler</h2><p class="card-desc">Thư mục \RPA Tra Soat · chỉ đổi tên và giờ, không đổi Action.</p></div><div class="header-actions"><button class="btn btn-outline btn-sm" data-action="open-task-scheduler">Mở Task Scheduler</button><button class="btn btn-outline btn-sm" data-action="reload-schedules">${ic('refresh')}Làm mới</button><button class="btn btn-outline btn-sm" data-action="back">${ic('back')}Quay lại</button></div></div>
      <div class="card-content" id="schedulesBody"></div>
    </section>
  </main>
</div>
<div id="toasts" class="toasts" aria-live="polite"></div>`;
  $('mainTitle').textContent = DATA.title || '';
  renderUpdated();
}
function renderUpdated() {
  $('updated').textContent = DATA.generated_at ? 'Cập nhật: ' + fmt(DATA.generated_at) : '';
}

/* ---------- flow ---------- */
function buildFlow() {
  const ids = (DATA.workflow_order || Object.keys(DATA.bots)).filter(id => DATA.bots[id]);
  $('flow').innerHTML = ids.map((id, i) => {
    const b = DATA.bots[id], o = b.operations || {}, s = o.status || (b.latest || {}).status || 'UNKNOWN';
    return `${i ? `<div class="connector">${ic('chevron')}</div>` : ''}
<button type="button" class="card flow-card" data-action="go" data-go="/bot/${esc(id)}" data-id="${esc(id)}">
  <div class="flow-top"><span class="step">${i + 1}</span>${badge(s)}</div>
  <div class="flow-name">${esc(b.display_name)}</div>
  <div class="flow-stats">
    <div class="flow-stat"><span>Success today</span><strong>${esc(o.success_count ?? '-')}</strong></div>
    <div class="flow-stat"><span>Runs today</span><strong>${esc(o.runs_today ?? '-')}</strong></div>
  </div>
</button>`;
  }).join('');
}
function markActiveCard(id) {
  document.querySelectorAll('.flow-card').forEach(x => {
    const on = x.dataset.id === id;
    x.classList.toggle('active', on);
    if (on) x.setAttribute('aria-current', 'true'); else x.removeAttribute('aria-current');
  });
}

/* ---------- routing ---------- */
function route() {
  const p = location.hash.replace(/^#/, '') || '/overview';
  const isSettings = !READONLY && p === '/settings';
  const isSchedules = !READONLY && p === '/schedules';
  $('detail').hidden = isSettings || isSchedules;
  $('settings').hidden = !isSettings;
  $('schedules').hidden = !isSchedules;
  if (isSettings) { markActiveCard(null); loadSettings(); return; }
  if (isSchedules) { markActiveCard(null); loadSchedules(); return; }
  const m = p.match(/^\/bot\/([^/]+)(?:\/run\/([^/]+))?(?:\/log)?$/);
  if (!m || !DATA.bots[m[1]]) { selectedBot = null; markActiveCard(null); $('empty').hidden = false; $('content').hidden = true; return; }
  renderBot(m[1], m[2] ? decodeURIComponent(m[2]) : null, /\/log$/.test(p));
}

/* ---------- data helpers ---------- */
function todayRuns(b) {
  const t = new Date().toDateString();
  return (b.runs || []).filter(r => { const d = new Date(r.started_at || r.completed_at); return !isNaN(d) && d.toDateString() === t; });
}
function inputEntries(id, r) {
  if (id === 'cms_on_hold') return [];
  if (id === 'fraud_classification') return Object.entries(r.resources || {}).filter(([k, v]) => k === 'upstream_input' && v && /\.xlsx$/i.test(v.path || ''));
  return Object.entries(r.resources || {}).filter(([k]) => /input|source|downloaded|cms_on_hold|manifest|upstream/i.test(k));
}
function outputEntries(id, r) {
  if (id === 'cms_on_hold') return Object.entries(r.resources || {}).filter(([k]) => !/process_log|contract/i.test(k));
  const inputs = new Set(inputEntries(id, r).map(x => x[0]));
  return Object.entries(r.resources || {}).filter(([k]) => !inputs.has(k) && !/process_log|run_directory/i.test(k));
}

/* ---------- bot detail ---------- */
function renderBot(id, rid, openLog = false) {
  selectedBot = id;
  const b = DATA.bots[id], o = b.operations || {};
  const allRuns = Array.isArray(b.runs) ? b.runs : [];
  const r = (rid ? allRuns.find(x => String(x.run_id) === String(rid)) : null) || b.latest || allRuns[0] || {};
  const t = tone(o.status || r.status);
  markActiveCard(id);
  $('empty').hidden = true;
  $('content').hidden = false;
  $('title').textContent = b.display_name;
  $('root').textContent = b.root_path || '';
  $('status').innerHTML = badge(o.status || r.status || 'UNKNOWN');
  $('banner').innerHTML = (o.message || o.policy || o.next_action || r.error) ? `
<div class="alert alert-${t}">${ic(TONE_ICON[t])}
  <div>
    <div class="alert-title">${esc(o.message || r.error || '')}</div>
    ${o.policy ? `<div class="alert-desc">${esc(o.policy)}</div>` : ''}
    ${o.next_action ? `<div class="alert-desc"><strong>${esc(o.next_action)}</strong></div>` : ''}
  </div>
</div>` : '';
  $('summary').innerHTML = [['Runs today', o.runs_today ?? 0], ['Success', o.success_count ?? 0], ['Failed', o.failed_count ?? 0], ['Run đang xem', r.run_id || '-']]
    .map(([k, v], i) => `<div class="stat"><span>${esc(k)}</span><strong class="${i === 3 ? 'text' : ''} ${i === 2 && Number(v) > 0 ? 'bad' : ''}" title="${esc(v)}">${esc(v)}</strong></div>`).join('');
  $('schedule').innerHTML = (o.schedule || []).length
    ? `<span class="small muted">Lịch chạy</span>` + o.schedule.map(x => `<span class="badge badge-outline">${esc(x)}</span>`).join('') : '';
  const today = todayRuns(b);
  $('runs').innerHTML = renderRuns(id, today);
  $('inputs').innerHTML = renderInputs(id, r);
  $('outputs').innerHTML = resourceTable(outputEntries(id, r)) + (id === 'vrol_master' && !r.live ? renderVisaResults(r) : '');
  $('vrol').innerHTML = id === 'vrol_master' ? renderVisaBoard(r) : '';
  $('overview').innerHTML = renderOverview(r);
  configureRetry(id, b);
  const logRun = rid ? allRuns.find(x => String(x.run_id) === String(rid)) : (r.run_id ? r : (b.latest || allRuns[0]));
  setupLiveLog(id, logRun);
  showTab(openLog ? 'logs' : (id === 'vrol_master' ? 'vrol' : (rid ? 'outputs' : 'runs')));
}

function emptyBox(msg) { return `<div class="empty">${esc(msg)}</div>`; }

function renderVisaResults(run) {
  const m = run.metrics || {}, handoff = (DATA.bots.vrol_master || {}).input_handoff || {};
  const mode = m.final_submit_enabled ? 'Final Submit được BẬT' : 'Dừng trước Final Submit';
  const overview = `<div class="alert alert-info" style="margin-top:16px"><div><div class="alert-title">${esc(mode)}</div><div class="alert-desc">GUID ${esc(m.completed_groups || 0)}/${esc(m.group_count ?? '?')} · PI ${esc(m.pi_pdf_count || 0)} PDF · REVIEW_REQUIRED ${esc(m.review_required_count || 0)} · Chờ Final Submit ${esc(m.awaiting_final_submit_count || 0)} · Đã xác nhận submit ${esc(m.final_submitted_count || 0)}${m.historical_registry_only ? ` · Registry lịch sử ${esc(m.historical_registry_only)}` : ''}</div><div class="alert-desc">FC: ${esc(m.source_fc_run_id || handoff.source_fc_run_id || '-')} · GUID2PAN: ${esc(m.source_guid2pan_run_id || handoff.source_guid2pan_run_id || '-')}</div></div></div>`;
  const all = run.guid_results || [], rows = (visaFilter === 'review' ? all.filter(r => r.needs_user_review) : all).filter(r => String(r.guid || '').toUpperCase().includes(visaSearch.toUpperCase()));
  const pages = Math.max(1, Math.ceil(rows.length / 200)); visaPage = Math.min(visaPage, pages - 1);
  const filters = `<p><button class="btn btn-outline btn-sm" data-action="visa-filter" data-filter="all">Tất cả GUID (${all.length})</button> <button class="btn btn-outline btn-sm" data-action="visa-filter" data-filter="review">Cần review / chờ submit (${all.filter(r => r.needs_user_review).length})</button> · Cập nhật mỗi ${visaPollSeconds}s khi đang chạy.</p><p><input class="input" id="visaSearch" placeholder="Tìm GUID" value="${esc(visaSearch)}"><button class="btn btn-outline btn-sm" data-action="visa-search">Tìm</button> <button class="btn btn-outline btn-sm" data-action="visa-page" data-page="${Math.max(0,visaPage-1)}">Trước</button> ${visaPage+1}/${pages} <button class="btn btn-outline btn-sm" data-action="visa-page" data-page="${Math.min(pages-1,visaPage+1)}">Sau</button></p>`;
  if (!rows.length) return overview + filters + emptyBox('Chưa có GUID trong bộ lọc đang chọn.');
  return overview + filters + `<div class="table-wrap"><table><thead><tr><th>GUID</th><th>Trạng thái / bước / lý do</th><th>ROL / ROL500 sau chạy</th><th>Thao tác</th></tr></thead><tbody>${rows.slice(visaPage*200, (visaPage+1)*200).map(r => `<tr><td class="mono">${esc(r.guid)}</td><td>${esc(r.status)}<br><span class="muted">${esc(r.action_stage || '')} · ${esc(r.reason_code || '')}</span></td><td>${esc(r.rol || '-')}<br>${esc(r.rol500_post_status || '')}<br>${esc((r.reported_rol_cases || []).join(' | '))}</td><td>${r.folder ? (READONLY ? '' : iconBtn('open-folder', r.folder, 'folder', 'Mở thư mục GUID')) + iconBtn('copy', r.folder, 'copy', 'Sao chép thư mục GUID') : ''}${!READONLY && r.screenshots?.[0] ? iconBtn('open-file', r.screenshots[0], 'file', 'Xem ảnh') : ''}</td></tr>`).join('')}</tbody></table></div>`;
}

function renderRuns(id, list) {
  if (!list.length) return emptyBox('Chưa có run hôm nay.');
  return `<div class="table-wrap"><table><thead><tr><th>Thời gian</th><th>Trạng thái</th><th>Run ID</th><th>Kết quả</th><th class="actions"></th></tr></thead><tbody>${
    list.map(r => {
      const o = (r.resources || {}).main_output || (r.resources || {}).final_output || {};
      return `<tr><td class="nowrap">${esc(fmt(r.started_at || r.completed_at))}</td><td>${badge(r.status)}</td><td class="mono">${esc(r.run_id)}</td><td class="path">${esc(o.path || '-')}</td><td class="actions"><span class="run-actions"><button type="button" class="btn btn-outline btn-sm" data-action="go" data-go="/bot/${esc(id)}/run/${esc(encodeURIComponent(r.run_id))}">Chi tiết</button><button type="button" class="btn btn-default btn-sm" data-action="go" data-go="/bot/${esc(id)}/run/${esc(encodeURIComponent(r.run_id))}/log">${r.status === 'RUNNING' ? 'Log trực tiếp' : (r.status === 'FAILED' ? 'Log lỗi' : 'Xem log')}</button></span></td></tr>`;
    }).join('')}</tbody></table></div>`;
}

function iconBtn(action, path, icon, label) {
  return `<button type="button" class="btn btn-ghost btn-icon" data-action="${action}" data-path="${esc(path)}" title="${esc(label)}" aria-label="${esc(label)}">${ic(icon)}</button>`;
}
function resourceTable(entries) {
  if (!entries.length) return emptyBox('Không có resource.');
  const hasSize = entries.some(([, v]) => v && v.file_size != null);
  return `<div class="table-wrap"><table><thead><tr><th>Resource</th><th>Đường dẫn đầy đủ</th><th>Tồn tại</th>${hasSize ? '<th>Dung lượng</th>' : ''}<th class="actions">Thao tác</th></tr></thead><tbody>${
    entries.map(([k, v]) => {
      v = v || {};
      const exists = v.exists === true ? '<span class="badge badge-success">Có</span>' : v.exists === false ? '<span class="badge badge-danger">Không</span>' : '<span class="muted">-</span>';
      const acts = (READONLY && v.href ? `<a class="btn btn-outline btn-sm" href="${esc(v.href)}" target="_blank" rel="noopener">Mở báo cáo PI / GUID</a>` : '') + (v.path ? (READONLY ? '' : iconBtn('open-folder', v.path, 'folder', 'Mở thư mục') + iconBtn('open-file', v.path, 'file', 'Mở file')) + iconBtn('copy', v.path, 'copy', 'Sao chép đường dẫn') : '');
      return `<tr><td class="nowrap" style="font-weight:500">${esc(k)}</td><td class="path">${esc(v.path || '-')}</td><td>${exists}</td>${hasSize ? `<td class="nowrap">${esc(sizeOf(v.file_size))}</td>` : ''}<td class="actions">${acts}</td></tr>`;
    }).join('')}</tbody></table></div>`;
}
function renderInputs(id, r) {
  if (id === 'cms_on_hold') return `<div class="alert alert-info">${ic('info')}<div><div class="alert-title">Bot này chạy không cần input đầu vào.</div><div class="alert-desc">CMS On-Hold tự đăng nhập hệ thống và xuất báo cáo theo cấu hình của chính bot.</div></div></div>`;
  return resourceTable(inputEntries(id, r));
}
function renderOverview(r) {
  const b = DATA.bots[selectedBot] || {}, contract = b.contract_publish || null;
  const e = Object.entries(r.metrics || {}).filter(x => x[1] != null);
  const metrics = e.length
    ? `<div class="metrics">${e.map(([k, v]) => `<div class="metric"><span>${esc(k.replaceAll('_', ' '))}</span><strong>${esc(v)}</strong></div>`).join('')}</div>`
    : emptyBox('Không có số liệu tổng quan.');
  if (selectedBot !== 'cms_on_hold' || !contract) return metrics;
  const ok = contract.status === 'PUBLISHED';
  const card = `<div class="alert alert-${ok ? 'success' : (contract.status === 'ERROR' ? 'danger' : 'warn')}" style="margin-bottom:12px">${ic(ok ? 'check' : 'clock')}<div><div class="alert-title">Contract T24: ${esc(contract.status || 'UNKNOWN')}</div><div class="alert-desc">${esc(contract.message || '')}</div>${contract.run_id ? `<div class="alert-desc mono">Run: ${esc(contract.run_id)} · Business date: ${esc(contract.business_date || '-')}</div>` : ''}${contract.output_path ? `<div class="alert-desc path">${esc(contract.output_path)}</div>` : ''}${contract.contract_path ? `<div class="alert-desc path">Contract: ${esc(contract.contract_path)}</div>` : ''}</div></div>`;
  return card + metrics;
}

function stripAnsi(text) { return String(text || '').replace(/[\u001B\u009B][[\]()#;?]*(?:(?:(?:[a-zA-Z\d]*(?:;[-a-zA-Z\d\/#&.:=?%@~_]+)*)?\u0007)|(?:(?:\d{1,4}(?:[;:]\d{0,4})*)?[\dA-PR-TZcf-nq-uy=><~]))/g, ''); }
function formatLogChunk(text) {
  return stripAnsi(text).split(/\r?\n/).map(line => {
    if (!line.trim()) return '';
    try {
      const x=JSON.parse(line), ts=x.timestamp||x.ts||'', lvl=x.level||(/failed|error/i.test(x.event||'')?'ERROR':'INFO');
      if (x.event==='classification_row') return `${ts}  ${lvl.padEnd(7)}  QT=${x.qt||x.excel_row} | ${x.processed}/${x.total} | AH=${x.ah||'-'} | AI=${x.ai||'-'} | AJ=${x.aj||'-'}`;
      if (x.event==='classification_progress') return `${ts}  ${lvl.padEnd(7)}  Tiến độ ${x.processed}/${x.total} (${x.percent}%) | 10.4=${x.eligible_104||0} | 13.1=${x.eligible_131||0} | 13.9=${x.eligible_139||0} | N=${x.rejected||0}`;
      if (x.event==='input_selected') return `${ts}  ${lvl.padEnd(7)}  RUN INPUT | ${x.input_path} | selected_by=${x.selected_by||'-'} | source_run_id=${x.source_run_id||'-'} | size=${x.input_file_size||0} | sha256=${x.input_sha256||'-'}`;
      if (x.event==='classification_output_saving') return `${ts}  ${lvl.padEnd(7)}  Đang lưu file 09 | ${x.output_file}`;
      if (x.event==='classification_output_saved') return `${ts}  ${lvl.padEnd(7)}  Đã tạo file 09 | Y=${x.eligible_rows} | N=${x.rejected_rows} | giữ AH=N=${x.includes_rejected_rows} | size=${x.file_size} bytes | ${x.output_file}`;
      if (x.event==='guid2pan_input_preparation_started') return `${ts}  ${lvl.padEnd(7)}  Bắt đầu chuẩn bị input GUID2PAN | auto_trigger=${x.auto_trigger}`;
      if (x.event==='guid2pan_source_opening') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 1/7 Mở file 09 | ${x.source_file}`;
      if (x.event==='guid2pan_source_validated') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 2/7 Đã kiểm tra Sheet1 | rows=${x.max_row}`;
      if (x.event==='guid2pan_guid_column_read') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 3/7 Đã đọc cột GUID | source_rows=${x.source_rows} | output_lines=${x.output_lines} | blank=${x.blank_guid_rows} | giữ trùng=${x.preserve_duplicates}`;
      if (x.event==='guid2pan_snapshot_written') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 4/7 Đã ghi snapshot | lines=${x.line_count} | ${x.snapshot_input}`;
      if (x.event==='guid2pan_working_input_written') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 5/7 Đã ghi input.txt | lines=${x.line_count} | ${x.working_input}`;
      if (x.event==='guid2pan_manifest_written') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 6/7 Đã ghi manifest | status=${x.status} | ${x.manifest_path}`;
      if (x.event==='guid2pan_trigger_started') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN 7/7 Đang gọi CMS GUID2PAN | timeout=${x.timeout_seconds}s | ${x.batch_file}`;
      if (x.event==='guid2pan_input_preparation_completed') return `${ts}  ${lvl.padEnd(7)}  GUID2PAN input ${x.status} | unique=${x.unique_guid_count||0} | blank=${x.blank_guid_rows||0} | duplicate=${x.duplicate_guid_rows||0} | ${x.working_input||''}`;
      if (x.event==='guid2pan_auto_trigger_skipped') return `${ts}  ${lvl.padEnd(7)}  Chưa gọi CMS GUID2PAN | ${x.reason} | ${x.next_action||''}`;
      const msg=x.message||x.error_message||x.error||x.event||line; const extra=['current','processed','total','percent','status','unique_guid_count','source_run_id','final_output_path'].filter(k=>x[k]!=null).map(k=>`${k}=${x[k]}`).join(' '); return `${ts}  ${lvl.padEnd(7)}  ${msg}${extra?'  '+extra:''}`;
    } catch { return line; }
  }).join('\n');
}
function setupLiveLog(botId, run) {
  if (logTimer) { clearInterval(logTimer); logTimer=null; }
  const box=$('liveLog'), st=$('logStatus');
  if (!run || !run.run_id) { logRunKey=''; logOffset=0; if(box)box.textContent='Chưa có run để xem log.'; if(st)st.textContent='Chưa có run'; return; }
  const key=`${botId}/${run.run_id}`; if (key!==logRunKey) { logRunKey=key; logOffset=0; if(box)box.textContent='Đang kết nối tới log của run...\n'; }
  if(st)st.textContent=`${run.run_id} · ${run.status}`;
  const poll=()=>loadLiveLog(botId,run.run_id);
  poll(); logTimer=setInterval(poll,1200);
}
async function loadLiveLog(botId, runId) {
  if(logBusy || !logRunKey) return; logBusy=true;
  try {
    const r=await fetch(`/api/bots/${encodeURIComponent(botId)}/runs/${encodeURIComponent(runId)}/log?offset=${logOffset}&limit=65536`,{cache:'no-store'}); if(!r.ok)throw new Error(await r.text()); const x=await r.json();
    const box=$('liveLog'),st=$('logStatus'); if(x.text){ if (box.textContent === 'Đang kết nối tới log của run...\n') box.textContent=''; const rendered=formatLogChunk(x.text); box.textContent += rendered + (rendered.endsWith('\n')?'':'\n'); logOffset=x.next_offset; if($('logFollow')?.checked) box.scrollTop=box.scrollHeight; }
    if(st)st.textContent=x.path ? `${runId} · ${x.status||''} · ${x.size||0} bytes · ${x.path}` : `${runId} · ${x.status||''} · chưa tìm thấy process_log`;
    if (!x.text && !x.path && box.textContent.startsWith('Đang kết nối')) box.textContent='Run đã được nhận diện nhưng chưa có file process_log. Dashboard sẽ tiếp tục kiểm tra khi run đang chạy.\n';
    if(x.complete && x.next_offset>=x.size && logTimer){clearInterval(logTimer);logTimer=null;}
  } catch(e){ const st=$('logStatus'); if(st)st.textContent='Không đọc được log: '+e.message; } finally {logBusy=false;}
}
function showTab(n) {
  currentTab = n;
  document.querySelectorAll('.tab').forEach(x => x.setAttribute('aria-selected', String(x.dataset.tab === n)));
  for (const x of ['vrol', 'runs', 'inputs', 'outputs', 'overview', 'logs']) $(x).hidden = x !== n;
}

/* ---------- retry ---------- */
function configureRetry(id, b) {
  const btn = $('retryButton'), row = $('retryInputRow'), sel = $('retryInput');
  const blocked = READONLY || (PLACEHOLDER_BOTS.includes(id) && !b.root_path);
  btn.hidden = blocked; row.hidden = true; sel.innerHTML = ''; sel.onchange = null;
  $('visaGuidRequest').hidden = READONLY || id !== 'vrol_master';
  $('visaManualInput').hidden = READONLY || id !== 'vrol_master';
  $('vrolModeRow').hidden = READONLY || id !== 'vrol_master';
  $('vrolRunSettings').hidden = READONLY || id !== 'vrol_master';
  if (id === 'vrol_master' && !READONLY && !vrolSettings) loadVrolSettings();
  $('vrolTabButton').hidden = id !== 'vrol_master';
  for (const f of ['vrolWorkbook', 'vrolMapping']) $(f).oninput = () => { $('vrolManualRun').disabled = true; $('vrolManualReport').innerHTML = ''; };
  $('visaChecksButton').hidden = READONLY || id !== 'vrol_master';
  $('visaGuidList').value = visaGuidDraft;
  $('visaGuidList').oninput = () => { visaGuidDraft = $('visaGuidList').value; };
  $('visaGuidRunButton').disabled = true;
  if (blocked) return;
  if (id === 'cms_on_hold') { btn.disabled = false; btn.innerHTML = `${ic('play')}Chạy lại CMS On-Hold`; return; }
  const candidates = (DATA.workflow_inputs || {})[id] || [];
  sel.innerHTML = candidates.length
    ? candidates.map((x,i) => `<option value="${esc(x.path)}">${i===0?'Mới nhất hôm nay · ':''}${esc(x.source_run_id || '')} · ${esc(x.resource_key)} · ${esc(x.path)}</option>`).join('')
    : '<option value="">Không tìm thấy input thành công của ngày hôm nay</option>';
  sel.disabled = !candidates.length; btn.disabled = !candidates.length;
  if (id === 'vrol_master' && (b.runs || []).some(r => isActive(r.status))) btn.disabled = true;
  if (id === 'vrol_master') $('visaGuidRunButton').disabled = btn.disabled;
  $('retryHelp').textContent = candidates.length
    ? 'Danh sách được kiểm tra lại từ file success thực tế của bot đứng trước mỗi lần dashboard làm mới.'
    : 'Chưa tìm thấy file success tồn tại trên ổ đĩa từ bot đứng trước trong ngày hôm nay.';
  if (id === 'vrol_master') $('retryHelp').textContent = b.input_handoff?.message || 'Chọn cặp workbook FC và mapping GUID2PAN cùng nguồn.';
  btn.innerHTML = `${ic('play')}${candidates.length ? 'Chạy với input mới nhất hôm nay' : 'Chưa có input hôm nay'}`;
  sel.onchange = () => { btn.innerHTML = `${ic('play')}Chạy với input đã chọn hôm nay`; };
  row.hidden = false;
}

/* ---------- VROL live board (contract vrol-dashboard/2) ---------- */
const VROL_STAGES = [['STARTING','Khởi động'],['WAITING_INPUT','Chờ input FC + GUID2PAN'],['LOGIN','Đăng nhập Visa'],['ROL500','ROL500 preflight'],['PROCESSING_GUIDS','Xử lý GUID'],['ROL500_POSTFLIGHT','ROL500 postflight'],['FINISHED','Hoàn tất']];
const VROL_BUCKETS = [['pi','Đã tải PI','success'],['no_cb','NO_CB','neutral'],['existing_cb','Đã có chargeback','neutral'],['draft','Nháp chờ Final Submit','info'],['submitted','Đã Final Submit','success'],['review','Cần review','danger'],['retry_later','Thử lại run sau','warn'],['diagnostic','Cần tạo case (chạy đầy đủ)','info']];
const VROL_ORIGIN = { MANUAL_USER_SELECTED: 'File tự chọn trên dashboard', FC_GUID2PAN: 'FC + GUID2PAN', FILES: 'File theo cấu hình' };
const dur = sec => { if (sec == null) return '-'; sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60); return h ? `${h} giờ ${m} phút` : (m ? `${m} phút` : `${sec % 60} giây`); };
const clock = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }); };
const ago = iso => { const t = Date.parse(iso); if (isNaN(t)) return '-'; const sec = (Date.now() - t) / 1000; return sec < 90 ? `${Math.max(0, Math.round(sec))} giây trước` : `${Math.round(sec / 60)} phút trước`; };
const guidActions = r => `${r.folder && !READONLY ? iconBtn('open-folder', r.folder, 'folder', 'Mở thư mục GUID') : ''}${r.screenshot && !READONLY ? iconBtn('open-file', r.screenshot, 'file', 'Xem ảnh') : ''}<button type="button" class="btn btn-ghost btn-icon" data-action="copy-text" data-value="${esc(r.guid)}" title="Copy GUID" aria-label="Copy GUID">${ic('copy')}</button>`;

function renderVisaBoard(run) {
  const L = run.live;
  if (!L) return `<div class="alert alert-info">${ic('info')}<div><div class="alert-title">Run này chưa có dashboard_status.json (contract v2)</div><div class="alert-desc">Đang hiển thị dạng cũ.</div></div></div>` + renderVisaResults(run);
  const p = L.progress || {}, q = L.queue || {}, b = L.buckets || {}, m = L.mode || {}, s = L.session || {}, h = L.health || {};
  const total = q.total || 0, done = p.done || 0, active = isActive(run.status);
  const pct = total ? Math.min(100, Math.round(done * 100 / total)) : (L.stage === 'FINISHED' ? 100 : 0);
  const banners = [];
  if (run.status === 'WAITING_OTP') banners.push(`<div class="alert alert-warn">${ic('clock')}<div><div class="alert-title">Đang chờ OTP Visa</div><div class="alert-desc">Thả file YYYYMMDD_HHMMSS_&lt;mã&gt;.txt vào ${esc(L.otp_folder || 'thư mục OTP')}</div></div></div>`);
  if (L.stage === 'WAITING_INPUT') banners.push(`<div class="alert alert-info">${ic('clock')}<div><div class="alert-title">Đang chờ input hôm nay: cặp FC + GUID2PAN hoàn tất sau giờ cắt (scheduled_source_not_before)</div><div class="alert-desc">${esc(L.input_wait_reason || '')}</div><div class="alert-desc path">${esc(L.contract_directory || '')}</div><div class="alert-desc">Bundle do dashboard xuất (collector chạy mỗi CRAWL_INTERVAL_MINUTES). Hết scheduled_input_wait_seconds mà chưa có input thì run dừng với SCHEDULED_INPUT_TIMEOUT.</div></div></div>`);
  if (run.status === 'FAILED') banners.push(`<div class="alert alert-danger">${ic('alert')}<div><div class="alert-title">Run dừng lỗi</div><div class="alert-desc">${esc(L.error || run.error || 'Xem Live log')}</div></div></div>`);
  const input = L.input || {};
  const srcTag = k => ((m.sources || {})[k] === 'dashboard' ? ' · dashboard' : ((m.sources || {})[k] === 'command_line' ? ' · lệnh chạy' : ''));
  const chips = [m.pi_only ? '<span class="badge badge-info">Chỉ tải chứng từ (PI)</span>' : (m.final_submit_enabled ? `<span class="badge badge-danger">Final Submit BẬT${srcTag('final_submit')}</span>` : `<span class="badge badge-outline">Dừng trước Final Submit${srcTag('final_submit')}</span>`),
    m.scheduled ? '<span class="badge badge-info">Chạy theo lịch (run_scheduled.cmd)</span>' : '<span class="badge badge-outline">Chạy tay</span>',
    `<span class="badge badge-outline">${m.headless ? 'Headless' : 'Headful'}${srcTag('headless')}</span>`, `<span class="badge badge-outline">${esc(m.workers || '?')} worker${srcTag('workers')}</span>`,
    `<span class="badge badge-outline" title="${esc(input.workbook || '')}">${esc(VROL_ORIGIN[input.origin] || input.origin || 'Input')}</span>`,
    s.generation ? `<span class="badge badge-outline">Phiên Chrome #${esc(s.generation)}${s.restart_after ? ` · restart mỗi ${esc(s.restart_after)} GUID` : ''}</span>` : ''].join(' ');
  const progress = `<div class="vrol-progress"><div class="vrol-progress-head"><strong>${esc(done)}/${esc(total || '?')} GUID</strong><span class="pct">${pct}%</span>
    <span class="muted">${p.guids_per_min ? esc(p.guids_per_min) + ' GUID/phút' : ''}${active && p.eta_seconds ? ' · còn khoảng ' + dur(p.eta_seconds) : ''}${p.running ? ` · ${esc(p.running)} đang xử lý` : ''} · cập nhật ${ago(L.updated_at)}</span></div>
    <div class="bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><span style="width:${pct}%"></span></div></div>`;
  const reached = new Map((L.stage_history || []).map(x => [x.stage, x.at]));
  const stages = VROL_STAGES.filter(([k]) => k !== 'WAITING_INPUT' || m.scheduled || reached.has(k));
  const cur = Math.max(0, stages.findIndex(x => x[0] === L.stage));
  const stepper = `<ol class="stepper">${stages.map(([k, lab], i) => `<li class="${L.stage === 'FINISHED' || i < cur ? 'done' : i === cur ? 'current' : ''}"><span class="step-dot"></span><span class="step-label">${lab}</span><small>${reached.has(k) ? clock(reached.get(k)) : ''}</small></li>`).join('')}</ol>`;
  const existing = (b.existing_cb || 0) + (q.existing_cb_rol500 || 0);
  const kpis = `<div class="kpis">${VROL_BUCKETS.map(([k, lab, t]) => {
    const v = k === 'existing_cb' ? existing : (b[k] || 0);
    const sub = k === 'existing_cb' ? `<small>ROL500 ${esc(q.existing_cb_rol500 || 0)} · Assoc D ${esc(b.existing_cb || 0)}</small>` : (k === 'retry_later' && v ? '<small>lỗi kỹ thuật, tự chạy lại</small>' : '');
    if (k === 'diagnostic' && !v) return '';
    return `<button type="button" class="kpi kpi-${t}${vrolBucket === k ? ' active' : ''}${v ? '' : ' zero'}" data-action="vrol-bucket" data-bucket="${k}"><span>${lab}</span><strong>${esc(v)}</strong>${sub}</button>`;
  }).join('')}</div>`;
  const groups = {};
  for (const r of L.review || []) (groups[r.group] = groups[r.group] || []).push(r);
  const review = Object.keys(groups).length
    ? Object.entries(groups).sort((a, c) => c[1].length - a[1].length).map(([g, rows]) => `<details class="rgroup" open><summary><strong>${esc(g)}</strong><span class="badge badge-danger">${rows.length}</span></summary>
      <p class="small muted">${esc(rows[0].hint || '')}</p><div class="table-wrap"><table><thead><tr><th>GUID</th><th>ROL</th><th>Worker</th><th></th></tr></thead><tbody>${rows.map(r => `<tr><td class="mono">${esc(r.guid)}</td><td class="mono">${esc(r.rol || '-')}</td><td>${esc(r.worker || '')}</td><td class="actions">${guidActions(r)}</td></tr>`).join('')}</tbody></table></div></details>`).join('')
    : emptyBox(done ? 'Chưa có GUID nào cần review.' : 'Chưa có kết quả.');
  const lanes = (L.workers || []).length
    ? `<div class="lanes">${L.workers.map(w => `<div class="lane${w.guid ? ' busy' : ''}"><span class="mono strong">${esc(w.id)}</span><span class="mono" title="${esc(w.guid)}">${w.guid ? esc(w.guid.slice(0, 14)) + '…' : '—'}</span><span class="small ${w.seconds > 180 ? 'bad' : 'muted'}" title="${esc(w.stage || '')}">${w.guid ? (w.seconds != null ? dur(w.seconds) : esc(w.stage || '')) : 'rảnh'}</span></div>`).join('')}</div>`
    : emptyBox('Worker chưa khởi tạo.');
  const health = `<div class="small muted health">CPU ${esc(h.cpu_total_pct ?? '-')}% · RAM ${esc(h.ram_used_pct ?? '-')}% · Chrome ${esc(h.chrome_rss_mb ?? '-')} MB · Restart Chrome ${esc(s.restarts ?? 0)} · Retry đọc lại ${esc((L.retries || {}).read_only || 0)}</div>`;
  const drafts = (L.drafts || []).length
    ? `<div class="table-wrap"><table><thead><tr><th>GUID</th><th>ROL</th><th>Loại</th><th></th></tr></thead><tbody>${L.drafts.map(r => `<tr><td class="mono">${esc(r.guid)}</td><td class="mono">${esc(r.rol || '-')}</td><td>${esc(r.action || r.label || '')}</td><td class="actions">${guidActions(r)}</td></tr>`).join('')}</tbody></table></div>`
    : emptyBox('Chưa có case nháp.');
  const excluded = Object.entries(q.excluded || {}).sort((a, c) => c[1] - a[1]);
  const exclusions = excluded.length
    ? `<details class="rgroup"><summary><strong>Dòng bị loại trước khi chạy</strong><span class="badge badge-outline">${excluded.reduce((n, x) => n + x[1], 0)}</span></summary><div class="table-wrap"><table><tbody>${excluded.map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num">${esc(v)}</td></tr>`).join('')}</tbody></table></div></details>`
    : '';
  const all = (run.guid_results || []).filter(r => vrolBucket === 'all' || r.category === vrolBucket).filter(r => String(r.guid || '').toUpperCase().includes(visaSearch.toUpperCase()));
  const pages = Math.max(1, Math.ceil(all.length / 100)); visaPage = Math.min(visaPage, pages - 1);
  const label = vrolBucket === 'all' ? 'Tất cả GUID đã xử lý' : (VROL_BUCKETS.find(x => x[0] === vrolBucket) || [0, vrolBucket])[1];
  const table = `<section id="vrolAll" class="vrol-section"><div class="section-head"><h3>${esc(label)} <span class="muted">(${all.length})</span></h3>
      <div class="toolbar">${vrolBucket !== 'all' ? `<button type="button" class="btn btn-outline btn-sm" data-action="vrol-bucket" data-bucket="${esc(vrolBucket)}">Bỏ lọc</button>` : ''}<input class="input" id="visaSearch" placeholder="Tìm GUID" value="${esc(visaSearch)}"><button type="button" class="btn btn-outline btn-sm" data-action="visa-search">Tìm</button>
      <button type="button" class="btn btn-outline btn-sm" data-action="visa-page" data-page="${Math.max(0, visaPage - 1)}">Trước</button><span class="small muted">${visaPage + 1}/${pages}</span><button type="button" class="btn btn-outline btn-sm" data-action="visa-page" data-page="${Math.min(pages - 1, visaPage + 1)}">Sau</button></div></div>
    <div class="table-wrap"><table><thead><tr><th>GUID</th><th>Kết quả (AM)</th><th>ROL</th><th></th></tr></thead><tbody>${all.slice(visaPage * 100, (visaPage + 1) * 100).map(r => `<tr><td class="mono">${esc(r.guid)}</td><td><span class="dotlabel b-${esc(r.category)}"></span>${esc(r.label || r.status)}<br><span class="muted small">${esc(r.reason_code || '')}</span></td><td class="mono">${esc(r.rol || '-')}</td><td class="actions">${guidActions(Object.assign({ screenshot: (r.screenshots || [])[0] }, r))}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">Không có GUID.</td></tr>'}</tbody></table></div></section>`;
  return `<div class="vrol-board">${banners.join('')}<div class="chips">${chips}</div>${progress}${stepper}${kpis}
    <div class="vrol-cols"><section class="vrol-section"><div class="section-head"><h3>Cần xử lý <span class="muted">(${(L.review || []).length})</span></h3></div>${review}${exclusions}</section>
    <section class="vrol-section"><div class="section-head"><h3>Worker</h3></div>${lanes}${health}
      <div class="section-head" style="margin-top:16px"><h3>Case nháp chờ Final Submit <span class="muted">(${(L.drafts || []).length})</span></h3>${(L.drafts || []).length ? '<button type="button" class="btn btn-outline btn-sm" data-action="vrol-drafts-csv">Tải CSV</button>' : ''}</div>${drafts}</section></div>${table}</div>`;
}

function vrolDraftsCsv() {
  const run = (DATA.bots.vrol_master || {}).latest || {}, rows = ((run.live || {}).drafts) || [];
  const q = v => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const csv = '﻿' + ['guid,rol,action,label,folder', ...rows.map(r => [r.guid, r.rol, r.action, r.label, r.folder].map(q).join(','))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = `vrol_drafts_${run.run_id || 'run'}.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/* ---------- VROL run settings remembered by the dashboard ---------- */
let vrolSettings = null;
const yesNo = v => v === 'YES' ? 'BẬT' : 'Tắt';
const browserLabel = v => v ? 'Headless' : 'Headful';
function fillVrolSettings(x) {
  vrolSettings = x; const c = x.config || {}, o = x.overrides || {}, e = x.effective || {};
  const setFirst = (id, text) => { const opt = $(id).options[0]; opt.textContent = text; };
  setFirst('vrolSetFinal', `Theo config.xlsx (đang: ${yesNo(c.final_submit)})`);
  setFirst('vrolSetWorkers', `Theo config.xlsx (đang: ${c.workers} worker)`);
  setFirst('vrolSetHeadless', `Theo config.xlsx (đang: ${browserLabel(c.headless)})`);
  $('vrolSetFinal').value = o.final_submit || 'CONFIG';
  $('vrolSetWorkers').value = o.workers ? String(o.workers) : 'CONFIG';
  $('vrolSetHeadless').value = o.headless == null ? 'CONFIG' : (o.headless ? 'HEADLESS' : 'HEADFUL');
  const src = k => o[k] == null ? 'config.xlsx' : 'dashboard';
  $('vrolSettingsInfo').innerHTML = `Đang áp dụng cho run kế tiếp: <strong>Final Submit ${esc(yesNo(e.final_submit))}</strong> (${src('final_submit')}) · <strong>${esc(e.workers)} worker</strong> (${src('workers')}) · <strong>${esc(browserLabel(e.headless))}</strong> (${src('headless')})${x.updated_at ? ' · lưu lúc ' + esc(fmt(x.updated_at)) : ''}.<br>Launcher chẩn đoán (--pre-submit-only, chỉ tải chứng từ) vẫn luôn chặn Final Submit. Lưu tại ${esc(x.path || '')}${c.config_found === false ? '<br><strong>Không thấy config.xlsx ở thư mục VROL: giá trị "theo config" đang là mặc định của bot.</strong>' : ''}`;
}
async function loadVrolSettings() {
  try { const r = await fetch('/api/vrol/run-settings', {cache: 'no-store'}); const x = await r.json(); if (!r.ok) throw new Error(x.error || r.status); fillVrolSettings(x); }
  catch (e) { $('vrolSettingsInfo').textContent = 'Không đọc được thiết lập VROL: ' + e.message; }
}
async function saveVrolSettings(reset = false) {
  const body = reset ? { final_submit: 'CONFIG', workers: 'CONFIG', headless: 'CONFIG' }
    : { final_submit: $('vrolSetFinal').value, workers: $('vrolSetWorkers').value, headless: $('vrolSetHeadless').value };
  const c = (vrolSettings || {}).config || {};
  const finalEff = body.final_submit === 'CONFIG' ? c.final_submit : body.final_submit;
  const lines = [`Final Submit: ${body.final_submit === 'CONFIG' ? 'theo config.xlsx (' + yesNo(c.final_submit) + ')' : yesNo(body.final_submit)}`,
    `Số worker: ${body.workers === 'CONFIG' ? 'theo config.xlsx (' + c.workers + ')' : body.workers}`,
    `Trình duyệt: ${body.headless === 'CONFIG' ? 'theo config.xlsx (' + browserLabel(c.headless) + ')' : (body.headless === 'HEADLESS' ? 'Headless' : 'Headful')}`];
  const ok = await confirmDialog({ title: finalEff === 'YES' ? 'BẬT Final Submit cho các run sau?' : 'Lưu thiết lập chạy VROL?',
    description: finalEff === 'YES' ? 'Từ run kế tiếp (kể cả lịch 19:40), bot sẽ GỬI dispute thật lên Visa cho case đủ điều kiện. Run đang chạy không bị ảnh hưởng.' : 'Áp dụng từ run kế tiếp, kể cả lịch 19:40. Run đang chạy không bị ảnh hưởng.',
    code: lines.join('\n'), confirmText: finalEff === 'YES' ? 'Bật Final Submit' : 'Lưu' });
  if (!ok) { if (vrolSettings) fillVrolSettings(vrolSettings); return; }
  try {
    const r = await fetch('/api/vrol/run-settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const x = await r.json(); if (!r.ok) throw new Error(x.error || r.status);
    fillVrolSettings(x); toast('Đã lưu thiết lập chạy VROL.', 'success');
  } catch (e) { toast('Không lưu được: ' + e.message, 'error'); }
}

/* ---------- VROL input chosen by the user ---------- */
async function vrolPick(kind) {
  const id = kind === 'workbook' ? 'vrolWorkbook' : 'vrolMapping';
  try {
    toast('Đang mở hộp thoại chọn file trên máy chạy dashboard…', 'info');
    const r = await fetch('/api/vrol/manual-input/pick', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind, initial: $(id).value }) });
    const x = await r.json(); if (!r.ok) throw new Error(x.error || r.status);
    if (x.path) { $(id).value = x.path; $('vrolManualRun').disabled = true; $('vrolManualReport').innerHTML = ''; }
  } catch (e) { toast('Không chọn được file: ' + e.message, 'error'); }
}
function manualReportHtml(x) {
  const t = x.ok ? (x.warnings.length ? 'warn' : 'success') : 'danger';
  const facts = x.eligible_guids != null ? `GUID đủ điều kiện ${esc(x.eligible_guids)} · có PAN ${esc(x.eligible_guids - x.missing_guids)} · thiếu PAN ${esc(x.missing_guids)} · mapping ${esc(x.mapping_guids)} dòng` : '';
  return `<div class="alert alert-${t}">${ic(TONE_ICON[t])}<div><div class="alert-title">${x.ok ? 'Có thể chạy VROL với 2 file này' : 'Chưa thể chạy'}</div>${facts ? `<div class="alert-desc">${facts}</div>` : ''}${[...x.errors, ...x.warnings].map(m => `<div class="alert-desc">• ${esc(m)}</div>`).join('')}</div></div>`;
}
async function vrolManualCheck(silent = false) {
  const body = JSON.stringify({ workbook: $('vrolWorkbook').value.trim(), mapping: $('vrolMapping').value.trim() });
  const r = await fetch('/api/vrol/manual-input/check', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
  const x = await r.json(); if (!r.ok) throw new Error(x.error || r.status);
  $('vrolManualReport').innerHTML = manualReportHtml(x);
  const running = ((DATA.bots.vrol_master || {}).runs || []).some(z => isActive(z.status));
  $('vrolManualRun').disabled = !x.ok || running;
  if (x.ok && running && !silent) toast('VROL đang chạy; đợi run hiện tại xong rồi bấm Chạy.', 'warning');
  return x;
}
async function vrolManualRun() {
  const button = $('vrolManualRun'); button.disabled = true;
  try {
    const x = await vrolManualCheck(true); if (!x.ok) return;
    const ok = await confirmDialog({ title: 'Chạy VROL với file tự chọn?', description: 'Bot sẽ đăng nhập Visa, tải PI, tạo case theo rule; Final Submit theo Thiết lập chạy VROL. Kết quả AK/AL/AM ghi vào file 09 đã chọn.',
      code: `09:        ${x.workbook}\ninput.txt: ${x.mapping}\nGUID đủ điều kiện: ${x.eligible_guids} · thiếu PAN: ${x.missing_guids}\nChế độ: ${vrolModeLabel()}`, confirmText: 'Chạy VROL' });
    if (!ok) return;
    const r = await fetch('/api/vrol/manual-input/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ workbook: x.workbook, mapping: x.mapping, mode: vrolModeValue() }) });
    const started = await r.json(); if (!r.ok) throw new Error(started.error || r.status);
    toast('Đã khởi chạy VROL với bundle ' + started.bundle_id, 'success');
    await refreshNow(true); showTab('vrol');
  } catch (e) { toast('Không thể chạy VROL: ' + e.message, 'error'); }
  finally { button.disabled = false; }
}

async function runVisaGuidRequest() {
  const input=$('retryInput').value, guids=$('visaGuidList').value.trim();
  if(!guids){toast('Nhập ít nhất một GUID.','warning');return;}
  const button=$('visaGuidRunButton');button.disabled=true;
  try {
    const body=JSON.stringify({input_path:input,guids,mode:vrolModeValue()});
    const preview=await fetch('/api/vrol/guid-request/preview',{method:'POST',headers:{'Content-Type':'application/json'},body});
    const result=await preview.json();if(!preview.ok)throw new Error(result.error||preview.status);
    const lines=result.rows.map(x=>`${x.guid} | rows=${x.row_count} | code=${x.codes.join('/')} | upstream=${x.upstream_values.join('/')} | ${!x.found?'KHÔNG CÓ TRONG FILE 09':!x.mapping_available?'THIẾU MAPPING':'đã tìm thấy'}`);
    const ok=await confirmDialog({title:`Chạy riêng ${result.requested_count} GUID?`,description:result.note+' Chế độ: '+vrolModeLabel()+'.',code:lines.join('\n'),confirmText:'Chạy danh sách GUID'});
    if(!ok)return;
    const response=await fetch('/api/vrol/guid-request',{method:'POST',headers:{'Content-Type':'application/json'},body});
    const started=await response.json();if(!response.ok)throw new Error(started.error||response.status);
    toast('Đã gửi run riêng: '+started.request_id+'. Xem requested_guid_report trong Output.','success');
    await refreshNow(true);
  }catch(error){toast('Không thể chạy GUID: '+error.message,'error');}
  finally{button.disabled=false;}
}

async function checkVisaInputs() {
  const button=$('visaChecksButton');button.disabled=true;
  try {
    const response=await fetch('/api/vrol/checks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({input_path:$('retryInput').value||null})});
    const result=await response.json();if(!response.ok)throw new Error(result.error||response.status);
    const lines=result.checks.map(x=>{const {name,status,message,...counts}=x;return `${status} | ${name}: ${message}${Object.keys(counts).length?' | '+Object.entries(counts).map(([k,v])=>`${k}=${v}`).join(', '):''}`;});
    await confirmDialog({title:`Kiểm tra VROL: ${result.status}`,description:`Chỉ đọc cấu hình/input (${result.input_mode}); không login hoặc gửi case. Không hiển thị mật khẩu, PAN, OTP hay GUID.`,code:lines.join('\n'),confirmText:'Đóng',wide:true});
  }catch(error){toast('Không thể kiểm tra: '+error.message,'error');}
  finally{button.disabled=false;}
}

async function retryBot() {
  const id = selectedBot;
  if (!id) return;
  const name = DATA.bots[id].display_name;
  const input = id === 'cms_on_hold' ? '' : $('retryInput').value;
  const ok = await confirmDialog({
    title: `Chạy lại ${name}?`,
    description: 'Bot sẽ được khởi chạy ngay trên máy này.',
    code: (id === 'guid2pan' ? 'Working input.txt: ' : 'Input: ') + (input || (id === 'cms_on_hold' ? 'không cần input' : 'không có input hợp lệ hôm nay')) + (id === 'vrol_master' ? '\nChế độ: ' + vrolModeLabel() : ''),
    confirmText: 'Chạy lại',
  });
  if (!ok) return;
  const btn = $('retryButton');
  btn.disabled = true;
  try {
    const r = await fetch('/api/retry/' + encodeURIComponent(id), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(id === 'vrol_master' ? { input_path: input, mode: vrolModeValue() } : { input_path: input }) });
    let x = {};
    try { x = await r.json(); } catch { /* non-JSON error body */ }
    if (r.ok) {
      toast('Đã gửi yêu cầu chạy bot. Đang kiểm tra trạng thái khởi động…', 'success');
      btn.innerHTML = `${ic('refresh-cw')}Đang chờ bot khởi động…`;
      await refreshNow(true);
      // The bot may need a moment to create the first run folder/log. Refresh aggressively until a new RUNNING/run appears.
      const beforeRuns = Number((DATA.bots[id]?.operations || {}).runs_today || 0);
      let checks = 0;
      const waitForStart = setInterval(async () => {
        checks += 1;
        await refreshNow(true);
        const bot = DATA.bots[id] || {}, op = bot.operations || {}, latest = bot.latest || {};
        const started = isActive(op.status) || isActive(latest.status) || Number(op.runs_today || 0) > beforeRuns;
        if (started || checks >= 15) {
          clearInterval(waitForStart);
          if (started) toast('Bot đã bắt đầu chạy. Dashboard sẽ tiếp tục tự làm mới.', 'success');
          else toast('Đã gửi lệnh nhưng chưa thấy run mới. Kiểm tra Task/command và log khởi động.', 'warning');
          route();
        }
      }, 1000);
    } else toast('Không thể chạy lại bot: ' + (x.error || r.status), 'error');
  } catch (e) {
    toast('Không thể chạy lại bot: ' + e.message, 'error');
  } finally {
    btn.disabled = false;
  }
}

/* ---------- refresh ---------- */
async function refreshNow(silent = false) {
  const btn = $('refreshButton');
  btn.disabled = true; btn.classList.add('spin');
  try {
    const r = await fetch('/api/refresh', { method: 'POST' });
    if (!r.ok) throw new Error(r.status);
    DATA = await r.json();
    buildFlow(); renderUpdated();
    const tab = currentTab;
    route();
    if (!$('content').hidden) showTab(tab);
    if (!silent) toast('Đã làm mới dữ liệu.', 'success');
  } catch (e) {
    if (!silent) toast('Không thể làm mới: ' + e.message, 'error');
  } finally {
    btn.disabled = false; btn.classList.remove('spin');
  }
}

/* ---------- Task Scheduler ---------- */
function taskResult(v){if(v===0)return '<span class="badge badge-success">0x0</span>';if(v==null)return '-';return `<span class="badge badge-danger">0x${(Number(v)>>>0).toString(16).toUpperCase()}</span>`;}
async function loadSchedules(){
 const body=$('schedulesBody');body.innerHTML='<div class="muted">Đang đọc Task Scheduler…</div>';
 try{const r=await fetch('/api/schedules',{cache:'no-store'}),x=await r.json();if(!r.ok||!x.ok)throw new Error(x.error||r.status);const a=x.tasks||[];
 body.innerHTML=a.length?`<div class="table-wrap"><table><thead><tr><th>Tên job</th><th>Giờ</th><th>Trạng thái</th><th>Next run</th><th>Last run</th><th>Kết quả</th><th>Action đầy đủ</th><th></th></tr></thead><tbody>${a.map(t=>{const action=((t.execute||'')+' '+(t.arguments||'')).trim();return `<tr><td><input class="input schedule-name" value="${esc(t.name)}" ${t.editable?'':'disabled'}></td><td><input type="time" class="input schedule-time" value="${esc(t.time||'')}" ${t.editable?'':'disabled'}></td><td>${badge(t.status||'UNKNOWN')}</td><td>${esc(fmt(t.next_run_time))}</td><td>${esc(fmt(t.last_run_time))}</td><td>${taskResult(t.last_result)}</td><td><div class="schedule-action mono">${esc(action||'-')}</div><div class="schedule-action-buttons"><button class="btn btn-outline btn-sm" data-action="copy-task-action" data-value="${esc(action)}">Copy</button><button class="btn btn-outline btn-sm" data-action="open-task-action" data-task-name="${esc(t.name)}">Mở file</button></div></td><td><button class="btn btn-default btn-sm" data-action="save-schedule" data-original-name="${esc(t.name)}" ${t.editable?'':'disabled'}>Lưu</button></td></tr>`}).join('')}</tbody></table></div>`:emptyBox('Không tìm thấy task trong \\RPA Tra Soat.');
 }catch(e){body.innerHTML=`<div class="alert alert-danger">${ic('alert')}<div><div class="alert-title">Không đọc được lịch chạy</div><div class="alert-desc">${esc(e.message)}</div></div></div>`;}}
async function saveSchedule(b){const row=b.closest('tr'),name=row.querySelector('.schedule-name').value.trim(),time=row.querySelector('.schedule-time').value,old=b.dataset.originalName;if(!name||!time){toast('Tên và giờ không được trống.','error');return;}const ok=await confirmDialog({title:'Cập nhật lịch?',description:'Tên và giờ sẽ thay đổi; Action được giữ nguyên.',code:`${old} → ${name} lúc ${time}`,confirmText:'Cập nhật'});if(!ok)return;b.disabled=true;try{const r=await fetch('/api/schedules',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({original_name:old,name,time})}),x=await r.json();if(!r.ok||!x.ok)throw new Error(x.error||r.status);toast(`Đã cập nhật ${x.name}.`,'success');await loadSchedules();}catch(e){toast('Không cập nhật được lịch: '+e.message,'error');}finally{b.disabled=false;}}
async function openTaskAction(name){try{const r=await fetch('/api/schedules/open-action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})}),x=await r.json();if(!r.ok||!x.ok)throw new Error(x.error||r.status);toast('Đã mở file Action trong Explorer.','success');}catch(e){toast('Không mở được Action: '+e.message,'error');}}
async function openTaskScheduler(){try{const r=await fetch('/api/schedules/open-task-scheduler',{method:'POST'}),x=await r.json();if(!r.ok||!x.ok)throw new Error(x.error||r.status);}catch(e){toast('Không mở được Task Scheduler: '+e.message,'error');}}

/* ---------- settings ---------- */
async function loadSettings() {
  const body = $('settingsBody');
  body.innerHTML = '<div class="muted">Đang tải…</div>';
  try {
    const r = await fetch('/api/settings');
    if (!r.ok) throw new Error(r.status);
    const a = await r.json();
    body.innerHTML = `
<div class="form-section"><h3>Cấu hình chung</h3>${a.settings.map(x => `
  <div class="form-row"><label class="label mono">${esc(x.key)}</label><input class="input" value="${esc(x.value)}"><button type="button" class="btn btn-outline" data-action="save-setting" data-key="${esc(x.key)}">Lưu</button></div>`).join('')}</div>
<hr class="separator">
<div class="form-section"><h3>Bot roots</h3>${a.bots.map(x => `
  <div class="form-row"><label class="label">${esc(x.display_name)}</label><input class="input mono" value="${esc(x.root_path)}"><button type="button" class="btn btn-outline" data-action="save-bot" data-id="${esc(x.bot_id)}" data-name="${esc(x.display_name)}">Lưu</button></div>`).join('')}</div>`;
  } catch (e) {
    body.innerHTML = `<div class="alert alert-danger">${ic('alert')}<div><div class="alert-title">Không tải được thiết lập</div><div class="alert-desc">${esc(e.message)}</div></div></div>`;
  }
}
async function postJson(url, payload, okMsg) {
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!r.ok) throw new Error(r.status);
    if (okMsg) toast(okMsg, 'success');
    return true;
  } catch (e) {
    toast('Thao tác thất bại: ' + e.message, 'error');
    return false;
  }
}

/* ---------- toast / dialog / clipboard ---------- */
function toast(msg, kind) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.setAttribute('role', kind === 'error' ? 'alert' : 'status');
  el.innerHTML = `${ic(kind === 'error' ? 'alert' : 'check')}<div>${esc(msg)}</div>`;
  $('toasts').appendChild(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 3500);
}
function confirmDialog({ title, description, code, confirmText, wide = false }) {
  return new Promise(resolve => {
    const prev = document.activeElement;
    const ov = document.createElement('div');
    ov.className = 'overlay';
    ov.innerHTML = `<div class="dialog${wide ? ' dialog-wide' : ''}" role="alertdialog" aria-modal="true" aria-labelledby="dlgTitle">
      <div><h2 id="dlgTitle">${esc(title)}</h2><p style="margin-top:6px">${esc(description || '')}</p></div>
      ${code ? `<div class="code path">${esc(code)}</div>` : ''}
      <div class="dialog-footer"><button type="button" class="btn btn-outline" data-r="0">Hủy</button><button type="button" class="btn btn-default" data-r="1">${esc(confirmText || 'Xác nhận')}</button></div>
    </div>`;
    const done = v => { document.removeEventListener('keydown', onKey, true); ov.remove(); if (prev && prev.focus) prev.focus(); resolve(v); };
    const onKey = e => { if (e.key === 'Escape') { e.preventDefault(); done(false); } };
    ov.addEventListener('click', e => { if (e.target === ov) done(false); const b = e.target.closest('[data-r]'); if (b) done(b.dataset.r === '1'); });
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(ov);
    ov.querySelector('[data-r="1"]').focus();
  });
}
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } finally { ta.remove(); }
  }
  toast('Đã sao chép đường dẫn.', 'success');
}

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const t = e.target.closest('[data-action]');
  if (!t) return;
  switch (t.dataset.action) {
    case 'go': go(t.dataset.go); break;
    case 'settings': go('/settings'); break;
    case 'schedules': go('/schedules'); break;
    case 'reload-schedules': loadSchedules(); break;
    case 'save-schedule': saveSchedule(t); break;
    case 'copy-task-action': navigator.clipboard.writeText(t.dataset.value || ''); toast('Đã copy Action.','success'); break;
    case 'open-task-action': openTaskAction(t.dataset.taskName); break;
    case 'open-task-scheduler': openTaskScheduler(); break;
    case 'back': go(selectedBot ? '/bot/' + selectedBot : '/overview'); break;
    case 'refresh': refreshNow(); break;
    case 'tab': showTab(t.dataset.tab); break;
    case 'retry': retryBot(); break;
    case 'vrol-guid-run': runVisaGuidRequest(); break;
    case 'vrol-checks': checkVisaInputs(); break;
    case 'vrol-bucket': vrolBucket = vrolBucket === t.dataset.bucket ? 'all' : t.dataset.bucket; visaPage = 0; { const tab=currentTab; route(); showTab(tab); } setTimeout(() => $('vrolAll')?.scrollIntoView({behavior:'smooth', block:'start'}), 0); break;
    case 'vrol-pick': vrolPick(t.dataset.kind); break;
    case 'vrol-manual-check': vrolManualCheck().catch(e => toast('Không kiểm tra được: ' + e.message, 'error')); break;
    case 'vrol-manual-run': vrolManualRun(); break;
    case 'vrol-drafts-csv': vrolDraftsCsv(); break;
    case 'vrol-settings-save': saveVrolSettings(false); break;
    case 'vrol-settings-reset': saveVrolSettings(true); break;
    case 'copy-text': navigator.clipboard.writeText(t.dataset.value || ''); toast('Đã copy.', 'success'); break;
    case 'visa-filter': visaFilter = t.dataset.filter; visaPage=0; { const tab=currentTab; route(); showTab(tab); } break;
    case 'visa-page': visaPage=Number(t.dataset.page)||0; { const tab=currentTab; route(); showTab(tab); } break;
    case 'visa-search': visaSearch=$('visaSearch').value.trim(); visaPage=0; { const tab=currentTab; route(); showTab(tab); } break;
    case 'copy': copyText(t.dataset.path); break;
    case 'clear-log': $('liveLog').textContent=''; logOffset=0; break;
    case 'open-folder': postJson('/api/open-folder', { path: t.dataset.path }); break;
    case 'open-file': postJson('/api/open-file', { path: t.dataset.path }); break;
    case 'save-setting': {
      const input = t.closest('.form-row').querySelector('input');
      postJson('/api/settings', { key: t.dataset.key, value: input.value }, 'Đã lưu.');
      break;
    }
    case 'save-bot': {
      const input = t.closest('.form-row').querySelector('input');
      (async()=>{const ok=await postJson('/api/bots/' + encodeURIComponent(t.dataset.id), { display_name: t.dataset.name, root_path: input.value, enabled: true }, 'Đã lưu và đồng bộ đường dẫn bot.');if(ok){await refreshNow(true);route();}})();
      break;
    }
  }
});
window.addEventListener('hashchange', route);

buildShell();
buildFlow();
route();
async function pollVisa() {
  try {
    if (!READONLY && !visaBusy && (selectedBot === 'vrol_master' || isActive(DATA.bots.vrol_master?.latest?.status))) {
      visaBusy = true;
      const response = await fetch('/api/vrol/live', {cache:'no-store'});
      if (response.ok) {
        const live = await response.json(), current = DATA.bots.vrol_master || {}, run = live.latest;
        visaPollSeconds = live.poll_seconds || 5;
        if (run?.run_id) {
          current.latest = run;
          current.runs = [run, ...(current.runs || []).filter(r => r.run_id !== run.run_id)];
          current.operations = {...current.operations, status:run.status}; DATA.bots.vrol_master = current;
          if (selectedBot === 'vrol_master') { const tab=currentTab; route(); showTab(tab); }
          buildFlow();
        }
      }
    }
  } catch { /* A transient read during atomic artifact publication retries next interval. */ }
  finally { visaBusy = false; setTimeout(pollVisa, visaPollSeconds * 1000); }
}
if (!READONLY) setTimeout(pollVisa, visaPollSeconds * 1000);
setInterval(() => { const running = Object.entries(DATA.bots || {}).some(([id,b]) => id !== 'vrol_master' && (isActive((b.operations || {}).status) || isActive((b.latest || {}).status))); if (running) refreshNow(true); }, 5000);
})();
