@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run install.cmd first.
  exit /b 1
)
".venv\Scripts\python.exe" -m unittest discover -s tests -p "test_*.py" -v
exit /b %ERRORLEVEL%
