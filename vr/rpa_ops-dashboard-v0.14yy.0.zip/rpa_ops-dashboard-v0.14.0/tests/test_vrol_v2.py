import json
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from openpyxl import Workbook

from rpa_ops.parsers.vrol_visa import one, VIETNAM
from rpa_ops.vrol_manual_input import check, publish, ORIGIN


def workbook(path, guids):
    wb = Workbook(); ws = wb.active; ws.title = 'Sheet1'
    names = ['GUID', 'BUT TOAN', 'NGAY GD', 'INVOICENUM', 'CODE CB', 'CHECK SALE', 'VALID CHARGEBACK']
    for i, name in enumerate(names, 1):ws.cell(2, i, name)
    for row, guid in enumerate(guids, 4):
        for i, value in enumerate([guid, 'QT', '20261001', '000123', '13.1', 'SALE', 'Y'], 1):ws.cell(row, i, value)
    wb.save(path); wb.close()


class VisaContractV2(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup); self.root = Path(self.temp.name)

    def status(self, folder, **extra):
        now = datetime.now(VIETNAM).isoformat(timespec='seconds')
        data = dict(schema='vrol-dashboard/2', run_id=folder.name, status='RUNNING', stage='PROCESSING_GUIDS', updated_at=now, pid=0,
                    mode=dict(workers=9, headless=True), queue=dict(total=10, excluded={'ALREADY_CHARGEBACK_IN_ROL500': 3}, existing_cb_rol500=2),
                    progress=dict(done=4, pending=6, guids_per_min=12.5, eta_seconds=29), buckets=dict(pi=1, existing_cb=1, draft=1, review=1),
                    drafts=[dict(guid='B', rol='2707000001')], review=[dict(guid='C', group='Có associated transactions', hint='h')],
                    rows=[dict(guid='A', bucket='pi', label='PI'), dict(guid='C', bucket='review', label='Có associated transactions', rol='2707000002', folder='F')],
                    files=dict(output_workbook=str(folder / 'out.xlsx')))
        data.update(extra); folder.mkdir(parents=True, exist_ok=True)
        (folder / 'dashboard_status.json').write_text(json.dumps(data), encoding='utf-8')

    def test_v2_run_is_read_from_one_file(self):
        folder = self.root / 'runtime' / 'async_parallel' / 'R1'; self.status(folder)
        run = one(folder)
        self.assertEqual(run['contract'], 'vrol-dashboard/2')
        self.assertEqual(run['metrics']['existing_cb_count'], 3)
        self.assertEqual(run['metrics']['awaiting_final_submit_count'], 1)
        self.assertEqual([r['guid'] for r in run['guid_results'] if r['needs_user_review']], ['C'])
        self.assertNotIn('rows', run['live'])
        self.assertEqual(run['resources']['final_output']['path'], str(folder / 'out.xlsx'))

    def test_v2_stale_run_with_dead_process_is_failed(self):
        folder = self.root / 'R2'
        old = (datetime.now(VIETNAM) - timedelta(minutes=10)).isoformat(timespec='seconds')
        self.status(folder, updated_at=old, pid=99999999)
        self.assertEqual(one(folder)['status'], 'FAILED')

    def test_v2_finished_status_maps_to_dashboard_status(self):
        folder = self.root / 'R3'; self.status(folder, status='SUCCESS_WITH_REVIEWS', stage='FINISHED')
        self.assertEqual(one(folder)['status'], 'COMPLETED_WITH_REVIEWS')

    def test_manual_pair_is_checked_and_frozen_with_source_path(self):
        wb = self.root / 'mine' / '09.xlsx'; wb.parent.mkdir(); workbook(wb, ['G1', 'G2'])
        mp = self.root / 'mine' / 'input.txt'; mp.write_text('G1|4111111111111234\nG2|4111111111115678\n', encoding='utf-8')
        report = check(wb, mp)
        self.assertTrue(report['ok']); self.assertEqual(report['eligible_guids'], 2); self.assertEqual(report['missing_guids'], 0)
        manifest, contract = publish(self.root / 'visa', wb, mp)
        saved = json.loads(manifest.read_text(encoding='utf-8'))
        self.assertEqual((saved['schema'], saved['status'], saved['origin']), ('vrol-input/1', 'READY', ORIGIN))
        self.assertEqual(saved['files']['workbook']['source_path'], str(wb.resolve()))
        self.assertTrue(saved['source_fc_run_id'].startswith('MANUAL:'))
        for entry in saved['files'].values():self.assertEqual(Path(entry['path']).parent, manifest.parent)

    def test_manual_pair_with_wrong_mapping_is_blocked(self):
        wb = self.root / '09.xlsx'; workbook(wb, ['G1', 'G2', 'G3', 'G4'])
        mp = self.root / 'input.txt'; mp.write_text('OTHER|4111111111111234\n', encoding='utf-8')
        report = check(wb, mp)
        self.assertFalse(report['ok']); self.assertEqual(report['missing_guids'], 4)
        with self.assertRaises(ValueError):publish(self.root / 'visa', wb, mp)

    def test_manual_endpoints_check_freeze_and_launch_but_refuse_while_running(self):
        from unittest.mock import patch
        from rpa_ops import db
        from rpa_ops.app import create
        from rpa_ops.collector import Collector
        visa = self.root / 'visa'; visa.mkdir(); (visa / 'run_vrol_from_ops.cmd').write_text('@echo off\nexit /b 0\n')
        wb = self.root / '09.xlsx'; workbook(wb, ['G1']); mp = self.root / 'input.txt'; mp.write_text('G1|4111111111111234\n', encoding='utf-8')
        dashboard = self.root / 'dashboard'; database = dashboard / 'data' / 'rpa_ops.db'; db.init(database)
        db.set_bot(database, 'vrol_master', 'VROL Visa', str(visa), True)
        state = dict(runs=[])
        def collect(_):
            snapshot = dict(bots=dict(vrol_master=dict(root_path=str(visa), runs=state['runs'], latest=dict(status='NOT_FOUND'))), workflow_inputs=dict(vrol_master=[]))
            (dashboard / 'data' / 'current_status.json').write_text(json.dumps(snapshot), encoding='utf-8'); return snapshot
        with patch.object(Collector, 'collect', collect), patch.object(Collector, 'start', lambda _: None), patch('rpa_ops.app.subprocess.Popen') as launch:
            client = create(dashboard).test_client()
            checked = client.post('/api/vrol/manual-input/check', json=dict(workbook=str(wb), mapping=str(mp))).get_json()
            self.assertTrue(checked['ok'])
            self.assertEqual(client.post('/api/vrol/manual-input/run', json=dict(workbook=str(wb), mapping=str(self.root / 'none.txt'))).status_code, 400)
            response = client.post('/api/vrol/manual-input/run', json=dict(workbook=str(wb), mapping=str(mp)))
            self.assertEqual(response.status_code, 200)
            manifest = Path(response.get_json()['manifest'])
            self.assertTrue(manifest.is_file() and manifest.parent.parent == visa / 'runtime' / 'ops_inputs')
            self.assertEqual(launch.call_args.kwargs['env']['RPA_OPS_SELECTED_INPUT'], str(manifest))
            self.assertNotIn('RPA_OPS_GUID_REQUEST', launch.call_args.kwargs['env'])
            self.assertEqual(launch.call_args.kwargs['env']['RPA_OPS_RUN_MODE'], 'FULL')
            response = client.post('/api/vrol/manual-input/run', json=dict(workbook=str(wb), mapping=str(mp), mode='PI_ONLY'))
            self.assertEqual(response.status_code, 200)
            self.assertEqual(launch.call_args.kwargs['env']['RPA_OPS_RUN_MODE'], 'PI_ONLY')
            self.assertEqual(client.post('/api/vrol/manual-input/run', json=dict(workbook=str(wb), mapping=str(mp), mode='SUBMIT_ALL')).status_code, 400)
            state['runs'] = [dict(run_id='R', status='RUNNING')]
            before = launch.call_count
            self.assertEqual(client.post('/api/vrol/manual-input/run', json=dict(workbook=str(wb), mapping=str(mp))).status_code, 400)
            self.assertEqual(launch.call_count, before)
            self.assertEqual(client.post('/api/vrol/manual-input/pick', json=dict(kind='other')).status_code, 400)

    def test_run_settings_default_to_config_and_are_remembered_for_next_runs(self):
        from unittest.mock import patch
        from rpa_ops import db
        from rpa_ops.app import create
        from rpa_ops.collector import Collector
        visa = self.root / 'visa'; visa.mkdir()
        wb = Workbook(); ws = wb.active; ws.title = 'Settings'; ws.append(['key', 'value'])
        for row in [('username', 'secret-user'), ('password', 'secret-pass'), ('allow_final_submit', 'NO'), ('async_worker_count', 5), ('async_worker_max', 5), ('headless', False)]:ws.append(row)
        wb.save(visa / 'config.xlsx'); wb.close()
        dashboard = self.root / 'dashboard'; database = dashboard / 'data' / 'rpa_ops.db'; db.init(database)
        db.set_bot(database, 'vrol_master', 'VROL Visa', str(visa), True)
        def collect(_):
            snapshot = dict(bots=dict(vrol_master=dict(root_path=str(visa), runs=[dict(run_id='R', status='RUNNING')], latest=dict(status='RUNNING'))), workflow_inputs={})
            (dashboard / 'data' / 'current_status.json').write_text(json.dumps(snapshot), encoding='utf-8'); return snapshot
        with patch.object(Collector, 'collect', collect), patch.object(Collector, 'start', lambda _: None):
            client = create(dashboard).test_client()
            first = client.get('/api/vrol/run-settings')
            self.assertEqual(first.status_code, 200); x = first.get_json()
            self.assertEqual(x['effective'], dict(final_submit='NO', workers=5, headless=False))
            self.assertNotIn('secret', first.get_data(as_text=True))
            # Saving is allowed while a run is active: it only applies to the next run.
            saved = client.post('/api/vrol/run-settings', json=dict(final_submit='YES', workers='9', headless='HEADLESS')).get_json()
            self.assertEqual(saved['effective'], dict(final_submit='YES', workers=9, headless=True))
            stored = json.loads((visa / 'runtime' / 'run_overrides.json').read_text(encoding='utf-8'))
            self.assertEqual((stored['schema'], stored['final_submit'], stored['workers'], stored['headless']), ('vrol-run-overrides/1', 'YES', 9, True))
            reset = client.post('/api/vrol/run-settings', json=dict(final_submit='CONFIG', workers='CONFIG', headless='CONFIG')).get_json()
            self.assertEqual(reset['effective'], dict(final_submit='NO', workers=5, headless=False))
            self.assertIsNone(json.loads((visa / 'runtime' / 'run_overrides.json').read_text(encoding='utf-8'))['final_submit'])
            for bad in [dict(final_submit='MAYBE'), dict(workers='12'), dict(headless='SOMETIMES')]:
                self.assertEqual(client.post('/api/vrol/run-settings', json=bad).status_code, 400)

    def test_shared_review_pack_for_v2_run_shows_settings_outcomes_reviews_and_drafts(self):
        from rpa_ops.vrol_export import publish
        folder = self.root / 'runtime' / 'async_parallel' / 'R9'
        self.status(folder, status='SUCCESS_WITH_REVIEWS', stage='FINISHED', completed_at='2026-11-21T20:30:00+07:00',
                    mode=dict(workers=9, headless=True, scheduled=True, final_submit_enabled=False, sources=dict(final_submit='dashboard', workers='dashboard', headless='config')))
        (folder / 'existing_chargebacks.csv').write_text('guid,source\nX,ROL500_PREFLIGHT\n', encoding='utf-8')
        shot = folder / 'groups' / 'REVIEW_REQUIRED_C' / 'a.png'; shot.parent.mkdir(parents=True); shot.write_bytes(b'png')
        live = json.loads((folder / 'dashboard_status.json').read_text(encoding='utf-8'))
        live['rows'][1].update(folder=str(shot.parent), screenshot=str(shot)); (folder / 'dashboard_status.json').write_text(json.dumps(live), encoding='utf-8')
        run = one(folder); out = self.root / 'reports'
        publish(dict(runs=[run]), out)
        page = (out / 'vrol' / 'R9' / 'index.html').read_text(encoding='utf-8')
        for text in ['Hoàn tất – còn GUID cần review', 'Theo lịch (run_scheduled.cmd)', 'Tắt – dừng trước Final Submit (dashboard)', '9 (dashboard)', 'Headless (config.xlsx)',
                     'Có associated transactions', 'Case nháp chờ Final Submit (1)', '2707000001', 'Chargeback đã có (CSV)']:
            self.assertIn(text, page)
        self.assertTrue((out / 'vrol' / 'R9' / 'groups' / 'REVIEW_REQUIRED_C' / 'a.png').is_file())
        self.assertIn('2707000001', (out / 'vrol' / 'R9' / 'drafts.csv').read_text(encoding='utf-8-sig'))
        self.assertIn('label', (out / 'vrol' / 'R9' / 'guid_results.csv').read_text(encoding='utf-8-sig').splitlines()[0])

    def test_manual_pair_missing_files(self):
        report = check(self.root / 'nope.xlsx', self.root / 'nope.txt')
        self.assertFalse(report['ok']); self.assertEqual(len(report['errors']), 2)


if __name__ == '__main__':
    unittest.main()
