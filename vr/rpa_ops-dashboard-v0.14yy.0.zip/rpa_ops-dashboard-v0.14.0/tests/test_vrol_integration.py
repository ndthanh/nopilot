import json
import os
import sys
import tempfile
import unittest
from datetime import datetime,timedelta
from pathlib import Path
from unittest.mock import patch
from openpyxl import Workbook
from rpa_ops.vrol_handoff import publish_pair,VIETNAM
from rpa_ops.parsers.vrol_visa import one
from rpa_ops.operations import enrich
from rpa_ops import db


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value),encoding='utf-8')


class VisaIntegration(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.now=datetime.now(VIETNAM);self.fc_id=self.now.strftime('%Y%m%d')+'_FC'
        self.workbook=self.root/'fc'/'09_chargeback_classified.xlsx';self.workbook.parent.mkdir()
        wb=Workbook();ws=wb.active;ws.title='Sheet1'
        names=['GUID','BUT TOAN','NGAY GD','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK']
        for i,name in enumerate(names,1):ws.cell(2,i,name)
        for i,value in enumerate(['G','QT',(self.now-timedelta(days=20)).strftime('%Y%m%d'),'000123','13.1','SALE','Y'],1):ws.cell(4,i,value)
        wb.save(self.workbook);wb.close()
        self.mapping=self.root/'gp'/'input.txt';self.mapping.parent.mkdir();self.mapping.write_text('G|4111111111111234\n')
        self.fc=dict(run_id=self.fc_id,status='SUCCESS',started_at=(self.now-timedelta(minutes=10)).isoformat(),completed_at=self.now.isoformat(),
                     resources=dict(final_output=dict(path=str(self.workbook)),guid2pan_input=dict(path=str(self.mapping))),metrics={})
        self.gp=dict(run_id=self.now.strftime('%Y%m%d')+'_GP',status='SUCCESS',started_at=(self.now-timedelta(minutes=8)).isoformat(),completed_at=self.now.isoformat(),
                     resources=dict(input_txt=dict(path=str(self.mapping)),final_output=dict(path=str(self.mapping))),metrics=dict(source_fc_run_id=self.fc_id))
        self.bots=dict(fraud_classification=dict(runs=[self.fc]),guid2pan=dict(runs=[self.gp]))
        self.vrol=self.root/'visa'

    def publish(self):return publish_pair(self.bots,self.vrol,today=self.now.date())

    def test_pair_is_frozen_and_independent_of_mutable_working_input(self):
        result=self.publish();self.assertEqual(result['status'],'READY')
        manifest=Path(result['inputs'][0]['path']);contract=json.loads(manifest.read_text())
        self.assertEqual(contract['source_fc_run_id'],self.fc_id)
        self.mapping.write_text('G|4111111111119999\n')
        self.assertEqual(self.publish()['status'],'READY')
        self.assertIn('1234',Path(contract['files']['mapping']['path']).read_text())

    def test_new_fc_never_pairs_with_old_guid2pan(self):
        self.fc['run_id']='NEW_FC'
        self.assertEqual(self.publish()['status'],'WAITING_INPUT')

    def test_contract_has_source_completion_times_for_evening_scheduler(self):
        result=self.publish();contract=json.loads(Path(result['inputs'][0]['path']).read_text())
        self.assertEqual(contract['source_fc_completed_at'],self.fc['completed_at'])
        self.assertEqual(contract['source_guid2pan_completed_at'],self.gp['completed_at'])

    def test_guid_only_file_is_rejected(self):
        self.mapping.write_text('G\n');result=self.publish()
        self.assertEqual(result['status'],'WAITING_INPUT');self.assertIn('NOT_MAPPING',result['reason'])

    def test_conflicting_pan_is_rejected(self):
        self.mapping.write_text('G|4111111111111234\nG|4111111111119999\n')
        self.assertIn('CONFLICTING',self.publish()['reason'])

    def test_missing_guid_is_rejected(self):
        self.mapping.write_text('OTHER|4111111111111234\n')
        self.assertIn('COVERAGE_INCOMPLETE',self.publish()['reason'])

    def test_changed_output_after_conversion_is_rejected(self):
        future=(self.now+timedelta(minutes=5)).timestamp();os.utime(self.mapping,(future,future))
        self.assertIn('CHANGED_AFTER_RUN',self.publish()['reason'])

    def test_coupled_fc_guid2pan_window_without_native_lineage(self):
        self.gp['metrics']={}
        self.assertEqual(self.publish()['status'],'READY')
        self.fc['run_id']='NEW';self.fc['started_at']=(self.now-timedelta(minutes=1)).isoformat()
        self.assertEqual(self.publish()['status'],'WAITING_INPUT')

    def test_ambiguous_conversions_require_lineage(self):
        self.gp['metrics']={};other=dict(self.gp,run_id='GP_OTHER')
        self.bots['guid2pan']['runs'].append(other)
        self.assertIn('PAIR_AMBIGUOUS',self.publish()['reason'])

    def test_wait_for_latest_fc_still_running(self):
        self.bots['fraud_classification']['runs'].append(dict(self.fc,run_id='NEW',status='RUNNING',started_at=self.now.isoformat()))
        self.assertEqual(self.publish()['status'],'WAITING_INPUT')

    def test_frozen_snapshot_tampering_is_rejected(self):
        result=self.publish();manifest=Path(result['inputs'][0]['path']);data=json.loads(manifest.read_text())
        Path(data['files']['mapping']['path']).write_text('changed')
        self.assertIn('FROZEN_INPUT_CHANGED',self.publish()['reason'])

    def test_native_bot_consumes_the_published_contract(self):
        project=Path(__file__).resolve().parents[2]/'vr9.1.13.16'
        if not project.is_dir():self.skipTest('Cross-project consumer check requires Visa source beside Dashboard; standalone Dashboard tests remain available')
        sys.path.insert(0,str(project));self.addCleanup(lambda:sys.path.remove(str(project)))
        from async_runtime.input_contract import validate_contract
        ready=self.publish();path=ready['inputs'][0]['path']
        contract,files=validate_contract(path)
        self.assertEqual(contract['source_fc_run_id'],self.fc_id)
        self.assertEqual(files['mapping'].read_text(),'G|4111111111111234\n')
        files['mapping'].write_text('G|4111111111119999\n')
        with self.assertRaisesRegex(ValueError,'SNAPSHOT_CHANGED'):validate_contract(path)

    def test_shared_report_only_publishes_pi_and_review_artifacts(self):
        from rpa_ops.vrol_export import publish
        run=self.root/'run';pdf=run/'documents'/'invoice_1234_shop.pdf';pdf.parent.mkdir(parents=True);pdf.write_bytes(b'%PDF-test')
        folder=run/'groups'/'REVIEW_REQUIRED_G';folder.mkdir(parents=True);shot=folder/'evidence.png';shot.write_bytes(b'image')
        (run/'input.txt').write_text('G|4111111111111234')
        bot=dict(runs=[dict(status='COMPLETED_WITH_ISSUES',resources=dict(run_directory=dict(path=str(run))),guid_results=[dict(guid='G',status='REVIEW_REQUIRED',needs_user_review=True,folder=str(folder),screenshots=[str(shot)])])])
        out=self.root/'shared';publish(bot,out)
        pack=out/'vrol'/'run'
        self.assertTrue((pack/'documents'/pdf.name).exists());self.assertTrue((pack/'groups'/folder.name/shot.name).exists())
        self.assertFalse((pack/'input.txt').exists())
        self.assertIn('groups/REVIEW_REQUIRED_G/evidence.png',(pack/'index.html').read_text(encoding='utf-8'))

    def test_database_keeps_configured_guid2pan_root(self):
        path=self.root/'data'/'rpa_ops.db';db.init(path)
        db.set_bot(path,'guid2pan','GUID2PAN',str(self.root/'configured_gp'),True)
        settings=db.load(path)
        gp=next(x for x in settings['bots'] if x['bot_id']=='guid2pan')
        self.assertEqual(gp['root_path'],str(self.root/'configured_gp'))
        self.assertTrue(any(x['bot_id']=='vrol_master' and x['parser']=='vrol_visa' for x in settings['bots']))

    def test_shared_consolidated_pack_uses_declared_run_lineage(self):
        from rpa_ops.vrol_export import publish
        base=self.root/'runtime'/'async_parallel';old=base/'old';new=base/'new'
        shot=old/'groups'/'REVIEW_REQUIRED_G'/'evidence.png';shot.parent.mkdir(parents=True);shot.write_bytes(b'image')
        outside=self.root/'outside.png';outside.write_bytes(b'private')
        pdf=new/'consolidated'/'documents'/'invoice_1234_shop.pdf';pdf.parent.mkdir(parents=True);pdf.write_bytes(b'%PDF-test')
        write(new/'consolidated'/'summary.json',dict(original_queue='old',resume_runs=['new'],historical_runs=[]))
        bot=dict(runs=[dict(status='COMPLETED_WITH_ISSUES',resources=dict(run_directory=dict(path=str(new)),pi_documents=dict(path=str(pdf.parent))),guid_results=[dict(guid='G',folder=str(shot.parent),screenshots=[str(shot),str(outside)])])])
        publish(bot,self.root/'shared');target=self.root/'shared'/'vrol'/'new'
        self.assertTrue((target/'documents'/pdf.name).exists())
        self.assertTrue((target/'groups'/'REVIEW_REQUIRED_G'/shot.name).exists())
        self.assertFalse((target/'groups'/'REVIEW_REQUIRED_G'/outside.name).exists())

    def test_live_parser_separates_queued_running_and_completed_and_keeps_review(self):
        run=self.root/'visa'/'runtime'/'async_parallel'/'run'
        write(run/'run_state.json',dict(status='RUNNING',pid=os.getpid(),started_at=self.now.isoformat(),heartbeat_at=self.now.isoformat(),group_count=3))
        write(run/'queue_manifest.json',[dict(guid=x) for x in ['A','B','C']])
        write(run/'groups'/'CONSUMER_A'/'guid_result.json',dict(guid='A',status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',result=dict(status='QUESTIONNAIRE_FILLED_AWAITING_FINAL_SUBMIT',rol='123456789'),outcome=dict(category='CONSUMER',needs_user_review=True,action_stage='AWAITING_FINAL_SUBMIT')))
        write(run/'groups'/'B'/'guid_state.json',dict(guid='B',status='RUNNING'))
        write(run/'groups'/'B'/'case_checkpoint.json',dict(stage='CASE_CREATION_SUBMIT_DISPATCHED',rol='987654321'))
        parsed=one(run);self.assertEqual(parsed['metrics']['completed_groups'],1)
        self.assertEqual(parsed['metrics']['consumer_count'],1)
        by={r['guid']:r for r in parsed['guid_results']}
        self.assertEqual(by['B']['action_stage'],'CASE_CREATION_SUBMIT_DISPATCHED');self.assertEqual(by['C']['status'],'QUEUED')
        self.assertTrue(by['A']['needs_user_review']);self.assertEqual(parsed['status'],'RUNNING')
        write(run/'async_summary.json',dict(status='COMPLETED',group_count=3))
        self.assertEqual(one(run)['status'],'COMPLETED_WITH_REVIEWS')

    def test_orphan_process_is_not_left_running(self):
        run=self.root/'run';write(run/'run_state.json',dict(status='RUNNING',pid=0,heartbeat_at=self.now.isoformat()))
        self.assertEqual(one(run)['status'],'FAILED')

    def test_consolidated_run_keeps_cumulative_guid_counts_and_paths(self):
        run=self.root/'combined'
        write(run/'run_state.json',dict(status='SUCCESS'))
        write(run/'async_summary.json',dict(status='COMPLETED',group_count=1))
        write(run/'consolidated'/'summary.json',dict(queued=2,completed=2,pi_pdfs=1,category_counts={'PI_DOWNLOADED':1,'REVIEW_REQUIRED':1}))
        write(run/'consolidated'/'guid_results.json',[
            dict(guid='A',status='PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION',folder='A',result={'status':'PI_EVIDENCE_DOWNLOADED_NO_ISSUER_ACTION'},outcome={'category':'PI_DOWNLOADED'}),
            dict(guid='B',status='CASE_RECONCILIATION_REQUIRED',folder='B',result={'status':'CASE_RECONCILIATION_REQUIRED'},outcome={'category':'REVIEW_REQUIRED','needs_user_review':True})])
        parsed=one(run)
        self.assertEqual(parsed['metrics']['group_count'],2)
        self.assertEqual(parsed['metrics']['completed_groups'],2)
        self.assertEqual(parsed['metrics']['review_required_count'],1)
        self.assertEqual(parsed['metrics']['pi_pdf_count'],1)
        self.assertIn('consolidated',parsed['resources']['pi_documents']['path'])

    def test_enrich_preserves_real_visa_bot(self):
        bot=dict(root_path=str(self.vrol),display_name='VROL Visa',runs=[],latest=dict(status='NOT_FOUND'),input_handoff=dict(status='READY',message='Ready'))
        payload=enrich(dict(bots=dict(vrol_master=bot)))
        self.assertEqual(payload['bots']['vrol_master']['root_path'],str(self.vrol))
        self.assertEqual(payload['bots']['vrol_master']['operations']['status'],'READY')

    def test_cmd_launch_and_live_endpoint_do_not_run_browser_in_tests(self):
        from rpa_ops.app import create
        from rpa_ops.collector import Collector
        result=self.publish();manifest=result['inputs'][0]['path']
        dashboard=self.root/'dashboard';database=dashboard/'data'/'rpa_ops.db';db.init(database)
        db.set_bot(database,'vrol_master','VROL Visa',str(self.vrol),True)
        command=self.vrol/'run_vrol_from_ops.cmd';command.write_text('@echo off\nexit /b 0\n')
        snapshot=dict(bots=dict(vrol_master=dict(root_path=str(self.vrol),runs=[],latest=dict(status='NOT_FOUND'))),workflow_inputs=dict(vrol_master=result['inputs']))
        def collect(_):write(dashboard/'data'/'current_status.json',snapshot);return snapshot
        with patch.object(Collector,'collect',collect),patch.object(Collector,'start',lambda _:None),patch('rpa_ops.app.subprocess.Popen') as launch:
            app=create(dashboard);client=app.test_client()
            response=client.post('/api/retry/vrol_master',json=dict(input_path=manifest))
            self.assertEqual(response.status_code,200)
            args=launch.call_args;self.assertEqual(args.args[0][:3],['cmd.exe','/d','/c'])
            self.assertEqual(args.kwargs['env']['RPA_OPS_SELECTED_INPUT'],manifest)
            self.assertEqual(client.get('/api/vrol/live').status_code,200)
            self.assertEqual(client.post('/api/retry/vrol_master',json=dict(input_path=str(self.mapping))).status_code,403)
            preview=client.post('/api/vrol/guid-request/preview',json=dict(input_path=manifest,guids='G\nMISSING')).get_json()
            self.assertEqual(preview['requested_count'],2)
            self.assertEqual(preview['rows'][0]['codes'],['13.1'])
            self.assertFalse(preview['rows'][1]['found'])
            self.assertEqual(client.post('/api/vrol/guid-request',json=dict(input_path=manifest,guids='G',code='13.9')).status_code,400)
            response=client.post('/api/vrol/guid-request',json=dict(input_path=manifest,guids='G'))
            self.assertEqual(response.status_code,200)
            request_file=Path(response.get_json()['request_file']);saved=json.loads(request_file.read_text())
            self.assertEqual(saved['guids'],['G']);self.assertNotIn('code',saved)
            self.assertEqual(launch.call_args.kwargs['env']['RPA_OPS_GUID_REQUEST'],str(request_file))
            self.assertNotIn('4111111111111234',request_file.read_text())
            before=launch.call_count
            check=client.post('/api/vrol/checks',json=dict(input_path=manifest))
            self.assertEqual(check.status_code,200);self.assertEqual(launch.call_count,before)
            raw=check.get_data(as_text=True);self.assertNotIn('4111111111111234',raw)
            self.assertEqual(client.post('/api/vrol/checks',json=dict(input_path=str(self.mapping))).status_code,403)


if __name__=='__main__':unittest.main()
