import json,tempfile,unittest
from datetime import datetime,timedelta
from pathlib import Path
from openpyxl import Workbook
from rpa_ops.vrol_checks import check
from rpa_ops.vrol_handoff import digest,VIETNAM

class VisaChecks(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.guid='SENSITIVE_GUID_MARKER';self.pan='4111111111111234';self.secret='PASSWORD_MUST_NEVER_APPEAR'
        (self.root/'run_vrol_from_ops.cmd').write_text('@echo off');env=self.root/'.venv'/'Scripts';env.mkdir(parents=True);(env/'python.exe').write_bytes(b'')
        otp=self.root/'otp';otp.mkdir()
        wb=Workbook();ws=wb.active;ws.title='Settings';ws.append(['key','value'])
        for key,value in dict(login_url='https://example.invalid',username='USER_MUST_NEVER_APPEAR',password=self.secret,welcome_name='NAME_MUST_NEVER_APPEAR',
            otp_polling_mode='FOLDER_FILENAME',otp_folder_path=str(otp),async_worker_count=5,async_worker_max=5,allow_final_submit='YES',trace_enabled='NO').items():ws.append([key,value])
        legacy=wb.create_sheet('RunSettings');legacy.append(['key','value']);legacy.append(['allow_final_submit','NO'])
        wb.save(self.root/'config.xlsx');wb.close()
        self.source=self.root/'09_chargeback_classified.xlsx';wb=Workbook();ws=wb.active;ws.title='Sheet1'
        for i,name in enumerate(['GUID','BUT TOAN','NGAY GD','INVOICENUM','CODE CB','CHECK SALE','VALID CHARGEBACK'],1):ws.cell(2,i,name)
        values=[self.guid,'QT',(datetime.now(VIETNAM)-timedelta(days=25)).strftime('%Y%m%d'),'123','13.1','SALE','Y']
        for i,value in enumerate(values,1):ws.cell(4,i,value)
        wb.save(self.source);wb.close();self.mapping=self.root/'input.txt';self.mapping.write_text(self.guid+'|'+self.pan+'\n')

    def test_checks_are_redacted_and_use_authoritative_final_switch(self):
        result=check(self.root);raw=json.dumps(result)
        for value in (self.guid,self.pan,self.secret,'USER_MUST_NEVER_APPEAR','NAME_MUST_NEVER_APPEAR'):self.assertNotIn(value,raw)
        by={x['name']:x for x in result['checks']}
        self.assertEqual(by['Normal input coverage']['missing_count'],0)
        self.assertEqual(by['OTP folder']['status'],'PASS')
        self.assertEqual(by['Final Submit']['status'],'WARN');self.assertIn('BẬT',by['Final Submit']['message'])

    def set_workers(self,count,cap):
        from openpyxl import load_workbook
        wb=load_workbook(self.root/'config.xlsx');ws=wb['Settings']
        for row in ws.iter_rows(min_row=2):
            if row[0].value=='async_worker_count':row[1].value=count
            if row[0].value=='async_worker_max':row[1].value=cap
        wb.save(self.root/'config.xlsx');wb.close()

    def test_workers_match_bot_resolution_up_to_nine_and_dashboard_overrides(self):
        self.set_workers(9,9)  # 2026-11-21: was FAIL because the check still assumed cap <= 5
        by={x['name']:x for x in check(self.root)['checks']}
        self.assertEqual((by['Workers']['status'],by['Workers']['effective']),('PASS',9))
        self.set_workers(9,5)  # the bot caps to 5 itself: warning, not failure
        by={x['name']:x for x in check(self.root)['checks']}
        self.assertEqual((by['Workers']['status'],by['Workers']['effective']),('WARN',5))
        (self.root/'runtime').mkdir();(self.root/'runtime'/'run_overrides.json').write_text(json.dumps(dict(final_submit='NO',workers=7)))
        by={x['name']:x for x in check(self.root)['checks']}
        self.assertEqual((by['Workers']['status'],by['Workers']['effective']),('PASS',7));self.assertIn('dashboard',by['Workers']['message'])
        self.assertEqual(by['Final Submit']['status'],'PASS');self.assertIn('TẮT',by['Final Submit']['message']);self.assertIn('dashboard',by['Final Submit']['message'])

    def test_mapping_conflict_does_not_leak_guid_or_pan(self):
        self.mapping.write_text(self.guid+'|'+self.pan+'\n'+self.guid+'|4111111111119999\n')
        result=check(self.root);self.assertEqual(result['status'],'FAIL')
        self.assertNotIn(self.guid,json.dumps(result));self.assertNotIn(self.pan,json.dumps(result))

    def test_invalid_contract_never_reports_fallback_pair_as_ready(self):
        manifest=self.root/'manifest.json';manifest.write_text(json.dumps(dict(schema='vrol-input/1',status='READY',business_date='2000-01-01')))
        result=check(self.root,manifest);self.assertEqual(result['input_mode'],'INVALID_CONTRACT');self.assertEqual(result['status'],'FAIL')

    def test_changed_snapshot_and_invalid_config_are_reported(self):
        manifest=self.root/'manifest.json';manifest.write_text(json.dumps(dict(schema='vrol-input/1',status='READY',business_date=datetime.now(VIETNAM).date().isoformat(),
            source_fc_run_id='FC',source_guid2pan_run_id='GP',files={k:dict(path=str(p),size=p.stat().st_size,sha256=digest(p)) for k,p in [('workbook',self.source),('mapping',self.mapping)]})))
        self.mapping.write_text('CHANGED');self.assertEqual(check(self.root,manifest)['input_mode'],'INVALID_CONTRACT')
        (self.root/'config.xlsx').write_bytes(b'broken');self.assertEqual(check(self.root)['status'],'FAIL')

if __name__=='__main__':unittest.main()
