@echo off
cd /d "%~dp0"
schtasks /Create /F /TN "\RPA Tra Soat\RPA Ops Dashboard" /SC ONLOGON /TR "cmd.exe /d /c call \"%CD%\run_server.cmd\"" /RL LIMITED /IT
pause
