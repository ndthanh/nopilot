# Chạy riêng theo danh sách GUID

Tại màn hình VROL trên Dashboard, chọn contract FC + GUID2PAN READY hôm nay, nhập
danh sách GUID (mỗi dòng một GUID; cũng nhận dấu phẩy/chấm phẩy/khoảng trắng), bấm
Xem trước và chạy danh sách GUID. Preview cho biết GUID tìm thấy, số dòng, CODE CB
từ file 09, giá trị VALID CHARGEBACK và có mapping hay chưa. Sau xác nhận, một
process/run riêng được tạo, dùng workers và Final Submit theo config Visa.

User chỉ nhập GUID. API và runtime không nhận override code; bot tự lấy code,
invoice/QT/ngày/merchant từ 09_chargeback_classified.xlsx và PAN từ input.txt trong
cùng snapshot contract. Không sửa workbook input gốc. Input.txt upstream có thể ở
đường dẫn cố định; mỗi contract đã được snapshot để tránh ghi đè giữa run.

## Ngoại lệ và các rule còn giữ

Chỉ chế độ này được bỏ điều kiện **VALID CHARGEBACK=Y** của upstream, ví dụ ngưỡng
hơn 35 giao dịch khiến upstream đánh N. Luồng scheduled/normal vẫn yêu cầu Y.
Không có giới hạn 35 mới ở VROL. Đây không phải PI-only: PI=Yes ưu tiên tải chứng
từ; không có PI và đủ điều kiện thì đi case/questionnaire đúng code trong Excel.

Các điều kiện vẫn giữ: CHECK SALE=SALE, 15<tuổi<120 ngày, đủ invoice/QT và code
10.4/13.1/13.9, mapping hợp lệ/không xung đột, Visa, preflight ROL500, registry,
review hold và rule runtime Assoc D/refund/ECI theo code. Mixed code không tự chọn
một code. GUID không có trong file 09 hoặc còn bị chặn sẽ có lý do ở báo cáo.
Chế độ này không mở/gửi lại case đã tạo trước đó và không tự bật Final Submit.

## Request và báo cáo riêng

Dashboard ghi runtime/guid_requests/<request_id>.json dưới root Visa, chỉ có schema
vrol-guid-request/1, request ID/time, path/hash manifest và GUID list. Request không
chứa code override hoặc PAN. Bot kiểm tra hash và schema, copy request vào run mới,
ghi request_mode=USER_SELECTED_GUIDS trong run_state. Không chạy cùng process VROL
khác: API chặn active run, process lock là bảo vệ cuối.

Trong runtime/async_parallel/<run_id>:

| File | Nội dung |
|---|---|
| guid_request.json | Yêu cầu GUID gắn contract/hash |
| requested_guid_source.json | Code/row/upstream flags tra từ workbook |
| requested_guid_report.csv / .json | Mỗi GUID: status, reason, code từ Excel, upstream filter override, PI count, ROL, Final flag, folder |
| input_exclusions.json | Lý do loại từng dòng/GUID |
| documents và groups/<OUTCOME>_<GUID> | PI tổng hợp và bằng chứng từng GUID |

Báo cáo được tạo ở finally, kể cả run lỗi sau khi đọc request. Phân biệt SKIPPED,
NOT_STARTED, NOT_PROCESSED và kết quả thực; partial row exclusions vẫn được giữ.
Output Dashboard có link requested_guid_report. Run vẫn có Excel kết quả riêng và
ROL500 postflight/reconciliation như luồng thường. Giữ registry/holds để bảo vệ
những case do run riêng đã tạo khi chạy scheduled về sau.

CLI chẩn đoán tương đương (file request do Dashboard sinh):

```bat
.venv\Scripts\python.exe run_async_parallel_case_review.py --config config.xlsx --backend native_async --headful --input-contract "D:\...\manifest.json" --guid-request "D:\...\request.json"
```

Không kết hợp request với --guid/--no-resume/--resume-run/--review-existing/
--recheck-read-only hoặc --scheduled. Không đổi hash/code bằng tay để ép replay.
