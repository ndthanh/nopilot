@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Run setup.cmd first.&pause&exit /b 1)
echo RPA Tra Soat: http://127.0.0.1:8765/#/overview
".venv\Scripts\python.exe" app.py
